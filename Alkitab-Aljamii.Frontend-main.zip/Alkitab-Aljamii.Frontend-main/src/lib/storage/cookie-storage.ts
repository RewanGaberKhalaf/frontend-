import Cookies from 'js-cookie';

// Non-root paths where cookies might have been incorrectly set
const KNOWN_STALE_PATHS = ['/login', '/admin', '/professor', '/student', '/dashboard'];

// Security: Use secure cookies in production (HTTPS only)
const isProduction = typeof window !== 'undefined' && window.location.protocol === 'https:';
const COOKIE_OPTIONS: Cookies.CookieAttributes = {
  expires: 1, // Reduced from 7 days to 1 day for security
  sameSite: 'Lax',
  path: '/',
  secure: isProduction, // Only send over HTTPS in production
};

export const authTokens = {
  getAccessToken: () => Cookies.get('access_token') ?? null,
  getRefreshToken: () => Cookies.get('refresh_token') ?? null,

  setTokens: (accessToken: string, refreshToken: string) => {
    // First clean up any stale cookies at wrong paths
    authTokens.cleanupStaleCookies();
    // Then set cookies at root path with security flags
    Cookies.set('access_token', accessToken, COOKIE_OPTIONS);
    Cookies.set('refresh_token', refreshToken, COOKIE_OPTIONS);
  },

  clearTokens: () => {
    // Remove from root path
    Cookies.remove('access_token', { path: '/' });
    Cookies.remove('refresh_token', { path: '/' });
    // Also clean up any stale cookies at wrong paths
    authTokens.cleanupStaleCookies();
  },

  clearAccessToken: () => {
    // Remove only access token - keeps refresh token for re-auth with new context
    Cookies.remove('access_token', { path: '/' });
    // Also clean up any stale access_token cookies at wrong paths
    const pathsToClean = new Set(KNOWN_STALE_PATHS);
    if (typeof window !== 'undefined') {
      const currentPath = window.location.pathname;
      const segments = currentPath.split('/').filter(Boolean);
      let path = '';
      for (const segment of segments) {
        path += '/' + segment;
        pathsToClean.add(path);
      }
    }
    for (const path of pathsToClean) {
      Cookies.remove('access_token', { path });
    }
  },

  cleanupStaleCookies: () => {
    // Get current path and all its parent segments
    const pathsToClean = new Set(KNOWN_STALE_PATHS);

    if (typeof window !== 'undefined') {
      const currentPath = window.location.pathname;
      // Add current path and all parent paths (except root)
      const segments = currentPath.split('/').filter(Boolean);
      let path = '';
      for (const segment of segments) {
        path += '/' + segment;
        pathsToClean.add(path);
      }
    }

    // Remove cookies from all non-root paths
    for (const path of pathsToClean) {
      Cookies.remove('access_token', { path });
      Cookies.remove('refresh_token', { path });
    }
  },
};
