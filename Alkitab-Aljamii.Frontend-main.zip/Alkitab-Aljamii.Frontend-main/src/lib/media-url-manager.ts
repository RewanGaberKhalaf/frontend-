/**
 * Media URL Manager
 *
 * Centralized manager for refreshing signed media URLs with:
 * - Deduplication: Same mediaId only refreshes once at a time
 * - Rate limiting: Max N requests per time window
 * - Exponential backoff: Retry with increasing delays on failure
 * - Caching: Recently fetched URLs are cached to avoid redundant calls
 */

import { mediaApi, resolveMediaUrl } from '@/lib/api';

interface PendingRefresh {
  promise: Promise<string | null>;
  timestamp: number;
}

interface CachedUrl {
  url: string;
  expiresAt: number;
}

interface RefreshAttempt {
  count: number;
  lastAttempt: number;
  backoffUntil: number;
}

class MediaUrlManager {
  // Pending refresh promises by mediaId - prevents duplicate concurrent calls
  private pendingRefreshes: Map<string, PendingRefresh> = new Map();

  // Cached URLs with expiration
  private urlCache: Map<string, CachedUrl> = new Map();

  // Track refresh attempts per mediaId for backoff
  private refreshAttempts: Map<string, RefreshAttempt> = new Map();

  // Global rate limiting
  private requestTimestamps: number[] = [];

  // Configuration
  private readonly CACHE_TTL_MS = 4 * 60 * 1000; // 4 minutes (URLs expire in 5 min)
  private readonly MAX_REQUESTS_PER_WINDOW = 10;
  private readonly RATE_WINDOW_MS = 10000; // 10 seconds
  private readonly MAX_BACKOFF_MS = 60000; // 1 minute max backoff
  private readonly BASE_BACKOFF_MS = 2000; // 2 seconds initial backoff
  private readonly MAX_ATTEMPTS = 3;

  /**
   * Refresh a signed URL for a media item
   * Returns the new URL or null if refresh failed
   */
  async refreshUrl(mediaId: string): Promise<string | null> {
    if (!mediaId) return null;

    // Check cache first
    const cached = this.urlCache.get(mediaId);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.url;
    }

    // Check if in backoff period
    const attempts = this.refreshAttempts.get(mediaId);
    if (attempts && attempts.backoffUntil > Date.now()) {
      console.log(`[MediaUrlManager] ${mediaId} in backoff until ${new Date(attempts.backoffUntil).toISOString()}`);
      return null;
    }

    // Check if max attempts exceeded recently
    if (attempts && attempts.count >= this.MAX_ATTEMPTS) {
      // Reset attempts after backoff period
      const resetAfter = attempts.lastAttempt + this.MAX_BACKOFF_MS;
      if (Date.now() < resetAfter) {
        console.log(`[MediaUrlManager] ${mediaId} max attempts exceeded, waiting for reset`);
        return null;
      }
      // Reset attempts
      this.refreshAttempts.delete(mediaId);
    }

    // Check for pending refresh for this mediaId
    const pending = this.pendingRefreshes.get(mediaId);
    if (pending) {
      // Return the existing promise to deduplicate
      return pending.promise;
    }

    // Check global rate limit
    if (!this.canMakeRequest()) {
      console.log(`[MediaUrlManager] Rate limited, waiting...`);
      // Wait a bit and try again
      await this.waitForRateLimit();
      return this.refreshUrl(mediaId);
    }

    // Create new refresh promise
    const refreshPromise = this.doRefresh(mediaId);
    this.pendingRefreshes.set(mediaId, {
      promise: refreshPromise,
      timestamp: Date.now(),
    });

    try {
      return await refreshPromise;
    } finally {
      // Clean up pending after completion
      this.pendingRefreshes.delete(mediaId);
    }
  }

  private async doRefresh(mediaId: string): Promise<string | null> {
    // Record request timestamp for rate limiting
    this.requestTimestamps.push(Date.now());

    // Track attempts
    const attempts = this.refreshAttempts.get(mediaId) || {
      count: 0,
      lastAttempt: 0,
      backoffUntil: 0,
    };
    attempts.count++;
    attempts.lastAttempt = Date.now();
    this.refreshAttempts.set(mediaId, attempts);

    try {
      const response = await mediaApi.getSignedUrl(mediaId);

      if (response.url) {
        // Resolve relative URL to full URL
        const resolvedUrl = resolveMediaUrl(response.url);

        // Cache the URL
        this.urlCache.set(mediaId, {
          url: resolvedUrl,
          expiresAt: Date.now() + this.CACHE_TTL_MS,
        });

        // Reset attempts on success
        this.refreshAttempts.delete(mediaId);

        return resolvedUrl;
      }

      return null;
    } catch (error) {
      console.error(`[MediaUrlManager] Failed to refresh URL for ${mediaId}:`, error);

      // Calculate backoff
      const backoffMs = Math.min(
        this.BASE_BACKOFF_MS * Math.pow(2, attempts.count - 1),
        this.MAX_BACKOFF_MS
      );
      attempts.backoffUntil = Date.now() + backoffMs;
      this.refreshAttempts.set(mediaId, attempts);

      // Check for rate limit error (429)
      if (this.isRateLimitError(error)) {
        // Apply global backoff
        this.applyGlobalBackoff();
      }

      return null;
    }
  }

  private canMakeRequest(): boolean {
    const now = Date.now();
    // Clean old timestamps
    this.requestTimestamps = this.requestTimestamps.filter(
      (ts) => now - ts < this.RATE_WINDOW_MS
    );
    return this.requestTimestamps.length < this.MAX_REQUESTS_PER_WINDOW;
  }

  private async waitForRateLimit(): Promise<void> {
    const now = Date.now();
    const oldestTimestamp = this.requestTimestamps[0] || now;
    const waitTime = Math.max(0, this.RATE_WINDOW_MS - (now - oldestTimestamp) + 100);
    await new Promise((resolve) => setTimeout(resolve, waitTime));
  }

  private isRateLimitError(error: unknown): boolean {
    if (error && typeof error === 'object') {
      const err = error as { response?: { status?: number }; status?: number };
      return err.response?.status === 429 || err.status === 429;
    }
    return false;
  }

  private applyGlobalBackoff(): void {
    // Add artificial delay to all pending timestamps to slow down rate
    const backoffTime = 5000; // 5 seconds
    const now = Date.now();
    // Fill the rate limit window to prevent new requests
    this.requestTimestamps = Array(this.MAX_REQUESTS_PER_WINDOW)
      .fill(0)
      .map((_, i) => now - (i * 100));
  }

  /**
   * Get a cached URL if available and not expired
   */
  getCachedUrl(mediaId: string): string | null {
    const cached = this.urlCache.get(mediaId);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.url;
    }
    return null;
  }

  /**
   * Pre-cache a URL (e.g., from initial load)
   */
  cacheUrl(mediaId: string, url: string): void {
    this.urlCache.set(mediaId, {
      url,
      expiresAt: Date.now() + this.CACHE_TTL_MS,
    });
  }

  /**
   * Clear cache for a specific mediaId
   */
  clearCache(mediaId: string): void {
    this.urlCache.delete(mediaId);
    this.refreshAttempts.delete(mediaId);
  }

  /**
   * Clear all caches
   */
  clearAllCaches(): void {
    this.urlCache.clear();
    this.refreshAttempts.clear();
    this.pendingRefreshes.clear();
    this.requestTimestamps = [];
  }
}

// Export singleton instance
export const mediaUrlManager = new MediaUrlManager();
