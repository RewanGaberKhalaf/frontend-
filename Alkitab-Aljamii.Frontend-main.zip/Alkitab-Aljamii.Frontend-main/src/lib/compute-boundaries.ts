/**
 * Compute page boundaries from HTML content client-side
 * Uses the same A4 dimensions and logic as PaginatedPreview and SecureBookViewer
 *
 * This must stay in sync with useLocalPagination.ts for consistent results
 */

// Placeholder URL pattern - must match backend ContentAssemblerService
const MEDIA_PLACEHOLDER_PREFIX = '__MEDIA__';
const MEDIA_PLACEHOLDER_SUFFIX = '__ENDMEDIA__';

/**
 * Normalize media URLs in HTML to stable placeholders
 * This ensures boundaries computed from HTML with different signed URLs
 * will still be valid when the server serves content
 *
 * Matches patterns like:
 * - <div data-resizable-media ... data-media-id="abc123" ... ><img src="..." ...></div>
 * - <img ... data-media-id="abc123" src="..." />
 */
function normalizeMediaUrls(html: string): string {
  // Parse the HTML and find all elements with data-media-id
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');

  // Find all elements with data-media-id (the resizable media container or img/video directly)
  const mediaContainers = doc.querySelectorAll('[data-media-id]');

  for (const container of Array.from(mediaContainers)) {
    const mediaId = container.getAttribute('data-media-id');
    if (!mediaId) continue;

    // Find the actual media element (img, video, or iframe) inside or the container itself
    const mediaEl = container.querySelector('img, video, iframe') || container;
    const srcAttr = mediaEl.getAttribute('src');

    if (srcAttr && !srcAttr.startsWith(MEDIA_PLACEHOLDER_PREFIX)) {
      const placeholder = `${MEDIA_PLACEHOLDER_PREFIX}${mediaId}${MEDIA_PLACEHOLDER_SUFFIX}`;
      mediaEl.setAttribute('src', placeholder);
    }
  }

  // Return the normalized HTML (body content only)
  return doc.body.innerHTML;
}

// A4 dimensions at 96 DPI
const A4_WIDTH_PX = 794;
const A4_HEIGHT_PX = 1123;

// Page margins and header/footer
const PAGE_MARGIN = 48;
const HEADER_HEIGHT = 32;
const FOOTER_HEIGHT = 32;
const PAGINATION_BUFFER = 8;

// Content area dimensions
const CONTENT_WIDTH = A4_WIDTH_PX - PAGE_MARGIN * 2; // 698px
const BASE_CONTENT_HEIGHT = A4_HEIGHT_PX - PAGE_MARGIN * 2; // 1027px

// Minimum space required after a header to prevent orphans (pixels)
const MIN_CONTENT_AFTER_HEADER = 120;

export interface PageBoundary {
  pageNumber: number;
  startIndex: number;
  endIndex: number;
  estimatedHeight?: number;
}

export interface ComputeBoundariesOptions {
  headerEnabled?: boolean;
  footerEnabled?: boolean;
}

/**
 * Compute page boundaries from HTML content
 * Creates a hidden measurement container to accurately calculate page breaks
 *
 * Handles:
 * - Oversized media (images/videos) by treating them as full-page elements
 * - Tables that span multiple pages by splitting with header repetition
 * - CSS page-break-before for chapter breaks
 * - Orphan prevention for headers
 */
export function computeBoundariesFromHtml(
  html: string,
  options: ComputeBoundariesOptions = {}
): { boundaries: PageBoundary[]; pageCount: number } {
  const { headerEnabled = true, footerEnabled = true } = options;

  if (!html || typeof window === 'undefined') {
    return {
      boundaries: [{ pageNumber: 1, startIndex: 0, endIndex: 0 }],
      pageCount: 1,
    };
  }

  // Normalize media URLs to stable placeholders before computing boundaries
  // This ensures boundaries will match when server serves content with placeholder URLs
  const normalizedHtml = normalizeMediaUrls(html);

  // Calculate available content height
  let contentHeight = BASE_CONTENT_HEIGHT;
  if (headerEnabled) contentHeight -= HEADER_HEIGHT;
  if (footerEnabled) contentHeight -= FOOTER_HEIGHT;
  const maxPageHeight = contentHeight - PAGINATION_BUFFER;

  // Create hidden measurement container
  const measureContainer = document.createElement('div');
  measureContainer.style.cssText = `
    position: absolute;
    left: -9999px;
    top: 0;
    width: ${CONTENT_WIDTH}px;
    visibility: hidden;
    font-size: 11pt;
    line-height: 1.6;
  `;
  measureContainer.className = 'ProseMirror chapter-content prose prose-sm dark:prose-invert';
  measureContainer.innerHTML = normalizedHtml;
  document.body.appendChild(measureContainer);

  try {
    const pageBoundaries: PageBoundary[] = [];
    let currentPageElements: HTMLElement[] = [];
    let currentHeight = 0;
    let currentStartIndex = 0;

    // Helper to measure element height including margins
    const measureElement = (el: HTMLElement): number => {
      const height = el.offsetHeight || el.getBoundingClientRect().height;
      const style = window.getComputedStyle(el);
      const marginTop = parseFloat(style.marginTop) || 0;
      const marginBottom = parseFloat(style.marginBottom) || 0;
      return height + marginTop + marginBottom;
    };

    // Helper to check if element is a header
    const isHeader = (el: HTMLElement): boolean => {
      const tagName = el.tagName.toLowerCase();
      return ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tagName);
    };

    // Helper to check for page break CSS
    const hasPageBreakBefore = (el: HTMLElement): boolean => {
      const style = window.getComputedStyle(el);
      const inlineStyle = el.style.pageBreakBefore || el.style.breakBefore;
      return (
        style.pageBreakBefore === 'always' ||
        style.breakBefore === 'page' ||
        inlineStyle === 'always' ||
        inlineStyle === 'page'
      );
    };

    // Helper to find table in element
    const findTable = (el: HTMLElement): HTMLTableElement | null => {
      if (el.tagName === 'TABLE') return el as HTMLTableElement;
      const wrapped = el.querySelector('table');
      return wrapped as HTMLTableElement | null;
    };

    // Helper to create a table chunk with header
    const createTableChunk = (
      table: HTMLTableElement,
      rows: HTMLElement[],
      thead: HTMLElement | null
    ): HTMLElement => {
      const newTable = document.createElement('table');
      Array.from(table.attributes).forEach((attr) => {
        newTable.setAttribute(attr.name, attr.value);
      });
      if (thead) {
        newTable.appendChild(thead.cloneNode(true));
      }
      const tbody = document.createElement('tbody');
      rows.forEach((row) => tbody.appendChild(row.cloneNode(true)));
      newTable.appendChild(tbody);
      return newTable;
    };

    // Helper to flush current page
    const flushPage = () => {
      if (currentPageElements.length > 0) {
        const pageHtml = currentPageElements.map(el => el.outerHTML).join('');
        const endIndex = currentStartIndex + pageHtml.length;
        pageBoundaries.push({
          pageNumber: pageBoundaries.length + 1,
          startIndex: currentStartIndex,
          endIndex,
          estimatedHeight: Math.round(currentHeight),
        });
        currentStartIndex = endIndex;
        currentPageElements = [];
        currentHeight = 0;
      }
    };

    // Process each child element
    const children = Array.from(measureContainer.children) as HTMLElement[];

    for (const child of children) {
      // Handle page breaks (chapter breaks)
      if (hasPageBreakBefore(child)) {
        flushPage();
        if (!child.textContent?.trim() && child.children.length === 0) {
          continue;
        }
      }

      const childHeight = measureElement(child);
      const table = findTable(child);

      // Handle tables - split across pages if needed
      if (table) {
        let rows = Array.from(table.querySelectorAll('tbody > tr')) as HTMLElement[];
        if (rows.length === 0) {
          rows = Array.from(table.querySelectorAll('tr')) as HTMLElement[];
        }

        const thead = table.querySelector('thead') as HTMLElement | null;
        const headerRow = table.querySelector('tr:first-child') as HTMLElement | null;
        const theadHeight = thead
          ? measureElement(thead)
          : headerRow
            ? measureElement(headerRow)
            : 0;

        // Check if table needs splitting
        if (
          childHeight > maxPageHeight ||
          (currentHeight > 0 && currentHeight + childHeight > maxPageHeight)
        ) {
          let chunkRows: HTMLElement[] = [];
          let chunkHeight = theadHeight;
          let isFirstChunk = true;

          for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            if (!row) continue;
            if (thead && row.parentElement === thead) continue;

            const rowHeight = measureElement(row);
            const fitsInChunk = isFirstChunk
              ? currentHeight + chunkHeight + rowHeight <= maxPageHeight
              : chunkHeight + rowHeight <= maxPageHeight;

            if (!fitsInChunk && chunkRows.length > 0) {
              const chunkTable = createTableChunk(table, chunkRows, thead);
              if (isFirstChunk) {
                currentPageElements.push(chunkTable);
                flushPage();
                isFirstChunk = false;
              } else {
                // Add chunk as its own page
                const chunkHtml = chunkTable.outerHTML;
                pageBoundaries.push({
                  pageNumber: pageBoundaries.length + 1,
                  startIndex: currentStartIndex,
                  endIndex: currentStartIndex + chunkHtml.length,
                  estimatedHeight: Math.round(chunkHeight),
                });
                currentStartIndex += chunkHtml.length;
              }
              chunkRows = [];
              chunkHeight = theadHeight;
            }

            chunkRows.push(row);
            chunkHeight += rowHeight;
          }

          // Handle remaining rows
          if (chunkRows.length > 0) {
            const chunkTable = createTableChunk(table, chunkRows, thead);
            if (isFirstChunk) {
              currentPageElements.push(chunkTable);
              currentHeight += chunkHeight;
            } else {
              currentPageElements.push(chunkTable);
              currentHeight = chunkHeight;
            }
          }

          continue;
        }
      }

      // Handle oversized media (images, videos) - scale to fit page
      if (
        (child.hasAttribute('data-resizable-media') ||
          child.tagName === 'IMG' ||
          child.tagName === 'VIDEO') &&
        childHeight > maxPageHeight
      ) {
        flushPage();

        // Create scaled clone for boundary calculation
        const clone = child.cloneNode(true) as HTMLElement;
        const mediaEl = (clone.querySelector('img, video') as HTMLElement) || clone;
        if (mediaEl) {
          mediaEl.style.maxHeight = `${maxPageHeight - 20}px`;
          mediaEl.style.width = 'auto';
          mediaEl.style.height = 'auto';
          mediaEl.style.objectFit = 'contain';
        }

        const scaledHtml = clone.outerHTML;
        pageBoundaries.push({
          pageNumber: pageBoundaries.length + 1,
          startIndex: currentStartIndex,
          endIndex: currentStartIndex + scaledHtml.length,
          estimatedHeight: maxPageHeight,
        });
        currentStartIndex += scaledHtml.length;
        continue;
      }

      // Check if element fits on current page
      if (currentHeight + childHeight > maxPageHeight && currentPageElements.length > 0) {
        flushPage();
      }

      // Prevent orphaned headers: if this is a header and there won't be enough
      // space for content after it, push it to the next page
      if (isHeader(child) && currentPageElements.length > 0) {
        const remainingSpace = maxPageHeight - currentHeight - childHeight;
        if (remainingSpace < MIN_CONTENT_AFTER_HEADER) {
          flushPage();
        }
      }

      // Clone the element
      const clone = child.cloneNode(true) as HTMLElement;
      currentPageElements.push(clone);
      currentHeight += childHeight;
    }

    // Flush remaining content
    flushPage();

    // Ensure at least one page
    if (pageBoundaries.length === 0) {
      pageBoundaries.push({
        pageNumber: 1,
        startIndex: 0,
        endIndex: normalizedHtml.length,
        estimatedHeight: 0,
      });
    }

    return {
      boundaries: pageBoundaries,
      pageCount: pageBoundaries.length,
    };
  } finally {
    // Clean up
    document.body.removeChild(measureContainer);
  }
}

/**
 * Compute boundaries for multiple chapters
 */
export async function computeBoundariesForChapters(
  chapters: Array<{ id: string; content: string }>,
  options?: ComputeBoundariesOptions
): Promise<Map<string, { boundaries: PageBoundary[]; pageCount: number }>> {
  const results = new Map<string, { boundaries: PageBoundary[]; pageCount: number }>();

  for (const chapter of chapters) {
    // Use requestAnimationFrame to allow UI updates between computations
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => {
        const result = computeBoundariesFromHtml(chapter.content, options);
        results.set(chapter.id, result);
        resolve();
      });
    });
  }

  return results;
}
