import { apiClient } from './client';

// ==================== COMMON TYPES ====================

export interface DateRange {
  from?: string;
  to?: string;
}

export interface TrendDataPoint {
  date: string;
  value: number;
}

// ==================== PROFESSOR ANALYTICS ====================

// Book-level analytics for a professor
export interface BookAnalytics {
  bookId: string;
  bookTitle: string;
  bookTitleAr: string | null;
  subjectName: string;
  status: string;
  totalChapters: number;
  totalReaders: number;
  activeReaders: number; // Last 7 days
  avgCompletionRate: number; // Percentage
  avgReadingTimeMinutes: number;
  chapters: ChapterAnalytics[];
}

export interface ChapterAnalytics {
  chapterId: string;
  chapterTitle: string;
  chapterTitleAr: string | null;
  order: number;
  totalReaders: number;
  completedCount: number;
  avgReadingTimeMinutes: number;
  hasQuiz: boolean;
  quizStats: ChapterQuizStats | null;
}

export interface ChapterQuizStats {
  totalAttempts: number;
  uniqueStudents: number;
  avgScore: number;
  passRate: number;
  avgTimeMinutes: number;
}

// Quiz-level analytics for a professor
export interface QuizAnalytics {
  quizId: string;
  quizTitle: string;
  quizTitleAr: string | null;
  bankName: string;
  totalQuestions: number;
  totalAttempts: number;
  uniqueStudents: number;
  avgScore: number;
  passRate: number;
  avgTimeMinutes: number;
  scoreDistribution: ScoreDistribution;
  questionStats: QuestionAnalytics[];
  recentAttempts: AttemptSummary[];
}

export interface ScoreDistribution {
  '0-20': number;
  '21-40': number;
  '41-60': number;
  '61-80': number;
  '81-100': number;
}

export interface QuestionAnalytics {
  questionId: string;
  questionText: string;
  questionType: string;
  difficulty: string;
  timesAnswered: number;
  correctRate: number;
  avgTimeSeconds: number;
}

export interface AttemptSummary {
  attemptId: string;
  studentName: string;
  studentEmail: string;
  score: number;
  passed: boolean;
  timeSpentMinutes: number;
  submittedAt: string;
}

// Professor overview stats
export interface ProfessorAnalyticsOverview {
  totalBooks: number;
  publishedBooks: number;
  totalQuizzes: number;
  totalStudentsReached: number;
  avgQuizScore: number;
  avgBookCompletionRate: number;
  recentActivity: ProfessorActivityItem[];
  bookPerformance: BookPerformanceSummary[];
  quizPerformance: QuizPerformanceSummary[];
}

export interface ProfessorActivityItem {
  type: 'quiz_attempt' | 'book_read' | 'chapter_completed';
  studentName: string;
  itemTitle: string;
  score?: number;
  timestamp: string;
}

export interface BookPerformanceSummary {
  bookId: string;
  bookTitle: string;
  readers: number;
  completionRate: number;
}

export interface QuizPerformanceSummary {
  quizId: string;
  quizTitle: string;
  attempts: number;
  avgScore: number;
  passRate: number;
}

// Student detail for drill-down
export interface StudentProgressDetail {
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  bookProgress: StudentBookProgress[];
  quizAttempts: StudentQuizAttempt[];
}

export interface StudentBookProgress {
  bookId: string;
  bookTitle: string;
  chaptersCompleted: number;
  totalChapters: number;
  totalReadingTimeMinutes: number;
  lastReadAt: string | null;
}

export interface StudentQuizAttempt {
  attemptId: string;
  quizId: string;
  quizTitle: string;
  score: number;
  passed: boolean;
  attemptNumber: number;
  submittedAt: string;
}

// ==================== FACULTY ADMIN ANALYTICS ====================

export interface FacultyAnalyticsOverview {
  facultyId: string;
  facultyName: string;
  totalProfessors: number;
  totalStudents: number;
  totalBooks: number;
  publishedBooks: number;
  totalQuizzes: number;
  totalQuizAttempts: number;
  avgQuizScore: number;
  overallPassRate: number;
  activeStudents7d: number;
  activeStudents30d: number;
  subjectPerformance: SubjectPerformance[];
  topPerformingSubjects: SubjectRanking[];
  strugglingSubjects: SubjectRanking[];
  engagementTrend: TrendDataPoint[];
}

export interface SubjectPerformance {
  subjectId: string;
  subjectCode: string;
  subjectName: string;
  professorCount: number;
  studentCount: number;
  bookCount: number;
  quizCount: number;
  avgQuizScore: number;
  passRate: number;
  activeStudents: number;
}

export interface SubjectRanking {
  subjectId: string;
  subjectName: string;
  metric: number; // avgScore or passRate
}

// Faculty drill-down by subject
export interface SubjectAnalyticsDetail {
  subjectId: string;
  subjectCode: string;
  subjectName: string;
  professors: ProfessorSummary[];
  books: BookSummaryForFaculty[];
  quizzes: QuizSummaryForFaculty[];
  studentEngagement: StudentEngagementStats;
}

export interface ProfessorSummary {
  userId: string;
  name: string;
  email: string;
  booksCount: number;
  quizzesCount: number;
  avgStudentScore: number;
}

export interface BookSummaryForFaculty {
  bookId: string;
  title: string;
  professorName: string;
  status: string;
  readers: number;
  completionRate: number;
}

export interface QuizSummaryForFaculty {
  quizId: string;
  title: string;
  professorName: string;
  attempts: number;
  avgScore: number;
  passRate: number;
}

export interface StudentEngagementStats {
  totalStudents: number;
  activeToday: number;
  activeThisWeek: number;
  activeThisMonth: number;
  neverActive: number;
}

// ==================== SUPER ADMIN ANALYTICS ====================

export interface SuperAdminAnalyticsOverview {
  totalUsers: number;
  totalFaculties: number;
  totalSubjects: number;
  totalBooks: number;
  publishedBooks: number;
  totalQuizzes: number;
  totalQuizAttempts: number;
  avgQuizScorePlatform: number;
  overallPassRate: number;
  activeUsers7d: number;
  activeUsers30d: number;
  facultyPerformance: FacultyPerformance[];
  topFaculties: FacultyRanking[];
  strugglingFaculties: FacultyRanking[];
  platformTrends: PlatformTrends;
  userGrowth: TrendDataPoint[];
  engagementTrend: TrendDataPoint[];
}

export interface FacultyPerformance {
  facultyId: string;
  facultyCode: string;
  facultyName: string;
  professorCount: number;
  studentCount: number;
  subjectCount: number;
  bookCount: number;
  quizCount: number;
  avgQuizScore: number;
  passRate: number;
  activeStudents: number;
  engagementRate: number; // activeStudents / totalStudents
}

export interface FacultyRanking {
  facultyId: string;
  facultyName: string;
  metric: number;
}

export interface PlatformTrends {
  quizAttemptsLast7d: number;
  quizAttemptsLast30d: number;
  newUsersLast7d: number;
  newUsersLast30d: number;
  booksPublishedLast30d: number;
}

// Faculty drill-down for super admin
export interface FacultyAnalyticsDetail {
  facultyId: string;
  facultyCode: string;
  facultyName: string;
  overview: FacultyAnalyticsOverview;
  subjectBreakdown: SubjectPerformance[];
}

// ==================== API ====================

const ANALYTICS_URL = '/analytics';

export const analyticsApi = {
  // ========================= PROFESSOR ANALYTICS =========================

  // Overview stats for professor dashboard
  getProfessorOverview: () =>
    apiClient.get<ProfessorAnalyticsOverview>(`${ANALYTICS_URL}/professor/overview`),

  // Detailed analytics for a specific book
  getBookAnalytics: (bookId: string) =>
    apiClient.get<BookAnalytics>(`${ANALYTICS_URL}/professor/book/${bookId}`),

  // Detailed analytics for a specific quiz
  getQuizAnalytics: (quizId: string) =>
    apiClient.get<QuizAnalytics>(`${ANALYTICS_URL}/professor/quiz/${quizId}`),

  // Get student progress for drill-down (professor can see students in their subjects)
  getStudentProgress: (studentId: string) =>
    apiClient.get<StudentProgressDetail>(`${ANALYTICS_URL}/professor/students/${studentId}`),

  // Get all students for a specific book
  getBookStudents: (bookId: string, params?: { page?: number; limit?: number }) =>
    apiClient.get<{ items: StudentProgressDetail[]; total: number }>(
      `${ANALYTICS_URL}/professor/books/${bookId}/students`,
      { params }
    ),

  // Get all attempts for a specific quiz
  getQuizAttempts: (quizId: string, params?: { page?: number; limit?: number }) =>
    apiClient.get<{ items: AttemptSummary[]; total: number }>(
      `${ANALYTICS_URL}/professor/quizzes/${quizId}/attempts`,
      { params }
    ),

  // ========================= FACULTY ADMIN ANALYTICS =========================

  // Overview stats for faculty admin dashboard
  getFacultyOverview: () =>
    apiClient.get<FacultyAnalyticsOverview>(`${ANALYTICS_URL}/faculty/overview`),

  // Detailed analytics for a specific subject
  getSubjectAnalytics: (subjectId: string) =>
    apiClient.get<SubjectAnalyticsDetail>(`${ANALYTICS_URL}/faculty/subject/${subjectId}`),

  // Get all professors in faculty with performance
  getFacultyProfessors: (params?: { page?: number; limit?: number }) =>
    apiClient.get<{ items: ProfessorSummary[]; total: number }>(
      `${ANALYTICS_URL}/faculty/professors`,
      { params }
    ),

  // Get student engagement stats for faculty
  getFacultyStudentEngagement: () =>
    apiClient.get<StudentEngagementStats>(`${ANALYTICS_URL}/faculty/student-engagement`),

  // ========================= SUPER ADMIN ANALYTICS =========================

  // Platform-wide overview stats
  getSuperAdminOverview: () =>
    apiClient.get<SuperAdminAnalyticsOverview>(`${ANALYTICS_URL}/super-admin/overview`),

  // Detailed analytics for a specific faculty
  getFacultyAnalyticsDetail: (facultyId: string) =>
    apiClient.get<FacultyAnalyticsDetail>(`${ANALYTICS_URL}/super-admin/faculty/${facultyId}`),

  // Get all faculties with performance metrics
  getAllFacultiesPerformance: (params?: { page?: number; limit?: number }) =>
    apiClient.get<{ items: FacultyPerformance[]; total: number }>(
      `${ANALYTICS_URL}/super-admin/faculties`,
      { params }
    ),

  // Get platform trends over time
  getPlatformTrends: (range?: DateRange) =>
    apiClient.get<{
      userGrowth: TrendDataPoint[];
      engagementTrend: TrendDataPoint[];
      quizAttemptsTrend: TrendDataPoint[];
    }>(`${ANALYTICS_URL}/super-admin/trends`, { params: range }),
};
