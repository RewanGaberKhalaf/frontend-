import { apiClient } from './client';
import type {
  Book,
  BookListItem,
  Chapter,
  BookVersion,
  BookVersionListItem,
  CreateBookDto,
  UpdateBookDto,
  CreateChapterDto,
  UpdateChapterDto,
  ReorderChaptersDto,
  CreateVersionDto,
  RejectBookDto,
  RejectionFeedbackResponse,
  BookQueryParams,
  PaginatedResponse,
  StudentChapterMetadata,
  SecureChapterContent,
  PageContent,
  SavePageBoundariesDto,
  SaveBoundariesResponse,
  SecurityIncidentDto,
  BookResource,
  GroupedBookResources,
  CreateBookResourceDto,
  CreateLinkResourceDto,
  CreateMediaResourceDto,
  UpdateBookResourceDto,
} from '@/types';

const BASE_URL = '/books';
const STUDENT_BASE_URL = '/student/books';
const PROFESSOR_BASE_URL = '/professor/books';

export const booksApi = {
  // ========================= BOOKS =============================
  getAll: (params?: BookQueryParams) =>
    apiClient.get<PaginatedResponse<BookListItem>>(BASE_URL, { params }),

  getById: (id: string) =>
    apiClient.get<Book>(`${BASE_URL}/${id}`),

  create: (data: CreateBookDto) =>
    apiClient.post<Book>(BASE_URL, data),

  update: (id: string, data: UpdateBookDto) =>
    apiClient.patch<Book>(`${BASE_URL}/${id}`, data),

  delete: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}`),

  // ========================= COVER IMAGE =============================
  uploadCover: async (bookId: string, file: File): Promise<Book> => {
    const formData = new FormData();
    formData.append('cover', file);
    const response = await apiClient.post<Book>(`${BASE_URL}/${bookId}/cover`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response;
  },

  removeCover: (bookId: string) =>
    apiClient.delete<Book>(`${BASE_URL}/${bookId}/cover`),

  getCoverUrl: (bookId: string) =>
    apiClient.get<{ url: string; expiresIn: number }>(`${BASE_URL}/${bookId}/cover/url`),

  // ========================= STATUS TRANSITIONS =============================
  submit: (id: string) =>
    apiClient.post<Book>(`${BASE_URL}/${id}/submit`),

  approve: (id: string) =>
    apiClient.put<Book>(`${BASE_URL}/${id}/approve`),

  reject: (id: string, data: RejectBookDto) =>
    apiClient.put<Book>(`${BASE_URL}/${id}/reject`, data),

  getRejectionFeedback: (id: string) =>
    apiClient.get<RejectionFeedbackResponse | null>(`${BASE_URL}/${id}/rejection-feedback`),

  publish: (id: string) =>
    apiClient.post<Book>(`${BASE_URL}/${id}/publish`),

  unpublish: (id: string) =>
    apiClient.post<Book>(`${BASE_URL}/${id}/unpublish`),

  republish: (id: string) =>
    apiClient.post<Book>(`${BASE_URL}/${id}/republish`),

  discardPendingChanges: (id: string) =>
    apiClient.post<Book>(`${BASE_URL}/${id}/discard-changes`),

  // ========================= CHAPTERS =============================
  /**
   * Get all chapters in a book.
   * @param bookId Book ID
   * @param viewMode When true, only returns published content (no draft changes).
   *   Non-authors always see published content regardless of this flag.
   */
  getChapters: (bookId: string, viewMode = false) =>
    apiClient.get<Chapter[]>(`${BASE_URL}/${bookId}/chapters`, {
      params: viewMode ? { viewMode: true } : undefined,
    }),

  /**
   * Get a single chapter by ID.
   * @param bookId Book ID
   * @param chapterId Chapter ID
   * @param viewMode When true, only returns published content (no draft changes).
   */
  getChapter: (bookId: string, chapterId: string, viewMode = false) =>
    apiClient.get<Chapter>(`${BASE_URL}/${bookId}/chapters/${chapterId}`, {
      params: viewMode ? { viewMode: true } : undefined,
    }),

  createChapter: (bookId: string, data: CreateChapterDto) =>
    apiClient.post<Chapter>(`${BASE_URL}/${bookId}/chapters`, data),

  updateChapter: (bookId: string, chapterId: string, data: UpdateChapterDto) =>
    apiClient.patch<Chapter>(`${BASE_URL}/${bookId}/chapters/${chapterId}`, data),

  deleteChapter: (bookId: string, chapterId: string) =>
    apiClient.delete<void>(`${BASE_URL}/${bookId}/chapters/${chapterId}`),

  reorderChapters: (bookId: string, data: ReorderChaptersDto) =>
    apiClient.put<Chapter[]>(`${BASE_URL}/${bookId}/chapters/reorder`, data),

  // ========================= VERSIONS =============================
  getVersions: (bookId: string) =>
    apiClient.get<BookVersionListItem[]>(`${BASE_URL}/${bookId}/versions`),

  getVersion: (bookId: string, version: number) =>
    apiClient.get<BookVersion>(`${BASE_URL}/${bookId}/versions/${version}`),

  createVersion: (bookId: string, data?: CreateVersionDto) =>
    apiClient.post<BookVersion>(`${BASE_URL}/${bookId}/versions`, data ?? {}),

  restoreVersion: (bookId: string, version: number) =>
    apiClient.post<BookVersion>(`${BASE_URL}/${bookId}/versions/${version}/restore`),

  // ========================= PAGE BOUNDARIES (PROFESSOR) =============================
  /**
   * Save page boundaries for a chapter
   * Used by professor after preview to enable server-side pagination
   */
  savePageBoundaries: (bookId: string, chapterId: string, data: SavePageBoundariesDto) =>
    apiClient.put<SaveBoundariesResponse>(
      `${BASE_URL}/${bookId}/chapters/${chapterId}/boundaries`,
      data
    ),

  // ========================= STUDENT ENDPOINTS =============================
  /**
   * Get chapter list with unlock status (without content)
   * For students only - returns metadata but no content
   */
  getStudentChapters: (bookId: string) =>
    apiClient.get<StudentChapterMetadata[]>(`${STUDENT_BASE_URL}/${bookId}/chapters`),

  /**
   * Get secure chapter content with watermark
   * Only works for unlocked chapters
   * If paginated, returns first page only
   */
  getSecureChapterContent: (bookId: string, chapterId: string) =>
    apiClient.get<SecureChapterContent>(`${STUDENT_BASE_URL}/${bookId}/chapters/${chapterId}/content`),

  /**
   * Get a specific page of chapter content
   * Requires valid access token from initial content request
   */
  getPageContent: (bookId: string, chapterId: string, pageNumber: number, accessToken: string) =>
    apiClient.get<PageContent>(
      `${STUDENT_BASE_URL}/${bookId}/chapters/${chapterId}/pages/${pageNumber}`,
      { headers: { 'x-access-token': accessToken } }
    ),

  /**
   * Report a security incident from the client
   */
  reportSecurityIncident: (data: SecurityIncidentDto) =>
    apiClient.post<{ success: boolean }>(`${STUDENT_BASE_URL}/security/incident`, data),

  // ========================= PROFESSOR ENDPOINTS =============================
  /**
   * Get chapter content for professor view (can see all student annotations)
   * This endpoint allows authors/professors to view their books' content
   */
  getProfessorChapterContent: (bookId: string, chapterId: string) =>
    apiClient.get<SecureChapterContent>(`${PROFESSOR_BASE_URL}/${bookId}/chapters/${chapterId}/content`),

  /**
   * Get a specific page of chapter content (professor view)
   */
  getProfessorPageContent: (bookId: string, chapterId: string, pageNumber: number, accessToken: string) =>
    apiClient.get<PageContent>(
      `${PROFESSOR_BASE_URL}/${bookId}/chapters/${chapterId}/pages/${pageNumber}`,
      { headers: { 'x-access-token': accessToken } }
    ),

  // ========================= RESOURCES =============================
  /**
   * Upload a file resource to a book
   */
  uploadResource: async (bookId: string, file: File, data: CreateBookResourceDto): Promise<BookResource> => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', data.title);
    if (data.titleAr) formData.append('titleAr', data.titleAr);
    if (data.description) formData.append('description', data.description);
    if (data.descriptionAr) formData.append('descriptionAr', data.descriptionAr);
    if (data.chapterId) formData.append('chapterId', data.chapterId);
    return apiClient.post<BookResource>(`${BASE_URL}/${bookId}/resources`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  /**
   * Create a link resource for a book
   */
  createLinkResource: (bookId: string, data: CreateLinkResourceDto) =>
    apiClient.post<BookResource>(`${BASE_URL}/${bookId}/resources/link`, data),

  /**
   * Create a resource from media library item
   */
  createMediaResource: (bookId: string, data: CreateMediaResourceDto) =>
    apiClient.post<BookResource>(`${BASE_URL}/${bookId}/resources/media`, data),

  /**
   * Get all resources for a book (professor/author view)
   */
  getResources: (bookId: string) =>
    apiClient.get<GroupedBookResources>(`${BASE_URL}/${bookId}/resources`),

  /**
   * Get resources for a student (with access control)
   */
  getStudentResources: (bookId: string) =>
    apiClient.get<GroupedBookResources>(`${BASE_URL}/${bookId}/resources/student`),

  /**
   * Get a single resource
   */
  getResource: (bookId: string, resourceId: string) =>
    apiClient.get<BookResource>(`${BASE_URL}/${bookId}/resources/${resourceId}`),

  /**
   * Get signed download URL for a resource
   */
  getResourceDownloadUrl: (bookId: string, resourceId: string) =>
    apiClient.get<{ url: string; fileName: string; mimeType: string }>(
      `${BASE_URL}/${bookId}/resources/${resourceId}/download`
    ),

  /**
   * Update resource metadata
   */
  updateResource: (bookId: string, resourceId: string, data: UpdateBookResourceDto) =>
    apiClient.patch<BookResource>(`${BASE_URL}/${bookId}/resources/${resourceId}`, data),

  /**
   * Delete a resource
   */
  deleteResource: (bookId: string, resourceId: string) =>
    apiClient.delete<void>(`${BASE_URL}/${bookId}/resources/${resourceId}`),

  /**
   * Reorder book-level resources
   */
  reorderBookResources: (bookId: string, resourceIds: string[]) =>
    apiClient.patch<{ success: boolean }>(`${BASE_URL}/${bookId}/resources/reorder`, { resourceIds }),

  /**
   * Reorder chapter-level resources
   */
  reorderChapterResources: (bookId: string, chapterId: string, resourceIds: string[]) =>
    apiClient.patch<{ success: boolean }>(
      `${BASE_URL}/${bookId}/resources/chapters/${chapterId}/reorder`,
      { resourceIds }
    ),

  /**
   * Publish all draft resources for a book
   */
  publishResources: (bookId: string) =>
    apiClient.post<{ publishedCount: number }>(`${BASE_URL}/${bookId}/resources/publish`),

  /**
   * Discard all draft resources for a book
   */
  discardDraftResources: (bookId: string) =>
    apiClient.delete<{ discardedCount: number }>(`${BASE_URL}/${bookId}/resources/drafts`),
};
