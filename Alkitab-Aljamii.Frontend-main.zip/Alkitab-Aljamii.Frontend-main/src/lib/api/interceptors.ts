import type { AxiosInstance, InternalAxiosRequestConfig, AxiosError, AxiosResponse } from 'axios';
import { defaultLocale } from '@/i18n/config';
import { authTokens } from '@/lib/storage/cookie-storage';

let accessToken: string | null = null;

// Get current locale from cookie (same source as next-intl)
function getCurrentLocale(): string {
  if (typeof document === 'undefined') return defaultLocale;
  const match = document.cookie.match(/(?:^|;\s*)locale=([^;]*)/);
  return match?.[1] ?? defaultLocale;
}
let isRefreshing = false;
let failedQueue: Array<{
  resolve: (token: string | null) => void;
  reject: (error: unknown) => void;
}> = [];

// Session nonce - incremented on login/logout to invalidate in-flight refreshes
let authSessionNonce = 0;

// Callback to refresh token - set by auth store
let refreshTokenCallback: (() => Promise<boolean>) | null = null;

export function setAccessToken(token: string | null): void {
  accessToken = token;
}

export function getAccessToken(): string | null {
  return accessToken;
}

export function getAuthSessionNonce(): number {
  return authSessionNonce;
}

export function setRefreshTokenCallback(callback: (() => Promise<boolean>) | null): void {
  refreshTokenCallback = callback;
}

export function clearAuthState(): void {
  accessToken = null;
  refreshTokenCallback = null;
  isRefreshing = false;
  failedQueue = [];
  // Increment nonce to invalidate any in-flight refresh requests
  authSessionNonce++;
}

function processQueue(error: unknown, token: string | null = null): void {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
}

export function setupInterceptors(instance: AxiosInstance): void {
  // Request interceptor - add auth token and Accept-Language header
  instance.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
      const token = getAccessToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      // Add Accept-Language header for i18n
      const locale = getCurrentLocale();
      config.headers.set('Accept-Language', locale);
      return config;
    },
    (error) => Promise.reject(error)
  );

  // Response interceptor - handle 401 with token refresh
  instance.interceptors.response.use(
    (response: AxiosResponse) => response,
    async (error: AxiosError) => {
      const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

      const status = error.response?.status;
      const errorData = error.response?.data as { code?: string; message?: string } | undefined;

      // Log all 403 errors for debugging
      if (status === 403) {
        console.log('[Auth] 403 received, errorData:', errorData);
      }

      // Handle 403 with context switch codes - user has other valid roles
      const switchContextCodes = ['ROLE_REVOKED_HAS_OTHERS', 'FACULTY_INACTIVE_HAS_OTHERS'];
      if (status === 403 && errorData?.code && switchContextCodes.includes(errorData.code)) {
        console.log('[Auth] Context invalid but user has other roles:', errorData.code);
        // Store the message and trigger a context reset
        if (typeof window !== 'undefined') {
          localStorage.setItem('auth_context_switch', errorData.message || 'Your current role is no longer valid.');
          // Clear access token from memory and cookies - keeps refresh token for re-auth
          setAccessToken(null);
          authTokens.clearAccessToken();
          // Force full page reload to reset all state and re-hydrate with new context
          window.location.href = '/';
        }
        return Promise.reject(error);
      }

      // Handle 403 with session invalidation codes - force logout immediately
      // This includes responses from /auth/refresh when user has no roles
      const invalidationCodes = ['ROLE_REVOKED', 'FACULTY_INACTIVE', 'ADMIN_CONFLICT', 'NO_ROLES'];
      if (status === 403 && errorData?.code && invalidationCodes.includes(errorData.code)) {
        console.log('[Auth] Session invalidated (403):', errorData.code, errorData.message);
        if (errorData.message) {
          localStorage.setItem('auth_error', errorData.message);
        }
        clearAuthState();
        redirectToLogin();
        return Promise.reject(error);
      }

      // Only handle 401 errors for token refresh
      if (status !== 401) {
        return Promise.reject(error);
      }

      console.log('[Auth] 401 received for:', originalRequest.url);

      // Don't retry refresh or login requests
      if (originalRequest.url?.includes('/auth/')) {
        console.log('[Auth] Skipping refresh for auth route');
        return Promise.reject(error);
      }

      // Already retried
      if (originalRequest._retry) {
        console.log('[Auth] Already retried, redirecting to login');
        redirectToLogin();
        return Promise.reject(error);
      }

      if (isRefreshing) {
        console.log('[Auth] Already refreshing, queuing request');
        // Queue the request while refreshing
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then((token) => {
          if (token && originalRequest.headers) {
            originalRequest.headers.Authorization = `Bearer ${token}`;
          }
          return instance(originalRequest);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      console.log('[Auth] Attempting token refresh, callback exists:', !!refreshTokenCallback);

      try {
        if (refreshTokenCallback) {
          const success = await refreshTokenCallback();
          console.log('[Auth] Refresh result:', success);
          if (success) {
            const newToken = getAccessToken();
            processQueue(null, newToken);
            if (newToken && originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
            }
            return instance(originalRequest);
          }
        } else {
          console.log('[Auth] No refresh callback registered!');
        }
        // Refresh failed
        console.log('[Auth] Refresh failed, redirecting to login');
        processQueue(error, null);
        redirectToLogin();
        return Promise.reject(error);
      } catch (refreshError) {
        console.log('[Auth] Refresh error:', refreshError);
        processQueue(refreshError, null);
        redirectToLogin();
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }
  );
}

function redirectToLogin(): void {
  setAccessToken(null);
  if (typeof window !== 'undefined') {
    const currentPath = window.location.pathname;
    if (!currentPath.startsWith('/login')) {
      const url = new URL('/login', window.location.origin);
      url.searchParams.set('redirect', currentPath);
      window.location.href = url.toString();
    }
  }
}
