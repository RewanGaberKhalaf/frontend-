// ==================== TOPIC TYPES ====================

export interface Topic {
  id: string;
  subjectId: string;
  name: string;
  nameAr: string | null;
  description: string | null;
  descriptionAr: string | null;
  questionCount: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateTopicData {
  name: string;
  nameAr?: string;
  description?: string;
  descriptionAr?: string;
}

export interface UpdateTopicData {
  name?: string;
  nameAr?: string;
  description?: string;
  descriptionAr?: string;
  isActive?: boolean;
}

export interface TopicQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  isActive?: boolean;
}

export interface BulkCreateTopicsData {
  topics: CreateTopicData[];
}

export interface BulkCreateTopicsResult {
  created: number;
  skipped: string[];
}

export interface PaginatedTopicResponse {
  data: Topic[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}
