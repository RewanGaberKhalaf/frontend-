import { apiClient } from './client';
import type {
  Faculty,
  CreateFacultyDto,
  UpdateFacultyDto,
  CreateMemberDto,
  FacultyMember,
  PaginationParams,
  PaginatedResponse,
} from '@/types';

const BASE_URL = '/faculties';

export interface FacultyAdminConflict {
  faculty: {
    id: string;
    name: string;
    nameAr?: string;
    code: string;
  };
  admins: FacultyMember[];
  adminCount: number;
}

export interface FacultyFilterParams extends PaginationParams {
  isActive?: boolean;
}

export const facultiesApi = {
  getAll: (params?: FacultyFilterParams) =>
    apiClient.get<PaginatedResponse<Faculty>>(BASE_URL, { params }),

  getById: (id: string) =>
    apiClient.get<Faculty>(`${BASE_URL}/${id}`),

  create: (data: CreateFacultyDto) =>
    apiClient.post<Faculty>(BASE_URL, data),

  update: (id: string, data: UpdateFacultyDto) =>
    apiClient.patch<Faculty>(`${BASE_URL}/${id}`, data),

  delete: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}`),

  restore: (id: string) =>
    apiClient.post<Faculty>(`${BASE_URL}/${id}/restore`),

  // Professor management (faculty level)
  getProfessors: (facultyId: string, params?: PaginationParams) =>
    apiClient.get<PaginatedResponse<FacultyMember>>(
      `${BASE_URL}/${facultyId}/professors`,
      { params }
    ),

  createProfessor: (facultyId: string, data: CreateMemberDto) =>
    apiClient.post<FacultyMember>(`${BASE_URL}/${facultyId}/professors`, data),

  addProfessor: (facultyId: string, professorId: string) =>
    apiClient.post<void>(`${BASE_URL}/${facultyId}/professors/${professorId}`),

  removeProfessor: (facultyId: string, professorId: string) =>
    apiClient.delete<void>(`${BASE_URL}/${facultyId}/professors/${professorId}`),

  // Student management (faculty level)
  getStudents: (facultyId: string, params?: PaginationParams) =>
    apiClient.get<PaginatedResponse<FacultyMember>>(
      `${BASE_URL}/${facultyId}/students`,
      { params }
    ),

  createStudent: (facultyId: string, data: CreateMemberDto) =>
    apiClient.post<FacultyMember>(`${BASE_URL}/${facultyId}/students`, data),

  addStudent: (facultyId: string, studentId: string) =>
    apiClient.post<void>(`${BASE_URL}/${facultyId}/students/${studentId}`),

  removeStudent: (facultyId: string, studentId: string) =>
    apiClient.delete<void>(`${BASE_URL}/${facultyId}/students/${studentId}`),

  // Faculty Admin management
  getFacultyAdmins: (facultyId: string) =>
    apiClient.get<FacultyMember[]>(`${BASE_URL}/${facultyId}/admins`),

  addFacultyAdmin: (facultyId: string, userId: string) =>
    apiClient.post<void>(`${BASE_URL}/${facultyId}/admins/${userId}`),

  removeFacultyAdmin: (facultyId: string, userId: string) =>
    apiClient.delete<void>(`${BASE_URL}/${facultyId}/admins/${userId}`),

  // Faculty Admin Conflicts (Super Admin only)
  getAdminConflicts: () =>
    apiClient.get<FacultyAdminConflict[]>(`${BASE_URL}/admin-conflicts`),
};
