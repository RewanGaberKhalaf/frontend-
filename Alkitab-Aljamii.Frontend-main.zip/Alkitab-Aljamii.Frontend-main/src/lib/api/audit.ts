import { apiClient } from './client';

export enum AuditAction {
  LOGIN = 'LOGIN',
  LOGOUT = 'LOGOUT',
  LOGIN_FAILED = 'LOGIN_FAILED',
  PASSWORD_CHANGED = 'PASSWORD_CHANGED',
  PASSWORD_RESET = 'PASSWORD_RESET',
  CONTEXT_SWITCHED = 'CONTEXT_SWITCHED',
  USER_CREATED = 'USER_CREATED',
  USER_UPDATED = 'USER_UPDATED',
  USER_DELETED = 'USER_DELETED',
  USER_RESTORED = 'USER_RESTORED',
  USER_DEACTIVATED = 'USER_DEACTIVATED',
  USER_ACTIVATED = 'USER_ACTIVATED',
  ROLE_ASSIGNED = 'ROLE_ASSIGNED',
  ROLE_REMOVED = 'ROLE_REMOVED',
  FACULTY_CREATED = 'FACULTY_CREATED',
  FACULTY_UPDATED = 'FACULTY_UPDATED',
  FACULTY_DELETED = 'FACULTY_DELETED',
  SUBJECT_CREATED = 'SUBJECT_CREATED',
  SUBJECT_UPDATED = 'SUBJECT_UPDATED',
  SUBJECT_DELETED = 'SUBJECT_DELETED',
  SUBJECT_USER_ASSIGNED = 'SUBJECT_USER_ASSIGNED',
  SUBJECT_USER_REMOVED = 'SUBJECT_USER_REMOVED',
  CONTENT_UPLOADED = 'CONTENT_UPLOADED',
  CONTENT_APPROVED = 'CONTENT_APPROVED',
  CONTENT_REJECTED = 'CONTENT_REJECTED',
  CONTENT_DELETED = 'CONTENT_DELETED',
  BOOK_CREATED = 'BOOK_CREATED',
  BOOK_UPDATED = 'BOOK_UPDATED',
  BOOK_DELETED = 'BOOK_DELETED',
  BOOK_APPROVED = 'BOOK_APPROVED',
  BOOK_REJECTED = 'BOOK_REJECTED',
  BOOK_PUBLISHED = 'BOOK_PUBLISHED',
  QUESTION_BANK_CREATED = 'QUESTION_BANK_CREATED',
  QUESTION_BANK_UPDATED = 'QUESTION_BANK_UPDATED',
  QUESTION_BANK_DELETED = 'QUESTION_BANK_DELETED',
  SETTINGS_CHANGED = 'SETTINGS_CHANGED',
  EXPORT_GENERATED = 'EXPORT_GENERATED',
  BULK_OPERATION = 'BULK_OPERATION',
}

export enum AuditCategory {
  AUTHENTICATION = 'AUTHENTICATION',
  USER_MANAGEMENT = 'USER_MANAGEMENT',
  ROLE_MANAGEMENT = 'ROLE_MANAGEMENT',
  FACULTY_MANAGEMENT = 'FACULTY_MANAGEMENT',
  SUBJECT_MANAGEMENT = 'SUBJECT_MANAGEMENT',
  CONTENT_MANAGEMENT = 'CONTENT_MANAGEMENT',
  BOOK_MANAGEMENT = 'BOOK_MANAGEMENT',
  QUESTION_MANAGEMENT = 'QUESTION_MANAGEMENT',
  SYSTEM = 'SYSTEM',
}

export interface AuditLog {
  id: string;
  userId?: string | null;
  userEmail?: string | null;
  userRole?: string | null;
  action: AuditAction;
  category: AuditCategory;
  targetType?: string | null;
  targetId?: string | null;
  targetName?: string | null;
  description?: string | null;
  metadata?: Record<string, unknown> | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  createdAt: string;
}

export interface AuditLogQueryParams {
  page?: number;
  limit?: number;
  action?: AuditAction;
  category?: AuditCategory;
  userId?: string;
  userEmail?: string;
  targetType?: string;
  targetId?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
}

export interface PaginatedAuditLogResponse {
  items: AuditLog[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

export interface AuditStats {
  totalEvents: number;
  eventsByCategory: Record<string, number>;
  eventsByAction: Record<string, number>;
  recentFailedLogins: number;
}

export const auditApi = {
  getAll: async (params?: AuditLogQueryParams): Promise<PaginatedAuditLogResponse> => {
    return apiClient.get<PaginatedAuditLogResponse>('/audit-logs', { params });
  },

  getStats: async (days = 7): Promise<AuditStats> => {
    return apiClient.get<AuditStats>('/audit-logs/stats', { params: { days } });
  },

  getAuthEvents: async (limit = 100): Promise<AuditLog[]> => {
    return apiClient.get<AuditLog[]>('/audit-logs/auth-events', { params: { limit } });
  },

  getByUser: async (userId: string, limit = 50): Promise<AuditLog[]> => {
    return apiClient.get<AuditLog[]>(`/audit-logs/user/${userId}`, { params: { limit } });
  },

  getByTarget: async (targetType: string, targetId: string, limit = 50): Promise<AuditLog[]> => {
    return apiClient.get<AuditLog[]>(`/audit-logs/target/${targetType}/${targetId}`, { params: { limit } });
  },
};
