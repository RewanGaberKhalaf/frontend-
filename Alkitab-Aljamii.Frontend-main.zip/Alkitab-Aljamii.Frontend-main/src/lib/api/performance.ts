import { apiClient } from './client';
import type {
  StudentDashboard,
  StudentPerformanceProfile,
  SubjectPerformance,
  PerformanceHistoryPoint,
  BenchmarkComparison,
  PerformanceGoal,
  StudyRecommendation,
  CreateGoalRequest,
  UpdateGoalRequest,
  ProfessorDashboard,
  ClassPerformanceStats,
  StudentPerformanceSummary,
  StudentListQuery,
  AtRiskAlert,
  AlertListQuery,
  Intervention,
  InterventionStatus,
  CreateInterventionRequest,
  FacultyPerformanceOverview,
  SubjectPerformanceOverview,
  ProfessorPerformanceSummary,
  AlertConfiguration,
  SystemPerformanceOverview,
} from './performance-types';

// Re-export all types for backwards compatibility
export * from './performance-types';

// ==================== API CLIENT ====================

export const performanceApi = {
  // ==================== STUDENT ENDPOINTS ====================
  student: {
    getDashboard: () =>
      apiClient.get<StudentDashboard>('/performance/student/dashboard'),

    getProfile: () =>
      apiClient.get<StudentPerformanceProfile>('/performance/student/profile'),

    getSubjects: () =>
      apiClient.get<SubjectPerformance[]>('/performance/student/subjects'),

    getHistory: (days: number = 30) =>
      apiClient.get<PerformanceHistoryPoint[]>(`/performance/student/history?days=${days}`),

    getBenchmarks: (subjectId?: string) =>
      apiClient.get<BenchmarkComparison[]>(
        `/performance/student/benchmarks${subjectId ? `?subjectId=${subjectId}` : ''}`
      ),

    getGoals: () =>
      apiClient.get<PerformanceGoal[]>('/performance/student/goals'),

    createGoal: (data: CreateGoalRequest) =>
      apiClient.post<PerformanceGoal>('/performance/student/goals', data),

    updateGoal: (goalId: string, data: UpdateGoalRequest) =>
      apiClient.patch<PerformanceGoal>(`/performance/student/goals/${goalId}`, data),

    cancelGoal: (goalId: string) =>
      apiClient.delete<void>(`/performance/student/goals/${goalId}`),

    getRecommendations: () =>
      apiClient.get<StudyRecommendation[]>('/performance/student/recommendations'),

    refreshMetrics: () =>
      apiClient.post<StudentPerformanceProfile>('/performance/student/refresh'),

    exportCsv: () =>
      apiClient.get<Blob>('/performance/student/export/csv', {
        responseType: 'blob',
      }),

    exportPdf: () =>
      apiClient.get<Blob>('/performance/student/export/pdf', {
        responseType: 'blob',
      }),
  },

  // ==================== PROFESSOR ENDPOINTS ====================
  professor: {
    getDashboard: () =>
      apiClient.get<ProfessorDashboard>('/performance/professor/dashboard'),

    getClassStats: (subjectId?: string) =>
      apiClient.get<ClassPerformanceStats>(
        `/performance/professor/stats${subjectId ? `?subjectId=${subjectId}` : ''}`
      ),

    getStudents: (query: StudentListQuery = {}) => {
      const params = new URLSearchParams();
      if (query.subjectId) params.append('subjectId', query.subjectId);
      if (query.riskLevel) params.append('riskLevel', query.riskLevel);
      if (query.sortBy) params.append('sortBy', query.sortBy);
      if (query.sortOrder) params.append('sortOrder', query.sortOrder);
      if (query.page) params.append('page', query.page.toString());
      if (query.limit) params.append('limit', query.limit.toString());
      return apiClient.get<{ students: StudentPerformanceSummary[]; total: number }>(
        `/performance/professor/students?${params.toString()}`
      );
    },

    getAtRiskStudents: () =>
      apiClient.get<StudentPerformanceSummary[]>('/performance/professor/students/at-risk'),

    getStudentDetail: (userId: string) =>
      apiClient.get<{
        profile: StudentPerformanceProfile;
        subjects: SubjectPerformance[];
        goals: PerformanceGoal[];
      }>(`/performance/professor/students/${userId}`),

    createStudentGoal: (userId: string, data: CreateGoalRequest) =>
      apiClient.post<PerformanceGoal>(`/performance/professor/students/${userId}/goals`, data),

    getAlerts: (query: AlertListQuery = {}) => {
      const params = new URLSearchParams();
      if (query.status) params.append('status', query.status);
      if (query.severity) params.append('severity', query.severity);
      if (query.page) params.append('page', query.page.toString());
      if (query.limit) params.append('limit', query.limit.toString());
      return apiClient.get<{ alerts: AtRiskAlert[]; total: number }>(
        `/performance/professor/alerts?${params.toString()}`
      );
    },

    acknowledgeAlert: (alertId: string) =>
      apiClient.patch<AtRiskAlert>(`/performance/professor/alerts/${alertId}/acknowledge`),

    resolveAlert: (alertId: string, note?: string) =>
      apiClient.patch<AtRiskAlert>(`/performance/professor/alerts/${alertId}/resolve`, { note }),

    getInterventions: (status?: InterventionStatus) =>
      apiClient.get<Intervention[]>(
        `/performance/professor/interventions${status ? `?status=${status}` : ''}`
      ),

    createIntervention: (data: CreateInterventionRequest) =>
      apiClient.post<Intervention>('/performance/professor/interventions', data),

    updateIntervention: (interventionId: string, data: { status?: InterventionStatus; note?: string; outcome?: string }) =>
      apiClient.patch<Intervention>(`/performance/professor/interventions/${interventionId}`, data),

    exportAtRiskCsv: () =>
      apiClient.get<Blob>('/performance/export/at-risk/csv', {
        responseType: 'blob',
      }),

    exportAtRiskPdf: () =>
      apiClient.get<Blob>('/performance/export/at-risk/pdf', {
        responseType: 'blob',
      }),
  },

  // ==================== FACULTY ADMIN ENDPOINTS ====================
  facultyAdmin: {
    getOverview: () =>
      apiClient.get<FacultyPerformanceOverview>('/performance/faculty-admin/overview'),

    getSubjects: () =>
      apiClient.get<SubjectPerformanceOverview[]>('/performance/faculty-admin/subjects'),

    getProfessors: () =>
      apiClient.get<ProfessorPerformanceSummary[]>('/performance/faculty-admin/professors'),

    getStudents: (query: StudentListQuery = {}) => {
      const params = new URLSearchParams();
      if (query.subjectId) params.append('subjectId', query.subjectId);
      if (query.riskLevel) params.append('riskLevel', query.riskLevel);
      if (query.sortBy) params.append('sortBy', query.sortBy);
      if (query.sortOrder) params.append('sortOrder', query.sortOrder);
      if (query.page) params.append('page', query.page.toString());
      if (query.limit) params.append('limit', query.limit.toString());
      return apiClient.get<{ students: StudentPerformanceSummary[]; total: number }>(
        `/performance/faculty-admin/students?${params.toString()}`
      );
    },

    getAtRiskStudents: () =>
      apiClient.get<StudentPerformanceSummary[]>('/performance/faculty-admin/students/at-risk'),

    getStudentDetail: (userId: string) =>
      apiClient.get<{
        profile: StudentPerformanceProfile;
        subjects: SubjectPerformance[];
      }>(`/performance/faculty-admin/students/${userId}`),

    getAlerts: (query: AlertListQuery = {}) => {
      const params = new URLSearchParams();
      if (query.status) params.append('status', query.status);
      if (query.severity) params.append('severity', query.severity);
      if (query.page) params.append('page', query.page.toString());
      if (query.limit) params.append('limit', query.limit.toString());
      return apiClient.get<{ alerts: AtRiskAlert[]; total: number }>(
        `/performance/faculty-admin/alerts?${params.toString()}`
      );
    },

    getAlertConfigurations: () =>
      apiClient.get<AlertConfiguration[]>('/performance/faculty-admin/config/alerts'),

    updateAlertConfiguration: (configId: string, data: Partial<AlertConfiguration>) =>
      apiClient.patch<AlertConfiguration>(`/performance/faculty-admin/config/alerts/${configId}`, data),

    exportAtRiskCsv: () =>
      apiClient.get<Blob>('/performance/export/at-risk/csv', {
        responseType: 'blob',
      }),

    exportAtRiskPdf: () =>
      apiClient.get<Blob>('/performance/export/at-risk/pdf', {
        responseType: 'blob',
      }),

    exportFacultyOverviewCsv: () =>
      apiClient.get<Blob>('/performance/export/faculty/csv', {
        responseType: 'blob',
      }),
  },

  // ==================== SUPER ADMIN ENDPOINTS ====================
  superAdmin: {
    getOverview: () =>
      apiClient.get<SystemPerformanceOverview>('/performance/super-admin/overview'),

    getFacultyDetail: (facultyId: string) =>
      apiClient.get<FacultyPerformanceOverview>(`/performance/super-admin/faculties/${facultyId}`),

    getAtRiskStudents: (facultyId?: string) =>
      apiClient.get<StudentPerformanceSummary[]>(
        `/performance/super-admin/at-risk${facultyId ? `?facultyId=${facultyId}` : ''}`
      ),

    getCriticalAlerts: (facultyId?: string) =>
      apiClient.get<{ alerts: AtRiskAlert[]; total: number }>(
        `/performance/super-admin/alerts/critical${facultyId ? `?facultyId=${facultyId}` : ''}`
      ),

    getStudents: (query: StudentListQuery = {}, facultyId?: string) => {
      const params = new URLSearchParams();
      if (facultyId) params.append('facultyId', facultyId);
      if (query.riskLevel) params.append('riskLevel', query.riskLevel);
      if (query.sortBy) params.append('sortBy', query.sortBy);
      if (query.sortOrder) params.append('sortOrder', query.sortOrder);
      if (query.page) params.append('page', query.page.toString());
      if (query.limit) params.append('limit', query.limit.toString());
      return apiClient.get<{ students: StudentPerformanceSummary[]; total: number }>(
        `/performance/super-admin/students?${params.toString()}`
      );
    },
  },
};

// ==================== EXPORT HELPERS ====================

/**
 * Helper function to download a blob as a file.
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
}

/**
 * Helper to export and download student performance as CSV.
 */
export async function downloadStudentPerformanceCsv(): Promise<void> {
  const blob = await performanceApi.student.exportCsv();
  downloadBlob(blob, `performance-report-${Date.now()}.csv`);
}

/**
 * Helper to export and download student performance as PDF.
 */
export async function downloadStudentPerformancePdf(): Promise<void> {
  const blob = await performanceApi.student.exportPdf();
  downloadBlob(blob, `performance-report-${Date.now()}.pdf`);
}

/**
 * Helper to export and download at-risk students report as CSV.
 */
export async function downloadAtRiskStudentsCsv(): Promise<void> {
  const blob = await performanceApi.professor.exportAtRiskCsv();
  downloadBlob(blob, `at-risk-students-${Date.now()}.csv`);
}

/**
 * Helper to export and download at-risk students report as PDF.
 */
export async function downloadAtRiskStudentsPdf(): Promise<void> {
  const blob = await performanceApi.professor.exportAtRiskPdf();
  downloadBlob(blob, `at-risk-students-${Date.now()}.pdf`);
}

/**
 * Helper to export and download faculty overview as CSV.
 */
export async function downloadFacultyOverviewCsv(): Promise<void> {
  const blob = await performanceApi.facultyAdmin.exportFacultyOverviewCsv();
  downloadBlob(blob, `faculty-performance-${Date.now()}.csv`);
}
