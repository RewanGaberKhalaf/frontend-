import { apiClient } from './client';
import type { LoginCredentials, LoginResponse, RefreshResponse } from '@/types';

export interface SwitchContextRequest {
  activeView: string;
  facultyId?: string;
}

export interface SwitchContextResponse {
  accessToken: string;
  expiresIn: number;
  activeView: string;
  facultyId?: string;
}

export interface RefreshRequest {
  refreshToken: string;
  activeView?: string;
  facultyId?: string;
}

export interface CompleteProfileRequest {
  nationalId: string;
  email: string;
  password: string;
}

export interface CompleteProfileResponse {
  success: boolean;
  message: string;
}

export const authApi = {
  login: (credentials: LoginCredentials) =>
    apiClient.post<LoginResponse>('/auth/login', credentials),

  refresh: (data: RefreshRequest) =>
    apiClient.post<RefreshResponse>('/auth/refresh', data),

  logout: (refreshToken: string) =>
    apiClient.post<void>('/auth/logout', { refreshToken }),

  switchContext: (data: SwitchContextRequest) =>
    apiClient.post<SwitchContextResponse>('/auth/switch-context', data),

  completeProfile: (data: CompleteProfileRequest) =>
    apiClient.post<CompleteProfileResponse>('/auth/complete-profile', data),
};
