import { apiClient, getApiBaseUrl } from './client';
import type { Content, CreateContentDto, PaginationParams, PaginatedResponse } from '@/types';

const BASE_URL = '/contents';


export interface ContentQueryParams extends PaginationParams {
  status?: string;
  subjectId?: string | string[];
  facultyId?: string | string[];
  uploaderId?: string | string[];
}

export interface PageCountResponse {
  totalPages: number;
  chunkSize: number;
}

export const contentApi = {
  // Returns paginated content - backend now returns standard { items, meta } format
  getAll: (params?: ContentQueryParams) =>
    apiClient.get<PaginatedResponse<Content>>(BASE_URL, { params }),

  getById: (id: string) =>
    apiClient.get<Content>(`${BASE_URL}/${id}`),

  upload: (data: CreateContentDto, file: File) => {
    const formData = new FormData();
    formData.append('title', data.title);
    if (data.titleAr) {
      formData.append('titleAr', data.titleAr);
    }
    formData.append('subjectId', data.subjectId);
    formData.append('contentType', data.contentType);
    if (data.description) {
      formData.append('description', data.description);
    }
    if (data.descriptionAr) {
      formData.append('descriptionAr', data.descriptionAr);
    }
    formData.append('file', file);
    return apiClient.upload<Content>(`${BASE_URL}/upload`, formData);
  },

  approve: (id: string) =>
    apiClient.put<Content>(`${BASE_URL}/${id}/approve`, {}),

  reject: (id: string, reason: string) =>
    apiClient.put<Content>(`${BASE_URL}/${id}/reject`, { reason }),

  delete: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}`),

  getStreamUrl: (id: string) =>
    `${getApiBaseUrl()}${BASE_URL}/${id}/stream`,

  // Paginated PDF endpoints
  getPageCount: (id: string) =>
    apiClient.get<PageCountResponse>(`${BASE_URL}/${id}/page-count`),

  getPagesUrl: (id: string, start: number, count: number) =>
    `${getApiBaseUrl()}${BASE_URL}/${id}/pages?start=${start}&count=${count}`,
};
