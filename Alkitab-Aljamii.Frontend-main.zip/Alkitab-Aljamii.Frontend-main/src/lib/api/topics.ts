import { apiClient } from './client';
import type {
  Topic,
  CreateTopicData,
  UpdateTopicData,
  TopicQueryParams,
  BulkCreateTopicsData,
  BulkCreateTopicsResult,
  PaginatedTopicResponse,
} from './topic-types';

// Re-export all types
export type {
  Topic,
  CreateTopicData,
  UpdateTopicData,
  TopicQueryParams,
  BulkCreateTopicsData,
  BulkCreateTopicsResult,
  PaginatedTopicResponse,
} from './topic-types';

// API endpoint base - topics are scoped under subjects
const getTopicsUrl = (subjectId: string) => `/subjects/${subjectId}/topics`;

export const topicsApi = {
  /**
   * Get all topics for a subject with pagination
   */
  getTopics: (subjectId: string, params?: TopicQueryParams) =>
    apiClient.get<PaginatedTopicResponse>(getTopicsUrl(subjectId), { params }),

  /**
   * Get all active topics for a subject (no pagination, for dropdowns)
   */
  getAllActiveTopics: (subjectId: string) =>
    apiClient.get<PaginatedTopicResponse>(getTopicsUrl(subjectId), {
      params: { isActive: true, limit: 1000 },
    }),

  /**
   * Get a single topic by ID
   */
  getTopic: (subjectId: string, topicId: string) =>
    apiClient.get<Topic>(`${getTopicsUrl(subjectId)}/${topicId}`),

  /**
   * Create a new topic
   */
  createTopic: (subjectId: string, data: CreateTopicData) =>
    apiClient.post<Topic>(getTopicsUrl(subjectId), data),

  /**
   * Bulk create topics
   */
  bulkCreateTopics: (subjectId: string, data: BulkCreateTopicsData) =>
    apiClient.post<BulkCreateTopicsResult>(`${getTopicsUrl(subjectId)}/bulk`, data),

  /**
   * Update a topic
   */
  updateTopic: (subjectId: string, topicId: string, data: UpdateTopicData) =>
    apiClient.put<Topic>(`${getTopicsUrl(subjectId)}/${topicId}`, data),

  /**
   * Delete a topic (soft delete)
   */
  deleteTopic: (subjectId: string, topicId: string) =>
    apiClient.delete<void>(`${getTopicsUrl(subjectId)}/${topicId}`),
};
