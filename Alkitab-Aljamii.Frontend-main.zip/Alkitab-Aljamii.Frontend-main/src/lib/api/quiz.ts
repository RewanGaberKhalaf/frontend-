import { apiClient } from './client';
import type { PaginatedResponse } from '@/types';
import type {
  QuestionBank,
  CreateQuestionBankData,
  UpdateQuestionBankData,
  QuestionBankQueryParams,
  Quiz,
  CreateQuizData,
  UpdateQuizData,
  QuizQueryParams,
  Question,
  CreateQuestionData,
  UpdateQuestionData,
  QuestionQueryParams,
  ChapterQuizConfig,
  CreateChapterQuizConfigData,
  UpdateChapterQuizConfigData,
  ChapterProgress,
  BookChapterProgress,
  ChapterQuizStatus,
  QuizAttempt,
  QuizAttemptDetail,
  QuizAttemptResult,
  ImportQuestionsResult,
} from './quiz-types';

// Re-export all types for backwards compatibility
export type {
  QuestionBank,
  CreateQuestionBankData,
  UpdateQuestionBankData,
  QuestionBankQueryParams,
  Quiz,
  CreateQuizData,
  UpdateQuizData,
  QuizQueryParams,
  QuestionType,
  Difficulty,
  QuestionOption,
  Question,
  CreateQuestionData,
  UpdateQuestionData,
  QuestionQueryParams,
  ChapterQuizConfig,
  CreateChapterQuizConfigData,
  UpdateChapterQuizConfigData,
  ChapterProgress,
  BookChapterProgress,
  ChapterQuizStatus,
  AttemptStatus,
  QuizAttempt,
  AttemptQuestion,
  QuizAttemptDetail,
  QuizAttemptResult,
  ImportQuestionsResult,
} from './quiz-types';

// ==================== API ENDPOINTS ====================

const QUESTION_BANK_URL = '/question-banks';
const QUIZ_URL = '/quizzes';
const CHAPTER_QUIZ_CONFIG_URL = '/chapter-quiz-configs';
const CHAPTER_PROGRESS_URL = '/chapter-progress';

export const quizApi = {
  // ========================= QUESTION BANKS =============================
  getQuestionBanks: (params?: QuestionBankQueryParams) =>
    apiClient.get<PaginatedResponse<QuestionBank>>(QUESTION_BANK_URL, { params }),

  getQuestionBank: (id: string) =>
    apiClient.get<QuestionBank>(`${QUESTION_BANK_URL}/${id}`),

  createQuestionBank: (data: CreateQuestionBankData) =>
    apiClient.post<QuestionBank>(QUESTION_BANK_URL, data),

  updateQuestionBank: (id: string, data: UpdateQuestionBankData) =>
    apiClient.put<QuestionBank>(`${QUESTION_BANK_URL}/${id}`, data),

  deleteQuestionBank: (id: string) =>
    apiClient.delete<void>(`${QUESTION_BANK_URL}/${id}`),

  getQuizzesByQuestionBank: (bankId: string) =>
    apiClient.get<Quiz[]>(`${QUESTION_BANK_URL}/${bankId}/quizzes`),

  getDifficultyCounts: (bankId: string, topicIds?: string[]) =>
    apiClient.get<{ easy: number; medium: number; hard: number }>(
      `${QUESTION_BANK_URL}/${bankId}/difficulty-counts`,
      { params: topicIds?.length ? { topicIds } : undefined }
    ),

  // ========================= QUESTIONS =============================
  getQuestions: (bankId: string, params?: QuestionQueryParams) =>
    apiClient.get<PaginatedResponse<Question>>(`${QUESTION_BANK_URL}/${bankId}/questions`, { params }),

  getQuestion: (bankId: string, questionId: string) =>
    apiClient.get<Question>(`${QUESTION_BANK_URL}/${bankId}/questions/${questionId}`),

  createQuestion: (bankId: string, data: CreateQuestionData) =>
    apiClient.post<Question>(`${QUESTION_BANK_URL}/${bankId}/questions`, data),

  updateQuestion: (bankId: string, questionId: string, data: UpdateQuestionData) =>
    apiClient.put<Question>(`${QUESTION_BANK_URL}/${bankId}/questions/${questionId}`, data),

  deleteQuestion: (bankId: string, questionId: string) =>
    apiClient.delete<void>(`${QUESTION_BANK_URL}/${bankId}/questions/${questionId}`),

  importQuestions: (bankId: string, file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return apiClient.post<ImportQuestionsResult>(
      `${QUESTION_BANK_URL}/${bankId}/questions/import`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    );
  },

  downloadImportTemplate: async () => {
    const response = await apiClient.get<Blob>(
      `${QUESTION_BANK_URL}/import/template`,
      { responseType: 'blob' }
    );
    // Create download link - response is the Blob directly or wrapped in data
    const blob = 'data' in response && response.data instanceof Blob ? response.data : response as unknown as Blob;
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'question-import-template.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  },

  // ========================= QUIZZES =============================
  getQuizzes: (params?: QuizQueryParams) =>
    apiClient.get<PaginatedResponse<Quiz>>(QUIZ_URL, { params }),

  getQuiz: (id: string) =>
    apiClient.get<Quiz>(`${QUIZ_URL}/${id}`),

  getQuizzesByBank: (bankId: string) =>
    apiClient.get<PaginatedResponse<Quiz>>(QUIZ_URL, { params: { bankId } }),

  createQuiz: (data: CreateQuizData) =>
    apiClient.post<Quiz>(QUIZ_URL, data),

  updateQuiz: (id: string, data: UpdateQuizData) =>
    apiClient.put<Quiz>(`${QUIZ_URL}/${id}`, data),

  deleteQuiz: (id: string) =>
    apiClient.delete<void>(`${QUIZ_URL}/${id}`),

  // ========================= QUIZ ATTEMPTS =============================
  startQuizAttempt: (quizId: string, chapterId?: string) =>
    apiClient.post<QuizAttemptDetail>(`${QUIZ_URL}/${quizId}/start`, { chapterId }),

  saveAnswer: (attemptId: string, questionId: string, selectedOptionId: string) =>
    apiClient.post<void>(`${QUIZ_URL}/attempts/${attemptId}/answer`, { questionId, selectedOptionId }),

  submitQuizAttempt: (attemptId: string, answers?: Record<string, string>) =>
    apiClient.post<QuizAttemptResult>(`${QUIZ_URL}/attempts/${attemptId}/submit`, { answers }),

  getActiveAttempt: (attemptId: string) =>
    apiClient.get<QuizAttemptDetail>(`${QUIZ_URL}/attempts/${attemptId}/active`),

  getQuizAttempt: (attemptId: string) =>
    apiClient.get<QuizAttemptResult>(`${QUIZ_URL}/attempts/${attemptId}`),

  getMyAttempts: (quizId?: string) =>
    apiClient.get<PaginatedResponse<QuizAttempt>>(`${QUIZ_URL}/my-attempts`, {
      params: quizId ? { quizId } : undefined,
    }),

  getAllAttempts: (quizId: string, params?: { page?: number; limit?: number }) =>
    apiClient.get<PaginatedResponse<QuizAttempt>>(`${QUIZ_URL}/${quizId}/attempts`, { params }),

  // ========================= CHAPTER QUIZ CONFIG =============================
  getChapterQuizConfig: (chapterId: string) =>
    apiClient.get<ChapterQuizConfig | null>(`${CHAPTER_QUIZ_CONFIG_URL}/chapter/${chapterId}`),

  getBookQuizConfigs: (bookId: string) =>
    apiClient.get<ChapterQuizConfig[]>(`${CHAPTER_QUIZ_CONFIG_URL}/book/${bookId}`),

  createChapterQuizConfig: (data: CreateChapterQuizConfigData) =>
    apiClient.post<ChapterQuizConfig>(CHAPTER_QUIZ_CONFIG_URL, data),

  updateChapterQuizConfig: (configId: string, data: UpdateChapterQuizConfigData) =>
    apiClient.put<ChapterQuizConfig>(`${CHAPTER_QUIZ_CONFIG_URL}/${configId}`, data),

  deleteChapterQuizConfig: (configId: string) =>
    apiClient.delete<void>(`${CHAPTER_QUIZ_CONFIG_URL}/${configId}`),

  // ========================= CHAPTER PROGRESS =============================
  getBookProgress: (bookId: string) =>
    apiClient.get<BookChapterProgress>(`${CHAPTER_PROGRESS_URL}/book/${bookId}`),

  getChapterProgress: (chapterId: string) =>
    apiClient.get<ChapterProgress | null>(`${CHAPTER_PROGRESS_URL}/chapter/${chapterId}`),

  initializeBookProgress: (bookId: string) =>
    apiClient.post<void>(`${CHAPTER_PROGRESS_URL}/book/${bookId}/initialize`),

  getChapterQuizStatus: (chapterId: string) =>
    apiClient.get<ChapterQuizStatus>(`${CHAPTER_PROGRESS_URL}/chapter/${chapterId}/quiz-status`),

  processQuizCompletion: (attemptId: string) =>
    apiClient.post<{ success: boolean; chapterId?: string; chapterTitle?: string }>(
      `${CHAPTER_PROGRESS_URL}/quiz-attempt/${attemptId}/process`
    ),

  updateReadingTime: (chapterId: string, readingTimeMs: number) =>
    apiClient.post<void>(`${CHAPTER_PROGRESS_URL}/chapter/${chapterId}/reading-time`, { readingTimeMs }),
};
