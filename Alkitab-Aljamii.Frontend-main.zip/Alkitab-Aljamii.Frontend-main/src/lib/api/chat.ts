import { apiClient, getApiBaseUrl } from './client';
import { getAccessToken } from './interceptors';

// ============ Types ============

export type ConversationType = 'book_qa' | 'tos_qa';

export interface ChatContext {
  bookId?: string;
  chapterId?: string;
  facultyId?: string;
  currentPage?: number;
  pageContent?: string;
}

export interface ChatSource {
  chunkId: string;
  content: string;
  score: number;
  chapterId?: string;
  chapterTitle?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  contextChunks?: ChatSource[];
  pageContext?: {
    currentPage?: number;
    chapterId?: string;
  };
  helpful?: boolean | null;
  createdAt: string;
}

export interface Conversation {
  id: string;
  conversationType: ConversationType;
  bookId: string | null;
  facultyId: string | null;
  title: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  messageCount?: number;
  lastMessage?: string;
}

export interface ConversationWithMessages extends Conversation {
  messages: ChatMessage[];
}

export interface ChatResponse {
  answer: string;
  sources: ChatSource[];
  messageId: string;
}

export interface CreateConversationDto {
  conversationType: ConversationType;
  bookId?: string;
  facultyId?: string;
}

export interface SendMessageDto {
  message: string;
  context?: ChatContext;
}

export interface AiHealthStatus {
  enabled: boolean;
  embedding: boolean;
  llm: boolean;
}

export interface StreamEvent {
  type: 'chunk' | 'sources' | 'done' | 'error' | 'message_id';
  data: unknown;
}

export type StreamCallback = (event: StreamEvent) => void;

// ============ API Client ============

const BASE_URL = '/ai-assistant';

export const chatApi = {
  // ========================= HEALTH =========================
  /**
   * Check if AI service is enabled and healthy
   */
  getHealth: () =>
    apiClient.get<AiHealthStatus>(`${BASE_URL}/health`),

  // ========================= CONVERSATIONS =========================
  /**
   * Get all conversations for the current user
   */
  getConversations: (conversationType?: ConversationType) =>
    apiClient.get<Conversation[]>(`${BASE_URL}/chat/conversations`, {
      params: conversationType ? { conversationType } : undefined,
    }),

  /**
   * Get a single conversation with all messages
   */
  getConversation: (conversationId: string) =>
    apiClient.get<ConversationWithMessages>(`${BASE_URL}/chat/conversations/${conversationId}`),

  /**
   * Create a new conversation
   */
  createConversation: (data: CreateConversationDto) =>
    apiClient.post<Conversation>(`${BASE_URL}/chat/conversations`, data),

  /**
   * Delete a conversation (soft delete)
   */
  deleteConversation: (conversationId: string) =>
    apiClient.delete<void>(`${BASE_URL}/chat/conversations/${conversationId}`),

  // ========================= MESSAGES =========================
  /**
   * Send a message and get AI response
   */
  sendMessage: (conversationId: string, data: SendMessageDto) =>
    apiClient.post<ChatResponse>(`${BASE_URL}/chat/conversations/${conversationId}/messages`, data),

  /**
   * Submit feedback for a message
   */
  submitFeedback: (messageId: string, helpful: boolean) =>
    apiClient.post<void>(`${BASE_URL}/chat/messages/feedback`, { messageId, helpful }),

  /**
   * Send a message with streaming response
   * Uses native fetch for SSE support
   */
  sendMessageStream: async (
    conversationId: string,
    data: SendMessageDto,
    onEvent: StreamCallback,
  ): Promise<void> => {
    const token = getAccessToken();
    const url = `${getApiBaseUrl()}${BASE_URL}/chat/conversations/${conversationId}/messages/stream`;

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : '',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    if (!response.body) {
      throw new Error('No response body for streaming');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();

      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');

      // Process complete lines, keep incomplete line in buffer
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const event = JSON.parse(line.slice(6)) as StreamEvent;
            onEvent(event);
          } catch {
            // Skip malformed JSON
          }
        }
      }
    }
  },

  // ========================= QUICK QUESTION (No Conversation) =========================
  /**
   * Ask a quick question without creating a conversation
   * Useful for in-context help
   */
  askQuestion: (question: string, context?: ChatContext) =>
    apiClient.post<{ answer: string; sources: ChatSource[] }>(`${BASE_URL}/chat/ask`, {
      question,
      context,
    }),
};
