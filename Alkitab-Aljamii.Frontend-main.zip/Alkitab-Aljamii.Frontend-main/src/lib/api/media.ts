import { apiClient, getApiBaseUrl } from './client';

const BASE_URL = '/media';

/**
 * Resolve a media URL to a full URL
 * Backend returns relative URLs like /media/:id/view?token=...
 * Uses same base URL as API client for consistency
 */
export function resolveMediaUrl(url: string): string {
  if (!url) return url;
  // Already an absolute URL
  if (url.startsWith('http://') || url.startsWith('https://')) {
    return url;
  }
  // Relative URL - prepend API base
  return `${getApiBaseUrl()}${url}`;
}

/**
 * Media type
 */
export type MediaType = 'image' | 'video' | 'audio' | 'document';

/**
 * Media item from the backend
 */
export interface MediaItem {
  id: string;
  name: string;
  type: MediaType;
  mimeType: string;
  size: number;
  url: string;
  thumbnailUrl?: string;
  tags: string[];
  createdAt: string;
}

/**
 * Paginated media response (from API client unwrapper)
 */
export interface PaginatedMediaResponse {
  items: MediaItem[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

/**
 * Query parameters for listing media
 */
export interface MediaQueryParams {
  type?: MediaType | 'all';
  search?: string;
  tags?: string[];
  page?: number;
  limit?: number;
}

/**
 * Upload parameters
 */
export interface UploadMediaParams {
  file: File;
  name?: string;
  tags?: string[];
}

/**
 * Update parameters
 */
export interface UpdateMediaParams {
  name?: string;
  tags?: string[];
}

export const mediaApi = {
  /**
   * Get all media items with optional filtering and pagination
   */
  getAll: (params?: MediaQueryParams) =>
    apiClient.get<PaginatedMediaResponse>(BASE_URL, {
      params: {
        ...params,
        tags: params?.tags?.join(','),
      },
    }),

  /**
   * Get a single media item by ID
   */
  getById: (id: string) =>
    apiClient.get<MediaItem>(`${BASE_URL}/${id}`),

  /**
   * Upload a new media file
   */
  upload: ({ file, name, tags }: UploadMediaParams) => {
    const formData = new FormData();
    formData.append('file', file);
    if (name) {
      formData.append('name', name);
    }
    if (tags && tags.length > 0) {
      formData.append('tags', tags.join(','));
    }
    return apiClient.upload<MediaItem>(`${BASE_URL}/upload`, formData);
  },

  /**
   * Update media item metadata
   */
  update: (id: string, data: UpdateMediaParams) =>
    apiClient.patch<MediaItem>(`${BASE_URL}/${id}`, data),

  /**
   * Delete a media item (soft delete)
   */
  delete: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}`),

  /**
   * Permanently delete a media item
   */
  deletePermanent: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}/permanent`),

  /**
   * Get a signed URL for the media file
   */
  getSignedUrl: (id: string, expiresIn?: number) =>
    apiClient.get<{ url: string; expiresIn: number }>(`${BASE_URL}/${id}/url`, {
      params: { expiresIn },
    }),

  /**
   * Get the stream URL for direct access (requires auth header)
   */
  getStreamUrl: (id: string) =>
    `${getApiBaseUrl()}${BASE_URL}/${id}/stream`,
};
