/**
 * Reading Time API
 *
 * API endpoints for reading time tracking and analytics.
 */

import { apiClient } from './client';
import type {
  StudentReadingOverview,
  BookReadingStats,
  ChapterReadingStats,
  ReadingSession,
  UpdateReadingTimeDto,
  BatchReadingTimeUpdate,
  PageTimeRecord,
  BookReadingAnalytics,
  FacultyReadingOverview,
  PlatformReadingOverview,
  SubjectReadingAnalytics,
  StudentBookReadingDetail,
  FacultyReadingComparison,
} from '@/types';

const READING_TIME_URL = '/reading-time';
const ANALYTICS_URL = '/analytics';

export const readingTimeApi = {
  // ============================================
  // Student Endpoints
  // ============================================

  /**
   * Get personal reading overview (total time, streaks, recent activity)
   */
  getOverview: () =>
    apiClient.get<StudentReadingOverview>(`${READING_TIME_URL}/overview`),

  /**
   * Get reading stats for a specific book
   */
  getBookStats: (bookId: string) =>
    apiClient.get<BookReadingStats>(`${READING_TIME_URL}/book/${bookId}`),

  /**
   * Get reading stats for a specific chapter
   */
  getChapterStats: (chapterId: string) =>
    apiClient.get<ChapterReadingStats>(`${READING_TIME_URL}/chapter/${chapterId}`),

  /**
   * Start a new reading session
   */
  startSession: (chapterId: string, bookId: string) =>
    apiClient.post<ReadingSession>(`${READING_TIME_URL}/session/start`, {
      chapterId,
      bookId,
    }),

  /**
   * End current reading session
   */
  endSession: (sessionId: string, finalData?: { readingTimeMs: number; pageRecords?: PageTimeRecord[] }) =>
    apiClient.post<ReadingSession>(`${READING_TIME_URL}/session/${sessionId}/end`, finalData),

  /**
   * Send heartbeat to keep session alive and sync data
   */
  heartbeat: (sessionId: string, data: { readingTimeMs: number; pageRecords?: PageTimeRecord[] }) =>
    apiClient.post<void>(`${READING_TIME_URL}/session/${sessionId}/heartbeat`, data),

  /**
   * Update reading time for a chapter (simple update without session)
   */
  updateReadingTime: (data: UpdateReadingTimeDto) => {
    // Transform to backend expected format (exclude chapterId from body, map pageRecords fields)
    const body: {
      readingTimeMs: number;
      sessionId?: string;
      isSessionEnd?: boolean;
      pageRecords?: Array<{
        page: number;
        timeMs: number;
        firstViewed?: string;
        lastViewed?: string;
        viewCount?: number;
      }>;
    } = {
      readingTimeMs: data.readingTimeMs,
      sessionId: data.sessionId,
      isSessionEnd: data.isSessionEnd,
    };

    if (data.pageRecords && data.pageRecords.length > 0) {
      body.pageRecords = data.pageRecords.map((record) => ({
        page: record.pageNumber,
        timeMs: record.timeSpentMs,
        firstViewed: record.firstViewedAt,
        lastViewed: record.lastViewedAt,
        viewCount: record.viewCount,
      }));
    }

    return apiClient.post<void>(
      `/chapter-progress/chapter/${data.chapterId}/reading-time`,
      body
    );
  },

  /**
   * Batch update reading time for multiple chapters
   */
  batchUpdateReadingTime: (data: BatchReadingTimeUpdate) =>
    apiClient.post<{ success: boolean; processed: number }>(
      `${READING_TIME_URL}/batch`,
      data
    ),

  // ============================================
  // Professor Analytics Endpoints
  // ============================================

  /**
   * Get reading analytics for a book (professor view)
   */
  getBookReadingAnalytics: (bookId: string) =>
    apiClient.get<BookReadingAnalytics>(
      `${ANALYTICS_URL}/professor/book/${bookId}/reading-time`
    ),

  /**
   * Get student reading details for a specific book
   */
  getStudentReadingDetails: (bookId: string, studentId: string) =>
    apiClient.get<StudentBookReadingDetail>(
      `${ANALYTICS_URL}/professor/book/${bookId}/student/${studentId}/reading-time`
    ),

  // ============================================
  // Faculty Admin Analytics Endpoints
  // ============================================

  /**
   * Get faculty-wide reading overview
   */
  getFacultyReadingOverview: () =>
    apiClient.get<FacultyReadingOverview>(
      `${ANALYTICS_URL}/faculty/reading-time/overview`
    ),

  /**
   * Get reading analytics for a subject
   */
  getSubjectReadingAnalytics: (subjectId: string) =>
    apiClient.get<SubjectReadingAnalytics>(
      `${ANALYTICS_URL}/faculty/subject/${subjectId}/reading-time`
    ),

  // ============================================
  // Super Admin Analytics Endpoints
  // ============================================

  /**
   * Get platform-wide reading overview
   */
  getPlatformReadingOverview: () =>
    apiClient.get<PlatformReadingOverview>(
      `${ANALYTICS_URL}/super-admin/reading-time/overview`
    ),

  /**
   * Get reading comparison across all faculties
   */
  getFacultyReadingComparison: () =>
    apiClient.get<FacultyReadingComparison[]>(
      `${ANALYTICS_URL}/super-admin/faculties/reading-time`
    ),
};

export default readingTimeApi;
