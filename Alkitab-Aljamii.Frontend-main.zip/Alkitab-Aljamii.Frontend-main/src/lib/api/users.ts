import { apiClient } from './client';
import type {
  User,
  CreateUserDto,
  UpdateUserDto,
  PaginationParams,
  PaginatedResponse,
  FacultyRole,
} from '@/types';

const BASE_URL = '/users';

export interface UserFilterParams extends PaginationParams {
  role?: FacultyRole;
  isActive?: boolean;
  facultyId?: string;
  subjectId?: string;
  isSuperAdmin?: boolean;
}

export interface UserFaculty {
  id: string;
  name: string;
  code: string;
  role: 'faculty_admin' | 'professor' | 'student';
}

export interface UserSubject {
  id: string;
  name: string;
  code: string;
  facultyName: string;
}

export interface UserAssociations {
  faculties: UserFaculty[];
  subjects: UserSubject[];
  adminOf?: { id: string; name: string; code: string }[];
}

export type ViewRole = 'super_admin' | 'faculty_admin' | 'professor' | 'student';

export interface AvailableView {
  role: ViewRole;
  facultyId?: string;
  facultyName?: string;
}

export interface AvailableViews {
  primaryRole: ViewRole;
  primaryFacultyId?: string;
  availableViews: AvailableView[];
  // Current active context from JWT token
  currentView?: ViewRole;
  currentFacultyId?: string;
}

export interface EmailCheckResult {
  exists: boolean;
  user?: {
    id: string;
    firstName: string;
    lastName: string;
    isSuperAdmin: boolean;
  };
}

export const usersApi = {
  // Get users with role-based filtering
  // Super Admin: all users, can filter by faculty/subject/role
  // Faculty Admin: users in their faculties
  // Professor: students in their subjects
  getAll: (params?: UserFilterParams) =>
    apiClient.get<PaginatedResponse<User>>(BASE_URL, { params }),

  // Get current user profile
  getMe: () => apiClient.get<User>(`${BASE_URL}/me`),

  // Get faculties accessible to current user
  getMyFaculties: (view?: string) =>
    apiClient.get<UserFaculty[]>(`${BASE_URL}/me/faculties`, {
      params: view ? { view } : undefined,
    }),

  // Get available views/roles for current user
  getAvailableViews: () => apiClient.get<AvailableViews>(`${BASE_URL}/me/available-views`),

  // Check if email exists
  checkEmail: (email: string) => apiClient.get<EmailCheckResult>(`${BASE_URL}/check-email`, { params: { email } }),

  getById: (id: string) =>
    apiClient.get<User>(`${BASE_URL}/${id}`),

  getAssociations: (id: string) =>
    apiClient.get<UserAssociations>(`${BASE_URL}/${id}/associations`),

  create: (data: CreateUserDto) =>
    apiClient.post<User>(BASE_URL, data),

  update: (id: string, data: UpdateUserDto) =>
    apiClient.patch<User>(`${BASE_URL}/${id}`, data),

  delete: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}`),

  updatePassword: (id: string, password: string) =>
    apiClient.patch<void>(`${BASE_URL}/${id}/password`, { password }),

  restore: (id: string) =>
    apiClient.post<User>(`${BASE_URL}/${id}/restore`),
};
