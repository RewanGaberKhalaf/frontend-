// ==================== ENUMS ====================

export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';
export type GoalStatus = 'active' | 'completed' | 'expired' | 'cancelled';
export type GoalType = 'book_completion' | 'chapter_completion' | 'quiz_score' | 'study_time' | 'quiz_pass_rate';
export type AlertStatus = 'pending' | 'acknowledged' | 'in_progress' | 'resolved' | 'escalated' | 'dismissed';
export type AlertType = 'low_engagement' | 'declining_performance' | 'quiz_failures' | 'missed_deadline' | 'inactivity' | 'low_completion_rate';
export type InterventionType = 'reach_out' | 'assign_remedial' | 'schedule_meeting' | 'adjust_deadline' | 'provide_resources' | 'escalate';
export type InterventionStatus = 'planned' | 'in_progress' | 'completed' | 'cancelled';

// ==================== STUDENT DTOs ====================

export interface StudentPerformanceProfile {
  id: string;
  userId: string;
  facultyId: string;
  academicPerformanceIndex: number;
  apiTrend: string | null;
  booksStarted: number;
  booksCompleted: number;
  chaptersCompleted: number;
  totalChaptersAvailable: number;
  overallCompletionRate: number;
  totalQuizzesTaken: number;
  quizzesPassed: number;
  averageQuizScore: number;
  quizPassRate: number;
  totalStudyTimeMinutes: number;
  avgDailyStudyTimeMinutes: number;
  lastActivityAt: string | null;
  activeDaysLast30: number;
  currentStreak: number;
  longestStreak: number;
  engagementScore: number;
  learningVelocity: number;
  riskLevel: RiskLevel;
  riskScore: number;
  facultyPercentile: number | null;
  lastComputedAt: string;
}

export interface SubjectPerformance {
  subjectId: string;
  subjectName: string;
  subjectNameAr: string | null;
  chaptersCompleted: number;
  totalChapters: number;
  completionRate: number;
  avgQuizScore: number;
  quizzesPassed: number;
  quizzesTaken: number;
  studyTimeMinutes: number;
  masteryLevel: number;
  lastActivityAt: string | null;
}

export interface PerformanceHistoryPoint {
  date: string;
  academicPerformanceIndex: number;
  completionRate: number;
  avgQuizScore: number;
  studyTimeMinutes: number;
  chaptersCompleted: number;
  quizzesPassed: number;
  activeDays: number;
}

export interface BenchmarkComparison {
  metric: string;
  studentValue: number;
  facultyAverage: number;
  subjectAverage: number | null;
  percentile: number;
}

export interface PerformanceGoal {
  id: string;
  type: GoalType;
  titleEn: string;
  titleAr: string | null;
  descriptionEn: string | null;
  descriptionAr: string | null;
  targetValue: number;
  currentValue: number;
  unit: string;
  progressPercent: number;
  deadline: string | null;
  status: GoalStatus;
  setBy: string;
  subjectId: string | null;
  bookId: string | null;
  createdAt: string;
}

export interface StudyRecommendation {
  id: string;
  type: string;
  titleEn: string;
  titleAr: string | null;
  reasonEn: string;
  reasonAr: string | null;
  priority: number;
  deepLink: string | null;
  chapterId: string | null;
  quizId: string | null;
  bookId: string | null;
  createdAt: string;
}

export interface StudentDashboard {
  profile: StudentPerformanceProfile;
  subjects: SubjectPerformance[];
  activeGoals: PerformanceGoal[];
  recommendations: StudyRecommendation[];
  benchmarks: BenchmarkComparison[];
}

// ==================== PROFESSOR DTOs ====================

export interface StudentPerformanceSummary {
  userId: string;
  firstName: string;
  lastName: string;
  email: string | null;
  academicPerformanceIndex: number;
  apiTrend: string | null;
  overallCompletionRate: number;
  averageQuizScore: number;
  engagementScore: number;
  riskLevel: RiskLevel;
  lastActivityAt: string | null;
  activeAlerts: number;
}

export interface AtRiskAlert {
  id: string;
  userId: string;
  studentName: string;
  alertType: AlertType;
  severity: RiskLevel;
  titleEn: string;
  titleAr: string | null;
  descriptionEn: string;
  descriptionAr: string | null;
  status: AlertStatus;
  assignedToName: string | null;
  triggeredAt: string;
  acknowledgedAt: string | null;
  resolvedAt: string | null;
}

export interface Intervention {
  id: string;
  userId: string;
  studentName: string;
  type: InterventionType;
  titleEn: string;
  titleAr: string | null;
  descriptionEn: string | null;
  descriptionAr: string | null;
  status: InterventionStatus;
  professorName: string;
  preInterventionApi: number;
  postInterventionApi: number | null;
  createdAt: string;
  completedAt: string | null;
}

export interface ProfessorDashboard {
  totalStudents: number;
  averageApi: number;
  atRiskCount: number;
  pendingAlerts: number;
  activeInterventions: number;
  topPerformers: StudentPerformanceSummary[];
  atRiskStudents: StudentPerformanceSummary[];
  recentAlerts: AtRiskAlert[];
}

export interface ClassPerformanceStats {
  totalStudents: number;
  averageApi: number;
  averageCompletionRate: number;
  averageQuizScore: number;
  atRiskCount: number;
  highPerformersCount: number;
  riskDistribution: {
    low: number;
    moderate: number;
    high: number;
    critical: number;
  };
}

// ==================== FACULTY ADMIN DTOs ====================

export interface ProfessorPerformanceSummary {
  userId: string;
  firstName: string;
  lastName: string;
  email: string | null;
  studentCount: number;
  averageStudentApi: number;
  atRiskStudentCount: number;
  activeInterventions: number;
  completedInterventions: number;
  interventionSuccessRate: number;
}

export interface FacultyPerformanceOverview {
  totalStudents: number;
  totalProfessors: number;
  averageApi: number;
  averageCompletionRate: number;
  averageQuizScore: number;
  atRiskStudentCount: number;
  criticalAlertCount: number;
  pendingAlertCount: number;
  activeInterventions: number;
  riskDistribution: {
    low: number;
    moderate: number;
    high: number;
    critical: number;
  };
  apiTrend: { date: string; value: number }[];
}

export interface SubjectPerformanceOverview {
  subjectId: string;
  subjectName: string;
  subjectNameAr: string | null;
  studentCount: number;
  averageApi: number;
  averageCompletionRate: number;
  averageQuizScore: number;
  atRiskCount: number;
}

export interface AlertConfiguration {
  id: string;
  alertType: AlertType;
  isEnabled: boolean;
  thresholdValue: number;
  thresholdUnit: string;
  lookbackDays: number;
  assignedRiskLevel: RiskLevel;
  escalateAfterDays: number | null;
}

// ==================== SUPER ADMIN DTOs ====================

export interface FacultySummary {
  facultyId: string;
  facultyName: string;
  facultyNameAr: string | null;
  studentCount: number;
  professorCount: number;
  averageApi: number;
  atRiskCount: number;
  criticalAlertCount: number;
}

export interface SystemPerformanceOverview {
  totalFaculties: number;
  totalStudents: number;
  totalProfessors: number;
  systemAverageApi: number;
  totalAtRiskStudents: number;
  totalCriticalAlerts: number;
  totalActiveInterventions: number;
  faculties: FacultySummary[];
  apiTrend: { date: string; value: number }[];
}

// ==================== REQUEST DTOs ====================

export interface CreateGoalRequest {
  type: GoalType;
  titleEn: string;
  titleAr?: string;
  descriptionEn?: string;
  descriptionAr?: string;
  targetValue: number;
  unit: string;
  deadline?: string;
  subjectId?: string;
  bookId?: string;
}

export interface UpdateGoalRequest {
  titleEn?: string;
  titleAr?: string;
  descriptionEn?: string;
  descriptionAr?: string;
  targetValue?: number;
  deadline?: string;
  status?: GoalStatus;
}

export interface CreateInterventionRequest {
  userId: string;
  type: InterventionType;
  titleEn: string;
  titleAr?: string;
  descriptionEn?: string;
  descriptionAr?: string;
  alertId?: string;
}

export interface StudentListQuery {
  subjectId?: string;
  riskLevel?: RiskLevel;
  sortBy?: 'api' | 'name' | 'lastActivity' | 'completionRate';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface AlertListQuery {
  status?: AlertStatus;
  severity?: RiskLevel;
  page?: number;
  limit?: number;
}
