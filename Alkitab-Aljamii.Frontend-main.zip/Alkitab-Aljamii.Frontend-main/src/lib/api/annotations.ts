import { apiClient } from './client';
import type {
  Annotation,
  AnnotationComment,
  PaginatedAnnotations,
  PaginatedComments,
  CreateAnnotationDto,
  UpdateAnnotationDto,
  CreateCommentDto,
  UpdateCommentDto,
  QueryAnnotationsParams,
  QueryBookmarksParams,
  AnnotationDashboard,
  AnnotationStats,
} from '@/types';

const BASE_URL = '/annotations';
const PROFESSOR_URL = '/professor/annotations';

export const annotationsApi = {
  // ========================= ANNOTATIONS =============================

  /**
   * Create a new annotation
   */
  create: (data: CreateAnnotationDto) =>
    apiClient.post<Annotation>(BASE_URL, data),

  /**
   * Get annotations for a book
   */
  getBookAnnotations: (bookId: string, params?: QueryAnnotationsParams) =>
    apiClient.get<PaginatedAnnotations>(`${BASE_URL}/book/${bookId}`, { params }),

  /**
   * Get annotations for a chapter
   */
  getChapterAnnotations: (chapterId: string, params?: QueryAnnotationsParams) =>
    apiClient.get<PaginatedAnnotations>(`${BASE_URL}/chapter/${chapterId}`, { params }),

  /**
   * Get current user's bookmarks
   */
  getMyBookmarks: (params?: QueryBookmarksParams) =>
    apiClient.get<Annotation[]>(`${BASE_URL}/my-bookmarks`, { params }),

  /**
   * Get annotation by ID
   */
  getById: (id: string) =>
    apiClient.get<Annotation>(`${BASE_URL}/${id}`),

  /**
   * Update annotation
   */
  update: (id: string, data: UpdateAnnotationDto) =>
    apiClient.patch<Annotation>(`${BASE_URL}/${id}`, data),

  /**
   * Delete annotation
   */
  delete: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/${id}`),

  // ========================= COMMENTS =============================

  /**
   * Add comment to annotation
   */
  addComment: (annotationId: string, data: CreateCommentDto) =>
    apiClient.post<AnnotationComment>(`${BASE_URL}/${annotationId}/comments`, data),

  /**
   * Update comment
   */
  updateComment: (commentId: string, data: UpdateCommentDto) =>
    apiClient.patch<AnnotationComment>(`${BASE_URL}/comments/${commentId}`, data),

  /**
   * Delete comment
   */
  deleteComment: (commentId: string) =>
    apiClient.delete<void>(`${BASE_URL}/comments/${commentId}`),

  // ========================= PROFESSOR ENDPOINTS =============================

  /**
   * Get annotation dashboard for professor
   */
  getDashboard: (params?: { bookId?: string; dateFrom?: string; dateTo?: string; recentLimit?: number }) =>
    apiClient.get<AnnotationDashboard>(`${PROFESSOR_URL}/dashboard`, { params }),

  /**
   * Get annotation statistics for a book
   */
  getBookStats: (bookId: string) =>
    apiClient.get<AnnotationStats>(`${PROFESSOR_URL}/stats/${bookId}`),

  /**
   * Get all annotations for a book (professor view)
   */
  getAllBookAnnotations: (bookId: string, params?: QueryAnnotationsParams) =>
    apiClient.get<PaginatedAnnotations>(`${PROFESSOR_URL}/book/${bookId}/all`, { params }),
};
