// ==================== QUESTION BANK TYPES ====================

export interface QuestionBank {
  id: string;
  name: string;
  nameAr: string | null;
  subjectId: string;
  subjectName: string;
  subjectNameAr: string | null;
  description: string | null;
  descriptionAr: string | null;
  totalQuestions: number;
  easyCount: number;
  mediumCount: number;
  hardCount: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateQuestionBankData {
  name: string;
  nameAr?: string;
  subjectId: string;
  description?: string;
  descriptionAr?: string;
}

export interface UpdateQuestionBankData {
  name?: string;
  nameAr?: string;
  description?: string;
  descriptionAr?: string;
  isActive?: boolean;
}

export interface QuestionBankQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  subjectId?: string;
  isActive?: boolean;
}

// ==================== QUIZ TYPES ====================

export interface Quiz {
  id: string;
  bankId: string;
  bankName: string;
  bankNameAr: string | null;
  title: string;
  titleAr: string | null;
  description: string | null;
  descriptionAr: string | null;
  easyQuestions: number;
  mediumQuestions: number;
  hardQuestions: number;
  totalQuestions: number;
  timeLimit: number | null;
  passingScore: number;
  maxAttempts: number | null;
  cooldownMinutes: number | null;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  isPoolBased: boolean;
  topicIds: string[];
  isActive: boolean;
  availableFrom: string | null;
  availableUntil: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateQuizData {
  bankId: string;
  topicIds?: string[];
  title: string;
  titleAr?: string;
  description?: string;
  descriptionAr?: string;
  easyQuestions: number;
  mediumQuestions: number;
  hardQuestions: number;
  timeLimit?: number;
  passingScore: number;
  maxAttempts?: number;
  cooldownMinutes?: number;
  shuffleQuestions?: boolean;
  shuffleOptions?: boolean;
  isPoolBased?: boolean;
  showAnswers?: 'immediately' | 'after_submission' | 'after_passing' | 'after_all_attempts' | 'never';
  availableFrom?: string;
  availableUntil?: string;
}

export interface UpdateQuizData {
  topicIds?: string[];
  title?: string;
  titleAr?: string;
  description?: string;
  descriptionAr?: string;
  easyQuestions?: number;
  mediumQuestions?: number;
  hardQuestions?: number;
  timeLimit?: number | null;
  passingScore?: number;
  maxAttempts?: number | null;
  cooldownMinutes?: number | null;
  shuffleQuestions?: boolean;
  shuffleOptions?: boolean;
  isPoolBased?: boolean;
  showAnswers?: 'immediately' | 'after_submission' | 'after_passing' | 'after_all_attempts' | 'never';
  availableFrom?: string | null;
  availableUntil?: string | null;
  isActive?: boolean;
}

export interface QuizQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  bankId?: string;
  isActive?: boolean;
}

// ==================== QUESTION TYPES ====================

export type QuestionType = 'multiple_choice' | 'true_false';
export type Difficulty = 'easy' | 'medium' | 'hard';

export interface QuestionOption {
  id: string;
  text: string;
  textAr: string | null;
  isCorrect: boolean;
  order: number;
}

export interface Question {
  id: string;
  bankId: string;
  topicId: string | null;
  questionText: string;
  questionTextAr: string | null;
  questionType: QuestionType;
  difficulty: Difficulty;
  topic: string | null;
  topicAr: string | null;
  options: QuestionOption[];
  explanation: string | null;
  explanationAr: string | null;
  points: number;
  chapterId: string | null;
  isActive: boolean;
  timesUsed: number;
  timesCorrect: number;
  correctRate: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateQuestionData {
  topicId?: string;
  questionText: string;
  questionTextAr?: string;
  questionType: QuestionType;
  difficulty: Difficulty;
  topic?: string;
  topicAr?: string;
  options: Array<{
    text: string;
    textAr?: string;
    isCorrect: boolean;
    order: number;
  }>;
  explanation?: string;
  explanationAr?: string;
  points?: number;
  chapterId?: string;
}

export interface UpdateQuestionData {
  topicId?: string | null;
  questionText?: string;
  questionTextAr?: string;
  questionType?: QuestionType;
  difficulty?: Difficulty;
  topic?: string;
  topicAr?: string;
  options?: Array<{
    text: string;
    textAr?: string;
    isCorrect: boolean;
    order: number;
  }>;
  explanation?: string;
  explanationAr?: string;
  points?: number;
  chapterId?: string;
  isActive?: boolean;
}

export interface QuestionQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  difficulty?: Difficulty;
  questionType?: QuestionType;
  topicId?: string;
  topic?: string;
  chapterId?: string;
  isActive?: boolean;
}

// ==================== CHAPTER QUIZ CONFIG TYPES ====================

export interface ChapterQuizConfig {
  id: string;
  chapterId: string;
  chapterTitle: string;
  chapterTitleAr: string | null;
  chapterOrder: number;
  bankId: string;
  bankName: string;
  bankNameAr: string | null;
  quizId: string;
  useChapterQuestionsOnly: boolean;
  easyQuestions: number;
  mediumQuestions: number;
  hardQuestions: number;
  totalQuestions: number;
  timeLimit: number | null;
  passingThreshold: number;
  maxAttempts: number | null;
  cooldownMinutes: number | null;
  isRequired: boolean;
  unlockNextChapter: boolean;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateChapterQuizConfigData {
  chapterId: string;
  bankId: string;
  useChapterQuestionsOnly?: boolean;
  easyQuestions?: number;
  mediumQuestions?: number;
  hardQuestions?: number;
  timeLimit?: number;
  passingThreshold?: number;
  maxAttempts?: number;
  cooldownMinutes?: number;
  isRequired?: boolean;
  unlockNextChapter?: boolean;
  shuffleQuestions?: boolean;
  shuffleOptions?: boolean;
}

export interface UpdateChapterQuizConfigData {
  bankId?: string;
  useChapterQuestionsOnly?: boolean;
  easyQuestions?: number;
  mediumQuestions?: number;
  hardQuestions?: number;
  timeLimit?: number | null;
  passingThreshold?: number;
  maxAttempts?: number | null;
  cooldownMinutes?: number | null;
  isRequired?: boolean;
  unlockNextChapter?: boolean;
  shuffleQuestions?: boolean;
  shuffleOptions?: boolean;
  isActive?: boolean;
}

// ==================== CHAPTER PROGRESS TYPES ====================

export interface ChapterProgress {
  id: string;
  userId: string;
  chapterId: string;
  chapterTitle: string;
  chapterTitleAr: string | null;
  chapterOrder: number;
  bookId: string;
  bookTitle: string;
  bookTitleAr: string | null;
  isUnlocked: boolean;
  unlockedAt: string | null;
  bestScore: number | null;
  attemptCount: number;
  passedAt: string | null;
  lastReadAt: string | null;
  readingTimeMs: number;
  quizRequired: boolean;
  passingThreshold: number;
}

export interface BookChapterProgress {
  bookId: string;
  bookTitle: string;
  bookTitleAr: string | null;
  totalChapters: number;
  unlockedChapters: number;
  completedChapters: number;
  chapters: ChapterProgress[];
}

export interface ChapterQuizStatus {
  chapterId: string;
  chapterTitle: string;
  chapterTitleAr: string | null;
  chapterOrder: number;
  hasQuiz: boolean;
  quizId: string | null;
  isUnlocked: boolean;
  canAttempt: boolean;
  bestScore: number | null;
  attemptCount: number;
  maxAttempts: number | null;
  passingThreshold: number;
  hasPassed: boolean;
  nextChapterId: string | null;
  nextChapterUnlocked: boolean;
  cooldownMinutes: number | null;
  cooldownEndsAt: string | null;
  isCooldownActive: boolean;
}

// ==================== QUIZ ATTEMPT TYPES ====================

export type AttemptStatus = 'in_progress' | 'submitted' | 'timed_out' | 'abandoned';

export interface QuizAttempt {
  id: string;
  quizId: string;
  quizTitle: string;
  quizTitleAr: string | null;
  userId: string;
  userFirstName?: string | null;
  userLastName?: string | null;
  userEmail?: string | null;
  attemptNumber: number;
  status: AttemptStatus;
  score: number | null;
  correctCount: number | null;
  totalQuestions: number;
  passed: boolean | null;
  startedAt: string;
  submittedAt: string | null;
  timeSpent: number | null;
  timeLimit: number | null;
}

export interface AttemptQuestion {
  id: string;
  questionId?: string;
  questionText: string;
  questionTextAr: string | null;
  questionType: QuestionType;
  options: Array<{
    key: string;
    text: string;
    textAr?: string | null;
  }>;
  orderIndex?: number;
}

export interface QuizAttemptDetail extends QuizAttempt {
  questions: AttemptQuestion[];
  answers: Record<string, string>;
}

export interface QuizAttemptResult extends QuizAttempt {
  questions: Array<{
    id: string;
    questionText: string;
    questionTextAr: string | null;
    questionType: QuestionType;
    options: Array<{
      id: string;
      text: string;
      textAr: string | null;
      order: number;
      isCorrect?: boolean;
    }>;
    selectedAnswer: string | null;
    correctAnswer: string | null;
    isCorrect: boolean;
    explanation: string | null;
    explanationAr: string | null;
    points: number;
    earnedPoints: number;
  }>;
  chapterUnlocked?: boolean;
  nextChapterId?: string | null;
  bookId?: string | null;
}

// ==================== IMPORT TYPES ====================

export interface ImportQuestionsResult {
  totalProcessed: number;
  successCount: number;
  errorCount: number;
  errors: string[];
}
