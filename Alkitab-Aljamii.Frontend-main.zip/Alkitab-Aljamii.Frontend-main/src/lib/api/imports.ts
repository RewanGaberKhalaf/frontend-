import { BulkOperationType } from '@/components/bulkImport/types';
import { EditTemplateForm } from '../validations/edit-template.schema';
import { apiClient } from './client';
import type { ImportType, Template} from '@/components/bulkImport/types';
export interface UploadFileResponse {
  templateId: string;
  fileMetadata: {
    headerColumns: string[];
  };
  requiredColumns: {
    required: string[];
    optional: string[];
  };
}

export interface SaveMappingsRequest {
  mappings: Record<string, string>;
}

export interface QuickUploadResponse {
  jobId: string;
}

export interface ImportResult {
  jobId: string;
  status: 'completed' | 'failed' | 'processing';
  totalRows: number;
  successCount: number;
  failureCount: number;
  errorFileUrl: string | null;
  result: {
    id: string;
    name: string;
    operation: string;
  };
}

export interface ApiTemplate {
  id: string;
  name: string;
  operation: string;
  status: string;
  userId: string;
  facultyId: string | null;
  mappings: {
    sourceColumnName: string;
    targetColumnName: string;
  }[];
  createdAt: string;
}


export const importsApi = {
  /**
   * Upload Excel file and get column information
   * POST /imports/upload/{role}
   */
  uploadFile: async (
    formData: FormData,
    role: 'super-admin' | 'faculty-admin' = 'faculty-admin'
  ): Promise<UploadFileResponse> => {
    return apiClient.upload<UploadFileResponse>(
      `/imports/upload/${role}`,
      formData
    );
  },

  /**
   * Save column mappings for a template
   * POST /imports/templates/:id/mappings
   */
  saveMappings: async (
    templateId: string,
    mappings: Record<string, string>
  ): Promise<void> => {
    await apiClient.post(`/imports/templates/${templateId}/mappings`, {
      mappings,
    });
  },

  /**
   * Get all templates
   * GET /imports/templates
   */
  getTemplates: async (facultyId?: string): Promise<Template[]> => {
    const params = facultyId ? { facultyId } : undefined;
    const apiTemplates = await apiClient.get<ApiTemplate[]>('/imports/templates', { params });
    
    // Transform API response to match frontend Template interface
    const validImportTypes: ImportType[] = [
      'students_only',
      'students_with_subjects',
      'professors_only',
      'professors_with_subjects',
      'student_enrollments',
      'professor_assignments',
      'student_unenrollments',
      'professor_unassignments',
    ];
    
    return apiTemplates.map((apiTemplate) => ({
      id: apiTemplate.id,
      name: apiTemplate.name,
      importType: validImportTypes.includes(apiTemplate.operation as ImportType)
        ? (apiTemplate.operation as ImportType)
        : 'students_only',
      facultyId: apiTemplate.facultyId ?? 'unknown',
      columnMappings: (apiTemplate.mappings || []).map((m) => ({
        excelColumn: m.sourceColumnName,
        databaseColumn: m.targetColumnName,
        isMatched: false,
      })),
      createdAt: new Date(apiTemplate.createdAt),
      updatedAt: new Date(apiTemplate.createdAt),
    }));
  },

  /**
   * Delete a template
   * DELETE /imports/templates/:id
   */
  deleteTemplate: async (templateId: string): Promise<void> => {
    await apiClient.delete(`/imports/templates/${templateId}`);
  },
  /**
   *Edit a template
   */
   updateTemplate: async (id: string, data: EditTemplateForm & { operation: BulkOperationType }) => {
    const bulkToImportMap: Record<BulkOperationType, string> = {
      [BulkOperationType.STUDENTS_ONLY]: 'students_only',
      [BulkOperationType.PROFESSORS_ONLY]: 'professors_only',
      [BulkOperationType.USERS]: 'student_enrollments', // default example
    };

    const payload = {
      ...data,
      operation: bulkToImportMap[data.operation],
    };

    const res = await apiClient.patch<Template>(`/imports/templates/${id}`, payload);
    return res; 
  },
  

  /**
   * Upload Excel file with existing template
   * POST /imports/upload/faculty-admin
   */
  uploadWithTemplate: async (
    formData: FormData,
    role: 'super-admin' | 'faculty-admin' = 'faculty-admin'
  ): Promise<QuickUploadResponse> => {
    return apiClient.upload<QuickUploadResponse>(
      `/imports/upload/${role}`,
      formData
    );
  },

  /**
   * Get import job status and results
   * GET /imports/{jobId}/result
   */
  getImportResult: async (jobId: string): Promise<ImportResult> => {
    return apiClient.get<ImportResult>(`/imports/${jobId}/result`);
  },
};
