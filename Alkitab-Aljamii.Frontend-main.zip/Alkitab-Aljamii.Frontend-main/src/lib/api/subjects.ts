import { apiClient } from './client';
import type {
  Subject,
  CreateSubjectDto,
  UpdateSubjectDto,
  SubjectAssignment,
  PaginationParams,
  PaginatedResponse,
} from '@/types';

export interface SubjectFilterParams extends PaginationParams {
  facultyId?: string | string[];
  search?: string;
  isActive?: boolean;
}

export const subjectsApi = {
  // List subjects with filters (role-based access)
  getAll: (params?: SubjectFilterParams) =>
    apiClient.get<PaginatedResponse<Subject>>('/subjects', { params }),

  // Get subjects for a specific faculty
  getByFaculty: (facultyId: string, params?: PaginationParams) =>
    apiClient.get<PaginatedResponse<Subject>>('/subjects', {
      params: { ...params, facultyId },
    }),

  getById: (id: string) => apiClient.get<Subject>(`/subjects/${id}`),

  // Create subject (facultyId in body)
  create: (data: CreateSubjectDto & { facultyId: string }) =>
    apiClient.post<Subject>('/subjects', data),

  update: (id: string, data: UpdateSubjectDto) =>
    apiClient.patch<Subject>(`/subjects/${id}`, data),

  delete: (id: string) => apiClient.delete<void>(`/subjects/${id}`),

  // Get assignments (professors and students) with search and pagination
  getAssignments: (
    subjectId: string,
    params?: {
      search?: string;
      roleInSubject?: 'professor' | 'student';
      page?: number;
      limit?: number;
    }
  ) =>
    apiClient.get<PaginatedResponse<SubjectAssignment>>(
      `/subjects/${subjectId}/assignments`,
      { params }
    ),

  // Assign user to subject
  assignUser: (subjectId: string, userId: string, roleInSubject: string) =>
    apiClient.post<void>(`/subjects/${subjectId}/assignments/${userId}`, {
      roleInSubject,
    }),

  // Remove user from subject
  removeUser: (subjectId: string, userId: string) =>
    apiClient.delete<void>(`/subjects/${subjectId}/assignments/${userId}`),
};
