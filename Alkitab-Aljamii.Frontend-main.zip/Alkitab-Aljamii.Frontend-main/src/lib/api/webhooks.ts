import { apiClient } from './client';

export interface ExternalSystem {
  id: string;
  code: string;
  name: string;
  description?: string;
  apiKeyPrefix: string;
  allowedIps: string[];
  rateLimitPerMinute: number;
  isActive: boolean;
  lastWebhookAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExternalSystemWithCredentials extends ExternalSystem {
  apiKey: string;
  hmacSecret: string;
}

export interface CreateExternalSystemDto {
  code: string;
  name: string;
  description?: string;
  allowedIps?: string[];
  rateLimitPerMinute?: number;
}

export interface UpdateExternalSystemDto {
  name?: string;
  description?: string;
  allowedIps?: string[];
  rateLimitPerMinute?: number;
  isActive?: boolean;
}

export interface RotateKeysResponse {
  apiKey: string;
  hmacSecret: string;
  apiKeyPrefix: string;
}

export type MappingStatus = 'pending' | 'approved' | 'rejected' | 'auto_matched';

export interface CourseMapping {
  id: string;
  externalSystemId: string;
  externalSystemCode: string;
  externalSystemName: string;
  externalCourseCode: string;
  externalCourseName?: string;
  subjectId?: string;
  subjectName?: string;
  subjectCode?: string;
  facultyId: string;
  facultyName: string;
  facultyCode: string;
  status: MappingStatus;
  approvedById?: string;
  approvedByName?: string;
  approvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CourseMappingQuery {
  status?: MappingStatus;
  externalSystemId?: string;
  facultyId?: string;
}

export interface ApproveMappingDto {
  subjectId: string;
}

const BASE_URL = '/admin';

export const webhooksApi = {
  // External Systems (Super Admin)
  getSystems: () =>
    apiClient.get<ExternalSystem[]>(`${BASE_URL}/external-systems`),

  getSystem: (id: string) =>
    apiClient.get<ExternalSystem>(`${BASE_URL}/external-systems/${id}`),

  createSystem: (data: CreateExternalSystemDto) =>
    apiClient.post<ExternalSystemWithCredentials>(`${BASE_URL}/external-systems`, data),

  updateSystem: (id: string, data: UpdateExternalSystemDto) =>
    apiClient.patch<ExternalSystem>(`${BASE_URL}/external-systems/${id}`, data),

  deleteSystem: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/external-systems/${id}`),

  activateSystem: (id: string) =>
    apiClient.post<void>(`${BASE_URL}/external-systems/${id}/activate`),

  deactivateSystem: (id: string) =>
    apiClient.post<void>(`${BASE_URL}/external-systems/${id}/deactivate`),

  rotateKeys: (id: string) =>
    apiClient.post<RotateKeysResponse>(`${BASE_URL}/external-systems/${id}/rotate-keys`),

  // Course Mappings (Super Admin - all)
  getAllMappings: (query?: CourseMappingQuery) =>
    apiClient.get<CourseMapping[]>(`${BASE_URL}/course-mappings`, { params: query }),

  // Course Mappings (Faculty Admin - by faculty)
  getFacultyMappings: (status?: MappingStatus) =>
    apiClient.get<CourseMapping[]>(`${BASE_URL}/faculty/course-mappings`, { params: { status } }),

  getPendingCount: () =>
    apiClient.get<{ count: number }>(`${BASE_URL}/faculty/course-mappings/pending-count`),

  // Course Mapping Operations
  getMapping: (id: string) =>
    apiClient.get<CourseMapping>(`${BASE_URL}/course-mappings/${id}`),

  approveMapping: (id: string, data: ApproveMappingDto) =>
    apiClient.post<CourseMapping>(`${BASE_URL}/course-mappings/${id}/approve`, data),

  rejectMapping: (id: string) =>
    apiClient.post<CourseMapping>(`${BASE_URL}/course-mappings/${id}/reject`),

  deleteMapping: (id: string) =>
    apiClient.delete<void>(`${BASE_URL}/course-mappings/${id}`),
};
