import { apiClient, axiosInstance, getApiBaseUrl } from './client';
import { authTokens } from '../storage/cookie-storage';

// ============ Types ============

export type NotificationType =
  | 'annotation_digest'
  | 'new_annotation'
  | 'comment_reply'
  | 'announcement'
  | 'comment_response'
  | 'course_update'
  | 'batch_import_complete'
  | 'batch_import_failed'
  | 'system_alert';

export type NotificationPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface Notification {
  id: string;
  type: NotificationType;
  priority: NotificationPriority;
  title: string;
  message: string;
  deepLink?: string | null;
  metadata?: Record<string, unknown> | null;
  isRead: boolean;
  readAt?: string | null;
  createdAt: string;
  expiresAt?: string | null;
}

export interface PaginatedNotifications {
  items: Notification[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

export interface NotificationPreferences {
  id: string;
  inAppEnabled: boolean;
  emailEnabled: boolean;
  typePreferences?: Record<string, { inApp: boolean; email: boolean }> | null;
  digestEnabled: boolean;
  digestIntervalMinutes: number;
  quietHoursEnabled: boolean;
  quietHoursStart?: string | null;
  quietHoursEnd?: string | null;
}

export interface UpdatePreferencesRequest {
  inAppEnabled?: boolean;
  emailEnabled?: boolean;
  typePreferences?: Record<string, { inApp: boolean; email: boolean }>;
  digestEnabled?: boolean;
  digestIntervalMinutes?: number;
  quietHoursEnabled?: boolean;
  quietHoursStart?: string;
  quietHoursEnd?: string;
}

export interface QueryNotificationsParams {
  page?: number;
  limit?: number;
  type?: NotificationType;
  isRead?: boolean;
  sortBy?: string;
  sortOrder?: 'ASC' | 'DESC';
}

// ============ SSE Event Types ============

export interface SSENotificationEvent {
  type: 'notification';
  data: Notification;
  timestamp: string;
}

export interface SSEUnreadCountEvent {
  type: 'unread_count';
  data: { count: number };
  timestamp: string;
}

export interface SSEPingEvent {
  type: 'ping';
  data: { timestamp: number };
  timestamp: string;
}

export type SSEEvent = SSENotificationEvent | SSEUnreadCountEvent | SSEPingEvent;

// ============ API Functions ============

export const notificationsApi = {
  /**
   * Get paginated notifications
   */
  getAll: (params?: QueryNotificationsParams): Promise<PaginatedNotifications> =>
    apiClient.get<PaginatedNotifications>('/notifications', { params }),

  /**
   * Get unread notification count
   */
  getUnreadCount: (): Promise<{ count: number }> =>
    apiClient.get<{ count: number }>('/notifications/unread-count'),

  /**
   * Get single notification
   */
  getById: (id: string): Promise<Notification> =>
    apiClient.get<Notification>(`/notifications/${id}`),

  /**
   * Mark notifications as read
   */
  markAsRead: (ids: string[]): Promise<void> =>
    apiClient.post<void>('/notifications/mark-read', { ids }),

  /**
   * Mark all notifications as read
   */
  markAllAsRead: (): Promise<void> =>
    apiClient.post<void>('/notifications/mark-all-read'),

  /**
   * Delete notifications
   */
  deleteNotifications: (ids: string[]): Promise<void> =>
    apiClient.delete<void>('/notifications', { data: { ids } }),

  /**
   * Get notification preferences
   */
  getPreferences: (): Promise<NotificationPreferences> =>
    apiClient.get<NotificationPreferences>('/notifications/preferences'),

  /**
   * Update notification preferences
   */
  updatePreferences: (data: UpdatePreferencesRequest): Promise<NotificationPreferences> =>
    apiClient.post<NotificationPreferences>('/notifications/preferences', data),

  /**
   * Create SSE connection for real-time notifications
   * Returns a cleanup function to close the connection
   */
  createSSEConnection: (
    onNotification: (notification: Notification) => void,
    onUnreadCount: (count: number) => void,
    onError?: (error: Event) => void,
    onOpen?: () => void,
  ): (() => void) => {
    const token = authTokens.getAccessToken();
    const baseUrl = getApiBaseUrl();
    const url = token
      ? `${baseUrl}/notifications/stream?token=${encodeURIComponent(token)}`
      : `${baseUrl}/notifications/stream`;
    const eventSource = new EventSource(url);

    eventSource.onopen = () => {
      console.log('[SSE] Connection established');
      onOpen?.();
    };

    eventSource.onmessage = (event) => {
      try {
        const wrapper = JSON.parse(event.data) as { data: SSEEvent };
        const parsed = wrapper.data;

        switch (parsed.type) {
          case 'notification':
            onNotification(parsed.data);
            break;
          case 'unread_count':
            onUnreadCount(parsed.data.count);
            break;
          case 'ping':
            // Keep-alive ping, no action needed
            break;
        }
      } catch (err) {
        console.error('[SSE] Failed to parse event:', err);
      }
    };

    eventSource.onerror = (error) => {
      console.error('[SSE] Connection error:', error);
      onError?.(error);
    };

    // Return cleanup function
    return () => {
      console.log('[SSE] Closing connection');
      eventSource.close();
    };
  },
};

// ============ Announcement Types & API ============

export type FacultyRole = 'faculty_admin' | 'professor' | 'student';

export interface Announcement {
  id: string;
  titleEn: string;
  titleAr?: string | null;
  messageEn: string;
  messageAr?: string | null;
  facultyId?: string | null;
  subjectId?: string | null;
  targetRole?: FacultyRole | null;
  useTemplate: boolean;
  deepLink?: string | null;
  scheduledAt?: string | null;
  sentAt?: string | null;
  expiresAt?: string | null;
  isDraft: boolean;
  isSent: boolean;
  createdAt: string;
  totalRecipients?: number;
  readCount?: number;
  readRate?: number;
}

export interface CreateAnnouncementRequest {
  titleEn: string;
  titleAr?: string;
  messageEn: string;
  messageAr?: string;
  facultyId?: string;
  subjectId?: string;
  targetRole?: FacultyRole;
  useTemplate?: boolean;
  deepLink?: string;
  scheduledAt?: string;
  expiresAt?: string;
  isDraft?: boolean;
}

export interface QueryAnnouncementsParams {
  page?: number;
  limit?: number;
  facultyId?: string;
  subjectId?: string;
  isDraft?: boolean;
  isSent?: boolean;
}

export interface PaginatedAnnouncements {
  items: Announcement[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

export interface AnnouncementAnalytics {
  totalRecipients: number;
  delivered: number;
  read: number;
  readRate: number;
  timeline: Array<{ date: string; count: number }>;
}

export const announcementsApi = {
  /**
   * Create announcement
   */
  create: (data: CreateAnnouncementRequest): Promise<Announcement> =>
    apiClient.post<Announcement>('/announcements', data),

  /**
   * Get paginated announcements
   */
  getAll: (params?: QueryAnnouncementsParams): Promise<PaginatedAnnouncements> =>
    apiClient.get<PaginatedAnnouncements>('/announcements', { params }),

  /**
   * Get single announcement with analytics
   */
  getById: (id: string): Promise<Announcement> =>
    apiClient.get<Announcement>(`/announcements/${id}`),

  /**
   * Update announcement (drafts only)
   */
  update: (id: string, data: Partial<CreateAnnouncementRequest>): Promise<Announcement> =>
    apiClient.patch<Announcement>(`/announcements/${id}`, data),

  /**
   * Delete announcement
   */
  delete: (id: string): Promise<void> =>
    apiClient.delete<void>(`/announcements/${id}`),

  /**
   * Send announcement to recipients
   */
  send: (id: string, userIds?: string[]): Promise<{ sentCount: number }> =>
    apiClient.post<{ sentCount: number }>(`/announcements/${id}/send`, { userIds }),

  /**
   * Mark announcement as read
   */
  markAsRead: (id: string): Promise<void> =>
    apiClient.post<void>(`/announcements/${id}/read`),

  /**
   * Get announcement analytics
   */
  getAnalytics: (id: string): Promise<AnnouncementAnalytics> =>
    apiClient.get<AnnouncementAnalytics>(`/announcements/${id}/analytics`),
};
