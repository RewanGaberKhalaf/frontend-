import { apiClient } from './client';

// ============ Types ============

export interface UniversityTos {
  id: string;
  contentJson: string | null;
  contentJsonAr: string | null;
  publishedContentJson: string | null;
  publishedContentJsonAr: string | null;
  version: number;
  isIndexed: boolean;
  lastIndexedAt: string | null;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface FacultyTos {
  id: string;
  facultyId: string;
  facultyName?: string;
  contentJson: string | null;
  contentJsonAr: string | null;
  publishedContentJson: string | null;
  publishedContentJsonAr: string | null;
  version: number;
  isIndexed: boolean;
  lastIndexedAt: string | null;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TosPublishResponse extends FacultyTos {
  indexingStarted: boolean;
}

export interface UniversityTosPublishResponse extends UniversityTos {
  indexingStarted: boolean;
}

export interface FacultyTosListItem {
  id: string;
  facultyId: string;
  facultyName: string;
  hasPublished: boolean;
  hasDraft: boolean;
  version: number;
  publishedAt: string | null;
  updatedAt: string;
}

export interface UpdateTosDto {
  contentJson?: string;
  contentJsonAr?: string;
}

export interface PublishedTosView {
  university: {
    contentJson: string | null;
    contentJsonAr: string | null;
    publishedAt: string | null;
    version: number;
  };
  faculty: {
    facultyId: string;
    facultyName: string;
    contentJson: string | null;
    contentJsonAr: string | null;
    publishedAt: string | null;
    version: number;
  };
}

export interface TosStatus {
  hasPublishedTos: boolean;
}

// ============ API Client ============

const BASE_URL = '/ai-assistant/tos';

export const tosApi = {
  // ========================= UNIVERSITY TOS (Super Admin) =========================

  /**
   * Get university TOS (super admin only)
   */
  getUniversityTos: () =>
    apiClient.get<UniversityTos>(`${BASE_URL}/university`),

  /**
   * Update university TOS draft (super admin only)
   */
  updateUniversityTos: (data: UpdateTosDto) =>
    apiClient.put<UniversityTos>(`${BASE_URL}/university`, data),

  /**
   * Publish university TOS (super admin only)
   */
  publishUniversityTos: () =>
    apiClient.post<UniversityTosPublishResponse>(`${BASE_URL}/university/publish`),

  // ========================= ALL FACULTY TOS (Super Admin) =========================

  /**
   * Get all faculty TOS list (super admin only)
   */
  getAllFacultyTos: () =>
    apiClient.get<FacultyTosListItem[]>(`${BASE_URL}/faculties`),

  /**
   * Get specific faculty TOS (super admin only)
   */
  getFacultyTosBySuperAdmin: (facultyId: string) =>
    apiClient.get<FacultyTos>(`${BASE_URL}/faculties/${facultyId}`),

  /**
   * Update specific faculty TOS (super admin only)
   */
  updateFacultyTosBySuperAdmin: (facultyId: string, data: UpdateTosDto) =>
    apiClient.put<FacultyTos>(`${BASE_URL}/faculties/${facultyId}`, data),

  /**
   * Publish specific faculty TOS (super admin only)
   */
  publishFacultyTosBySuperAdmin: (facultyId: string) =>
    apiClient.post<TosPublishResponse>(`${BASE_URL}/faculties/${facultyId}/publish`),

  // ========================= MY FACULTY TOS (Faculty Admin) =========================

  /**
   * Get TOS for current faculty admin's faculty
   */
  getMyFacultyTos: () =>
    apiClient.get<FacultyTos>(`${BASE_URL}/my-faculty`),

  /**
   * Update TOS for current faculty admin's faculty
   */
  updateMyFacultyTos: (data: UpdateTosDto) =>
    apiClient.put<FacultyTos>(`${BASE_URL}/my-faculty`, data),

  /**
   * Publish TOS for current faculty admin's faculty
   */
  publishMyFacultyTos: () =>
    apiClient.post<TosPublishResponse>(`${BASE_URL}/my-faculty/publish`),

  // ========================= PUBLIC VIEW =========================

  /**
   * Get published TOS for viewing (university + faculty combined)
   */
  getPublishedTos: (facultyId: string) =>
    apiClient.get<PublishedTosView>(`${BASE_URL}/view/${facultyId}`),

  /**
   * Check TOS status for a faculty
   */
  getTosStatus: (facultyId: string) =>
    apiClient.get<TosStatus>(`${BASE_URL}/status/${facultyId}`),
};
