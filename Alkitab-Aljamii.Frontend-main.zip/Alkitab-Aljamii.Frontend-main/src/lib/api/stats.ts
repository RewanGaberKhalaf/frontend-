import { apiClient } from './client';

// Shared types for dashboard data
export interface RecentBook {
  id: string;
  title: string;
  status: string;
  subjectName: string;
  authorName: string;
  createdAt: string;
}

export interface BooksByFaculty {
  facultyId: string;
  facultyName: string;
  count: number;
}

export interface BooksBySubject {
  subjectId: string;
  subjectName: string;
  count: number;
}

export interface RecentUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  createdAt: string;
}

export interface SubjectWithBookCount {
  id: string;
  name: string;
  code: string;
  bookCount: number;
}

// Super Admin Stats
export interface SuperAdminStats {
  totalUsers: number;
  totalFaculties: number;
  totalSubjects: number;
  totalBooks: number;
  pendingBooks: number;
  approvedBooks: number;
  rejectedBooks: number;
  publishedBooks: number;
  booksByFaculty: BooksByFaculty[];
  recentBooks: RecentBook[];
  recentUsers: RecentUser[];
}

// Faculty Admin Stats
export interface FacultyAdminStats {
  totalProfessors: number;
  totalStudents: number;
  totalSubjects: number;
  totalBooks: number;
  pendingBooks: number;
  approvedBooks: number;
  rejectedBooks: number;
  publishedBooks: number;
  booksBySubject: BooksBySubject[];
  recentBooks: RecentBook[];
  pendingQueue: RecentBook[];
}

// Professor Stats
export interface ProfessorStats {
  totalBooks: number;
  approvedBooks: number;
  pendingBooks: number;
  rejectedBooks: number;
  publishedBooks: number;
  totalSubjects: number;
  recentBooks: RecentBook[];
  subjects: SubjectWithBookCount[];
}

// Student Stats
export interface StudentStats {
  availableBooks: number;
  totalSubjects: number;
  recentBooks: RecentBook[];
  subjects: SubjectWithBookCount[];
}

export const statsApi = {
  getSuperAdminStats: () => apiClient.get<SuperAdminStats>('/stats/super-admin'),
  // These endpoints now use facultyId from JWT context (set via switch-context)
  getFacultyAdminStats: () => apiClient.get<FacultyAdminStats>('/stats/faculty-admin'),
  getProfessorStats: () => apiClient.get<ProfessorStats>('/stats/professor'),
  getStudentStats: () => apiClient.get<StudentStats>('/stats/student'),
};
