import axios, { type AxiosInstance, type AxiosRequestConfig } from 'axios';
import { setupInterceptors } from './interceptors';

// Use /api proxy (via nginx in prod) to avoid CORS issues
// Set NEXT_PUBLIC_API_URL for local development (e.g., http://localhost:8000)
const API_URL = process.env['NEXT_PUBLIC_API_URL'] || '/api';

/**
 * Get the base URL for streaming/SSE endpoints that don't use axios.
 * - Local dev: uses NEXT_PUBLIC_API_URL (e.g., http://localhost:8000)
 * - Production: uses /api (nginx proxy)
 */
export function getApiBaseUrl(): string {
  return API_URL;
}

const axiosInstance: AxiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    // Required for ngrok free tier to skip browser warning page
    'ngrok-skip-browser-warning': 'true',
  },
  // Serialize arrays as repeated params: subjectId=a&subjectId=b (NestJS format)
  paramsSerializer: {
    indexes: null, // This removes brackets: subjectId=a&subjectId=b instead of subjectId[]=a&subjectId[]=b
  },
});

setupInterceptors(axiosInstance);

// Backend wraps responses in { success: true, data: ... }
// For paginated responses: { success: true, data: [...], meta: {...} }
// This helper unwraps appropriately
interface ApiResponseSingle<T> {
  success: boolean;
  data: T;
}

interface ApiResponsePaginated<T> {
  success: boolean;
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

function unwrapResponse<T>(response: unknown): T {
  if (
    response &&
    typeof response === 'object' &&
    'success' in response &&
    'data' in response
  ) {
    // Check if it's a paginated response (has meta)
    if ('meta' in response) {
      const paginated = response as ApiResponsePaginated<unknown>;
      // Return as { items, meta } format for frontend
      return {
        items: paginated.data,
        meta: paginated.meta,
      } as T;
    }
    return (response as ApiResponseSingle<T>).data;
  }
  return response as T;
}

export const apiClient = {
  get: <T>(url: string, config?: AxiosRequestConfig) =>
    axiosInstance.get<T>(url, config).then((res) => unwrapResponse<T>(res.data)),

  post: <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    axiosInstance.post<T>(url, data, config).then((res) => unwrapResponse<T>(res.data)),

  put: <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    axiosInstance.put<T>(url, data, config).then((res) => unwrapResponse<T>(res.data)),

  patch: <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    axiosInstance.patch<T>(url, data, config).then((res) => unwrapResponse<T>(res.data)),

  delete: <T>(url: string, config?: AxiosRequestConfig) =>
    axiosInstance.delete<T>(url, config).then((res) => unwrapResponse<T>(res.data)),

  upload: <T>(url: string, formData: FormData, config?: AxiosRequestConfig) =>
    axiosInstance.post<T>(url, formData, {
      ...config,
      headers: {
        ...config?.headers,
        'Content-Type': 'multipart/form-data',
      },
    }).then((res) => unwrapResponse<T>(res.data)),
};

export { axiosInstance };
