/**
 * A4 page dimension constants at 96 DPI
 * Used across secure-book-viewer, paginated-preview, book-editor, and chapter-editor
 */

// A4 dimensions at 96 DPI
export const A4_WIDTH_PX = 794;
export const A4_HEIGHT_PX = 1123;

// Page margins - balanced for good readability while matching print
// Using 48px (~12.7mm) for preview display
export const PAGE_MARGIN = 48;

// Header and footer heights
export const HEADER_HEIGHT = 32;
export const FOOTER_HEIGHT = 32;

// Content area dimensions (calculated)
export const CONTENT_WIDTH = A4_WIDTH_PX - PAGE_MARGIN * 2; // 698px
export const BASE_CONTENT_HEIGHT = A4_HEIGHT_PX - PAGE_MARGIN * 2; // 1027px

// Content height accounting for header/footer
export const CONTENT_HEIGHT_WITH_HEADER_FOOTER =
  BASE_CONTENT_HEIGHT - HEADER_HEIGHT - FOOTER_HEIGHT; // 963px

// Safety buffer for pagination - small buffer to prevent content overflow
export const PAGINATION_BUFFER = 8;

// Zoom constraints
export const MIN_ZOOM = 0.5;
export const MAX_ZOOM = 2;
export const DEFAULT_ZOOM = 1;
