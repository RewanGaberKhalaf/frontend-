import type { ViewRole } from '@/lib/api/users';
import type { FacultyRole } from '@/types/user';

// Labels for view roles (used in navigation and UI)
export const VIEW_ROLE_LABELS: Record<ViewRole, string> = {
  super_admin: 'Super Admin',
  faculty_admin: 'Faculty Admin',
  professor: 'Professor',
  student: 'Student',
};

// Labels for faculty-level roles
export const FACULTY_ROLE_LABELS: Record<FacultyRole, string> = {
  faculty_admin: 'Faculty Admin',
  professor: 'Professor',
  student: 'Student',
};

// Options for faculty role selection
export const FACULTY_ROLE_OPTIONS: { value: FacultyRole; label: string }[] = [
  { value: 'faculty_admin', label: 'Faculty Admin' },
  { value: 'professor', label: 'Professor' },
  { value: 'student', label: 'Student' },
];

// Backwards compatibility - alias for VIEW_ROLE_LABELS
export const ROLE_LABELS = VIEW_ROLE_LABELS;
