import {
  LayoutDashboard,
  Users,
  Building2,
  FileText,
  CheckSquare,
  BookOpen,
  GraduationCap,
  Link2,
  Megaphone,
  BookText,
  Database,
  ClipboardList,
  BarChart3,
  TrendingUp,
  ScrollText,
  Tags,
  FileCheck,
  Upload,
  type LucideIcon,
} from 'lucide-react';
import type { ViewRole } from '@/lib/api/users';
import { ROUTES } from './routes';

export interface NavItem {
  labelKey: string;
  href: string;
  icon: LucideIcon;
  exact?: boolean;
}

export const NAVIGATION: Record<ViewRole, NavItem[]> = {
  super_admin: [
    { labelKey: 'nav.dashboard', href: ROUTES.SUPER_ADMIN.DASHBOARD, icon: LayoutDashboard, exact: true },
    { labelKey: 'nav.analytics', href: ROUTES.SUPER_ADMIN.ANALYTICS, icon: BarChart3 },
    { labelKey: 'nav.performance', href: ROUTES.SUPER_ADMIN.PERFORMANCE, icon: TrendingUp },
    { labelKey: 'nav.users', href: ROUTES.SUPER_ADMIN.USERS, icon: Users },
    { labelKey: 'nav.faculties', href: ROUTES.SUPER_ADMIN.FACULTIES, icon: Building2 },
    { labelKey: 'nav.courses', href: ROUTES.SUPER_ADMIN.SUBJECTS, icon: BookOpen },
    { labelKey: 'nav.bulkImport', href: ROUTES.SUPER_ADMIN.BULK_IMPORT, icon: Upload },
    // Content deprecated - replaced by Books
    // { labelKey: 'nav.content', href: ROUTES.SUPER_ADMIN.CONTENTS, icon: FileText },
    { labelKey: 'nav.announcements', href: ROUTES.SUPER_ADMIN.ANNOUNCEMENTS, icon: Megaphone },
    { labelKey: 'nav.auditLogs', href: ROUTES.SUPER_ADMIN.AUDIT_LOGS, icon: ScrollText },
    { labelKey: 'nav.tos', href: ROUTES.SUPER_ADMIN.TOS, icon: FileCheck },
    // External systems disabled - uncomment when ready
    // { labelKey: 'nav.externalSystems', href: ROUTES.SUPER_ADMIN.EXTERNAL_SYSTEMS, icon: Server },
  ],
  faculty_admin: [
    { labelKey: 'nav.dashboard', href: ROUTES.FACULTY_ADMIN.DASHBOARD, icon: LayoutDashboard, exact: true },
    { labelKey: 'nav.analytics', href: ROUTES.FACULTY_ADMIN.ANALYTICS, icon: BarChart3 },
    { labelKey: 'nav.performance', href: ROUTES.FACULTY_ADMIN.PERFORMANCE, icon: TrendingUp },
    { labelKey: 'nav.courses', href: ROUTES.FACULTY_ADMIN.SUBJECTS, icon: BookOpen },
    { labelKey: 'nav.professors', href: ROUTES.FACULTY_ADMIN.PROFESSORS, icon: GraduationCap },
    { labelKey: 'nav.students', href: ROUTES.FACULTY_ADMIN.STUDENTS, icon: Users },
    { labelKey: 'nav.bulkImport', href: ROUTES.FACULTY_ADMIN.BULK_IMPORT, icon: Upload },
    // Content deprecated - replaced by Books
    // { labelKey: 'nav.contentApproval', href: ROUTES.FACULTY_ADMIN.CONTENT_APPROVAL, icon: CheckSquare },
    { labelKey: 'nav.bookApproval', href: ROUTES.FACULTY_ADMIN.BOOK_APPROVAL, icon: BookText },
    { labelKey: 'nav.questionBanks', href: ROUTES.FACULTY_ADMIN.QUESTION_BANKS, icon: Database },
    { labelKey: 'nav.announcements', href: ROUTES.FACULTY_ADMIN.ANNOUNCEMENTS, icon: Megaphone },
    { labelKey: 'nav.auditLogs', href: ROUTES.FACULTY_ADMIN.AUDIT_LOGS, icon: ScrollText },
    { labelKey: 'nav.tos', href: ROUTES.FACULTY_ADMIN.TOS, icon: FileCheck },
    // Course mappings deprecated - webhook integration disabled
    // { labelKey: 'nav.courseMappings', href: ROUTES.FACULTY_ADMIN.COURSE_MAPPINGS, icon: Link2 },
  ],
  professor: [
    { labelKey: 'nav.dashboard', href: ROUTES.PROFESSOR.DASHBOARD, icon: LayoutDashboard, exact: true },
    { labelKey: 'nav.analytics', href: ROUTES.PROFESSOR.ANALYTICS, icon: BarChart3 },
    { labelKey: 'nav.performance', href: ROUTES.PROFESSOR.PERFORMANCE, icon: TrendingUp },
    { labelKey: 'nav.myCourses', href: ROUTES.PROFESSOR.MY_SUBJECTS, icon: BookOpen },
    // Content deprecated - replaced by Books
    // { labelKey: 'nav.myContent', href: ROUTES.PROFESSOR.MY_CONTENT, icon: FileText },
    { labelKey: 'nav.myBooks', href: ROUTES.PROFESSOR.BOOKS, icon: BookText },
    { labelKey: 'nav.questionBanks', href: ROUTES.PROFESSOR.QUESTION_BANKS, icon: Database },
    { labelKey: 'topics.title', href: ROUTES.PROFESSOR.TOPICS, icon: Tags },
    // Quizzes now accessible under Question Banks
    { labelKey: 'nav.announcements', href: ROUTES.PROFESSOR.ANNOUNCEMENTS, icon: Megaphone },
  ],
  student: [
    { labelKey: 'nav.dashboard', href: ROUTES.STUDENT.DASHBOARD, icon: LayoutDashboard, exact: true },
    { labelKey: 'nav.performance', href: ROUTES.STUDENT.PERFORMANCE, icon: TrendingUp },
    { labelKey: 'nav.myCourses', href: ROUTES.STUDENT.MY_SUBJECTS, icon: BookOpen },
    // Content deprecated - replaced by Books
    // { labelKey: 'nav.browseContent', href: ROUTES.STUDENT.BROWSE, icon: BookOpen },
    { labelKey: 'nav.books', href: ROUTES.STUDENT.BOOKS, icon: BookText },
  ],
};
