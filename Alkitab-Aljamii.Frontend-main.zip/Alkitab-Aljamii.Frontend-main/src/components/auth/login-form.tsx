'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useAuthStore } from '@/stores';
import { loginSchema, type LoginFormData } from '@/lib/validations';
import { ROLE_HOME_ROUTES } from '@/lib/constants';

export function LoginForm() {
  const t = useTranslations();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState<string | null>(null);
  const { login, isLoading } = useAuthStore();

  // Check for auth error from localStorage (set by interceptor on session invalidation)
  useEffect(() => {
    const authError = localStorage.getItem('auth_error');
    console.log('[LoginForm] Checking localStorage auth_error:', authError);
    if (authError) {
      setError(authError);
      toast.error(authError);
      localStorage.removeItem('auth_error');
    }
  }, []);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setError(null);
    try {
      await login(data);
      const user = useAuthStore.getState().user;
      const redirect = searchParams.get('redirect');

      // For super admin, go to super-admin dashboard
      // For others, we need to load views first (handled by dashboard layout)
      const defaultRoute = user?.isSuperAdmin
        ? ROLE_HOME_ROUTES['super_admin']
        : '/'; // Home page will redirect based on available views

      // Security: Validate redirect URL to prevent open redirect attacks
      // Only allow relative paths starting with / and not containing //
      const isValidRedirect = redirect &&
        redirect.startsWith('/') &&
        !redirect.startsWith('//') &&
        !redirect.includes('://');

      const targetUrl = isValidRedirect ? redirect : defaultRoute;

      if (targetUrl) {
        router.replace(targetUrl);
        router.refresh();
      } else {
        setError(t('auth.noRoleFound'));
      }
    } catch (err: unknown) {
      console.error('Login error:', err);
      // Extract error message from API response
      const axiosError = err as { response?: { data?: { message?: string } } };
      const apiMessage = axiosError?.response?.data?.message;
      setError(apiMessage || t('auth.invalidCredentials'));
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {error && (
          <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
            {error}
          </div>
        )}

        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('auth.email')}</FormLabel>
              <FormControl>
                <Input
                  type="email"
                  placeholder={t('auth.emailPlaceholder')}
                  autoComplete="email"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('auth.password')}</FormLabel>
              <FormControl>
                <Input
                  type="password"
                  placeholder={t('auth.passwordPlaceholder')}
                  autoComplete="current-password"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {t('auth.loginButton')}
        </Button>
      </form>
    </Form>
  );
}
