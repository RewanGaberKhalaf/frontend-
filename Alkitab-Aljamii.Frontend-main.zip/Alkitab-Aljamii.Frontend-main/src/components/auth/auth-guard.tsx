'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, AlertTriangle, Clock, RefreshCw } from 'lucide-react';
import { useAuthStore, useViewContextStore } from '@/stores';
import { ROLE_HOME_ROUTES } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import type { ViewRole } from '@/lib/api/users';

interface AuthGuardProps {
  children: React.ReactNode;
  allowedRoles?: ViewRole[];
}

export function AuthGuard({ children, allowedRoles }: AuthGuardProps) {
  const router = useRouter();
  const { isAuthenticated, isHydrated, user } = useAuthStore();
  const {
    activeView,
    primaryRole,
    loadAvailableViews,
    isLoading: viewsLoading,
    error: viewsError,
    isRateLimited,
  } = useViewContextStore();
  const [viewsInitialized, setViewsInitialized] = useState(false);

  // Use activeView from context, fall back to primaryRole, then derive from isSuperAdmin
  const effectiveRole = activeView ?? primaryRole ?? (user?.isSuperAdmin ? 'super_admin' : null);

  // Load available views when authenticated
  useEffect(() => {
    if (isHydrated && isAuthenticated && user && !viewsInitialized && !viewsLoading) {
      loadAvailableViews().then(() => setViewsInitialized(true));
    }
  }, [isHydrated, isAuthenticated, user, viewsInitialized, viewsLoading, loadAvailableViews]);

  // Handle retry for failed view loading
  const handleRetry = () => {
    setViewsInitialized(false);
    loadAvailableViews(true).then(() => setViewsInitialized(true));
  };

  useEffect(() => {
    // Wait for hydration to complete before making decisions
    if (!isHydrated) return;

    if (!isAuthenticated) {
      router.push('/login');
      return;
    }

    // Wait for views to be loaded before checking role access
    if (!viewsInitialized && !user?.isSuperAdmin) return;

    // Check if user's effective role (activeView) is allowed
    if (allowedRoles && effectiveRole && !allowedRoles.includes(effectiveRole)) {
      router.push(ROLE_HOME_ROUTES[effectiveRole]);
    }
  }, [isHydrated, isAuthenticated, effectiveRole, allowedRoles, router, viewsInitialized, user?.isSuperAdmin]);

  // Show loading while hydrating or loading views
  if (!isHydrated || (isAuthenticated && !viewsInitialized && !viewsError && !user?.isSuperAdmin)) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Show error state if views failed to load (including rate limiting)
  if (isAuthenticated && viewsError && !effectiveRole && !user?.isSuperAdmin) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center p-8 max-w-md">
          {isRateLimited ? (
            <>
              <Clock className="h-12 w-12 sm:h-16 sm:w-16 text-amber-500 mx-auto mb-4" />
              <h2 className="text-lg sm:text-xl font-semibold mb-2">Too Many Requests</h2>
              <p className="text-sm text-muted-foreground mb-4">
                You&apos;re making requests too quickly. Please wait a moment and try again.
              </p>
            </>
          ) : (
            <>
              <AlertTriangle className="h-12 w-12 sm:h-16 sm:w-16 text-destructive mx-auto mb-4" />
              <h2 className="text-lg sm:text-xl font-semibold mb-2">Failed to Load</h2>
              <p className="text-sm text-muted-foreground mb-4">
                {viewsError || 'Something went wrong. Please try again.'}
              </p>
            </>
          )}
          <Button onClick={handleRetry} disabled={viewsLoading} className="gap-2">
            {viewsLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null;
  }

  // Check against effective role (activeView), not just user.role
  if (allowedRoles && effectiveRole && !allowedRoles.includes(effectiveRole)) {
    return null;
  }

  return <>{children}</>;
}
