'use client';

import { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { ChapterReadingBreakdown } from '@/types';

interface ChapterReadingChartProps {
  /** Chapter reading data */
  data: ChapterReadingBreakdown[];
  /** Chart title */
  title?: string;
  /** Chart description */
  description?: string;
  /** Additional class names */
  className?: string;
  /** Show in compact mode */
  compact?: boolean;
  /** Value to display: 'totalTime' or 'avgTime' */
  valueType?: 'totalTime' | 'avgTime';
  /** Highlight chapter by ID */
  highlightChapterId?: string;
}

function formatMinutes(minutes: number): string {
  if (minutes < 60) {
    return `${Math.round(minutes)}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export function ChapterReadingChart({
  data,
  title = 'Reading Time by Chapter',
  description,
  className,
  compact = false,
  valueType = 'totalTime',
  highlightChapterId,
}: ChapterReadingChartProps) {
  const chartData = useMemo(() => {
    return data
      .sort((a, b) => a.order - b.order)
      .map((chapter) => ({
        name: `Ch. ${chapter.order}`,
        fullName: chapter.chapterTitle,
        value: valueType === 'totalTime' ? chapter.totalReadingTimeMinutes : chapter.avgTimeMinutes,
        readers: chapter.uniqueReaders,
        completion: chapter.completionRate,
        id: chapter.chapterId,
      }));
  }, [data, valueType]);

  const maxValue = useMemo(() => {
    return Math.max(...chartData.map((d) => d.value), 1);
  }, [chartData]);

  const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ payload: typeof chartData[0] }> }) => {
    if (!active || !payload?.[0]) return null;
    const item = payload[0].payload;

    return (
      <div className="bg-popover border rounded-lg shadow-lg p-3 text-sm">
        <p className="font-medium mb-1">{item.fullName}</p>
        <div className="space-y-1 text-muted-foreground">
          <p>
            {valueType === 'totalTime' ? 'Total time' : 'Avg time'}:{' '}
            <span className="text-foreground font-medium">{formatMinutes(item.value)}</span>
          </p>
          <p>
            Readers: <span className="text-foreground">{item.readers}</span>
          </p>
          <p>
            Completion: <span className="text-foreground">{Math.round(item.completion * 100)}%</span>
          </p>
        </div>
      </div>
    );
  };

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className={compact ? 'pb-2' : undefined}>
        <CardTitle className={compact ? 'text-base' : undefined}>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className={compact ? 'pt-0' : undefined}>
        <ResponsiveContainer width="100%" height={compact ? 200 : 300}>
          <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 12 }}
              tickLine={false}
              axisLine={false}
              className="text-muted-foreground"
            />
            <YAxis
              tickFormatter={formatMinutes}
              tick={{ fontSize: 12 }}
              tickLine={false}
              axisLine={false}
              className="text-muted-foreground"
              domain={[0, maxValue * 1.1]}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {chartData.map((entry) => (
                <Cell
                  key={entry.id}
                  className={cn(
                    'transition-opacity',
                    highlightChapterId && entry.id !== highlightChapterId && 'opacity-40'
                  )}
                  fill={entry.id === highlightChapterId ? 'hsl(var(--primary))' : 'hsl(var(--chart-1))'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export default ChapterReadingChart;
