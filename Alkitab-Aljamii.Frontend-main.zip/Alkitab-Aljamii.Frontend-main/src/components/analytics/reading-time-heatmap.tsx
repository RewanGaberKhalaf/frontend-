'use client';

import { useMemo } from 'react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import type { DailyReadingData } from '@/types';

interface ReadingTimeHeatmapProps {
  /** Daily reading data for the past weeks */
  data: DailyReadingData[];
  /** Number of weeks to show */
  weeks?: number;
  /** Chart title */
  title?: string;
  /** Chart description */
  description?: string;
  /** Additional class names */
  className?: string;
}

function formatMinutes(minutes: number): string {
  if (minutes < 60) {
    return `${Math.round(minutes)}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

function getIntensityClass(minutes: number, maxMinutes: number): string {
  if (minutes === 0) return 'bg-muted';

  const ratio = minutes / maxMinutes;

  if (ratio < 0.25) return 'bg-green-200 dark:bg-green-900/40';
  if (ratio < 0.5) return 'bg-green-300 dark:bg-green-800/60';
  if (ratio < 0.75) return 'bg-green-400 dark:bg-green-700/80';
  return 'bg-green-500 dark:bg-green-600';
}

const DAYS_OF_WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function ReadingTimeHeatmap({
  data,
  weeks = 12,
  title = 'Reading Activity',
  description,
  className,
}: ReadingTimeHeatmapProps) {
  const { grid, maxMinutes, totalMinutes, totalSessions } = useMemo(() => {
    // Create a map of date -> data
    const dataMap = new Map(data.map((d) => [d.date, d]));

    // Generate dates for the grid (past N weeks ending today)
    const today = new Date();
    const startDate = new Date(today);
    startDate.setDate(startDate.getDate() - (weeks * 7) + 1);

    // Adjust to start from Sunday
    const dayOfWeek = startDate.getDay();
    startDate.setDate(startDate.getDate() - dayOfWeek);

    const grid: Array<Array<{ date: string; timeMs: number; sessions: number } | null>> = [];
    let currentDate = new Date(startDate);
    let maxMs = 0;
    let totalMs = 0;
    let sessions = 0;

    // Create weeks
    while (currentDate <= today) {
      const week: Array<{ date: string; timeMs: number; sessions: number } | null> = [];

      for (let day = 0; day < 7; day++) {
        if (currentDate > today) {
          week.push(null);
        } else {
          const dateStr = currentDate.toISOString().split('T')[0] ?? '';
          const dayData = dataMap.get(dateStr);
          const timeMs = dayData?.timeMs || 0;
          const daySessions = dayData?.sessionsCount || 0;

          week.push({ date: dateStr, timeMs, sessions: daySessions });
          maxMs = Math.max(maxMs, timeMs);
          totalMs += timeMs;
          sessions += daySessions;
        }

        currentDate.setDate(currentDate.getDate() + 1);
      }

      grid.push(week);
    }

    return {
      grid,
      maxMinutes: Math.max(maxMs / 60000, 1), // Convert to minutes, min 1 to avoid division by zero
      totalMinutes: Math.round(totalMs / 60000),
      totalSessions: sessions,
    };
  }, [data, weeks]);

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{title}</CardTitle>
            {description && <CardDescription>{description}</CardDescription>}
          </div>
          <div className="text-right text-sm">
            <div className="font-medium">{formatMinutes(totalMinutes)}</div>
            <div className="text-xs text-muted-foreground">{totalSessions} sessions</div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-1">
          {/* Day labels */}
          <div className="flex flex-col gap-1 pe-2 text-xs text-muted-foreground">
            {DAYS_OF_WEEK.map((day, i) => (
              <div
                key={day}
                className="h-3 flex items-center"
                style={{ visibility: i % 2 === 1 ? 'visible' : 'hidden' }}
              >
                {day}
              </div>
            ))}
          </div>

          {/* Grid */}
          <div className="flex-1 overflow-x-auto">
            <TooltipProvider>
              <div className="flex gap-1">
                {grid.map((week, weekIndex) => (
                  <div key={weekIndex} className="flex flex-col gap-1">
                    {week.map((day, dayIndex) => {
                      if (!day) {
                        return <div key={dayIndex} className="h-3 w-3" />;
                      }

                      const minutes = day.timeMs / 60000;

                      return (
                        <Tooltip key={dayIndex}>
                          <TooltipTrigger asChild>
                            <div
                              className={cn(
                                'h-3 w-3 rounded-sm cursor-default transition-colors',
                                getIntensityClass(minutes, maxMinutes)
                              )}
                            />
                          </TooltipTrigger>
                          <TooltipContent side="top" className="text-xs">
                            <p className="font-medium">{formatDate(day.date)}</p>
                            <p className="text-muted-foreground">
                              {minutes > 0 ? (
                                <>
                                  {formatMinutes(minutes)} • {day.sessions} session{day.sessions !== 1 ? 's' : ''}
                                </>
                              ) : (
                                'No reading'
                              )}
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      );
                    })}
                  </div>
                ))}
              </div>
            </TooltipProvider>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-end gap-2 mt-4 text-xs text-muted-foreground">
          <span>Less</span>
          <div className="flex gap-0.5">
            <div className="h-3 w-3 rounded-sm bg-muted" />
            <div className="h-3 w-3 rounded-sm bg-green-200 dark:bg-green-900/40" />
            <div className="h-3 w-3 rounded-sm bg-green-300 dark:bg-green-800/60" />
            <div className="h-3 w-3 rounded-sm bg-green-400 dark:bg-green-700/80" />
            <div className="h-3 w-3 rounded-sm bg-green-500 dark:bg-green-600" />
          </div>
          <span>More</span>
        </div>
      </CardContent>
    </Card>
  );
}

export default ReadingTimeHeatmap;
