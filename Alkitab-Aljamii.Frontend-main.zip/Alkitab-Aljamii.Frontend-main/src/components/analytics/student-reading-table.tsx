'use client';

import { useState, useMemo } from 'react';
import { ChevronDown, ChevronUp, Clock, BookOpen, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import type { TopReaderSummary } from '@/types';

interface StudentReadingTableProps {
  /** List of top readers */
  data: TopReaderSummary[];
  /** Table title */
  title?: string;
  /** Table description */
  description?: string;
  /** Additional class names */
  className?: string;
  /** Maximum rows to show initially */
  initialRowCount?: number;
  /** Called when a student row is clicked */
  onStudentClick?: (studentId: string) => void;
  /** Show ranking badges */
  showRanking?: boolean;
}

function formatMinutes(minutes: number): string {
  if (minutes < 60) {
    return `${Math.round(minutes)}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;

  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

function getRankingBadge(rank: number) {
  if (rank === 1) {
    return <Badge className="bg-yellow-500 hover:bg-yellow-600">1st</Badge>;
  }
  if (rank === 2) {
    return <Badge className="bg-gray-400 hover:bg-gray-500">2nd</Badge>;
  }
  if (rank === 3) {
    return <Badge className="bg-amber-600 hover:bg-amber-700">3rd</Badge>;
  }
  return <Badge variant="outline">{rank}th</Badge>;
}

export function StudentReadingTable({
  data,
  title = 'Top Readers',
  description,
  className,
  initialRowCount = 10,
  onStudentClick,
  showRanking = true,
}: StudentReadingTableProps) {
  const [showAll, setShowAll] = useState(false);

  const displayedData = useMemo(() => {
    if (showAll || data.length <= initialRowCount) {
      return data;
    }
    return data.slice(0, initialRowCount);
  }, [data, showAll, initialRowCount]);

  const hasMore = data.length > initialRowCount;

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          {title}
        </CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              {showRanking && <TableHead className="w-16">Rank</TableHead>}
              <TableHead>Student</TableHead>
              <TableHead className="text-right">Time Spent</TableHead>
              <TableHead className="text-right">Sessions</TableHead>
              <TableHead className="text-right">Last Active</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayedData.map((student, index) => (
              <TableRow
                key={student.userId}
                className={cn(
                  onStudentClick && 'cursor-pointer hover:bg-muted/50'
                )}
                onClick={() => onStudentClick?.(student.userId)}
              >
                {showRanking && (
                  <TableCell>{getRankingBadge(index + 1)}</TableCell>
                )}
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">
                        {getInitials(student.studentName)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{student.studentName}</span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>{formatMinutes(student.totalTimeMinutes)}</span>
                  </div>
                </TableCell>
                <TableCell className="text-right">{student.sessionsCount}</TableCell>
                <TableCell className="text-right text-muted-foreground">
                  {formatDate(student.lastReadAt)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {hasMore && (
          <div className="mt-4 flex justify-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAll(!showAll)}
              className="gap-1"
            >
              {showAll ? (
                <>
                  Show Less <ChevronUp className="h-4 w-4" />
                </>
              ) : (
                <>
                  Show All ({data.length}) <ChevronDown className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        )}

        {data.length === 0 && (
          <div className="py-8 text-center text-muted-foreground">
            <User className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No reading data yet</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default StudentReadingTable;
