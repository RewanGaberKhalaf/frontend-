"use client";

import { useRouter } from "next/navigation";
import { MoreHorizontal, Eye, Pencil } from "lucide-react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "@/components/shared/data-table";
import type { ColumnDef } from "@tanstack/react-table";
import type { Content } from "@/types";

type UseContentColumnsProps = Record<string, never>;

export function useContentColumns({
 
}: UseContentColumnsProps): ColumnDef<Content>[] {
  const t = useTranslations("content");
  const tCommon = useTranslations("common");
  const router = useRouter();
  return [
    {
      accessorKey: "title",
      enableSorting: true,
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("contentTitle")} />
      ),
    },
    {
      accessorKey: "subjectName",
      enableSorting: false,
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("subject")} />
      ),
    },
    {
      accessorKey: "uploadedByName",
      enableSorting: false,
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("uploadedBy")} />
      ),
    },
    {
      accessorKey: "status",
      enableSorting: true,
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("status")} />
      ),
    },
    {
      accessorKey: "createdAt",
      enableSorting: true,
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("uploadedAt")} />
      ),
      cell: ({ row }) => new Date(row.original.createdAt).toLocaleDateString(),
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const content = row.original;
        
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">{tCommon("actions")}</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() =>
                  router.push(`/super-admin/view/${content.id}`)
                }
              >
                <Eye className="me-2 h-4 w-4" />
                {tCommon("view")}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() =>
                  router.push(`/super-admin/edit/${content.id}`)
                }
              >
                <Pencil className="me-2 h-4 w-4" />
                {tCommon("edit")}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
            
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];
}
