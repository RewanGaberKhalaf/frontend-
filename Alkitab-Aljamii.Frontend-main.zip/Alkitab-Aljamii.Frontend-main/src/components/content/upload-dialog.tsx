'use client';

import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Upload, Loader2, X, FileText, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { contentApi } from '@/lib/api/content';
import { subjectsApi } from '@/lib/api/subjects';
import type { Subject, ContentType } from '@/types';
import { useEffect } from 'react';

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

const schema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  titleAr: z.string().max(200).optional(),
  description: z.string().max(500).optional(),
  descriptionAr: z.string().max(500).optional(),
  subjectId: z.string().min(1, 'Subject is required'),
  contentType: z.enum(['textbook', 'reference', 'notes', 'guide', 'other']),
});

type FormData = z.infer<typeof schema>;

interface UploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  facultyId?: string;
}

const CONTENT_TYPES: { value: ContentType; label: string }[] = [
  { value: 'textbook', label: 'Textbook' },
  { value: 'reference', label: 'Reference Book' },
  { value: 'notes', label: 'Lecture Notes' },
  { value: 'guide', label: 'Study Guide' },
  { value: 'other', label: 'Other' },
];

export function UploadDialog({ open, onOpenChange, onSuccess, facultyId }: UploadDialogProps) {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const t = useTranslations();

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { title: '', titleAr: '', description: '', descriptionAr: '', subjectId: '', contentType: 'textbook' },
  });

  useEffect(() => {
    if (open) {
      const loadSubjects = async () => {
        try {
          const params = facultyId ? { facultyId } : {};
          const result = await subjectsApi.getAll(params);
          setSubjects(result.items);
        } catch {
          toast.error(t('errors.loadSubjectsFailed'));
        }
      };
      loadSubjects();
    }
  }, [open, facultyId, t]);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    setFileError(null);

    if (selected) {
      if (selected.type !== 'application/pdf') {
        setFileError(t('content.onlyPdfAllowed'));
        setFile(null);
        return;
      }
      if (selected.size > MAX_FILE_SIZE) {
        setFileError(t('content.fileSizeLimit'));
        setFile(null);
        return;
      }
      setFile(selected);
    }
  }, [t]);

  const clearFile = useCallback(() => {
    setFile(null);
    setFileError(null);
  }, []);

  const handleSubmit = async (data: FormData) => {
    if (!file) {
      setFileError(t('content.selectFile'));
      return;
    }
    setIsUploading(true);
    try {
      await contentApi.upload(data, file);
      toast.success(t('content.uploadSuccess'));
      form.reset();
      setFile(null);
      onOpenChange(false);
      onSuccess();
    } catch {
      toast.error(t('content.uploadFailed'));
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog  open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-center text-lg font-semibold">{t('content.uploadContent')}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
  <form
    onSubmit={form.handleSubmit(handleSubmit)}
    className="flex flex-col max-h-[75vh]"
  >
    {/* ===== Scrollable Content ===== */}
    <div
      className="
        flex-1
        overflow-y-auto
        space-y-4
        px-1
        scrollbar-thin
        scrollbar-thumb-muted
        scrollbar-track-transparent
      "
    >
      <FormField
        control={form.control}
        name="title"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('content.title')}</FormLabel>
            <FormControl>
              <Input
                placeholder={t('content.titlePlaceholder')}
                className="w-full"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="titleAr"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('content.titleAr')}</FormLabel>
            <FormControl>
              <Input
                dir="rtl"
                className="w-full"
                {...field}
              />
            </FormControl>
            <FormDescription>{t('common.optional')}</FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="subjectId"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('content.subject')}</FormLabel>
            <Select onValueChange={field.onChange} value={field.value}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder={t('content.selectSubject')} />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="contentType"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('content.type')}</FormLabel>
            <Select onValueChange={field.onChange} value={field.value}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {CONTENT_TYPES.map((ct) => (
                  <SelectItem key={ct.value} value={ct.value}>
                    {t(`content.types.${ct.value}`)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="description"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('content.description')}</FormLabel>
            <FormControl>
              <Textarea
                placeholder={t('content.descriptionPlaceholder')}
                rows={2}
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="descriptionAr"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('content.descriptionAr')}</FormLabel>
            <FormControl>
              <Textarea
                dir="rtl"
                rows={2}
                {...field}
              />
            </FormControl>
            <FormDescription>{t('common.optional')}</FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      {/* ===== File Upload ===== */}
      <div className="space-y-2">
        <FormLabel>
          {t('content.file')} <span className="text-destructive">*</span>
        </FormLabel>

        {file ? (
          <div className="flex items-center gap-3 rounded-lg border border-green-200 dark:border-green-900/50 bg-green-50/50 dark:bg-green-900/10 p-3">
            <FileText className="h-8 w-8 text-green-600 dark:text-green-400 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{file.name}</p>
              <p className="text-xs text-muted-foreground">
                {formatFileSize(file.size)}
              </p>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="shrink-0 h-8 w-8"
              onClick={clearFile}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            <Input
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              className={`w-full ${fileError ? 'border-destructive' : ''}`}
            />
            <p className="text-xs text-muted-foreground">
              {t('content.pdfOnly')} • {t('content.maxSize', { size: '50MB' })}
            </p>
          </div>
        )}

        {fileError && (
          <div className="flex items-center gap-2 text-sm text-destructive">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{fileError}</span>
          </div>
        )}
      </div>
    </div>

    {/* ===== Fixed Footer Buttons ===== */}
    <div className="flex justify-end gap-2 pt-4 mt-2 border-t bg-background">
      <Button
        type="button"
        variant="outline"
        onClick={() => onOpenChange(false)}
      >
        {t('common.cancel')}
      </Button>

      <Button type="submit" disabled={isUploading || !file}>
        {isUploading ? (
          <Loader2 className="me-2 h-4 w-4 animate-spin" />
        ) : (
          <Upload className="me-2 h-4 w-4" />
        )}
        {t('content.upload')}
      </Button>
    </div>
  </form>
</Form>

      </DialogContent>
    </Dialog>
  );
}
