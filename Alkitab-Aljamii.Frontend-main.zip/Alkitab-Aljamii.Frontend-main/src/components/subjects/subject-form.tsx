'use client';

import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Combobox } from '@/components/ui/combobox';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { facultiesApi } from '@/lib/api/faculties';
import type { Subject, Faculty } from '@/types';

const subjectSchema = z.object({
  name: z.string().min(1, 'Name is required').max(100),
  nameAr: z.string().max(100).optional(),
  code: z.string().min(1, 'Code is required').max(20),
  facultyId: z.string().min(1, 'Faculty is required'),
  description: z.string().max(500).optional(),
  descriptionAr: z.string().max(500).optional(),
  isActive: z.boolean().optional(),
});

type SubjectFormData = z.infer<typeof subjectSchema>;

interface SubjectFormProps {
  subject?: Subject;
  onSubmit: (data: SubjectFormData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export function SubjectForm({ subject, onSubmit, onCancel, isLoading }: SubjectFormProps) {
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const t = useTranslations();
  const isEditing = !!subject;

  const form = useForm<SubjectFormData>({
    resolver: zodResolver(subjectSchema),
    defaultValues: {
      name: subject?.name ?? '',
      nameAr: subject?.nameAr ?? '',
      code: subject?.code ?? '',
      facultyId: subject?.facultyId ?? '',
      description: subject?.description ?? '',
      descriptionAr: subject?.descriptionAr ?? '',
      ...(subject && { isActive: subject.isActive ?? true }),
    },
  });

  useEffect(() => {
    const loadFaculties = async () => {
      try {
        const result = await facultiesApi.getAll({ limit: 100 });
        setFaculties(result.items);
      } catch {
        setFaculties([]);
      }
    };
    loadFaculties();
  }, []);

  return (
    <Form {...form}>
    <form
      onSubmit={form.handleSubmit(onSubmit)}
      className="flex flex-col max-h-[70vh]  bg-background "
    >
      {/* ===== Scrollable Content ===== */}
      <div className="flex-1 overflow-y-auto space-y-4 px-4 py-4">

        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('subjects.name')}</FormLabel>
              <FormControl>
                <Input placeholder="Name Of The Subject..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="nameAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('subjects.nameAr')}</FormLabel>
              <FormControl>
                <Input dir="rtl" {...field} />
              </FormControl>
              <FormDescription>{t('common.optional')}</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="code"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('subjects.code')}</FormLabel>
              <FormControl>
                <Input placeholder="Code Of The Subject..." {...field} />
              </FormControl>
              <FormDescription>
                {t('subjects.codeDescription')}
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="facultyId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('subjects.faculty')}</FormLabel>
              <FormControl>
                <Combobox
                  options={faculties.map((f) => ({
                    value: f.id,
                    label: f.name,
                  }))}
                  value={field.value}
                  onValueChange={field.onChange}
                  placeholder={t('subjects.selectFaculty')}
                  searchPlaceholder={t('common.search')}
                  emptyText={t('common.noResults')}
                  disabled={isEditing}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('subjects.description')}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Subject description..."
                  className="resize-none"
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="descriptionAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('subjects.descriptionAr')}</FormLabel>
              <FormControl>
                <Textarea
                  className="resize-none"
                  dir="rtl"
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormDescription>{t('common.optional')}</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        {isEditing && (
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{t('subjects.active')}</FormLabel>
                  <FormDescription>
                    {t('subjects.activeDescription')}
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        )}
      </div>

      {/* ===== Fixed Footer ===== */}
      <div className="flex justify-end gap-2 px-4 py-4 border-t bg-background">
        <Button type="button" variant="outline" onClick={onCancel}>
          {t('common.cancel')}
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading && (
            <Loader2 className="me-2 h-4 w-4 animate-spin" />
          )}
          {isEditing ? t('common.save') : t('subjects.create')}
        </Button>
      </div>
    </form>
</Form>

  );
}
