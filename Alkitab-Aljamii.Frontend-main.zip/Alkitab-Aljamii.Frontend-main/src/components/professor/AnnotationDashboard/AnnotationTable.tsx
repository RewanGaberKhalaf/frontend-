'use client';

import { useState, useCallback } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import {
  MessageSquare,
  Bookmark,
  Highlighter,
  FileText,
  BookOpen,
  AlertTriangle,
  ArrowUpDown,
  ChevronDown,
  ChevronUp,
  MoreHorizontal,
  ExternalLink,
  Loader2,
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Skeleton } from '@/components/ui/skeleton';
import { CommentThread } from '@/components/annotations/CommentThread';
import { cn } from '@/lib/utils';
import { useAuthStore } from '@/stores/auth-store';
import { annotationsApi } from '@/lib/api/annotations';
import type { Annotation, AnnotationType, AnnotationComment, CreateCommentDto } from '@/types';

interface AnnotationTableProps {
  annotations: Annotation[];
  isLoading: boolean;
  onSortChange: (field: 'createdAt' | 'updatedAt') => void;
  onAnnotationClick: (annotation: Annotation) => void;
}

const typeIcons: Record<AnnotationType, React.ReactNode> = {
  text_highlight: <Highlighter className="h-4 w-4" />,
  page_comment: <FileText className="h-4 w-4" />,
  bookmark: <Bookmark className="h-4 w-4" />,
  chapter_comment: <BookOpen className="h-4 w-4" />,
  book_comment: <MessageSquare className="h-4 w-4" />,
};

const typeLabels: Record<AnnotationType, string> = {
  text_highlight: 'Highlight',
  page_comment: 'Page Comment',
  bookmark: 'Bookmark',
  chapter_comment: 'Chapter Comment',
  book_comment: 'Book Comment',
};

function getInitials(firstName: string, lastName: string): string {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
}

export function AnnotationTable({
  annotations,
  isLoading,
  onSortChange,
  onAnnotationClick,
}: AnnotationTableProps) {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [annotationDetails, setAnnotationDetails] = useState<Map<string, Annotation>>(new Map());
  const [loadingDetails, setLoadingDetails] = useState<Set<string>>(new Set());

  const currentUser = useAuthStore((state) => state.user);

  const fetchAnnotationDetails = useCallback(async (annotationId: string) => {
    if (annotationDetails.has(annotationId) || loadingDetails.has(annotationId)) {
      return;
    }

    setLoadingDetails((prev) => new Set(prev).add(annotationId));
    try {
      const details = await annotationsApi.getById(annotationId);
      setAnnotationDetails((prev) => new Map(prev).set(annotationId, details));
    } catch {
      toast.error('Failed to load comments');
    } finally {
      setLoadingDetails((prev) => {
        const next = new Set(prev);
        next.delete(annotationId);
        return next;
      });
    }
  }, [annotationDetails, loadingDetails]);

  const toggleRow = (id: string) => {
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        // Fetch details when expanding
        fetchAnnotationDetails(id);
      }
      return next;
    });
  };

  const handleAddComment = useCallback(async (annotationId: string, data: CreateCommentDto) => {
    const newComment = await annotationsApi.addComment(annotationId, data);
    // Update the cached details with new comment
    setAnnotationDetails((prev) => {
      const current = prev.get(annotationId);
      if (!current) return prev;
      const next = new Map(prev);
      next.set(annotationId, {
        ...current,
        comments: [...(current.comments || []), newComment],
        commentCount: (current.commentCount || 0) + 1,
      });
      return next;
    });
  }, []);

  const handleDeleteComment = useCallback(async (annotationId: string, commentId: string) => {
    await annotationsApi.deleteComment(commentId);
    // Remove comment from cached details
    setAnnotationDetails((prev) => {
      const current = prev.get(annotationId);
      if (!current) return prev;
      const next = new Map(prev);
      const removeComment = (comments: AnnotationComment[]): AnnotationComment[] =>
        comments
          .filter((c) => c.id !== commentId)
          .map((c) => ({ ...c, replies: c.replies ? removeComment(c.replies) : [] }));
      next.set(annotationId, {
        ...current,
        comments: removeComment(current.comments || []),
        commentCount: Math.max(0, (current.commentCount || 0) - 1),
      });
      return next;
    });
  }, []);

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="flex items-center gap-4 p-4 border rounded-lg">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-[200px]" />
              <Skeleton className="h-3 w-[150px]" />
            </div>
            <Skeleton className="h-8 w-[100px]" />
          </div>
        ))}
      </div>
    );
  }

  if (annotations.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>No annotations found</p>
        <p className="text-sm">Try adjusting your filters</p>
      </div>
    );
  }

  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[40px]"></TableHead>
            <TableHead>Student</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Chapter / Page</TableHead>
            <TableHead>Content</TableHead>
            <TableHead className="text-center">Replies</TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                className="-ml-3 h-8"
                onClick={() => onSortChange('createdAt')}
              >
                Date
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {annotations.map((annotation) => (
            <Collapsible key={annotation.id} open={expandedRows.has(annotation.id)} asChild>
              <>
                <TableRow
                  className={cn(
                    'cursor-pointer hover:bg-muted/50',
                    annotation.isOrphaned && 'bg-destructive/5'
                  )}
                  onClick={() => toggleRow(annotation.id)}
                >
                  <TableCell>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        {expandedRows.has(annotation.id) ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">
                          {getInitials(annotation.user.firstName, annotation.user.lastName)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">
                          {annotation.user.firstName} {annotation.user.lastName}
                        </p>
                        {annotation.user.email && (
                          <p className="text-xs text-muted-foreground">{annotation.user.email}</p>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span
                        className="flex items-center justify-center w-6 h-6 rounded"
                        style={{
                          backgroundColor: annotation.highlightColor || '#f3f4f6',
                        }}
                      >
                        {typeIcons[annotation.type]}
                      </span>
                      <span className="text-sm">{typeLabels[annotation.type]}</span>
                      {annotation.isOrphaned && (
                        <Badge variant="destructive" className="text-xs">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          Orphaned
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {annotation.textAnchor?.selectedText ? (
                        <span className="text-muted-foreground">
                          {annotation.pageNumber && `p. ${annotation.pageNumber}`}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">
                          {annotation.pageNumber ? `Page ${annotation.pageNumber}` : '—'}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="max-w-[300px]">
                    <p className="text-sm truncate">
                      {annotation.content ||
                        annotation.textAnchor?.selectedText ||
                        '(No content)'}
                    </p>
                  </TableCell>
                  <TableCell className="text-center">
                    {annotation.commentCount > 0 && (
                      <Badge variant="secondary">{annotation.commentCount}</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-muted-foreground">
                      {formatDistanceToNow(new Date(annotation.createdAt), { addSuffix: true })}
                    </span>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            onAnnotationClick(annotation);
                          }}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          View in Book
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
                <CollapsibleContent asChild>
                  <TableRow className="bg-muted/30">
                    <TableCell colSpan={8} className="p-4">
                      <div className="space-y-4">
                        {/* Selected text */}
                        {annotation.textAnchor?.selectedText && (
                          <div>
                            <p className="text-xs font-medium text-muted-foreground mb-1">
                              Selected Text:
                            </p>
                            <p
                              className="text-sm p-2 rounded border-l-4"
                              style={{ borderColor: annotation.highlightColor || '#FFEB3B' }}
                            >
                              &ldquo;{annotation.textAnchor.selectedText}&rdquo;
                            </p>
                          </div>
                        )}

                        {/* Content/Note */}
                        {annotation.content && (
                          <div>
                            <p className="text-xs font-medium text-muted-foreground mb-1">Note:</p>
                            <p className="text-sm">{annotation.content}</p>
                          </div>
                        )}

                        {/* Orphan reason */}
                        {annotation.isOrphaned && annotation.orphanReason && (
                          <div className="flex items-start gap-2 p-2 bg-destructive/10 rounded text-sm">
                            <AlertTriangle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                            <p>{annotation.orphanReason}</p>
                          </div>
                        )}

                        {/* Comments Section */}
                        <div className="border-t pt-4">
                          <p className="text-xs font-medium text-muted-foreground mb-3">
                            Discussion ({annotationDetails.get(annotation.id)?.commentCount ?? annotation.commentCount} comments)
                          </p>
                          {loadingDetails.has(annotation.id) ? (
                            <div className="flex items-center justify-center py-4 text-muted-foreground">
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              Loading comments...
                            </div>
                          ) : currentUser ? (
                            <CommentThread
                              comments={annotationDetails.get(annotation.id)?.comments || []}
                              annotationUserId={annotation.user.id}
                              currentUserId={currentUser.id}
                              isTeachingAnnotation={annotation.isTeachingAnnotation}
                              onAddComment={(data) => handleAddComment(annotation.id, data)}
                              onDeleteComment={(commentId) => handleDeleteComment(annotation.id, commentId)}
                            />
                          ) : (
                            <p className="text-sm text-muted-foreground">Sign in to view and add comments</p>
                          )}
                        </div>

                        {/* Action button */}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onAnnotationClick(annotation)}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          View in Book
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                </CollapsibleContent>
              </>
            </Collapsible>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
