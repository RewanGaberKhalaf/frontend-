'use client';

import { X, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import type { AnnotationType, AnnotationStatus, QueryAnnotationsParams } from '@/types';

interface Chapter {
  id: string;
  title: string;
}

interface User {
  id: string;
  name: string;
}

interface AnnotationFiltersProps {
  filters: QueryAnnotationsParams;
  onFiltersChange: (filters: QueryAnnotationsParams) => void;
  chapters: Chapter[];
  users?: User[];
}

const ANNOTATION_TYPES: { value: AnnotationType; label: string }[] = [
  { value: 'text_highlight', label: 'Text Highlight' },
  { value: 'page_comment', label: 'Page Comment' },
  { value: 'bookmark', label: 'Bookmark' },
  { value: 'chapter_comment', label: 'Chapter Comment' },
  { value: 'book_comment', label: 'Book Comment' },
];

const ANNOTATION_STATUSES: { value: AnnotationStatus; label: string }[] = [
  { value: 'active', label: 'Active' },
  { value: 'orphaned', label: 'Orphaned' },
  { value: 'archived', label: 'Archived' },
];

export function AnnotationFilters({
  filters,
  onFiltersChange,
  chapters,
  users = [],
}: AnnotationFiltersProps) {
  const activeFilterCount = [
    filters.type,
    filters.status,
    filters.onlyOrphaned,
    filters.chapterId,
    filters.userId,
    filters.dateFrom,
    filters.dateTo,
  ].filter(Boolean).length;

  const handleClearFilters = () => {
    onFiltersChange({
      page: 1,
      limit: filters.limit,
      sortBy: filters.sortBy,
      sortOrder: filters.sortOrder,
    });
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* Quick filters */}
      <Select
        value={filters.type || 'all'}
        onValueChange={(value) =>
          onFiltersChange({
            ...filters,
            type: value === 'all' ? undefined : (value as AnnotationType),
            page: 1,
          })
        }
      >
        <SelectTrigger className="w-[160px]">
          <SelectValue placeholder="Type" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Types</SelectItem>
          {ANNOTATION_TYPES.map((type) => (
            <SelectItem key={type.value} value={type.value}>
              {type.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={filters.onlyOrphaned ? 'orphaned' : (filters.status || 'all')}
        onValueChange={(value) => {
          if (value === 'orphaned') {
            // Use onlyOrphaned filter for orphaned detection (includes effectively orphaned)
            onFiltersChange({
              ...filters,
              status: undefined,
              onlyOrphaned: true,
              page: 1,
            });
          } else {
            onFiltersChange({
              ...filters,
              status: value === 'all' ? undefined : (value as AnnotationStatus),
              onlyOrphaned: undefined,
              page: 1,
            });
          }
        }}
      >
        <SelectTrigger className="w-[140px]">
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Statuses</SelectItem>
          {ANNOTATION_STATUSES.filter(s => s.value !== 'orphaned').map((status) => (
            <SelectItem key={status.value} value={status.value}>
              {status.label}
            </SelectItem>
          ))}
          <SelectItem value="orphaned">Orphaned</SelectItem>
        </SelectContent>
      </Select>

      <Select
        value={filters.chapterId || 'all'}
        onValueChange={(value) =>
          onFiltersChange({
            ...filters,
            chapterId: value === 'all' ? undefined : value,
            page: 1,
          })
        }
      >
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Chapter" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Chapters</SelectItem>
          {chapters.map((chapter) => (
            <SelectItem key={chapter.id} value={chapter.id}>
              {chapter.title}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Advanced filters popover */}
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Filter className="h-4 w-4" />
            More Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="start">
          <div className="space-y-4">
            <h4 className="font-medium">Advanced Filters</h4>

            {users.length > 0 && (
              <div className="space-y-2">
                <Label>Student</Label>
                <Select
                  value={filters.userId || 'all'}
                  onValueChange={(value) =>
                    onFiltersChange({
                      ...filters,
                      userId: value === 'all' ? undefined : value,
                      page: 1,
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Students" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Students</SelectItem>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label>Date Range</Label>
              <div className="flex gap-2">
                <Input
                  type="date"
                  value={filters.dateFrom || ''}
                  onChange={(e) =>
                    onFiltersChange({
                      ...filters,
                      dateFrom: e.target.value || undefined,
                      page: 1,
                    })
                  }
                  className="flex-1"
                />
                <Input
                  type="date"
                  value={filters.dateTo || ''}
                  onChange={(e) =>
                    onFiltersChange({
                      ...filters,
                      dateTo: e.target.value || undefined,
                      page: 1,
                    })
                  }
                  className="flex-1"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Page Number</Label>
              <Input
                type="number"
                min={1}
                value={filters.pageNumber || ''}
                onChange={(e) =>
                  onFiltersChange({
                    ...filters,
                    pageNumber: e.target.value ? parseInt(e.target.value) : undefined,
                    page: 1,
                  })
                }
                placeholder="Filter by page"
              />
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {/* Clear filters */}
      {activeFilterCount > 0 && (
        <Button variant="ghost" size="sm" onClick={handleClearFilters}>
          <X className="h-4 w-4 mr-1" />
          Clear
        </Button>
      )}
    </div>
  );
}
