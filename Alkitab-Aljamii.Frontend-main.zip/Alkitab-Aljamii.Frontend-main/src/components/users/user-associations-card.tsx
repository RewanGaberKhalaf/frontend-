'use client';

import Link from 'next/link';
import { Building2, BookOpen } from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { FACULTY_ROLE_LABELS } from '@/lib/constants/user';
import type { UserAssociations } from '@/lib/api/users';

interface UserAssociationsCardProps {
  associations: UserAssociations;
  labels: {
    title: string;
    description: string;
    faculties: string;
    subjects: string;
    notAssignedToFaculty: string;
    notAssignedToSubject: string;
  };
}

export function UserAssociationsCard({ associations, labels }: UserAssociationsCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          {labels.title}
        </CardTitle>
        <CardDescription>{labels.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            {labels.faculties}
          </h4>
          {associations.faculties.length === 0 ? (
            <p className="text-sm text-muted-foreground">{labels.notAssignedToFaculty}</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {associations.faculties.map((f) => (
                <Link key={`${f.id}-${f.role}`} href={`/super-admin/faculties/${f.id}`}>
                  <Badge variant="outline" className="cursor-pointer hover:bg-muted gap-1">
                    {f.name} ({f.code})
                    <span className="text-muted-foreground">• {FACULTY_ROLE_LABELS[f.role]}</span>
                  </Badge>
                </Link>
              ))}
            </div>
          )}
        </div>

        <Separator />

        <div>
          <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            {labels.subjects}
          </h4>
          {associations.subjects.length === 0 ? (
            <p className="text-sm text-muted-foreground">{labels.notAssignedToSubject}</p>
          ) : (
            <div className="space-y-2">
              {associations.subjects.map((s) => (
                <Link key={s.id} href={`/super-admin/subjects/${s.id}`}>
                  <div className="flex items-center justify-between p-2 rounded border hover:bg-muted cursor-pointer">
                    <div>
                      <p className="text-sm font-medium">{s.name}</p>
                      <p className="text-xs text-muted-foreground">{s.code}</p>
                    </div>
                    <Badge variant="secondary">{s.facultyName}</Badge>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
