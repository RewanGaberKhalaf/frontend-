'use client';

import { useState, useEffect } from 'react';
import { Plus, Trash2, Loader2, Building2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ConfirmDialog } from '@/components/shared';
import { facultiesApi } from '@/lib/api/faculties';
import { FACULTY_ROLE_LABELS } from '@/lib/constants/user';
import type { User, Faculty, FacultyRole } from '@/types';

interface ManageFacultyRolesProps {
  user: User;
  onUpdate: () => void;
}

export function ManageFacultyRoles({ user, onUpdate }: ManageFacultyRolesProps) {
  const t = useTranslations();
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [isLoadingFaculties, setIsLoadingFaculties] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedFaculty, setSelectedFaculty] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<FacultyRole | ''>('');
  const [isAdding, setIsAdding] = useState(false);
  const [roleToRemove, setRoleToRemove] = useState<{ facultyId: string; role: FacultyRole } | null>(null);
  const [isRemoving, setIsRemoving] = useState(false);

  // Load available faculties
  useEffect(() => {
    const loadFaculties = async () => {
      setIsLoadingFaculties(true);
      try {
        const response = await facultiesApi.getAll({ limit: 100 });
        setFaculties(response.items);
      } catch (error) {
        console.error('Failed to load faculties:', error);
      } finally {
        setIsLoadingFaculties(false);
      }
    };
    loadFaculties();
  }, []);

  // Filter out faculties where user already has the selected role
  const getAvailableFaculties = (roleToCheck: FacultyRole | '') => {
    if (!roleToCheck) return faculties;

    const existingFacultyIds = (user.facultyRoles ?? [])
      .filter(fr => fr.role === roleToCheck)
      .map(fr => fr.facultyId);

    // Students can only be in one faculty
    if (roleToCheck === 'student') {
      const hasStudentRole = (user.facultyRoles ?? []).some(fr => fr.role === 'student');
      if (hasStudentRole) return [];
    }

    return faculties.filter(f => !existingFacultyIds.includes(f.id));
  };

  // Check if user can have the selected role (students can't be other roles, etc.)
  const getAvailableRoles = (): FacultyRole[] => {
    const currentRoles = user.facultyRoles ?? [];
    const hasStudentRole = currentRoles.some(fr => fr.role === 'student');
    const hasNonStudentRole = currentRoles.some(fr => fr.role !== 'student');
    const hasFacultyAdminRole = currentRoles.some(fr => fr.role === 'faculty_admin');

    // If user is already a student, they can't have other roles
    if (hasStudentRole) {
      return [];
    }

    // If user has non-student roles, they can't become a student
    if (hasNonStudentRole) {
      // Faculty admin can only be assigned to one faculty total
      if (hasFacultyAdminRole) {
        return ['professor'];
      }
      return ['faculty_admin', 'professor'];
    }

    return ['faculty_admin', 'professor', 'student'];
  };

  const handleAddRole = async () => {
    const roleToAdd = availableRoles.length === 1 ? availableRoles[0] : selectedRole;
    if (!selectedFaculty || !roleToAdd) return;

    setIsAdding(true);
    try {
      if (roleToAdd === 'faculty_admin') {
        await facultiesApi.addFacultyAdmin(selectedFaculty, user.id);
      } else if (roleToAdd === 'professor') {
        await facultiesApi.addProfessor(selectedFaculty, user.id);
      } else if (roleToAdd === 'student') {
        await facultiesApi.addStudent(selectedFaculty, user.id);
      }

      toast.success(t('users.roleAddSuccess'));
      setShowAddDialog(false);
      setSelectedFaculty('');
      setSelectedRole('');
      onUpdate();
    } catch (error: unknown) {
      console.error('Failed to add role:', error);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const err = error as any;
      const message = err?.response?.data?.message ?? t('users.roleAddError');
      toast.error(message);
    } finally {
      setIsAdding(false);
    }
  };

  const handleRemoveRole = async () => {
    if (!roleToRemove) return;

    setIsRemoving(true);
    try {
      const { facultyId, role } = roleToRemove;

      if (role === 'faculty_admin') {
        await facultiesApi.removeFacultyAdmin(facultyId, user.id);
      } else if (role === 'professor') {
        await facultiesApi.removeProfessor(facultyId, user.id);
      } else if (role === 'student') {
        await facultiesApi.removeStudent(facultyId, user.id);
      }

      toast.success(t('users.roleRemoveSuccess'));
      setRoleToRemove(null);
      onUpdate();
    } catch (error: unknown) {
      console.error('Failed to remove role:', error);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const err = error as any;
      const message = err?.response?.data?.message ?? t('users.roleRemoveError');
      toast.error(message);
    } finally {
      setIsRemoving(false);
    }
  };

  const availableRoles = getAvailableRoles();
  const canAddRoles = availableRoles.length > 0;

  // Auto-select role if only one option available
  const effectiveSelectedRole: FacultyRole | '' = availableRoles.length === 1
    ? (availableRoles[0] ?? '')
    : selectedRole;

  // Get available faculties based on effective role
  const availableFaculties = getAvailableFaculties(effectiveSelectedRole);

  // Super admins can't have faculty roles - return after all hooks
  if (user.isSuperAdmin) {
    return null;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold flex items-center gap-2">
          <Building2 className="h-4 w-4" />
          {t('users.facultyRoles')}
        </h4>

        {canAddRoles && (
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Plus className="h-4 w-4 mr-1" />
                {t('users.addRole')}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('users.addFacultyRole')}</DialogTitle>
                <DialogDescription>
                  {t('users.addFacultyRoleDescription')}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                {/* Only show role selector if multiple options available */}
                {availableRoles.length > 1 ? (
                  <div className="space-y-2">
                    <Label>{t('users.role')}</Label>
                    <Select
                      value={selectedRole}
                      onValueChange={(v) => {
                        setSelectedRole(v as FacultyRole);
                        setSelectedFaculty('');
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={t('users.selectRole')} />
                      </SelectTrigger>
                      <SelectContent>
                        {availableRoles.map((role) => (
                          <SelectItem key={role} value={role}>
                            {FACULTY_ROLE_LABELS[role]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>{t('users.role')}</Label>
                    <div className="flex h-10 w-full items-center rounded-md border bg-muted px-3 text-sm">
                      {FACULTY_ROLE_LABELS[effectiveSelectedRole as FacultyRole]}
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label>{t('nav.faculties')}</Label>
                  <Select
                    value={selectedFaculty}
                    onValueChange={setSelectedFaculty}
                    disabled={!effectiveSelectedRole || isLoadingFaculties}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={
                        isLoadingFaculties
                          ? t('common.loading')
                          : availableFaculties.length === 0
                            ? t('users.noAvailableFaculties')
                            : t('users.selectFaculty')
                      } />
                    </SelectTrigger>
                    <SelectContent>
                      {availableFaculties.map((faculty) => (
                        <SelectItem key={faculty.id} value={faculty.id}>
                          {faculty.name} ({faculty.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowAddDialog(false)}
                >
                  {t('common.cancel')}
                </Button>
                <Button
                  onClick={handleAddRole}
                  disabled={!selectedFaculty || !effectiveSelectedRole || isAdding}
                >
                  {isAdding && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {t('common.add')}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {(!user.facultyRoles || user.facultyRoles.length === 0) ? (
        <p className="text-sm text-muted-foreground">{t('users.noFacultyRoles')}</p>
      ) : (
        <div className="space-y-2">
          {user.facultyRoles.map((fr) => (
            <div
              key={`${fr.facultyId}-${fr.role}`}
              className="flex items-center justify-between p-2 rounded border"
            >
              <div className="flex items-center gap-2">
                <Badge variant="outline">
                  {fr.facultyName}
                </Badge>
                <Badge variant="secondary">
                  {FACULTY_ROLE_LABELS[fr.role]}
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={() => setRoleToRemove({ facultyId: fr.facultyId, role: fr.role })}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!roleToRemove}
        onOpenChange={(open) => !open && setRoleToRemove(null)}
        title={t('users.removeRoleTitle')}
        description={t('users.removeRoleDescription')}
        confirmLabel={t('common.remove')}
        onConfirm={handleRemoveRole}
        loading={isRemoving}
        destructive
      />
    </div>
  );
}
