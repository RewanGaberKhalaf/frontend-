'use client';

import { Webhook, UserPlus, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import type { UserCreationSource } from '@/types';

interface UserInfoCardProps {
  labels: {
    title: string;
    role: string;
    lastLogin: string;
    createdAt: string;
    updatedAt: string;
    never: string;
    nationalId?: string;
    createdVia?: string;
    profileStatus?: string;
    profileComplete?: string;
    profileIncomplete?: string;
    manual?: string;
    webhook?: string;
    notSet?: string;
  };
  roleDisplay: string;
  lastLogin: string | null;
  createdAt: string;
  updatedAt: string;
  nationalId?: string | null;
  profileCompleted?: boolean;
  createdVia?: UserCreationSource;
}

export function UserInfoCard({
  labels,
  roleDisplay,
  lastLogin,
  createdAt,
  updatedAt,
  nationalId,
  profileCompleted,
  createdVia,
}: UserInfoCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{labels.title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <InfoRow label={labels.role} value={roleDisplay} />
        <Separator />

        {/* National ID */}
        {labels.nationalId && (
          <>
            <InfoRow
              label={labels.nationalId}
              value={nationalId || labels.notSet || 'Not set'}
              mono={!!nationalId}
            />
            <Separator />
          </>
        )}

        {/* Created Via */}
        {labels.createdVia && createdVia && (
          <>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{labels.createdVia}</p>
              <div className="flex items-center gap-2 mt-1">
                {createdVia === 'webhook' ? (
                  <Badge variant="outline" className="gap-1 text-xs">
                    <Webhook className="h-3 w-3" />
                    {labels.webhook || 'Webhook'}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="gap-1 text-xs">
                    <UserPlus className="h-3 w-3" />
                    {labels.manual || 'Manual'}
                  </Badge>
                )}
              </div>
            </div>
            <Separator />
          </>
        )}

        {/* Profile Status - only show for webhook users */}
        {labels.profileStatus && createdVia === 'webhook' && (
          <>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{labels.profileStatus}</p>
              <div className="flex items-center gap-2 mt-1">
                {profileCompleted ? (
                  <Badge variant="outline" className="gap-1 text-xs text-green-600 border-green-200 bg-green-50">
                    <CheckCircle2 className="h-3 w-3" />
                    {labels.profileComplete || 'Complete'}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="gap-1 text-xs text-yellow-600 border-yellow-200 bg-yellow-50">
                    <AlertCircle className="h-3 w-3" />
                    {labels.profileIncomplete || 'Incomplete'}
                  </Badge>
                )}
              </div>
            </div>
            <Separator />
          </>
        )}

        <InfoRow
          label={labels.lastLogin}
          value={lastLogin ? new Date(lastLogin).toLocaleString() : labels.never}
        />
        <Separator />
        <InfoRow
          label={labels.createdAt}
          value={new Date(createdAt).toLocaleDateString()}
        />
        <Separator />
        <InfoRow
          label={labels.updatedAt}
          value={new Date(updatedAt).toLocaleDateString()}
        />
      </CardContent>
    </Card>
  );
}

function InfoRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className={`text-sm ${mono ? 'font-mono' : ''}`}>{value}</p>
    </div>
  );
}
