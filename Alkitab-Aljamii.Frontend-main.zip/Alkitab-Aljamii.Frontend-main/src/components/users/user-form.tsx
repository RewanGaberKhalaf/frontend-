"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import type { User } from "@/types";

const createUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  nationalId: z.string().max(14).optional().or(z.literal("")),
  isSuperAdmin: z.boolean().optional(),
});

const updateUserSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  nationalId: z.string().max(14).optional().or(z.literal("")),
  isActive: z.boolean(),
});

export type CreateUserFormData = z.infer<typeof createUserSchema>;
export type UpdateUserFormData = z.infer<typeof updateUserSchema>;

interface BaseUserFormProps {
  onCancel: () => void;
  isLoading?: boolean;
  canCreateSuperAdmin?: boolean;
}

interface CreateUserFormProps extends BaseUserFormProps {
  user?: undefined;
  onSubmit: (data: CreateUserFormData) => Promise<void>;
}

interface EditUserFormProps extends BaseUserFormProps {
  user: User;
  onSubmit: (data: UpdateUserFormData) => Promise<void>;
}

type UserFormProps = CreateUserFormProps | EditUserFormProps;

export function UserForm(props: UserFormProps) {
  const { onCancel, isLoading } = props;
  const t = useTranslations();
  const isEditing = !!props.user;

  const form = useForm<CreateUserFormData | UpdateUserFormData>({
    resolver: zodResolver(isEditing ? updateUserSchema : createUserSchema),
    defaultValues: isEditing
      ? {
          firstName: props.user.firstName,
          lastName: props.user.lastName,
          nationalId: props.user.nationalId || "",
          isActive: props.user.isActive,
        }
      : {
          email: "",
          firstName: "",
          lastName: "",
          password: "",
          nationalId: "",
        },
  });

  const handleSubmit = async (
    data: CreateUserFormData | UpdateUserFormData
  ) => {
    // Convert empty nationalId to undefined
    const cleanedData = {
      ...data,
      nationalId: data.nationalId?.trim() || undefined,
    };

    if (isEditing) {
      await (props as EditUserFormProps).onSubmit(cleanedData as UpdateUserFormData);
    } else {
      await (props as CreateUserFormProps).onSubmit(cleanedData as CreateUserFormData);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className=" space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("users.firstName")}</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("users.lastName")}</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="nationalId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t("users.nationalId")}</FormLabel>
              <FormControl>
                <Input placeholder="12345678901234" maxLength={14} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {!isEditing && (
          <>
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("users.email")}</FormLabel>
                  <FormControl>
                    <Input
                      type="email"
                      placeholder="Enter Valid Email..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("users.password")}</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="••••••••" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}

        {isEditing && (
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{t("users.active")}</FormLabel>
                  <p className="text-sm text-muted-foreground">
                    {t("users.activeDescription")}
                  </p>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value as boolean}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t("common.cancel")}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEditing ? t("common.save") : t("users.create")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
