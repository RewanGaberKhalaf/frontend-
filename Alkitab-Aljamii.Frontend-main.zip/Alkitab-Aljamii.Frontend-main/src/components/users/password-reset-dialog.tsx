'use client';

import { useState, useMemo } from 'react';
import { Loader2, Check, X } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface PasswordResetDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (password: string) => Promise<void>;
}

export function PasswordResetDialog({
  open,
  onOpenChange,
  onSubmit,
}: PasswordResetDialogProps) {
  const t = useTranslations();
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const validation = useMemo(() => ({
    minLength: password.length >= 8,
    hasUppercase: /[A-Z]/.test(password),
    hasLowercase: /[a-z]/.test(password),
    hasNumber: /\d/.test(password),
  }), [password]);

  const isValid = validation.minLength && validation.hasUppercase && validation.hasLowercase && validation.hasNumber;

  const handleSubmit = async () => {
    if (!isValid) return;
    setIsLoading(true);
    try {
      await onSubmit(password);
      setPassword('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setPassword('');
  };

  const RequirementItem = ({ met, text }: { met: boolean; text: string }) => (
    <div className={`flex items-center gap-2 text-sm ${met ? 'text-green-600' : 'text-muted-foreground'}`}>
      {met ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
      {text}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t('users.resetPassword')}</DialogTitle>
          <DialogDescription>
            {t('users.resetPasswordDescription')}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="password">{t('users.newPassword')}</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <div className="space-y-1 pt-2">
              <RequirementItem met={validation.minLength} text="At least 8 characters" />
              <RequirementItem met={validation.hasUppercase} text="One uppercase letter" />
              <RequirementItem met={validation.hasLowercase} text="One lowercase letter" />
              <RequirementItem met={validation.hasNumber} text="One number" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            {t('common.cancel')}
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isLoading || !isValid}
          >
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {t('users.updatePassword')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
