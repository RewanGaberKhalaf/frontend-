'use client';

import { useRouter } from 'next/navigation';
import {
  MoreHorizontal,
  Eye,
  Pencil,
  Trash2,
  RotateCcw,
  KeyRound,
  Webhook,
  AlertCircle,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { FACULTY_ROLE_LABELS } from '@/lib/constants/user';
import type { ColumnDef } from '@tanstack/react-table';
import type { User } from '@/types';

function getRoleDisplay(user: User): string {
  if (user.isSuperAdmin) return 'Super Admin';
  if (!user.facultyRoles || user.facultyRoles.length === 0) return 'No Roles';
  // Show unique roles
  const uniqueRoles = [...new Set(user.facultyRoles.map(fr => fr.role))];
  return uniqueRoles.map(r => FACULTY_ROLE_LABELS[r]).join(', ');
}

interface UseUserColumnsProps {
  currentUserId?: string;
  onDelete: (user: User) => void;
  onRestore: (user: User) => void;
  onResetPassword: (user: User) => void;
}

export function useUserColumns({
  currentUserId,
  onDelete,
  onRestore,
  onResetPassword,
}: UseUserColumnsProps): ColumnDef<User>[] {
  const t = useTranslations();
  const router = useRouter();

  return [
    {
      id: 'firstName',
      accessorKey: 'firstName',
      header: t('users.name'),
      enableSorting: true,
      cell: ({ row }) => {
        const user = row.original;
        return (
          <div className="flex items-center gap-2">
            <button
              onClick={() => router.push(`/super-admin/users/${user.id}`)}
              className="font-medium hover:underline"
            >
              {user.firstName} {user.lastName}
            </button>
            {user.createdVia === 'webhook' && (
              <Tooltip>
                <TooltipTrigger>
                  {user.profileCompleted ? (
                    <Webhook className="h-3.5 w-3.5 text-muted-foreground" />
                  ) : (
                    <AlertCircle className="h-3.5 w-3.5 text-yellow-500" />
                  )}
                </TooltipTrigger>
                <TooltipContent>
                  {user.profileCompleted
                    ? t('users.createdViaWebhook')
                    : t('users.profileIncomplete')}
                </TooltipContent>
              </Tooltip>
            )}
          </div>
        );
      },
    },
    { accessorKey: 'email', header: t('users.email'), enableSorting: true },
    {
      id: 'role',
      header: t('users.role'),
      enableSorting: false,
      cell: ({ row }) => (
        <Badge variant={row.original.isSuperAdmin ? 'destructive' : 'outline'}>
          {getRoleDisplay(row.original)}
        </Badge>
      ),
    },
    {
      accessorKey: 'isActive',
      header: t('users.status'),
      enableSorting: true,
      cell: ({ row }) => (
        <Badge variant={row.original.isActive ? 'default' : 'secondary'}>
          {row.original.isActive ? t('users.active') : t('users.inactive')}
        </Badge>
      ),
    },
    {
      accessorKey: 'createdAt',
      header: t('users.createdAt'),
      enableSorting: true,
      cell: ({ row }) => new Date(row.original.createdAt).toLocaleDateString(),
    },
    {
      id: 'actions',
      cell: ({ row }) => {
        const user = row.original;
        const isSelf = currentUserId === user.id;

        return (
          <Tooltip>
            <DropdownMenu>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">Actions</span>
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() => router.push(`/super-admin/users/${user.id}`)}
              >
                <Eye className="mr-2 h-4 w-4" />
                {t('common.view')}
              </DropdownMenuItem>
              {!isSelf && (
                <>
                  <DropdownMenuItem
                    onClick={() => router.push(`/super-admin/users/${user.id}`)}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    {t('common.edit')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onResetPassword(user)}>
                    <KeyRound className="mr-2 h-4 w-4" />
                    {t('users.resetPassword')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  {user.isActive ? (
                    <DropdownMenuItem
                      onClick={() => onDelete(user)}
                      className="text-destructive"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      {t('users.delete')}
                    </DropdownMenuItem>
                  ) : (
                    <DropdownMenuItem onClick={() => onRestore(user)}>
                      <RotateCcw className="mr-2 h-4 w-4" />
                      {t('users.restore')}
                    </DropdownMenuItem>
                  )}
                </>
              )}
              </DropdownMenuContent>
            </DropdownMenu>
            <TooltipContent>{t('tooltips.actions.moreActions')}</TooltipContent>
          </Tooltip>
        );
      },
    },
  ];
}
