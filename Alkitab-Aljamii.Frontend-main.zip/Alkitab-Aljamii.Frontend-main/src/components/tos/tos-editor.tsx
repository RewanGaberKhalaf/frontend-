'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import mammoth from 'mammoth';
import { RichTextEditor, type RichTextEditorRef } from '@/components/shared/rich-text-editor';
import { mediaApi } from '@/lib/api/media';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2, Save, Send, CheckCircle2, AlertCircle, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export interface TosEditorProps {
  title: string;
  description: string;
  contentJson: string | null;
  contentJsonAr: string | null;
  publishedContentJson: string | null;
  publishedContentJsonAr: string | null;
  version: number;
  isIndexed: boolean;
  publishedAt: string | null;
  onSave: (contentJson?: string, contentJsonAr?: string) => Promise<void>;
  onPublish: () => Promise<void>;
  className?: string;
}

export function TosEditor({
  title,
  description,
  contentJson,
  contentJsonAr,
  publishedContentJson,
  publishedContentJsonAr,
  version,
  isIndexed,
  publishedAt,
  onSave,
  onPublish,
  className,
}: TosEditorProps) {
  const t = useTranslations('tos');
  const tCommon = useTranslations('common');

  const [activeLanguage, setActiveLanguage] = useState<'en' | 'ar'>('en');
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [showPublishDialog, setShowPublishDialog] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [editorsReady, setEditorsReady] = useState({ en: false, ar: false });

  const editorEnRef = useRef<RichTextEditorRef>(null);
  const editorArRef = useRef<RichTextEditorRef>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Set content from JSON when editors are ready (with polling for editor availability)
  useEffect(() => {
    if (!contentJson || editorsReady.en) return;

    const setContent = () => {
      if (editorEnRef.current?.editor) {
        try {
          const parsed = JSON.parse(contentJson);
          editorEnRef.current.editor.commands.setContent(parsed);
          setEditorsReady(prev => ({ ...prev, en: true }));
          return true;
        } catch {
          return true; // Stop polling on parse error
        }
      }
      return false;
    };

    // Try immediately
    if (setContent()) return;

    // Poll until editor is ready
    const interval = setInterval(() => {
      if (setContent()) {
        clearInterval(interval);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [contentJson, editorsReady.en]);

  useEffect(() => {
    if (!contentJsonAr || editorsReady.ar) return;

    const setContent = () => {
      if (editorArRef.current?.editor) {
        try {
          const parsed = JSON.parse(contentJsonAr);
          editorArRef.current.editor.commands.setContent(parsed);
          setEditorsReady(prev => ({ ...prev, ar: true }));
          return true;
        } catch {
          return true; // Stop polling on parse error
        }
      }
      return false;
    };

    // Try immediately
    if (setContent()) return;

    // Poll until editor is ready
    const interval = setInterval(() => {
      if (setContent()) {
        clearInterval(interval);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [contentJsonAr, editorsReady.ar]);

  const handleUpdate = useCallback(() => {
    setHasChanges(true);
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const enContent = editorEnRef.current?.editor
        ? JSON.stringify(editorEnRef.current.editor.getJSON())
        : undefined;
      const arContent = editorArRef.current?.editor
        ? JSON.stringify(editorArRef.current.editor.getJSON())
        : undefined;

      await onSave(enContent, arContent);
      setHasChanges(false);
      toast.success(t('saveSuccess'));
    } catch (error) {
      toast.error(t('saveError'));
    } finally {
      setIsSaving(false);
    }
  };

  const handlePublish = async () => {
    setIsPublishing(true);
    try {
      const enContent = editorEnRef.current?.editor
        ? JSON.stringify(editorEnRef.current.editor.getJSON())
        : undefined;
      const arContent = editorArRef.current?.editor
        ? JSON.stringify(editorArRef.current.editor.getJSON())
        : undefined;

      await onSave(enContent, arContent);
      await onPublish();
      setHasChanges(false);
      toast.success(t('publishSuccess'));
    } catch (error) {
      toast.error(t('publishError'));
    } finally {
      setIsPublishing(false);
      setShowPublishDialog(false);
    }
  };

  const handleImportWord = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.docx')) {
      toast.error(t('invalidFileType'));
      return;
    }

    setIsImporting(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      let imageCount = 0;

      // Word style mappings
      const styleMap = [
        "p[style-name='Title'] => h1:fresh",
        "p[style-name='Subtitle'] => h2:fresh",
        "p[style-name='Heading 1'] => h1:fresh",
        "p[style-name='Heading 2'] => h2:fresh",
        "p[style-name='Heading 3'] => h3:fresh",
        "p[style-name='Heading 4'] => h4:fresh",
        "p[style-name='عنوان'] => h1:fresh",
        "p[style-name='عنوان 1'] => h1:fresh",
        "p[style-name='عنوان 2'] => h2:fresh",
        "p[style-name='Quote'] => blockquote:fresh",
      ];

      const result = await mammoth.convertToHtml(
        { arrayBuffer },
        {
          styleMap,
          convertImage: mammoth.images.imgElement(async (image) => {
            imageCount++;
            try {
              const imageBuffer = await image.read();
              const extension = image.contentType.split('/')[1] || 'png';
              const uint8Array = new Uint8Array(imageBuffer);
              const blob = new Blob([uint8Array], { type: image.contentType });
              const imageFile = new File(
                [blob],
                `tos-image-${imageCount}.${extension}`,
                { type: image.contentType }
              );
              const uploadedMedia = await mediaApi.upload({ file: imageFile });
              return { src: uploadedMedia.url };
            } catch {
              return { src: '' };
            }
          }),
        }
      );

      // Get the current editor based on active language
      const editor = activeLanguage === 'en' ? editorEnRef.current?.editor : editorArRef.current?.editor;

      if (editor) {
        // Set the HTML content in the editor
        editor.commands.setContent(result.value);
        setHasChanges(true);
        toast.success(t('importSuccess'));
      }
    } catch (error) {
      console.error('Error importing Word document:', error);
      toast.error(t('importError'));
    } finally {
      setIsImporting(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <Card className={cn('flex flex-col', className)}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle>{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {hasChanges && (
              <Badge variant="outline" className="text-orange-600 border-orange-300">
                {t('hasChanges')}
              </Badge>
            )}
            {publishedAt ? (
              <Badge variant="secondary" className="text-green-600 bg-green-50">
                {t('version', { version })}
              </Badge>
            ) : (
              <Badge variant="outline" className="text-gray-500">
                {t('neverPublished')}
              </Badge>
            )}
            {isIndexed ? (
              <Badge variant="secondary" className="text-blue-600 bg-blue-50">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                {t('indexed')}
              </Badge>
            ) : publishedAt ? (
              <Badge variant="outline" className="text-yellow-600">
                <AlertCircle className="w-3 h-3 mr-1" />
                {t('notIndexed')}
              </Badge>
            ) : null}
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <Tabs value={activeLanguage} onValueChange={(v) => setActiveLanguage(v as 'en' | 'ar')} className="flex-1 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="en">
                {t('english')}
                {activeLanguage === 'en' && ' *'}
              </TabsTrigger>
              <TabsTrigger value="ar">
                {t('arabic')}
                <span className="text-xs text-muted-foreground ml-1">({tCommon('optional')})</span>
              </TabsTrigger>
            </TabsList>
            <div className="flex items-center gap-2">
              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                accept=".docx"
                className="hidden"
                onChange={handleImportWord}
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={isSaving || isPublishing || isImporting}
              >
                {isImporting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4 mr-2" />
                )}
                {isImporting ? t('importing') : t('importWord')}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSave}
                disabled={isSaving || isPublishing}
              >
                {isSaving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                {isSaving ? t('saving') : t('saveDraft')}
              </Button>
              <Button
                size="sm"
                onClick={() => setShowPublishDialog(true)}
                disabled={isSaving || isPublishing}
              >
                {isPublishing ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                {isPublishing ? t('publishing') : t('publish')}
              </Button>
            </div>
          </div>

          <TabsContent value="en" className="flex-1 mt-0">
            <RichTextEditor
              ref={editorEnRef}
              content=""
              onUpdate={handleUpdate}
              placeholder={t('emptyContent')}
              className="h-[500px]"
              contentClassName="h-[calc(100%-50px)] overflow-auto"
              showToolbar={true}
              minHeight="400px"
            />
          </TabsContent>

          <TabsContent value="ar" className="flex-1 mt-0" dir="rtl">
            <RichTextEditor
              ref={editorArRef}
              content=""
              onUpdate={handleUpdate}
              placeholder={t('emptyContent')}
              className="h-[500px]"
              contentClassName="h-[calc(100%-50px)] overflow-auto"
              showToolbar={true}
              minHeight="400px"
            />
          </TabsContent>
        </Tabs>

        {publishedAt && (
          <div className="mt-4 text-sm text-muted-foreground">
            {t('lastPublished', { date: new Date(publishedAt).toLocaleString() })}
          </div>
        )}
      </CardContent>

      {/* Publish Confirmation Dialog */}
      <AlertDialog open={showPublishDialog} onOpenChange={setShowPublishDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('confirmPublishTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('confirmPublish')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{tCommon('cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handlePublish} disabled={isPublishing}>
              {isPublishing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t('publishing')}
                </>
              ) : (
                t('publish')
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
