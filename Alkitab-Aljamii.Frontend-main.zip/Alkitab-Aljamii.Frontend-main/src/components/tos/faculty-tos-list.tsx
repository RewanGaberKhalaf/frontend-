'use client';

import { useTranslations } from 'next-intl';
import { useRouter } from 'next/navigation';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle2, XCircle, Edit, ExternalLink } from 'lucide-react';
import type { FacultyTosListItem } from '@/lib/api/tos';
import { cn } from '@/lib/utils';

interface FacultyTosListProps {
  faculties: FacultyTosListItem[];
  onEdit?: (facultyId: string) => void;
  className?: string;
}

export function FacultyTosList({ faculties, onEdit, className }: FacultyTosListProps) {
  const t = useTranslations('tos');
  const tCommon = useTranslations('common');
  const router = useRouter();

  const handleEdit = (facultyId: string) => {
    if (onEdit) {
      onEdit(facultyId);
    } else {
      router.push(`/super-admin/tos/${facultyId}`);
    }
  };

  return (
    <Card className={cn(className)}>
      <CardHeader>
        <CardTitle>{t('allFaculties')}</CardTitle>
        <CardDescription>{t('facultyListDescription')}</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t('facultyName')}</TableHead>
              <TableHead className="text-center">{t('hasDraft')}</TableHead>
              <TableHead className="text-center">{t('hasPublishedVersion')}</TableHead>
              <TableHead className="text-center">{t('version', { version: '' }).replace('Version ', '')}</TableHead>
              <TableHead>{t('lastUpdated')}</TableHead>
              <TableHead className="text-right">{tCommon('actions')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {faculties.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                  {tCommon('noData')}
                </TableCell>
              </TableRow>
            ) : (
              faculties.map((faculty) => (
                <TableRow key={faculty.facultyId}>
                  <TableCell className="font-medium">{faculty.facultyName}</TableCell>
                  <TableCell className="text-center">
                    {faculty.hasDraft ? (
                      <Badge variant="outline" className="text-blue-600 border-blue-300">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        {tCommon('yes')}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-400">
                        <XCircle className="w-3 h-3 mr-1" />
                        {tCommon('no')}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {faculty.hasPublished ? (
                      <Badge variant="secondary" className="text-green-600 bg-green-50">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        {tCommon('yes')}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-400">
                        <XCircle className="w-3 h-3 mr-1" />
                        {tCommon('no')}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {faculty.version > 0 ? faculty.version : '-'}
                  </TableCell>
                  <TableCell>
                    {new Date(faculty.updatedAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(faculty.facultyId)}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      {t('viewEdit')}
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
