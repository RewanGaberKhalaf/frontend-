'use client';

import { cn } from '@/lib/utils';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { RiskBadge } from './risk-badge';
import { ChevronRight, AlertTriangle, Clock } from 'lucide-react';
import type { StudentPerformanceSummary } from '@/lib/api/performance';
import { formatDistanceToNow } from 'date-fns';

interface StudentTableProps {
  students: StudentPerformanceSummary[];
  onViewStudent?: (userId: string) => void;
  showAlerts?: boolean;
  className?: string;
}

const getTrendIcon = (trend: string | null) => {
  if (!trend) return null;
  if (trend === 'improving') return <span className="text-green-600">+</span>;
  if (trend === 'declining') return <span className="text-red-600">-</span>;
  return null;
};

export function StudentTable({
  students,
  onViewStudent,
  showAlerts = true,
  className,
}: StudentTableProps) {
  return (
    <div className={cn('rounded-md border', className)}>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student</TableHead>
            <TableHead className="text-center">API</TableHead>
            <TableHead className="text-center">Completion</TableHead>
            <TableHead className="text-center">Quiz Avg</TableHead>
            <TableHead className="text-center">Risk</TableHead>
            {showAlerts && <TableHead className="text-center">Alerts</TableHead>}
            <TableHead className="text-center">Last Active</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {students.length === 0 ? (
            <TableRow>
              <TableCell colSpan={showAlerts ? 8 : 7} className="text-center text-muted-foreground py-8">
                No students found
              </TableCell>
            </TableRow>
          ) : (
            students.map((student) => (
              <TableRow
                key={student.userId}
                className="cursor-pointer hover:bg-muted/50"
                onClick={() => onViewStudent?.(student.userId)}
              >
                <TableCell>
                  <div>
                    <p className="font-medium">{student.firstName} {student.lastName}</p>
                    {student.email && (
                      <p className="text-xs text-muted-foreground">{student.email}</p>
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <span className={cn(
                      'font-semibold',
                      student.academicPerformanceIndex >= 70 ? 'text-green-600' :
                      student.academicPerformanceIndex >= 50 ? 'text-yellow-600' :
                      'text-red-600'
                    )}>
                      {Math.round(student.academicPerformanceIndex)}
                    </span>
                    {getTrendIcon(student.apiTrend)}
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  {Math.round(student.overallCompletionRate)}%
                </TableCell>
                <TableCell className="text-center">
                  {Math.round(student.averageQuizScore)}%
                </TableCell>
                <TableCell className="text-center">
                  <RiskBadge level={student.riskLevel} size="sm" />
                </TableCell>
                {showAlerts && (
                  <TableCell className="text-center">
                    {student.activeAlerts > 0 ? (
                      <div className="flex items-center justify-center gap-1 text-orange-600">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        <span className="text-sm font-medium">{student.activeAlerts}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                <TableCell className="text-center">
                  {student.lastActivityAt ? (
                    <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {formatDistanceToNow(new Date(student.lastActivityAt), { addSuffix: true })}
                    </div>
                  ) : (
                    <span className="text-muted-foreground text-xs">Never</span>
                  )}
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
