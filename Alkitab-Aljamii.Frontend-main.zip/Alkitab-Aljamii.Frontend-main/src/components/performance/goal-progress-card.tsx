'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, Clock, CheckCircle, XCircle } from 'lucide-react';
import type { PerformanceGoal } from '@/lib/api/performance';
import { formatDistanceToNow } from 'date-fns';

interface GoalProgressCardProps {
  goal: PerformanceGoal;
  locale?: string;
  className?: string;
}

const statusConfig = {
  active: {
    label: 'Active',
    icon: Target,
    className: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  },
  completed: {
    label: 'Completed',
    icon: CheckCircle,
    className: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  },
  expired: {
    label: 'Expired',
    icon: Clock,
    className: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400',
  },
  cancelled: {
    label: 'Cancelled',
    icon: XCircle,
    className: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  },
};

export function GoalProgressCard({ goal, locale = 'en', className }: GoalProgressCardProps) {
  const config = statusConfig[goal.status];
  const StatusIcon = config.icon;
  const title = locale === 'ar' && goal.titleAr ? goal.titleAr : goal.titleEn;
  const description = locale === 'ar' && goal.descriptionAr ? goal.descriptionAr : goal.descriptionEn;

  const progressColor = goal.progressPercent >= 100
    ? 'bg-green-500'
    : goal.progressPercent >= 50
      ? 'bg-blue-500'
      : 'bg-yellow-500';

  return (
    <Card className={cn('', className)}>
      <CardContent className="pt-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-sm truncate">{title}</h4>
            {description && (
              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{description}</p>
            )}
          </div>
          <Badge variant="secondary" className={cn('shrink-0 text-xs', config.className)}>
            <StatusIcon className="h-3 w-3 me-1" />
            {config.label}
          </Badge>
        </div>

        <div className="space-y-2">
          {/* Progress bar */}
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={cn('h-full transition-all duration-500', progressColor)}
              style={{ width: `${Math.min(goal.progressPercent, 100)}%` }}
            />
          </div>

          {/* Progress details */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              {goal.currentValue} / {goal.targetValue} {goal.unit}
            </span>
            <span className="font-medium">{Math.round(goal.progressPercent)}%</span>
          </div>

          {/* Deadline */}
          {goal.deadline && goal.status === 'active' && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
              <Clock className="h-3 w-3" />
              <span>
                Due {formatDistanceToNow(new Date(goal.deadline), { addSuffix: true })}
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
