'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { BookOpen, Clock, CheckCircle, Star } from 'lucide-react';
import type { SubjectPerformance } from '@/lib/api/performance';

interface SubjectPerformanceCardProps {
  subject: SubjectPerformance;
  locale?: string;
  onClick?: () => void;
  className?: string;
}

const getMasteryLabel = (level: number): string => {
  if (level >= 80) return 'Expert';
  if (level >= 60) return 'Proficient';
  if (level >= 40) return 'Developing';
  return 'Beginner';
};

const getMasteryColor = (level: number): string => {
  if (level >= 80) return 'text-green-600';
  if (level >= 60) return 'text-blue-600';
  if (level >= 40) return 'text-yellow-600';
  return 'text-muted-foreground';
};

export function SubjectPerformanceCard({
  subject,
  locale = 'en',
  onClick,
  className,
}: SubjectPerformanceCardProps) {
  const name = locale === 'ar' && subject.subjectNameAr ? subject.subjectNameAr : subject.subjectName;

  const formatTime = (minutes: number): string => {
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = Math.round(minutes % 60);
      return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
    }
    return `${Math.round(minutes)}m`;
  };

  return (
    <Card
      className={cn(
        'cursor-pointer hover:bg-muted/50 transition-colors',
        className
      )}
      onClick={onClick}
    >
      <CardContent className="pt-4">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <BookOpen className="h-4 w-4 text-primary" />
            </div>
            <div>
              <h4 className="font-medium text-sm">{name}</h4>
              <p className="text-xs text-muted-foreground">
                {subject.chaptersCompleted} / {subject.totalChapters} chapters
              </p>
            </div>
          </div>
          <div className={cn('flex items-center gap-1', getMasteryColor(subject.masteryLevel))}>
            <Star className="h-4 w-4" />
            <span className="text-sm font-medium">{getMasteryLabel(subject.masteryLevel)}</span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mb-4">
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-500"
              style={{ width: `${subject.completionRate}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {Math.round(subject.completionRate)}% complete
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="text-lg font-semibold">{Math.round(subject.avgQuizScore)}%</p>
            <p className="text-xs text-muted-foreground">Quiz Avg</p>
          </div>
          <div>
            <p className="text-lg font-semibold flex items-center justify-center gap-1">
              <CheckCircle className="h-3.5 w-3.5 text-green-600" />
              {subject.quizzesPassed}/{subject.quizzesTaken}
            </p>
            <p className="text-xs text-muted-foreground">Quizzes</p>
          </div>
          <div>
            <p className="text-lg font-semibold flex items-center justify-center gap-1">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              {formatTime(subject.studyTimeMinutes)}
            </p>
            <p className="text-xs text-muted-foreground">Study Time</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
