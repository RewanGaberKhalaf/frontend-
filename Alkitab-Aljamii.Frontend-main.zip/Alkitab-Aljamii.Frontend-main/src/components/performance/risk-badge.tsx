'use client';

import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import type { RiskLevel } from '@/lib/api/performance';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md';
  showDot?: boolean;
  className?: string;
}

const riskConfig: Record<RiskLevel, { label: string; className: string; dotColor: string }> = {
  low: {
    label: 'Low Risk',
    className: 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800',
    dotColor: 'bg-green-500',
  },
  moderate: {
    label: 'Moderate',
    className: 'bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-400 dark:border-yellow-800',
    dotColor: 'bg-yellow-500',
  },
  high: {
    label: 'High Risk',
    className: 'bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800',
    dotColor: 'bg-orange-500',
  },
  critical: {
    label: 'Critical',
    className: 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800',
    dotColor: 'bg-red-500',
  },
};

export function RiskBadge({ level, size = 'md', showDot = true, className }: RiskBadgeProps) {
  const config = riskConfig[level];

  return (
    <Badge
      variant="outline"
      className={cn(
        'font-medium',
        size === 'sm' ? 'text-[10px] px-1.5 py-0' : 'text-xs px-2 py-0.5',
        config.className,
        className
      )}
    >
      {showDot && (
        <span className={cn('w-1.5 h-1.5 rounded-full me-1.5', config.dotColor)} />
      )}
      {config.label}
    </Badge>
  );
}

export function getRiskColor(level: RiskLevel): string {
  const colors: Record<RiskLevel, string> = {
    low: '#10b981',
    moderate: '#f59e0b',
    high: '#f97316',
    critical: '#ef4444',
  };
  return colors[level];
}
