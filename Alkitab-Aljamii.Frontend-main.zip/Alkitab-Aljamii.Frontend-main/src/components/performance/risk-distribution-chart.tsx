'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartTooltip, ChartLegend } from '@/components/shared/chart-tooltip';

interface RiskDistribution {
  low: number;
  moderate: number;
  high: number;
  critical: number;
}

interface RiskDistributionChartProps {
  distribution: RiskDistribution;
  title?: string;
  className?: string;
}

const RISK_COLORS = {
  low: '#10b981',
  moderate: '#f59e0b',
  high: '#f97316',
  critical: '#ef4444',
};

const RISK_LABELS = {
  low: 'Low Risk',
  moderate: 'Moderate',
  high: 'High Risk',
  critical: 'Critical',
};

export function RiskDistributionChart({
  distribution,
  title = 'Risk Distribution',
  className,
}: RiskDistributionChartProps) {
  const data = [
    { name: RISK_LABELS.low, value: distribution.low, color: RISK_COLORS.low },
    { name: RISK_LABELS.moderate, value: distribution.moderate, color: RISK_COLORS.moderate },
    { name: RISK_LABELS.high, value: distribution.high, color: RISK_COLORS.high },
    { name: RISK_LABELS.critical, value: distribution.critical, color: RISK_COLORS.critical },
  ].filter(item => item.value > 0);

  const total = Object.values(distribution).reduce((sum, v) => sum + v, 0);

  if (total === 0) {
    return (
      <Card className={cn('', className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">No data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn('', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[180px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={45}
                outerRadius={70}
                paddingAngle={3}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <ChartLegend items={data} className="mt-2" />
      </CardContent>
    </Card>
  );
}
