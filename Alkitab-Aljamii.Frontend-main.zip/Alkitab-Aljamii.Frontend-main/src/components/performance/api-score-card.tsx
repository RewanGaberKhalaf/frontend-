'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface ApiScoreCardProps {
  score: number;
  trend?: string | null;
  percentile?: number | null;
  title?: string;
  subtitle?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const getScoreColor = (score: number): string => {
  if (score >= 80) return '#10b981'; // green
  if (score >= 60) return '#3b82f6'; // blue
  if (score >= 40) return '#f59e0b'; // amber
  return '#ef4444'; // red
};

const getScoreLabel = (score: number): string => {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Fair';
  return 'Needs Improvement';
};

const getTrendIcon = (trend: string | null | undefined) => {
  if (!trend) return <Minus className="h-4 w-4 text-muted-foreground" />;
  if (trend === 'improving') return <TrendingUp className="h-4 w-4 text-green-600" />;
  if (trend === 'declining') return <TrendingDown className="h-4 w-4 text-red-600" />;
  return <Minus className="h-4 w-4 text-muted-foreground" />;
};

export function ApiScoreCard({
  score,
  trend,
  percentile,
  title = 'Academic Performance Index',
  subtitle,
  size = 'md',
  className,
}: ApiScoreCardProps) {
  const color = getScoreColor(score);
  const label = getScoreLabel(score);
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const sizeClasses = {
    sm: { svg: 'w-24 h-24', text: 'text-2xl', label: 'text-xs' },
    md: { svg: 'w-32 h-32', text: 'text-3xl', label: 'text-sm' },
    lg: { svg: 'w-40 h-40', text: 'text-4xl', label: 'text-base' },
  };

  return (
    <Card className={cn('', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center justify-between">
          {title}
          {getTrendIcon(trend)}
        </CardTitle>
        {subtitle && <CardDescription className="text-xs">{subtitle}</CardDescription>}
      </CardHeader>
      <CardContent className="flex flex-col items-center gap-3">
        <div className="relative">
          <svg className={sizeClasses[size].svg} viewBox="0 0 100 100">
            {/* Background circle */}
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              className="text-muted/20"
            />
            {/* Progress circle */}
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke={color}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-700 ease-out"
              style={{ transform: 'rotate(-90deg)', transformOrigin: 'center' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={cn('font-bold', sizeClasses[size].text)}>{Math.round(score)}</span>
            <span className={cn('text-muted-foreground', sizeClasses[size].label)}>{label}</span>
          </div>
        </div>
        {percentile !== null && percentile !== undefined && (
          <div className="text-center">
            <span className="text-sm text-muted-foreground">
              Top <span className="font-semibold text-foreground">{Math.round(100 - percentile)}%</span> of your faculty
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
