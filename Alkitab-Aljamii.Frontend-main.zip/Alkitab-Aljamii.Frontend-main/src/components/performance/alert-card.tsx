'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  AlertTriangle,
  TrendingDown,
  Clock,
  BookX,
  Timer,
  Eye,
  CheckCircle,
  User,
} from 'lucide-react';
import type { AtRiskAlert, AlertType, RiskLevel } from '@/lib/api/performance';
import { formatDistanceToNow } from 'date-fns';

interface AlertCardProps {
  alert: AtRiskAlert;
  locale?: string;
  onAcknowledge?: (alertId: string) => void;
  onResolve?: (alertId: string) => void;
  onViewStudent?: (userId: string) => void;
  className?: string;
}

const alertTypeIcons: Record<AlertType, typeof AlertTriangle> = {
  low_engagement: Timer,
  declining_performance: TrendingDown,
  quiz_failures: BookX,
  missed_deadline: Clock,
  inactivity: Timer,
  low_completion_rate: TrendingDown,
};

const severityConfig: Record<RiskLevel, { className: string; bgClassName: string }> = {
  low: {
    className: 'border-green-200 dark:border-green-800',
    bgClassName: 'bg-green-50/50 dark:bg-green-900/10',
  },
  moderate: {
    className: 'border-yellow-200 dark:border-yellow-800',
    bgClassName: 'bg-yellow-50/50 dark:bg-yellow-900/10',
  },
  high: {
    className: 'border-orange-200 dark:border-orange-800',
    bgClassName: 'bg-orange-50/50 dark:bg-orange-900/10',
  },
  critical: {
    className: 'border-red-200 dark:border-red-800',
    bgClassName: 'bg-red-50/50 dark:bg-red-900/10',
  },
};

const statusBadgeConfig = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  acknowledged: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  in_progress: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
  resolved: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  escalated: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  dismissed: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400',
};

export function AlertCard({
  alert,
  locale = 'en',
  onAcknowledge,
  onResolve,
  onViewStudent,
  className,
}: AlertCardProps) {
  const Icon = alertTypeIcons[alert.alertType] || AlertTriangle;
  const config = severityConfig[alert.severity];
  const title = locale === 'ar' && alert.titleAr ? alert.titleAr : alert.titleEn;
  const description = locale === 'ar' && alert.descriptionAr ? alert.descriptionAr : alert.descriptionEn;

  return (
    <Card className={cn('border', config.className, config.bgClassName, className)}>
      <CardContent className="pt-4">
        <div className="flex items-start gap-3">
          <div className={cn(
            'p-2 rounded-lg shrink-0',
            alert.severity === 'critical' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' :
            alert.severity === 'high' ? 'bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400' :
            alert.severity === 'moderate' ? 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400' :
            'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400'
          )}>
            <Icon className="h-4 w-4" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <div>
                <h4 className="font-medium text-sm">{title}</h4>
                <button
                  onClick={() => onViewStudent?.(alert.userId)}
                  className="text-xs text-primary hover:underline flex items-center gap-1 mt-0.5"
                >
                  <User className="h-3 w-3" />
                  {alert.studentName}
                </button>
              </div>
              <Badge variant="secondary" className={cn('shrink-0 text-xs', statusBadgeConfig[alert.status])}>
                {alert.status.replace('_', ' ')}
              </Badge>
            </div>

            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{description}</p>

            <div className="flex items-center justify-between mt-3">
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(alert.triggeredAt), { addSuffix: true })}
              </span>

              <div className="flex items-center gap-2">
                {alert.status === 'pending' && onAcknowledge && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => onAcknowledge(alert.id)}
                  >
                    <Eye className="h-3 w-3 me-1" />
                    Acknowledge
                  </Button>
                )}
                {(alert.status === 'acknowledged' || alert.status === 'in_progress') && onResolve && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => onResolve(alert.id)}
                  >
                    <CheckCircle className="h-3 w-3 me-1" />
                    Resolve
                  </Button>
                )}
              </div>
            </div>

            {alert.assignedToName && (
              <div className="mt-2 text-xs text-muted-foreground">
                Assigned to: <span className="font-medium text-foreground">{alert.assignedToName}</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
