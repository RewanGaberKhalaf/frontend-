'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  BookOpen,
  RotateCcw,
  Timer,
  TrendingUp,
  ExternalLink,
} from 'lucide-react';
import type { StudyRecommendation } from '@/lib/api/performance';
import Link from 'next/link';

interface RecommendationCardProps {
  recommendation: StudyRecommendation;
  locale?: string;
  className?: string;
}

const typeIcons: Record<string, typeof BookOpen> = {
  review_chapter: BookOpen,
  retake_quiz: RotateCcw,
  increase_activity: Timer,
  focus_subject: TrendingUp,
};

const priorityColors: Record<number, string> = {
  1: 'border-red-200 bg-red-50/50 dark:border-red-800 dark:bg-red-900/10',
  2: 'border-orange-200 bg-orange-50/50 dark:border-orange-800 dark:bg-orange-900/10',
  3: 'border-yellow-200 bg-yellow-50/50 dark:border-yellow-800 dark:bg-yellow-900/10',
  4: 'border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-900/10',
  5: 'border-green-200 bg-green-50/50 dark:border-green-800 dark:bg-green-900/10',
};

export function RecommendationCard({
  recommendation,
  locale = 'en',
  className,
}: RecommendationCardProps) {
  const Icon = typeIcons[recommendation.type] || TrendingUp;
  const title = locale === 'ar' && recommendation.titleAr ? recommendation.titleAr : recommendation.titleEn;
  const reason = locale === 'ar' && recommendation.reasonAr ? recommendation.reasonAr : recommendation.reasonEn;
  const colorClass = priorityColors[recommendation.priority] || priorityColors[3];

  return (
    <Card className={cn('border', colorClass, className)}>
      <CardContent className="pt-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-primary/10 shrink-0">
            <Icon className="h-4 w-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-sm">{title}</h4>
            <p className="text-xs text-muted-foreground mt-1">{reason}</p>
            {recommendation.deepLink && (
              <Link href={recommendation.deepLink}>
                <Button variant="link" size="sm" className="h-auto p-0 mt-2 text-xs">
                  Go to content
                  <ExternalLink className="h-3 w-3 ms-1" />
                </Button>
              </Link>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
