'use client';

import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { TrendingUp, TrendingDown, Minus, Info, type LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: number | string;
  subtitle?: string;
  icon?: LucideIcon;
  trend?: 'up' | 'down' | 'stable';
  trendValue?: string;
  format?: 'number' | 'percent' | 'time' | 'custom';
  className?: string;
  iconColor?: string;
  href?: string;
  infoTooltip?: React.ReactNode;
}

const formatValue = (value: number | string, format: MetricCardProps['format']): string => {
  if (typeof value === 'string') return value;

  switch (format) {
    case 'percent':
      return `${Math.round(value)}%`;
    case 'time':
      if (value >= 60) {
        const hours = Math.floor(value / 60);
        const mins = Math.round(value % 60);
        return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
      }
      return `${Math.round(value)}m`;
    case 'number':
    default:
      return value.toLocaleString();
  }
};

export function MetricCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendValue,
  format = 'number',
  className,
  iconColor = 'text-primary',
  infoTooltip,
}: MetricCardProps) {
  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;
  const trendColor = trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : 'text-muted-foreground';

  return (
    <Card className={cn('hover:bg-muted/50 transition-colors', className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center gap-1">
          <CardTitle className="text-xs sm:text-sm font-medium">{title}</CardTitle>
          {infoTooltip && (
            <Tooltip>
              <TooltipTrigger asChild>
                <button type="button" className="text-muted-foreground hover:text-foreground transition-colors">
                  <Info className="h-3.5 w-3.5" />
                </button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs" sideOffset={5}>
                {infoTooltip}
              </TooltipContent>
            </Tooltip>
          )}
        </div>
        {Icon && <Icon className={cn('h-4 w-4', iconColor)} />}
      </CardHeader>
      <CardContent>
        <div className="flex items-end gap-2">
          <div className="text-xl sm:text-2xl font-bold">{formatValue(value, format)}</div>
          {trend && (
            <div className={cn('flex items-center gap-0.5 text-xs', trendColor)}>
              <TrendIcon className="h-3 w-3" />
              {trendValue && <span>{trendValue}</span>}
            </div>
          )}
        </div>
        {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
      </CardContent>
    </Card>
  );
}
