'use client';

import { useRef, useEffect } from 'react';
import { MessageSquarePlus, Bookmark, Loader2, X, Send, Highlighter, Bell } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import { CustomSelection, type SelectionRange } from './CustomSelection';

export type PopoverMode = 'buttons' | 'annotate';

export interface PopoverContentProps {
  containerRef: React.RefObject<HTMLElement>;
  selectionRects: DOMRect[];
  selectedText: string;
  isCreating: boolean;
  selectionRange: SelectionRange | null;
  isProfessor: boolean;
  mode: PopoverMode;
  note: string;
  notifyStudents: boolean;
  onSelectionChange: (selection: SelectionRange | null, rects: DOMRect[]) => void;
  onAnnotateClick: (e: React.MouseEvent) => void;
  onBookmarkClick: () => void;
  onSaveAnnotation: () => void;
  onBackToButtons: () => void;
  onNoteChange: (note: string) => void;
  onNotifyChange: (notify: boolean) => void;
}

interface MobileSheetProps extends PopoverContentProps {
  isVisible: boolean;
  onClose: () => void;
}

interface DesktopPopoverProps extends PopoverContentProps {
  isVisible: boolean;
  position: { left: number; top: number };
  onPointerDown: (e: React.MouseEvent | React.TouchEvent) => void;
}

export function MobileSheet({
  containerRef,
  selectionRects,
  selectedText,
  isCreating,
  isProfessor,
  mode,
  note,
  notifyStudents,
  isVisible,
  onClose,
  onSelectionChange,
  onAnnotateClick,
  onBookmarkClick,
  onSaveAnnotation,
  onBackToButtons,
  onNoteChange,
  onNotifyChange,
}: MobileSheetProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (mode === 'annotate' && textareaRef.current) {
      setTimeout(() => textareaRef.current?.focus(), 100);
    }
  }, [mode]);

  return (
    <>
      <CustomSelection
        containerRef={containerRef}
        onSelectionChange={onSelectionChange}
        isActive={true}
        selectionRects={selectionRects}
        highlightColor="rgba(59, 130, 246, 0.3)"
      />

      <Sheet open={isVisible} onOpenChange={(open) => !open && onClose()}>
        <SheetContent
          side="bottom"
          title="Annotate Selection"
          className="rounded-t-xl max-h-[80vh] px-3 sm:px-6"
          data-annotation-popover="true"
          onPointerDownOutside={(e) => e.preventDefault()}
          onInteractOutside={(e) => e.preventDefault()}
        >
          <SheetHeader className="pb-2">
            <SheetTitle className="flex items-center gap-2 text-base sm:text-lg">
              <Highlighter className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
              {mode === 'buttons' ? 'Selected Text' : 'Add Annotation'}
            </SheetTitle>
            <SheetDescription asChild>
              <div className="text-xs sm:text-sm text-muted-foreground italic border-l-2 pl-2 sm:pl-3 border-primary/50 mt-2 line-clamp-3">
                &ldquo;{selectedText.slice(0, 150)}{selectedText.length > 150 ? '...' : ''}&rdquo;
              </div>
            </SheetDescription>
          </SheetHeader>

          <div className="px-0 pb-4 sm:pb-6 pt-2">
            {isCreating ? (
              <div className="flex items-center justify-center gap-2 py-6 sm:py-8 text-muted-foreground">
                <Loader2 className="h-4 w-4 sm:h-5 sm:w-5 animate-spin" />
                <span className="text-sm sm:text-base">Saving...</span>
              </div>
            ) : mode === 'buttons' ? (
              <div className="flex flex-col gap-2 sm:gap-3 mt-3 sm:mt-4">
                <Button
                  size="lg"
                  className="w-full justify-start gap-2 sm:gap-3 h-12 sm:h-14"
                  onClick={onAnnotateClick}
                >
                  <MessageSquarePlus className="h-4 w-4 sm:h-5 sm:w-5 shrink-0" />
                  <div className="text-left">
                    <div className="font-medium text-sm sm:text-base">Annotate</div>
                    <div className="text-[10px] sm:text-xs opacity-80">Ask a question or comment</div>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  size="lg"
                  className="w-full justify-start gap-2 sm:gap-3 h-12 sm:h-14"
                  onClick={onBookmarkClick}
                >
                  <Bookmark className="h-4 w-4 sm:h-5 sm:w-5 shrink-0" />
                  <div className="text-left">
                    <div className="font-medium text-sm sm:text-base">Bookmark</div>
                    <div className="text-[10px] sm:text-xs opacity-80">Save for later (private)</div>
                  </div>
                </Button>
              </div>
            ) : (
              <div className="space-y-3 sm:space-y-4 mt-2">
                <Textarea
                  ref={textareaRef}
                  value={note}
                  onChange={(e) => onNoteChange(e.target.value)}
                  placeholder="Ask a question or leave a comment..."
                  className="min-h-[100px] sm:min-h-[120px] text-sm sm:text-base resize-none"
                  rows={4}
                />

                {isProfessor && (
                  <div className="flex items-center space-x-2 p-2.5 rounded-md bg-amber-500/10 dark:bg-amber-500/20 border border-amber-500/30">
                    <Checkbox
                      id="notify-students-mobile"
                      checked={notifyStudents}
                      onCheckedChange={(checked) => onNotifyChange(checked === true)}
                      className="border-amber-500/50 data-[state=checked]:!bg-amber-500 data-[state=checked]:!border-amber-500 data-[state=checked]:!text-white"
                    />
                    <Label
                      htmlFor="notify-students-mobile"
                      className="text-xs sm:text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-1.5 text-amber-700 dark:text-amber-400"
                    >
                      <Bell className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
                      Notify all students
                    </Label>
                  </div>
                )}

                <div className="flex items-center gap-2 sm:gap-3">
                  <Button
                    variant="outline"
                    className="flex-1 h-10 sm:h-12 text-sm sm:text-base"
                    onClick={onBackToButtons}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1 h-10 sm:h-12 text-sm sm:text-base"
                    onClick={onSaveAnnotation}
                    disabled={!note.trim()}
                  >
                    <Send className="h-3.5 w-3.5 sm:h-4 sm:w-4 me-1.5 sm:me-2" />
                    Post
                  </Button>
                </div>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}

export function DesktopPopover({
  containerRef,
  selectionRects,
  selectedText,
  isCreating,
  isProfessor,
  mode,
  note,
  notifyStudents,
  isVisible,
  position,
  onSelectionChange,
  onAnnotateClick,
  onBookmarkClick,
  onSaveAnnotation,
  onBackToButtons,
  onNoteChange,
  onNotifyChange,
  onPointerDown,
}: DesktopPopoverProps) {
  const popoverRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (mode === 'annotate' && textareaRef.current) {
      setTimeout(() => textareaRef.current?.focus(), 100);
    }
  }, [mode]);

  return (
    <>
      <CustomSelection
        containerRef={containerRef}
        onSelectionChange={onSelectionChange}
        isActive={true}
        selectionRects={selectionRects}
        highlightColor="rgba(59, 130, 246, 0.2)"
      />

      <div
        ref={popoverRef}
        className={cn(
          'fixed z-[9999] pointer-events-auto selection-popover',
          'transition-all duration-150 ease-out',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-1'
        )}
        style={{
          left: position.left,
          top: position.top,
        }}
        onMouseDown={onPointerDown}
        onTouchStart={onPointerDown}
        data-annotation-popover="true"
      >
        <div className={cn(
          'bg-popover border rounded-lg shadow-lg',
          mode === 'buttons' ? 'p-1.5' : 'p-3'
        )}>
          {isCreating ? (
            <div className="px-3 py-1.5 flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Saving...</span>
            </div>
          ) : mode === 'buttons' ? (
            <div className="flex items-center gap-1">
              <button
                onClick={onAnnotateClick}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium',
                  'bg-primary/10 hover:bg-primary/20 text-primary',
                  'transition-colors duration-150',
                  'focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-1'
                )}
                title="Ask a question or leave a comment (visible to classmates & professors)"
              >
                <MessageSquarePlus className="h-4 w-4" />
                <span>Annotate</span>
              </button>

              <div className="w-px h-6 bg-border" />

              <button
                onClick={onBookmarkClick}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm',
                  'hover:bg-muted text-muted-foreground hover:text-foreground',
                  'transition-colors duration-150',
                  'focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-1'
                )}
                title="Save for later (private)"
              >
                <Bookmark className="h-4 w-4" />
                <span>Bookmark</span>
              </button>
            </div>
          ) : (
            <div className="w-72 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquarePlus className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Add Annotation</span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={onBackToButtons}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="text-xs text-muted-foreground italic line-clamp-2 border-l-2 pl-2 border-primary/50">
                &ldquo;{selectedText.slice(0, 100)}{selectedText.length > 100 ? '...' : ''}&rdquo;
              </div>

              <Textarea
                ref={textareaRef}
                value={note}
                onChange={(e) => onNoteChange(e.target.value)}
                placeholder="Ask a question or leave a comment..."
                className="min-h-[80px] text-sm resize-none"
                rows={3}
              />

              {isProfessor && (
                <div className="flex items-center space-x-2 p-2 rounded-md bg-amber-500/10 dark:bg-amber-500/20 border border-amber-500/30">
                  <Checkbox
                    id="notify-students-desktop"
                    checked={notifyStudents}
                    onCheckedChange={(checked) => onNotifyChange(checked === true)}
                    className="border-amber-500/50 data-[state=checked]:!bg-amber-500 data-[state=checked]:!border-amber-500 data-[state=checked]:!text-white"
                  />
                  <Label
                    htmlFor="notify-students-desktop"
                    className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-1.5 cursor-pointer text-amber-700 dark:text-amber-400"
                  >
                    <Bell className="h-3 w-3" />
                    Notify all students
                  </Label>
                </div>
              )}

              <div className="flex items-center justify-end gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onBackToButtons}
                >
                  Cancel
                </Button>
                <Button
                  size="sm"
                  onClick={onSaveAnnotation}
                  disabled={!note.trim()}
                >
                  <Send className="h-3 w-3 me-1.5" />
                  Post
                </Button>
              </div>

              <p className="text-[10px] text-muted-foreground text-center">
                Ctrl+Enter to post
              </p>
            </div>
          )}
        </div>

        {mode === 'buttons' && (
          <div
            className="absolute left-1/2 -translate-x-1/2 -bottom-1.5"
            style={{
              width: 0,
              height: 0,
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderTop: '6px solid hsl(var(--popover))',
              filter: 'drop-shadow(0 1px 1px rgba(0,0,0,0.1))',
            }}
          />
        )}
      </div>
    </>
  );
}
