'use client';

import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { cn } from '@/lib/utils';

export interface SelectionRange {
  startContainer: Node;
  startOffset: number;
  endContainer: Node;
  endOffset: number;
  selectedText: string;
}

interface CustomSelectionProps {
  containerRef: React.RefObject<HTMLElement>;
  onSelectionChange: (selection: SelectionRange | null, rects: DOMRect[]) => void;
  isActive: boolean;
  selectionRects: DOMRect[];
  showHandles?: boolean;
  highlightColor?: string;
}

/**
 * Simple custom selection overlay - just shows the highlight, no handle resizing
 * (Handle resizing with DOM ranges is too fragile across browsers)
 */
export function CustomSelection({
  isActive,
  selectionRects,
  highlightColor = 'rgba(59, 130, 246, 0.3)',
}: CustomSelectionProps) {
  if (!isActive || selectionRects.length === 0) return null;

  return (
    <>
      {/* Selection highlight overlay */}
      {selectionRects.map((rect, index) => (
        <div
          key={index}
          className="fixed pointer-events-none"
          style={{
            left: rect.left,
            top: rect.top,
            width: rect.width,
            height: rect.height,
            backgroundColor: highlightColor,
            borderRadius: '2px',
            zIndex: 9998,
          }}
        />
      ))}
    </>
  );
}

/**
 * Hook to manage custom selection state
 */
export function useCustomSelection(containerRef: React.RefObject<HTMLElement>) {
  const [selectionData, setSelectionData] = useState<SelectionRange | null>(null);
  const [selectionRects, setSelectionRects] = useState<DOMRect[]>([]);
  const [isActive, setIsActive] = useState(false);

  const handleSelectionChange = useCallback((selection: SelectionRange | null, rects: DOMRect[]) => {
    setSelectionData(selection);
    setSelectionRects(rects);
  }, []);

  const activateSelection = useCallback(() => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return false;

    const range = selection.getRangeAt(0);

    // Check if selection is within container
    if (containerRef.current && !containerRef.current.contains(range.commonAncestorContainer)) {
      return false;
    }

    // Get rects
    const rects = Array.from(range.getClientRects()).filter(
      (rect) => rect.width > 0 && rect.height > 0
    );

    if (rects.length === 0) return false;

    setSelectionData({
      startContainer: range.startContainer,
      startOffset: range.startOffset,
      endContainer: range.endContainer,
      endOffset: range.endOffset,
      selectedText: range.toString(),
    });
    setSelectionRects(rects);
    setIsActive(true);

    return true;
  }, [containerRef]);

  const clearSelection = useCallback(() => {
    setSelectionData(null);
    setSelectionRects([]);
    setIsActive(false);
  }, []);

  // Activate with pre-computed rects (avoids re-reading from DOM)
  // On mobile, rects may be empty - that's okay, we still activate
  const activateWithRects = useCallback((selectedText: string, rects: DOMRect[]) => {
    if (!selectedText) return false;

    setSelectionData({
      startContainer: document.body, // Placeholder - not used for display
      startOffset: 0,
      endContainer: document.body,
      endOffset: 0,
      selectedText,
    });
    setSelectionRects(rects);
    setIsActive(true);
    return true;
  }, []);

  // Get bounding rect for popover positioning
  const getBoundingRect = useCallback((): DOMRect | null => {
    if (selectionRects.length === 0) return null;

    const left = Math.min(...selectionRects.map(r => r.left));
    const top = Math.min(...selectionRects.map(r => r.top));
    const right = Math.max(...selectionRects.map(r => r.right));
    const bottom = Math.max(...selectionRects.map(r => r.bottom));

    return new DOMRect(left, top, right - left, bottom - top);
  }, [selectionRects]);

  // Memoize return value to prevent infinite re-renders
  return useMemo(() => ({
    selectionData,
    selectionRects,
    isActive,
    handleSelectionChange,
    activateSelection,
    activateWithRects,
    clearSelection,
    getBoundingRect,
  }), [
    selectionData,
    selectionRects,
    isActive,
    handleSelectionChange,
    activateSelection,
    activateWithRects,
    clearSelection,
    getBoundingRect,
  ]);
}
