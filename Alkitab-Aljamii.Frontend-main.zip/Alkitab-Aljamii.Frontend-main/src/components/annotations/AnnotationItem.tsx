'use client';

import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import {
  MessageSquare,
  MoreVertical,
  Trash2,
  Edit,
  Bookmark,
  AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import type { Annotation } from '@/types';
import { cn } from '@/lib/utils';

interface AnnotationItemProps {
  annotation: Annotation;
  isOwner: boolean;
  isSelected?: boolean;
  onClick: () => void;
  onDelete: () => Promise<void>;
  onEdit?: () => void;
  compact?: boolean;
}

const typeLabels: Record<string, string> = {
  text_highlight: 'Highlight',
  page_comment: 'Page Comment',
  bookmark: 'Bookmark',
  chapter_comment: 'Chapter Comment',
  book_comment: 'Book Comment',
};

const typeIcons: Record<string, React.ReactNode> = {
  bookmark: <Bookmark className="h-3 w-3" />,
};

export function AnnotationItem({
  annotation,
  isOwner,
  isSelected = false,
  onClick,
  onDelete,
  onEdit,
  compact = false,
}: AnnotationItemProps) {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isDeleting) return;
    setIsDeleting(true);
    try {
      await onDelete();
    } finally {
      setIsDeleting(false);
    }
  };

  const initials = `${annotation.user.firstName[0]}${annotation.user.lastName[0]}`.toUpperCase();
  const displayName = `${annotation.user.firstName} ${annotation.user.lastName}`;
  const timeAgo = formatDistanceToNow(new Date(annotation.createdAt), { addSuffix: true });

  return (
    <div
      onClick={onClick}
      className={cn(
        'p-2 sm:p-3 border rounded-lg cursor-pointer transition-colors',
        isSelected
          ? 'border-primary bg-primary/5'
          : 'border-border hover:border-primary/50 hover:bg-accent/50',
        annotation.isOrphaned && 'opacity-75 border-warning'
      )}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-1.5 sm:gap-2">
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 flex-1">
          <Avatar className="h-5 w-5 sm:h-6 sm:w-6 flex-shrink-0">
            <AvatarFallback className="text-[10px] sm:text-xs">{initials}</AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1 flex-wrap">
              <span className="text-xs sm:text-sm font-medium truncate max-w-[120px] sm:max-w-none">{displayName}</span>
              {isOwner && (
                <Badge variant="outline" className="text-[9px] sm:text-[10px] px-1 py-0">
                  You
                </Badge>
              )}
            </div>
            <span className="text-[10px] sm:text-xs text-muted-foreground">{timeAgo}</span>
          </div>
        </div>

        <div className="flex items-center gap-0.5 sm:gap-1 flex-shrink-0">
          {/* Type badge */}
          <Badge
            variant="secondary"
            className="text-[9px] sm:text-[10px] px-1 sm:px-1.5 py-0 flex items-center gap-0.5 sm:gap-1"
            style={
              annotation.highlightColor
                ? { backgroundColor: annotation.highlightColor, color: '#000' }
                : undefined
            }
          >
            {typeIcons[annotation.type]}
            {!compact && <span className="hidden xs:inline">{typeLabels[annotation.type]}</span>}
          </Badge>

          {/* Actions dropdown */}
          {isOwner && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <Button variant="ghost" size="icon" className="h-6 w-6 sm:h-7 sm:w-7">
                  <MoreVertical className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {onEdit && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(); }}>
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={handleDelete}
                  disabled={isDeleting}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  {isDeleting ? 'Deleting...' : 'Delete'}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>

      {/* Orphaned warning */}
      {annotation.isOrphaned && (
        <div className="mt-1.5 sm:mt-2 flex items-center gap-1 text-[10px] sm:text-xs text-warning">
          <AlertTriangle className="h-3 w-3" />
          <span>Content may have changed</span>
        </div>
      )}

      {/* Selected text preview */}
      {annotation.textAnchor?.selectedText && !compact && (
        <div className="mt-1.5 sm:mt-2 text-xs sm:text-sm italic text-muted-foreground line-clamp-2 border-l-2 pl-2"
             style={{ borderColor: annotation.highlightColor || 'currentColor' }}>
          "{annotation.textAnchor.selectedText}"
        </div>
      )}

      {/* Content/Note */}
      {annotation.content && (
        <p className={cn('mt-1.5 sm:mt-2 text-xs sm:text-sm', compact ? 'line-clamp-1' : 'line-clamp-3')}>
          {annotation.content}
        </p>
      )}

      {/* Footer */}
      <div className="mt-1.5 sm:mt-2 flex items-center justify-between text-[10px] sm:text-xs text-muted-foreground">
        <div className="flex items-center gap-2 sm:gap-3">
          {annotation.commentCount > 0 && (
            <span className="flex items-center gap-1">
              <MessageSquare className="h-3 w-3" />
              {annotation.commentCount}
            </span>
          )}
          {annotation.pageNumber && (
            <span>Page {annotation.pageNumber}</span>
          )}
        </div>
      </div>
    </div>
  );
}
