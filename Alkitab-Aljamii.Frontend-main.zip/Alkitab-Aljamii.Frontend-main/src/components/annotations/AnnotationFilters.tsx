'use client';

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import type { AnnotationType } from '@/types';

interface Chapter {
  id: string;
  title: string;
}

interface AnnotationFiltersProps {
  filterType: AnnotationType | 'all';
  filterChapter: string | 'all';
  onFilterTypeChange: (type: AnnotationType | 'all') => void;
  onFilterChapterChange: (chapterId: string | 'all') => void;
  chapters?: Chapter[];
  showChapterFilter?: boolean;
}

const typeOptions: { value: AnnotationType | 'all'; label: string }[] = [
  { value: 'all', label: 'All Types' },
  { value: 'text_highlight', label: 'Highlights' },
  { value: 'page_comment', label: 'Page Comments' },
  { value: 'chapter_comment', label: 'Chapter Comments' },
  { value: 'book_comment', label: 'Book Comments' },
];

export function AnnotationFilters({
  filterType,
  filterChapter,
  onFilterTypeChange,
  onFilterChapterChange,
  chapters = [],
  showChapterFilter = true,
}: AnnotationFiltersProps) {
  const hasActiveFilters = filterType !== 'all' || filterChapter !== 'all';

  const clearFilters = () => {
    onFilterTypeChange('all');
    onFilterChapterChange('all');
  };

  return (
    <div className="flex flex-col xs:flex-row items-stretch xs:items-center gap-2 flex-wrap">
      {/* Type filter */}
      <Select value={filterType} onValueChange={onFilterTypeChange}>
        <SelectTrigger className="w-full xs:w-[120px] sm:w-[140px] h-8 text-xs">
          <SelectValue placeholder="All Types" />
        </SelectTrigger>
        <SelectContent>
          {typeOptions.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Chapter filter */}
      {showChapterFilter && chapters.length > 0 && (
        <Select value={filterChapter} onValueChange={onFilterChapterChange}>
          <SelectTrigger className="w-full xs:w-[130px] sm:w-[160px] h-8 text-xs">
            <SelectValue placeholder="All Chapters" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Chapters</SelectItem>
            {chapters.map((chapter) => (
              <SelectItem key={chapter.id} value={chapter.id}>
                {chapter.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {/* Clear filters button */}
      {hasActiveFilters && (
        <Button
          variant="ghost"
          size="sm"
          className="h-8 px-2 text-xs w-full xs:w-auto"
          onClick={clearFilters}
        >
          <X className="h-3 w-3 mr-1" />
          Clear
        </Button>
      )}
    </div>
  );
}
