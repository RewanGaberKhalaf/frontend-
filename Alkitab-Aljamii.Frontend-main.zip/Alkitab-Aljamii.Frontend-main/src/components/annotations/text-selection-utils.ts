import type { ContentBlock } from "./MobileSelectionSheet";

/**
 * Get the block type from an element
 */
export function getBlockType(element: Element): ContentBlock["type"] {
  const tagName = element.tagName.toLowerCase();
  if (["h1", "h2", "h3", "h4", "h5", "h6"].includes(tagName)) return "heading";
  if (tagName === "pre" || tagName === "code") return "code";
  if (tagName === "li") return "list-item";
  if (tagName === "blockquote") return "blockquote";
  return "paragraph";
}

/**
 * Check if element is a block-level element
 */
export function isBlockElement(element: Element): boolean {
  const blockTags = [
    "p",
    "div",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "li",
    "blockquote",
    "pre",
    "code",
    "section",
    "article",
  ];
  return blockTags.includes(element.tagName.toLowerCase());
}

/**
 * Find all block elements within a container
 */
export function findBlockElements(container: Element): Element[] {
  return Array.from(
    container.querySelectorAll(
      "p, h1, h2, h3, h4, h5, h6, li, blockquote, pre, code, div"
    )
  ).filter((el) => {
    const text = el.textContent?.trim();
    return (
      text &&
      text.length > 0 &&
      !el.querySelector("p, h1, h2, h3, h4, h5, h6, li, blockquote, pre")
    );
  });
}

interface ContentBlocksResult {
  blocks: ContentBlock[];
  selectedBlockIndex: number;
  canExpandUp: boolean;
  canExpandDown: boolean;
}

/**
 * Extract content blocks around the selection
 * Returns the selected block plus surrounding blocks for context
 */
export function getContentBlocksFromSelection(
  selection: Selection,
  container: Element,
  expandCount: number = 2
): ContentBlocksResult {
  if (!selection.rangeCount) {
    return { blocks: [], selectedBlockIndex: -1, canExpandUp: false, canExpandDown: false };
  }

  const range = selection.getRangeAt(0);
  let selectedNode: Node | null = range.startContainer;

  // Find the block element containing the selection
  let selectedBlock: Element | null = null;
  while (selectedNode && selectedNode !== container) {
    if (selectedNode.nodeType === Node.ELEMENT_NODE && isBlockElement(selectedNode as Element)) {
      selectedBlock = selectedNode as Element;
      break;
    }
    selectedNode = selectedNode.parentNode;
  }

  if (!selectedBlock) {
    return {
      blocks: [{ type: "paragraph", text: container.textContent || "" }],
      selectedBlockIndex: 0,
      canExpandUp: false,
      canExpandDown: false,
    };
  }

  // Get all block-level children of the container
  let blockContainer = selectedBlock.parentElement;
  while (blockContainer && blockContainer !== container) {
    const children = Array.from(blockContainer.children);
    if (children.filter(isBlockElement).length > 1) break;
    blockContainer = blockContainer.parentElement;
  }
  if (!blockContainer) blockContainer = container as HTMLElement;

  const allBlocks = findBlockElements(blockContainer);

  // Find index of selected block
  let selectedIndex = allBlocks.indexOf(selectedBlock);
  if (selectedIndex === -1) {
    selectedIndex = allBlocks.findIndex(
      (b) => b.contains(range.startContainer) || range.startContainer.contains(b)
    );
  }
  if (selectedIndex === -1) selectedIndex = 0;

  // Get surrounding blocks
  const startIndex = Math.max(0, selectedIndex - expandCount);
  const endIndex = Math.min(allBlocks.length - 1, selectedIndex + expandCount);

  const blocks: ContentBlock[] = [];
  for (let i = startIndex; i <= endIndex; i++) {
    const el = allBlocks[i];
    if (el) {
      blocks.push({
        type: getBlockType(el),
        text: el.textContent || "",
      });
    }
  }

  return {
    blocks,
    selectedBlockIndex: selectedIndex - startIndex,
    canExpandUp: startIndex > 0,
    canExpandDown: endIndex < allBlocks.length - 1,
  };
}

/**
 * Computes the node path from a DOM node to the container
 * Returns a path like "0.2.1" representing the index path through the DOM tree
 */
export function computeNodePath(node: Node, container: Element): string | null {
  const path: number[] = [];
  let current: Node | null = node;

  if (current.nodeType === Node.TEXT_NODE) {
    current = current.parentNode;
  }

  while (current && current !== container) {
    const parent = current.parentNode;
    if (!parent) break;

    const children = Array.from(parent.childNodes).filter(
      (child) => child.nodeType === Node.ELEMENT_NODE || child.nodeType === Node.TEXT_NODE
    );
    const index = children.indexOf(current as ChildNode);
    if (index === -1) break;

    path.unshift(index);
    current = parent;
  }

  if (current !== container) return null;

  return path.join(".");
}

/**
 * Gets text context around a selection
 */
export function getContext(
  fullText: string,
  startOffset: number,
  endOffset: number,
  contextLength: number = 50
): { prefix: string; suffix: string } {
  const prefix = fullText.substring(Math.max(0, startOffset - contextLength), startOffset);
  const suffix = fullText.substring(endOffset, endOffset + contextLength);
  return { prefix, suffix };
}

/**
 * Extracts all text content from an element
 */
export function getFullTextContent(element: Element): string {
  return element.textContent || "";
}

/**
 * Check if selection is too large (likely accidental)
 */
export function isSelectionTooLarge(
  selectedText: string,
  containerText: string,
  threshold: number = 0.8
): boolean {
  const containerTextLength = containerText.replace(/[\s\u200B-\u200D\u2060\uFEFF]/g, "").length;
  const selectedTextLength = selectedText.replace(/[\s\u200B-\u200D\u2060\uFEFF]/g, "").length;
  return containerTextLength > 0 && selectedTextLength > containerTextLength * threshold;
}
