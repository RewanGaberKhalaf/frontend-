"use client";

import { useRef } from "react";
import type { TextSelectionData } from "@/types";
import { MobileSelectionSheet } from "./MobileSelectionSheet";
import { useIsMobile } from "./use-is-mobile";
import { useTextSelection } from "./use-text-selection";

interface TextSelectionHandlerProps {
  children: React.ReactNode;
  onSelection: (selection: TextSelectionData | null) => void;
  containerClassName?: string;
  /** Called before clearing selection. Return false to prevent clearing (e.g., for unsaved content warning) */
  onBeforeClear?: () => boolean;
}

/**
 * Medium-like text selection handler
 * - Always allows text selection
 * - Keeps selection visible when popover appears
 * - Smooth, non-intrusive experience
 */
export function TextSelectionHandler({
  children,
  onSelection,
  containerClassName,
  onBeforeClear,
}: TextSelectionHandlerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  const {
    mobileSheetOpen,
    setMobileSheetOpen,
    contentBlocks,
    initialMobileSelection,
    canExpandUp,
    canExpandDown,
    handleSelectionStart,
    handleSelectionEnd,
    handleDoubleClick,
    handleMobileSelectionConfirm,
    handleExpandUp,
    handleExpandDown,
  } = useTextSelection({
    containerRef,
    onSelection,
    isMobile,
    onBeforeClear,
  });

  return (
    <>
      <div
        ref={containerRef}
        className={containerClassName}
        onMouseDown={handleSelectionStart}
        onMouseUp={handleSelectionEnd}
        onDoubleClick={handleDoubleClick}
        onTouchStart={handleSelectionStart}
        onTouchEnd={handleSelectionEnd}
        style={
          {
            // Consistent text selection across all content
            userSelect: "text",
            WebkitUserSelect: "text",
            MozUserSelect: "text",
            cursor: "text",
            // Allow long-press text selection on iOS
            WebkitTouchCallout: "default",
            // Allow browser to handle touch gestures for selection handles
            touchAction: "auto",
          } as React.CSSProperties
        }
      >
        {/* Styles for selection behavior */}
        <style jsx>{`
          div :global(img),
          div :global(video),
          div :global(iframe) {
            user-select: none !important;
            -webkit-user-select: none !important;
          }
          /* Ensure text is selectable on mobile */
          div :global(p),
          div :global(span),
          div :global(h1),
          div :global(h2),
          div :global(h3),
          div :global(h4),
          div :global(h5),
          div :global(h6),
          div :global(li),
          div :global(blockquote) {
            -webkit-user-select: text !important;
            user-select: text !important;
          }
        `}</style>
        {children}
      </div>

      {/* Mobile selection sheet */}
      <MobileSelectionSheet
        open={mobileSheetOpen}
        onOpenChange={setMobileSheetOpen}
        contentBlocks={contentBlocks}
        initialSelection={initialMobileSelection}
        onConfirm={handleMobileSelectionConfirm}
        onExpandUp={handleExpandUp}
        onExpandDown={handleExpandDown}
        canExpandUp={canExpandUp}
        canExpandDown={canExpandDown}
      />
    </>
  );
}
