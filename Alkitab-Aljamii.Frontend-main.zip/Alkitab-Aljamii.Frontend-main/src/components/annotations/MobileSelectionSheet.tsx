'use client';

import { useState, useCallback, useMemo, useEffect } from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Check, X, RotateCcw, ChevronUp, ChevronDown } from 'lucide-react';

export interface ContentBlock {
  type: 'paragraph' | 'heading' | 'code' | 'list-item' | 'blockquote' | 'other';
  text: string;
  level?: number; // For headings (1-6)
}

interface MobileSelectionSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contentBlocks: ContentBlock[];
  initialSelection?: string;
  onConfirm: (selectedText: string) => void;
  onExpandUp?: () => void;
  onExpandDown?: () => void;
  canExpandUp?: boolean;
  canExpandDown?: boolean;
}

interface WordToken {
  text: string;
  globalIndex: number;
  blockIndex: number;
  isSpace: boolean;
  isNewline: boolean;
}

function tokenizeBlocks(blocks: ContentBlock[]): WordToken[] {
  const tokens: WordToken[] = [];
  let globalIndex = 0;

  blocks.forEach((block, blockIndex) => {
    // Split by spaces but keep track
    const parts = block.text.split(/(\s+)/);

    for (const part of parts) {
      if (part.length === 0) continue;

      const isSpace = /^\s+$/.test(part);
      const isNewline = /\n/.test(part);

      tokens.push({
        text: part,
        globalIndex,
        blockIndex,
        isSpace,
        isNewline,
      });

      globalIndex++;
    }
  });

  return tokens;
}

function getBlockStyle(block: ContentBlock): string {
  switch (block.type) {
    case 'heading':
      return 'font-bold text-lg';
    case 'code':
      return 'font-mono text-sm bg-muted p-2 rounded border';
    case 'blockquote':
      return 'border-l-4 border-primary/50 pl-3 italic';
    case 'list-item':
      return 'pl-4 before:content-["•"] before:mr-2 before:text-muted-foreground';
    default:
      return '';
  }
}

export function MobileSelectionSheet({
  open,
  onOpenChange,
  contentBlocks,
  initialSelection,
  onConfirm,
  onExpandUp,
  onExpandDown,
  canExpandUp = false,
  canExpandDown = false,
}: MobileSelectionSheetProps) {
  const [startMarker, setStartMarker] = useState<number | null>(null);
  const [endMarker, setEndMarker] = useState<number | null>(null);

  const tokens = useMemo(() => tokenizeBlocks(contentBlocks), [contentBlocks]);

  // Group tokens by block for rendering
  const tokensByBlock = useMemo(() => {
    const grouped: Map<number, WordToken[]> = new Map();
    for (const token of tokens) {
      if (!grouped.has(token.blockIndex)) {
        grouped.set(token.blockIndex, []);
      }
      grouped.get(token.blockIndex)!.push(token);
    }
    return grouped;
  }, [tokens]);

  // Find initial selection in text
  useEffect(() => {
    if (initialSelection && open && tokens.length > 0) {
      // Find the token that matches the start of the initial selection
      const fullText = tokens.filter(t => !t.isSpace).map(t => t.text).join(' ');
      const normalizedSelection = initialSelection.trim();

      // Find first word of selection
      const firstWord = normalizedSelection.split(/\s+/)[0];
      const wordTokens = tokens.filter(t => !t.isSpace);
      const startTokenIdx = wordTokens.findIndex(t => t.text === firstWord);

      if (startTokenIdx !== -1) {
        const startToken = wordTokens[startTokenIdx];
        if (startToken) {
          setStartMarker(startToken.globalIndex);

          // Find last word
          const words = normalizedSelection.split(/\s+/);
          const lastWord = words[words.length - 1];
          // Look for it after the start
          for (let i = startTokenIdx; i < wordTokens.length; i++) {
            const token = wordTokens[i];
            if (token && token.text === lastWord) {
              setEndMarker(token.globalIndex);
              break;
            }
          }
        }
      }
    }
  }, [initialSelection, tokens, open]);

  // Reset when closed
  useEffect(() => {
    if (!open) {
      setStartMarker(null);
      setEndMarker(null);
    }
  }, [open]);

  const handleWordTap = useCallback((globalIndex: number) => {
    if (startMarker === null) {
      setStartMarker(globalIndex);
      setEndMarker(null);
    } else if (endMarker === null) {
      if (globalIndex < startMarker) {
        setEndMarker(startMarker);
        setStartMarker(globalIndex);
      } else {
        setEndMarker(globalIndex);
      }
    } else {
      setStartMarker(globalIndex);
      setEndMarker(null);
    }
  }, [startMarker, endMarker]);

  const handleReset = useCallback(() => {
    setStartMarker(null);
    setEndMarker(null);
  }, []);

  const selectedText = useMemo(() => {
    if (startMarker === null) return '';

    const effectiveEnd = endMarker ?? startMarker;
    const start = Math.min(startMarker, effectiveEnd);
    const end = Math.max(startMarker, effectiveEnd);

    const selectedTokens = tokens.filter(
      t => t.globalIndex >= start && t.globalIndex <= end
    );

    // Reconstruct text with proper spacing
    let result = '';
    let lastBlockIndex = -1;

    for (const token of selectedTokens) {
      if (token.blockIndex !== lastBlockIndex && lastBlockIndex !== -1) {
        result += '\n\n'; // Block separator
      }
      result += token.text;
      lastBlockIndex = token.blockIndex;
    }

    return result.trim();
  }, [startMarker, endMarker, tokens]);

  const handleConfirm = useCallback(() => {
    if (!selectedText) return;
    onConfirm(selectedText);
    onOpenChange(false);
  }, [selectedText, onConfirm, onOpenChange]);

  const handleClose = useCallback(() => {
    onOpenChange(false);
  }, [onOpenChange]);

  const isInSelection = useCallback((globalIndex: number) => {
    if (startMarker === null) return false;
    const effectiveEnd = endMarker ?? startMarker;
    const start = Math.min(startMarker, effectiveEnd);
    const end = Math.max(startMarker, effectiveEnd);
    return globalIndex >= start && globalIndex <= end;
  }, [startMarker, endMarker]);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[70vh] sm:h-[75vh] flex flex-col px-3 sm:px-6">
        <SheetHeader className="shrink-0">
          <SheetTitle className="text-sm sm:text-base">Select Text to Annotate</SheetTitle>
          <p className="text-xs sm:text-sm text-muted-foreground">
            {startMarker === null
              ? 'Tap a word to start your selection'
              : endMarker === null
              ? 'Tap another word to complete selection'
              : 'Selection complete. Confirm or tap to reselect.'}
          </p>
        </SheetHeader>

        {/* Expand up button */}
        {canExpandUp && onExpandUp && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onExpandUp}
            className="shrink-0 w-full text-muted-foreground h-8 text-xs sm:text-sm"
          >
            <ChevronUp className="h-3.5 w-3.5 sm:h-4 sm:w-4 mr-1" />
            Load more above
          </Button>
        )}

        <div className="flex-1 overflow-y-auto my-1.5 sm:my-2 p-2 sm:p-3 bg-muted/30 rounded-lg space-y-2 sm:space-y-3">
          {contentBlocks.map((block, blockIndex) => {
            const blockTokens = tokensByBlock.get(blockIndex) || [];

            return (
              <div
                key={blockIndex}
                className={cn('leading-relaxed', getBlockStyle(block))}
              >
                {blockTokens.map((token) => {
                  if (token.isSpace) {
                    return (
                      <span key={token.globalIndex}>
                        {token.isNewline ? <br /> : token.text}
                      </span>
                    );
                  }

                  const inSelection = isInSelection(token.globalIndex);
                  const isStart = token.globalIndex === startMarker;
                  const isEnd = token.globalIndex === endMarker;

                  return (
                    <span
                      key={token.globalIndex}
                      onClick={() => handleWordTap(token.globalIndex)}
                      className={cn(
                        'cursor-pointer rounded px-0.5 -mx-0.5 transition-colors inline',
                        inSelection && 'bg-yellow-300 dark:bg-yellow-600',
                        isStart && 'ring-2 ring-green-500 ring-offset-1',
                        isEnd && endMarker !== startMarker && 'ring-2 ring-blue-500 ring-offset-1',
                        !inSelection && 'active:bg-muted-foreground/20'
                      )}
                    >
                      {token.text}
                    </span>
                  );
                })}
              </div>
            );
          })}
        </div>

        {/* Expand down button */}
        {canExpandDown && onExpandDown && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onExpandDown}
            className="shrink-0 w-full text-muted-foreground h-8 text-xs sm:text-sm"
          >
            <ChevronDown className="h-3.5 w-3.5 sm:h-4 sm:w-4 mr-1" />
            Load more below
          </Button>
        )}

        {/* Selected text preview */}
        {selectedText && (
          <div className="shrink-0 mb-1.5 sm:mb-2 p-2 sm:p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg max-h-20 sm:max-h-24 overflow-y-auto">
            <p className="text-[10px] sm:text-xs text-muted-foreground mb-0.5 sm:mb-1">Selected text:</p>
            <p className="text-xs sm:text-sm whitespace-pre-wrap line-clamp-3">&ldquo;{selectedText}&rdquo;</p>
          </div>
        )}

        <SheetFooter className="shrink-0 flex-row gap-1.5 sm:gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleReset}
            disabled={startMarker === null}
            className="flex-1 h-9 sm:h-10 text-xs sm:text-sm"
          >
            <RotateCcw className="h-3.5 w-3.5 sm:h-4 sm:w-4 mr-0.5 sm:mr-1" />
            Reset
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleClose}
            className="flex-1 h-9 sm:h-10 text-xs sm:text-sm"
          >
            <X className="h-3.5 w-3.5 sm:h-4 sm:w-4 mr-0.5 sm:mr-1" />
            Cancel
          </Button>
          <Button
            size="sm"
            onClick={handleConfirm}
            disabled={!selectedText}
            className="flex-1 h-9 sm:h-10 text-xs sm:text-sm"
          >
            <Check className="h-3.5 w-3.5 sm:h-4 sm:w-4 mr-0.5 sm:mr-1" />
            Confirm
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

export default MobileSelectionSheet;
