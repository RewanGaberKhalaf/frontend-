/**
 * Utility functions for text highlighting and range creation
 */

/**
 * Finds a text node within a container at a given path
 */
export function findNodeAtPath(container: HTMLElement, path: string): Node | null {
  if (!path) return container;

  const indices = path.split('.').map((i) => parseInt(i, 10));
  let current: Node = container;

  for (const index of indices) {
    const children = Array.from(current.childNodes).filter(
      (child) => child.nodeType === Node.ELEMENT_NODE || child.nodeType === Node.TEXT_NODE
    );

    const child = children[index];
    if (!child) return null;
    current = child;
  }

  return current;
}

/**
 * Strip invisible/zero-width Unicode characters used for content obfuscation
 */
export function stripInvisibleChars(text: string): string {
  // Remove zero-width and invisible Unicode characters
  return text.replace(/[\u200B-\u200D\u2060\uFEFF\u00AD\u034F\u061C\u115F\u1160\u17B4\u17B5\u180E\u2000-\u200F\u202A-\u202F\u205F-\u206F\u3000\u3164\uFE00-\uFE0F]/g, '');
}

/**
 * Normalize text for comparison (collapse whitespace and strip invisible chars)
 */
export function normalizeText(text: string): string {
  return stripInvisibleChars(text).replace(/\s+/g, ' ').trim();
}

/**
 * Maps a clean text offset to the real offset in text with invisible characters
 */
export function mapCleanOffsetToReal(text: string, cleanOffset: number): number {
  let cleanPos = 0;
  let realPos = 0;

  while (cleanPos < cleanOffset && realPos < text.length) {
    const char = text.charAt(realPos);
    // Check if this is an invisible character
    if (!/[\u200B-\u200D\u2060\uFEFF\u00AD\u034F\u061C\u115F\u1160\u17B4\u17B5\u180E\u2000-\u200F\u202A-\u202F\u205F-\u206F\u3000\u3164\uFE00-\uFE0F]/.test(char)) {
      cleanPos++;
    }
    realPos++;
  }

  return realPos;
}

/**
 * Finds text across all text nodes in a container and creates a range
 * Handles invisible characters by searching with stripped text
 */
export function findTextInContainer(
  container: HTMLElement,
  selectedText: string
): Range | null {
  // Strip invisible chars from search text to get the actual visible content
  const cleanSearchText = stripInvisibleChars(selectedText);

  if (!cleanSearchText.trim()) {
    return null;
  }

  // Get all text content and build a map of positions to nodes
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
  const textNodes: { node: Text; start: number; end: number; cleanStart: number; cleanEnd: number }[] = [];
  let totalLength = 0;
  let cleanTotalLength = 0;

  let node: Text | null;
  while ((node = walker.nextNode() as Text | null)) {
    const content = node.textContent || '';
    const cleanContent = stripInvisibleChars(content);
    const length = content.length;
    const cleanLength = cleanContent.length;

    if (length > 0) {
      textNodes.push({
        node,
        start: totalLength,
        end: totalLength + length,
        cleanStart: cleanTotalLength,
        cleanEnd: cleanTotalLength + cleanLength,
      });
      totalLength += length;
      cleanTotalLength += cleanLength;
    }
  }

  // Build full clean text content for searching
  const fullCleanText = textNodes.map((t) => stripInvisibleChars(t.node.textContent || '')).join('');

  // Find the clean search text in clean content
  let cleanTextIndex = fullCleanText.indexOf(cleanSearchText);

  // If not found with exact match, try with normalized whitespace
  if (cleanTextIndex === -1) {
    const normalizedSearch = cleanSearchText.replace(/\s+/g, ' ').trim();
    const normalizedFull = fullCleanText.replace(/\s+/g, ' ');

    // Find position accounting for whitespace normalization
    const searchIndex = normalizedFull.indexOf(normalizedSearch);
    if (searchIndex !== -1) {
      // Map back to original position by counting non-collapsed chars
      let normalizedPos = 0;
      let cleanPos = 0;
      while (normalizedPos < searchIndex && cleanPos < fullCleanText.length) {
        const char = fullCleanText.charAt(cleanPos);
        const prevChar = cleanPos > 0 ? fullCleanText.charAt(cleanPos - 1) : '';
        // Only count if not collapsing whitespace
        if (!/\s/.test(char) || !/\s/.test(prevChar)) {
          normalizedPos++;
        }
        cleanPos++;
      }
      cleanTextIndex = cleanPos;
    }
  }

  if (cleanTextIndex === -1) return null;

  const cleanTextEndIndex = cleanTextIndex + cleanSearchText.length;

  // Find start node and offset using clean positions
  let startNode: Text | null = null;
  let startOffset = 0;
  let endNode: Text | null = null;
  let endOffset = 0;

  for (const textInfo of textNodes) {
    const nodeContent = textInfo.node.textContent || '';

    // Find start node
    if (!startNode && cleanTextIndex >= textInfo.cleanStart && cleanTextIndex < textInfo.cleanEnd) {
      startNode = textInfo.node;
      // Map clean offset to real offset
      const cleanOffsetInNode = cleanTextIndex - textInfo.cleanStart;
      startOffset = mapCleanOffsetToReal(nodeContent, cleanOffsetInNode);
    }

    // Find end node
    if (cleanTextEndIndex > textInfo.cleanStart && cleanTextEndIndex <= textInfo.cleanEnd) {
      endNode = textInfo.node;
      // Map clean offset to real offset
      const cleanOffsetInNode = cleanTextEndIndex - textInfo.cleanStart;
      endOffset = mapCleanOffsetToReal(nodeContent, cleanOffsetInNode);
    }

    if (startNode && endNode) break;
  }

  if (!startNode || !endNode) return null;

  try {
    const range = document.createRange();
    range.setStart(startNode, startOffset);
    range.setEnd(endNode, endOffset);
    return range;
  } catch {
    return null;
  }
}

/**
 * Creates a Range object for a text selection within a node
 * Falls back to searching the entire container if nodePath doesn't work
 */
export function createRange(
  container: HTMLElement,
  nodePath: string,
  startOffset: number,
  endOffset: number,
  selectedText: string
): Range | null {
  // Strip invisible chars from selectedText to get clean version for searching
  const cleanSelectedText = stripInvisibleChars(selectedText);

  // First try: use nodePath to find the specific node
  const node = findNodeAtPath(container, nodePath);
  if (node) {
    // If it's an element, look for text node child
    let textNode = node;
    if (node.nodeType === Node.ELEMENT_NODE) {
      const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
      const firstTextNode = walker.nextNode();
      if (firstTextNode) textNode = firstTextNode;
    }

    if (textNode.nodeType === Node.TEXT_NODE) {
      const textContent = textNode.textContent || '';
      const cleanTextContent = stripInvisibleChars(textContent);

      // Try to find the CLEAN text in this node
      const foundIndex = cleanTextContent.indexOf(cleanSelectedText);
      if (foundIndex !== -1 && cleanSelectedText.length > 0) {
        try {
          // Map clean index back to real index
          const realStartIndex = mapCleanOffsetToReal(textContent, foundIndex);
          const realEndIndex = mapCleanOffsetToReal(textContent, foundIndex + cleanSelectedText.length);
          const range = document.createRange();
          range.setStart(textNode, realStartIndex);
          range.setEnd(textNode, realEndIndex);
          return range;
        } catch {
          // Fall through to container search
        }
      }

      // Try with original offsets ONLY if they create a non-collapsed range
      if (startOffset < endOffset && endOffset <= textContent.length) {
        try {
          const range = document.createRange();
          range.setStart(textNode, startOffset);
          range.setEnd(textNode, endOffset);
          return range;
        } catch {
          // Fall through to container search
        }
      }
    }
  }

  // Fallback: search entire container for the text
  return findTextInContainer(container, selectedText);
}
