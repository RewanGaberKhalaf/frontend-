"use client";

import { useCallback, useRef, useState } from "react";
import type { ContentBlock } from "./MobileSelectionSheet";
import { getBlockType } from "./text-selection-utils";

export interface ExpandState {
  allBlocks: Element[];
  startIndex: number;
  endIndex: number;
  container: Element | null;
}

export interface MobileSelectionState {
  mobileSheetOpen: boolean;
  contentBlocks: ContentBlock[];
  initialMobileSelection: string;
  canExpandUp: boolean;
  canExpandDown: boolean;
}

export interface MobileSelectionActions {
  setMobileSheetOpen: (open: boolean) => void;
  setContentBlocks: (blocks: ContentBlock[]) => void;
  setInitialMobileSelection: (text: string) => void;
  setCanExpandUp: (can: boolean) => void;
  setCanExpandDown: (can: boolean) => void;
  handleExpandUp: () => void;
  handleExpandDown: () => void;
  updateExpandState: (state: ExpandState) => void;
}

export interface UseMobileSelectionReturn extends MobileSelectionState, MobileSelectionActions {}

export function useMobileSelection(): UseMobileSelectionReturn {
  // Mobile selection sheet state
  const [mobileSheetOpen, setMobileSheetOpen] = useState(false);
  const [contentBlocks, setContentBlocks] = useState<ContentBlock[]>([]);
  const [initialMobileSelection, setInitialMobileSelection] = useState("");
  const [canExpandUp, setCanExpandUp] = useState(false);
  const [canExpandDown, setCanExpandDown] = useState(false);

  // Track expansion state for callbacks
  const expandStateRef = useRef<ExpandState>({
    allBlocks: [],
    startIndex: 0,
    endIndex: 0,
    container: null,
  });

  const updateExpandState = useCallback((state: ExpandState) => {
    expandStateRef.current = state;
  }, []);

  // Handle expand up - add more blocks above current selection
  const handleExpandUp = useCallback(() => {
    const { allBlocks, startIndex, container } = expandStateRef.current;
    if (startIndex <= 0 || !container) return;

    // Add 2 more blocks above
    const newStartIndex = Math.max(0, startIndex - 2);
    expandStateRef.current.startIndex = newStartIndex;

    // Rebuild blocks array
    const newBlocks: ContentBlock[] = [];
    for (let i = newStartIndex; i <= expandStateRef.current.endIndex; i++) {
      const el = allBlocks[i];
      if (el) {
        newBlocks.push({
          type: getBlockType(el),
          text: el.textContent || "",
        });
      }
    }

    setContentBlocks(newBlocks);
    setCanExpandUp(newStartIndex > 0);
  }, []);

  // Handle expand down - add more blocks below current selection
  const handleExpandDown = useCallback(() => {
    const { allBlocks, endIndex, container } = expandStateRef.current;
    if (endIndex >= allBlocks.length - 1 || !container) return;

    // Add 2 more blocks below
    const newEndIndex = Math.min(allBlocks.length - 1, endIndex + 2);
    expandStateRef.current.endIndex = newEndIndex;

    // Rebuild blocks array
    const newBlocks: ContentBlock[] = [];
    for (let i = expandStateRef.current.startIndex; i <= newEndIndex; i++) {
      const el = allBlocks[i];
      if (el) {
        newBlocks.push({
          type: getBlockType(el),
          text: el.textContent || "",
        });
      }
    }

    setContentBlocks(newBlocks);
    setCanExpandDown(newEndIndex < allBlocks.length - 1);
  }, []);

  return {
    // State
    mobileSheetOpen,
    contentBlocks,
    initialMobileSelection,
    canExpandUp,
    canExpandDown,
    // Setters
    setMobileSheetOpen,
    setContentBlocks,
    setInitialMobileSelection,
    setCanExpandUp,
    setCanExpandDown,
    // Actions
    handleExpandUp,
    handleExpandDown,
    updateExpandState,
  };
}
