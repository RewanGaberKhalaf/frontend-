'use client';

import { useEffect, useState, useRef, useCallback, useMemo } from 'react';
import type { Annotation } from '@/types';
import { cn } from '@/lib/utils';
import { createRange } from './highlight-utils';

// Teaching annotation highlight color (distinct from student colors)
const TEACHING_ANNOTATION_COLOR = '#0EA5E9'; // Sky blue

interface HighlightPosition {
  annotationId: string;
  rects: DOMRect[];
  color: string;
  isOrphaned: boolean;
  isTeachingAnnotation: boolean;
}

interface HighlightRendererProps {
  annotations: Annotation[];
  containerRef: React.RefObject<HTMLElement>;
  onHighlightClick: (annotation: Annotation) => void;
  selectedAnnotationId?: string | null;
  /** Annotation to focus/flash (e.g., when navigating from sidebar) */
  focusedAnnotationId?: string | null;
  /** Current user ID to determine which annotations to show */
  currentUserId?: string;
  /** Whether to show user's own highlights by default */
  showOwnHighlights?: boolean;
  /** Whether to show all highlights (for professor view) */
  showAllHighlights?: boolean;
  /** Current page number for filtering annotations */
  currentPage?: number;
}

export function HighlightRenderer({
  annotations,
  containerRef,
  onHighlightClick,
  selectedAnnotationId,
  focusedAnnotationId,
  currentUserId,
  showOwnHighlights = false,
  showAllHighlights = false,
  currentPage,
}: HighlightRendererProps) {
  const [highlights, setHighlights] = useState<HighlightPosition[]>([]);
  const [flashingId, setFlashingId] = useState<string | null>(null);
  const overlayRef = useRef<HTMLDivElement>(null);

  // Handle focused annotation - flash and scroll into view
  useEffect(() => {
    if (!focusedAnnotationId) {
      // Clear flash when focus is removed
      setFlashingId(null);
      return;
    }

    setFlashingId(focusedAnnotationId);
    // Clear flash after animation
    const timeout = setTimeout(() => {
      setFlashingId(null);
    }, 3500);
    return () => clearTimeout(timeout);
  }, [focusedAnnotationId]);

  // Filter annotations to show:
  // - Teaching annotations are always visible to all users
  // - All annotations if showAllHighlights is enabled (professor view)
  // - Only focused annotation OR
  // - User's own annotations if showOwnHighlights is enabled (on current page)
  const visibleAnnotations = useMemo(() => {
    return annotations.filter((a) => {
      // Always show focused annotation (user navigated to its page)
      if (a.id === focusedAnnotationId) return true;

      // Check if annotation is on current page (or has no page - show on all pages)
      const isOnCurrentPage = !a.pageNumber || !currentPage || a.pageNumber === currentPage;

      // Teaching annotations are always visible to all users on the current page
      if (a.isTeachingAnnotation && isOnCurrentPage) {
        return true;
      }

      // Show all annotations if enabled (professor view)
      if (showAllHighlights && isOnCurrentPage) {
        return true;
      }

      // Show own annotations if enabled AND on current page
      if (showOwnHighlights && currentUserId && a.user?.id === currentUserId && isOnCurrentPage) {
        return true;
      }

      // Hide others
      return false;
    });
  }, [annotations, focusedAnnotationId, showOwnHighlights, showAllHighlights, currentUserId, currentPage]);

  const calculateHighlights = useCallback(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const containerRect = container.getBoundingClientRect();

    // Calculate scale factor by comparing actual size to visual size
    // This handles CSS transform: scale() applied to ancestors
    const scaleX = container.offsetWidth > 0 ? containerRect.width / container.offsetWidth : 1;
    const scaleY = container.offsetHeight > 0 ? containerRect.height / container.offsetHeight : 1;

    const newHighlights: HighlightPosition[] = [];

    for (const annotation of visibleAnnotations) {
      if (!annotation.textAnchor || annotation.type !== 'text_highlight') continue;

      const { nodePath, startOffset, endOffset, selectedText } = annotation.textAnchor;

      const range = createRange(container, nodePath, startOffset, endOffset, selectedText);
      if (!range) continue;

      const rects = Array.from(range.getClientRects()).map((rect) => {
        // Convert screen coordinates to container-relative coordinates
        // Then divide by scale to get unscaled coordinates for CSS positioning
        const relativeLeft = (rect.left - containerRect.left + container.scrollLeft * scaleX) / scaleX;
        const relativeTop = (rect.top - containerRect.top + container.scrollTop * scaleY) / scaleY;
        const width = rect.width / scaleX;
        const height = rect.height / scaleY;

        return new DOMRect(relativeLeft, relativeTop, width, height);
      });

      if (rects.length > 0) {
        // Teaching annotations use a distinct color
        const color = annotation.isTeachingAnnotation
          ? TEACHING_ANNOTATION_COLOR
          : (annotation.highlightColor || '#FFEB3B');

        newHighlights.push({
          annotationId: annotation.id,
          rects,
          color,
          isOrphaned: annotation.isOrphaned,
          isTeachingAnnotation: annotation.isTeachingAnnotation ?? false,
        });
      }
    }

    setHighlights(newHighlights);
  }, [visibleAnnotations, containerRef]);

  // Track scale changes to recalculate highlights when zoom changes
  const lastScaleRef = useRef({ x: 1, y: 1 });

  // Single consolidated effect for highlight calculation
  // Runs on mount, when annotations change, page changes, etc.
  useEffect(() => {
    // Delay to ensure DOM is ready
    const timeout = setTimeout(() => {
      calculateHighlights();
    }, 150);

    // Debounced resize handler
    let resizeTimeout: NodeJS.Timeout;
    const handleResize = () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(calculateHighlights, 100);
    };

    // Check for scale changes (zoom) periodically
    // This is needed because CSS transforms don't trigger resize events
    let scaleCheckInterval: NodeJS.Timeout;
    if (containerRef.current) {
      scaleCheckInterval = setInterval(() => {
        if (!containerRef.current) return;
        const container = containerRef.current;
        const rect = container.getBoundingClientRect();
        const scaleX = container.offsetWidth > 0 ? rect.width / container.offsetWidth : 1;
        const scaleY = container.offsetHeight > 0 ? rect.height / container.offsetHeight : 1;

        // If scale changed, recalculate
        if (Math.abs(scaleX - lastScaleRef.current.x) > 0.01 ||
            Math.abs(scaleY - lastScaleRef.current.y) > 0.01) {
          lastScaleRef.current = { x: scaleX, y: scaleY };
          calculateHighlights();
        }
      }, 200);
    }

    window.addEventListener('resize', handleResize);
    return () => {
      clearTimeout(timeout);
      clearTimeout(resizeTimeout);
      clearInterval(scaleCheckInterval);
      window.removeEventListener('resize', handleResize);
    };
  }, [calculateHighlights, containerRef]);

  const handleHighlightClick = (annotationId: string) => {
    const annotation = annotations.find((a) => a.id === annotationId);
    if (annotation) {
      onHighlightClick(annotation);
    }
  };

  if (highlights.length === 0) return null;

  return (
    <div
      ref={overlayRef}
      className="absolute inset-0 pointer-events-none"
      style={{ zIndex: 10 }}
    >
      {/* CSS for flash animation - subtle fade in/out */}
      <style jsx>{`
        @keyframes highlight-fade-in {
          0% { opacity: 0; }
          20% { opacity: 1; }
          80% { opacity: 1; }
          100% { opacity: 0; }
        }
        .flash-highlight {
          animation: highlight-fade-in 3.5s ease-in-out forwards;
        }
      `}</style>
      {highlights.map((highlight) => {
        const isFlashing = highlight.annotationId === flashingId;
        const isSelected = highlight.annotationId === selectedAnnotationId;
        const isFocused = highlight.annotationId === focusedAnnotationId;
        const isTeaching = highlight.isTeachingAnnotation;

        // Determine background color based on state
        let bgColor = 'transparent';
        let borderColor = 'transparent';
        let borderWidth = '2px';

        if (isFlashing || isFocused) {
          // Flash/focus: blue highlight
          bgColor = 'rgba(59, 130, 246, 0.15)';
          borderColor = 'rgba(59, 130, 246, 0.8)';
        } else if (isTeaching) {
          // Teaching annotations: always visible with distinct styling
          const color = highlight.color || TEACHING_ANNOTATION_COLOR;
          bgColor = `${color}30`; // 19% opacity for teaching annotations
          borderColor = color;
          borderWidth = '3px'; // Thicker border for teaching annotations
        } else if (showAllHighlights || showOwnHighlights) {
          // Show highlights: use their highlight color with transparency
          const color = highlight.color || '#FFEB3B';
          bgColor = `${color}40`; // 25% opacity
          borderColor = color;
        }

        // Generate title/tooltip
        let title = '';
        if (highlight.isOrphaned) {
          title = 'This highlight may be outdated';
        } else if (isTeaching) {
          title = 'Instructor note';
        }

        return (
          <div key={highlight.annotationId}>
            {highlight.rects.map((rect, index) => (
              <div
                key={`${highlight.annotationId}-${index}`}
                className={cn(
                  'absolute pointer-events-auto cursor-pointer transition-all duration-300',
                  isFlashing && 'flash-highlight',
                  highlight.isOrphaned && 'opacity-30'
                )}
                style={{
                  left: rect.left,
                  top: rect.top,
                  width: rect.width,
                  height: rect.height,
                  backgroundColor: bgColor,
                  borderBottom: borderColor !== 'transparent' ? `${borderWidth} solid ${borderColor}` : 'none',
                  borderRadius: '2px',
                }}
                onClick={() => handleHighlightClick(highlight.annotationId)}
                title={title || undefined}
              />
            ))}
          </div>
        );
      })}
    </div>
  );
}
