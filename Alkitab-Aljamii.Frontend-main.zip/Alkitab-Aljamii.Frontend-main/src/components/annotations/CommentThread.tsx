'use client';

import React, { useState, useMemo } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Send, Trash2, Reply } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import type { AnnotationComment, CreateCommentDto } from '@/types';
import { cn } from '@/lib/utils';

interface CommentItemProps {
  comment: AnnotationComment;
  /** The annotation author's user ID */
  annotationUserId: string;
  /** Whether this is from a teaching annotation (shows Instructor instead of Author) */
  isTeachingAnnotation?: boolean;
  currentUserId: string;
  onReply?: (parentId: string) => void;
  onDelete?: (commentId: string) => Promise<void>;
  depth?: number;
}

function CommentItem({
  comment,
  annotationUserId,
  isTeachingAnnotation = false,
  currentUserId,
  onReply,
  onDelete,
  depth = 0,
}: CommentItemProps) {
  const [isDeleting, setIsDeleting] = useState(false);

  const initials = `${comment.user.firstName[0]}${comment.user.lastName[0]}`.toUpperCase();
  const displayName = `${comment.user.firstName} ${comment.user.lastName}`;
  const timeAgo = formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true });
  const canDelete = comment.user.id === currentUserId;
  // Check if this comment is from the annotation author
  const isAnnotationAuthor = comment.user.id === annotationUserId;

  const handleDelete = async () => {
    if (!onDelete || isDeleting) return;
    setIsDeleting(true);
    try {
      await onDelete(comment.id);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className={cn('space-y-2', depth > 0 && 'ml-4 sm:ml-6 border-l pl-2 sm:pl-3')}>
      <div className="flex items-start gap-1.5 sm:gap-2">
        <Avatar className="h-6 w-6 sm:h-7 sm:w-7 flex-shrink-0">
          <AvatarFallback className="text-[10px] sm:text-xs">{initials}</AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
            <span className="text-xs sm:text-sm font-medium truncate max-w-[120px] sm:max-w-none">{displayName}</span>
            {/* Show Instructor badge for any teaching staff member */}
            {comment.isTeachingStaff ? (
              <Badge variant="default" className="text-[9px] sm:text-[10px] px-1 py-0 bg-sky-500 hover:bg-sky-500">
                Instructor
              </Badge>
            ) : isAnnotationAuthor ? (
              <Badge variant="outline" className="text-[9px] sm:text-[10px] px-1 py-0">
                Author
              </Badge>
            ) : null}
            <span className="text-[10px] sm:text-xs text-muted-foreground">{timeAgo}</span>
            {comment.isEdited && (
              <span className="text-[10px] sm:text-xs text-muted-foreground">(edited)</span>
            )}
          </div>

          <p className="text-xs sm:text-sm mt-1 whitespace-pre-wrap">{comment.content}</p>

          <div className="flex items-center gap-1 sm:gap-2 mt-1">
            {onReply && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 px-1.5 sm:px-2 text-[10px] sm:text-xs"
                onClick={() => onReply(comment.id)}
              >
                <Reply className="h-3 w-3 mr-0.5 sm:mr-1" />
                Reply
              </Button>
            )}
            {canDelete && onDelete && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 px-1.5 sm:px-2 text-[10px] sm:text-xs text-destructive hover:text-destructive"
                onClick={handleDelete}
                disabled={isDeleting}
              >
                <Trash2 className="h-3 w-3 mr-0.5 sm:mr-1" />
                {isDeleting ? '...' : 'Delete'}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Nested replies */}
      {comment.replies && comment.replies.length > 0 && (
        <div className="space-y-2">
          {comment.replies.map((reply) => (
            <CommentItem
              key={reply.id}
              comment={reply}
              annotationUserId={annotationUserId}
              isTeachingAnnotation={isTeachingAnnotation}
              currentUserId={currentUserId}
              onReply={onReply}
              onDelete={onDelete}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface CommentThreadProps {
  comments: AnnotationComment[];
  annotationUserId: string;
  currentUserId: string;
  onAddComment: (data: CreateCommentDto) => Promise<void>;
  onDeleteComment: (commentId: string) => Promise<void>;
  isLoading?: boolean;
  /** When true, shows simplified notes UI (no replies, different placeholder) */
  isPrivate?: boolean;
  /** Whether this is a teaching annotation (shows Instructor badge instead of Author) */
  isTeachingAnnotation?: boolean;
}

export function CommentThread({
  comments,
  annotationUserId,
  currentUserId,
  onAddComment,
  onDeleteComment,
  isLoading = false,
  isPrivate = false,
  isTeachingAnnotation = false,
}: CommentThreadProps) {
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Build a proper tree structure from flat comments list
  // This handles both cases: API returning nested replies OR flat list with parentId
  const commentTree = useMemo(() => {
    // Create a map for quick lookup
    const commentMap = new Map<string, AnnotationComment>();
    comments.forEach(c => {
      // Clone the comment to avoid mutating props, and ensure replies array exists
      commentMap.set(c.id, { ...c, replies: c.replies ? [...c.replies] : [] });
    });

    const rootComments: AnnotationComment[] = [];

    // Build the tree
    commentMap.forEach(comment => {
      if (comment.parentId) {
        // This is a reply - add it to parent's replies
        const parent = commentMap.get(comment.parentId);
        if (parent) {
          // Only add if not already in replies (avoid duplicates)
          if (!parent.replies?.some(r => r.id === comment.id)) {
            parent.replies = parent.replies || [];
            parent.replies.push(comment);
          }
        }
      } else {
        // This is a root comment
        rootComments.push(comment);
      }
    });

    // Sort by creation date (oldest first)
    rootComments.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    return rootComments;
  }, [comments]);

  const handleSubmit = async () => {
    if (!newComment.trim() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      await onAddComment({
        content: newComment.trim(),
        parentId: replyingTo ?? undefined,
      });
      setNewComment('');
      setReplyingTo(null);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReply = (parentId: string) => {
    setReplyingTo(parentId);
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
  };

  const replyingToComment = replyingTo
    ? comments.find((c) => c.id === replyingTo)
    : null;

  return (
    <div className="space-y-3 sm:space-y-4">
      {/* Comments list */}
      {comments.length === 0 ? (
        <p className="text-xs sm:text-sm text-muted-foreground text-center py-3 sm:py-4">
          {isPrivate ? 'No notes yet. Add a note below.' : 'No comments yet. Be the first to comment!'}
        </p>
      ) : (
        <div className="space-y-2 sm:space-y-3">
          {commentTree.map((comment) => (
            <CommentItem
              key={comment.id}
              comment={comment}
              annotationUserId={annotationUserId}
              isTeachingAnnotation={isTeachingAnnotation}
              currentUserId={currentUserId}
              onReply={isPrivate ? undefined : handleReply}
              onDelete={onDeleteComment}
            />
          ))}
        </div>
      )}

      {/* Reply indicator */}
      {replyingToComment && (
        <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-muted-foreground bg-accent/50 p-1.5 sm:p-2 rounded">
          <Reply className="h-3.5 w-3.5 sm:h-4 sm:w-4 shrink-0" />
          <span className="truncate">
            Replying to {replyingToComment.user.firstName}
          </span>
          <Button
            variant="ghost"
            size="sm"
            className="h-5 px-1 ml-auto text-[10px] sm:text-xs shrink-0"
            onClick={handleCancelReply}
          >
            Cancel
          </Button>
        </div>
      )}

      {/* Comment input */}
      <div className="flex gap-1.5 sm:gap-2">
        <Textarea
          placeholder={
            isPrivate
              ? 'Add a note...'
              : replyingTo
                ? 'Write a reply...'
                : 'Add a comment...'
          }
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="min-h-[50px] sm:min-h-[60px] text-xs sm:text-sm resize-none"
          disabled={isLoading || isSubmitting}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
              handleSubmit();
            }
          }}
        />
        <Button
          size="icon"
          className="h-8 w-8 sm:h-10 sm:w-10 shrink-0"
          onClick={handleSubmit}
          disabled={!newComment.trim() || isLoading || isSubmitting}
        >
          <Send className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
        </Button>
      </div>
      <p className="text-[10px] sm:text-xs text-muted-foreground">
        Press Ctrl+Enter to send
      </p>
    </div>
  );
}
