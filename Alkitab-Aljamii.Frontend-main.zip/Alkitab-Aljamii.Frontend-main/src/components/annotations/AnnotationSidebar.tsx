'use client';

import { useEffect } from 'react';
import { X, ChevronLeft, Loader2, MessageSquarePlus, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAnnotationStore, useAnnotations, useSelectedAnnotation } from '@/stores/annotation-store';
import { useAuthStore } from '@/stores/auth-store';
import { AnnotationItem } from './AnnotationItem';
import { AnnotationFilters } from './AnnotationFilters';
import { CommentThread } from './CommentThread';
import type { Annotation, CreateCommentDto } from '@/types';
import { cn } from '@/lib/utils';

interface ChapterInfo {
  id: string;
  title: string;
}

interface AnnotationSidebarProps {
  chapters?: ChapterInfo[];
  onAnnotationClick?: (annotation: Annotation) => void;
  className?: string;
}

/**
 * Annotation sidebar component
 * - Integrated into layout (not fixed position)
 * - Shows list of annotations with filters
 * - Click annotation to view details and comments
 */
export function AnnotationSidebar({
  chapters = [],
  onAnnotationClick,
  className,
}: AnnotationSidebarProps) {
  const user = useAuthStore((state) => state.user);

  const annotations = useAnnotations();
  const selectedAnnotation = useSelectedAnnotation();
  const filterType = useAnnotationStore((state) => state.filterType);
  const filterChapter = useAnnotationStore((state) => state.filterChapter);
  const isLoading = useAnnotationStore((state) => state.isLoading);
  const hasNextPage = useAnnotationStore((state) => state.hasNextPage);
  const total = useAnnotationStore((state) => state.total);
  const isSidebarOpen = useAnnotationStore((state) => state.isSidebarOpen);
  const bookId = useAnnotationStore((state) => state.bookId);
  const error = useAnnotationStore((state) => state.error);
  const isRateLimited = useAnnotationStore((state) => state.isRateLimited);

  const {
    fetchAnnotations,
    fetchMoreAnnotations,
    selectAnnotation,
    deleteAnnotation,
    setFilterType,
    setFilterChapter,
    setSidebarOpen,
    addComment,
    deleteComment,
  } = useAnnotationStore();

  // Fetch annotations when context changes
  useEffect(() => {
    if (bookId) {
      fetchAnnotations();
    }
  }, [bookId, fetchAnnotations]);

  const handleClose = () => {
    setSidebarOpen(false);
    selectAnnotation(null);
  };

  const handleBack = () => {
    selectAnnotation(null);
  };

  const handleAnnotationClick = (annotation: Annotation) => {
    selectAnnotation(annotation);
    onAnnotationClick?.(annotation);
  };

  const handleDeleteAnnotation = async (id: string) => {
    await deleteAnnotation(id);
  };

  const handleAddComment = async (data: CreateCommentDto) => {
    if (!selectedAnnotation) return;
    await addComment(selectedAnnotation.id, data);
  };

  const handleDeleteComment = async (commentId: string) => {
    await deleteComment(commentId);
  };

  // Render annotation list items
  const renderAnnotationList = () => {
    const items: Annotation[] = annotations;
    return items.map((item) => (
      <AnnotationItem
        key={item.id}
        annotation={item}
        isOwner={user?.id === item.user.id}
        isSelected={selectedAnnotation?.id === item.id}
        onClick={() => handleAnnotationClick(item)}
        onDelete={async () => handleDeleteAnnotation(item.id)}
        compact
      />
    ));
  };

  // Don't render if not open
  if (!isSidebarOpen) return null;

  return (
    <>
      {/* Mobile backdrop */}
      <div
        className="fixed inset-0 bg-black/50 z-40 md:hidden"
        onClick={handleClose}
      />

      {/* Sidebar */}
      <div
        className={cn(
          // Responsive width: full on very small, 80 (320px) on sm+, 96 (384px) on lg+
          'w-full xs:w-80 lg:w-96 shrink-0 bg-background border-s flex flex-col overflow-hidden',
          'transition-all duration-200 ease-out',
          // Mobile: fixed overlay from the end (right in LTR, left in RTL)
          'fixed md:relative inset-y-0 end-0 z-50 md:z-auto',
          'top-0 h-full md:h-auto',
          // Max width on mobile to leave some space
          'max-w-[calc(100vw-3rem)] xs:max-w-none',
          className
        )}
      >
      {/* Header */}
      <div className="flex items-center justify-between p-2 sm:p-3 border-b shrink-0">
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          {selectedAnnotation && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 sm:h-8 sm:w-8 shrink-0"
              onClick={handleBack}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
          )}
          <h3 className="font-medium text-sm truncate">
            {selectedAnnotation ? 'Annotation Details' : 'Annotations'}
          </h3>
          {!selectedAnnotation && total > 0 && (
            <span className="text-xs text-muted-foreground shrink-0">({total})</span>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 sm:h-8 sm:w-8 shrink-0"
          onClick={handleClose}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {selectedAnnotation ? (
        // Detail view
        <ScrollArea className="flex-1">
          <div className="p-2 sm:p-3 space-y-3 sm:space-y-4">
            {/* Annotation details */}
            <AnnotationItem
              annotation={selectedAnnotation}
              isOwner={user?.id === selectedAnnotation.user.id}
              isSelected={false}
              onClick={() => {}}
              onDelete={async () => handleDeleteAnnotation(selectedAnnotation.id)}
            />

            {/* Comments/Notes section */}
            <div className="border-t pt-4">
              {selectedAnnotation.type === 'bookmark' || selectedAnnotation.visibility === 'private' ? (
                // Private bookmark - show notes section (no replies, simplified UI)
                <>
                  <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                    <MessageSquarePlus className="h-4 w-4" />
                    Notes
                  </h4>
                  <CommentThread
                    comments={selectedAnnotation.comments || []}
                    annotationUserId={selectedAnnotation.user.id}
                    currentUserId={user?.id || ''}
                    onAddComment={handleAddComment}
                    onDeleteComment={handleDeleteComment}
                    isPrivate={true}
                    isTeachingAnnotation={selectedAnnotation.isTeachingAnnotation}
                  />
                </>
              ) : (
                // Public annotation - show comments section with full functionality
                <>
                  <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                    <MessageSquarePlus className="h-4 w-4" />
                    Comments ({selectedAnnotation.commentCount})
                  </h4>
                  <CommentThread
                    comments={selectedAnnotation.comments || []}
                    annotationUserId={selectedAnnotation.user.id}
                    currentUserId={user?.id || ''}
                    onAddComment={handleAddComment}
                    onDeleteComment={handleDeleteComment}
                    isTeachingAnnotation={selectedAnnotation.isTeachingAnnotation}
                  />
                </>
              )}
            </div>
          </div>
        </ScrollArea>
      ) : (
        // List view
        <>
          {/* Filters */}
          <div className="p-2 sm:p-3 border-b shrink-0">
            <AnnotationFilters
              filterType={filterType}
              filterChapter={filterChapter}
              onFilterTypeChange={setFilterType}
              onFilterChapterChange={setFilterChapter}
              chapters={chapters}
            />
          </div>

          {/* Annotations list */}
          <ScrollArea className="flex-1">
            <div className="p-2 sm:p-3 space-y-2">
              {isLoading && (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              )}

              {/* Error state */}
              {!isLoading && error && (
                <div className="text-center py-6 sm:py-8 px-2">
                  <AlertTriangle className={cn(
                    "h-8 w-8 sm:h-10 sm:w-10 mx-auto mb-3",
                    isRateLimited ? "text-amber-500" : "text-destructive"
                  )} />
                  <p className="text-sm font-medium mb-1">
                    {isRateLimited ? 'Too many requests' : 'Failed to load'}
                  </p>
                  <p className="text-xs text-muted-foreground mb-4">
                    {isRateLimited
                      ? 'Please wait a moment and try again.'
                      : 'Something went wrong loading annotations.'}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchAnnotations()}
                    className="gap-1.5"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    Try Again
                  </Button>
                </div>
              )}

              {!isLoading && !error && annotations.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <p className="text-sm">No annotations yet</p>
                  <p className="text-xs mt-1">
                    Select text to create a highlight
                  </p>
                </div>
              )}

              {!isLoading && !error && annotations.length > 0 && (
                <>
                  {renderAnnotationList()}

                  {/* Load more */}
                  {hasNextPage && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-2"
                      onClick={fetchMoreAnnotations}
                    >
                      Load More
                    </Button>
                  )}
                </>
              )}
            </div>
          </ScrollArea>
        </>
      )}
      </div>
    </>
  );
}
