"use client";

import { useCallback, useRef, useEffect, useState } from "react";
import type { TextSelectionData } from "@/types";
import type { ContentBlock } from "./MobileSelectionSheet";
import {
  computeNodePath,
  getContext,
  getFullTextContent,
  getContentBlocksFromSelection,
  isSelectionTooLarge,
} from "./text-selection-utils";
import { useMobileSelection } from "./use-mobile-selection";

interface UseTextSelectionOptions {
  containerRef: React.RefObject<HTMLDivElement | null>;
  onSelection: (selection: TextSelectionData | null) => void;
  isMobile: boolean;
  /** Called before clearing selection. Return false to prevent clearing (e.g., for unsaved content warning) */
  onBeforeClear?: () => boolean;
}

interface UseTextSelectionReturn {
  hasActiveSelection: boolean;
  mobileSheetOpen: boolean;
  setMobileSheetOpen: (open: boolean) => void;
  contentBlocks: ContentBlock[];
  initialMobileSelection: string;
  canExpandUp: boolean;
  canExpandDown: boolean;
  handleSelectionStart: () => void;
  handleSelectionEnd: () => void;
  handleDoubleClick: () => void;
  handleMobileSelectionConfirm: (selectedText: string) => void;
  handleExpandUp: () => void;
  handleExpandDown: () => void;
}

export function useTextSelection({
  containerRef,
  onSelection,
  isMobile,
  onBeforeClear,
}: UseTextSelectionOptions): UseTextSelectionReturn {
  const [hasActiveSelection, setHasActiveSelection] = useState(false);

  // Mobile selection state
  const mobileSelection = useMobileSelection();
  const {
    mobileSheetOpen,
    contentBlocks,
    initialMobileSelection,
    canExpandUp,
    canExpandDown,
    setMobileSheetOpen,
    setContentBlocks,
    setInitialMobileSelection,
    setCanExpandUp,
    setCanExpandDown,
    handleExpandUp,
    handleExpandDown,
    updateExpandState,
  } = mobileSelection;

  // Stable refs
  const onSelectionRef = useRef(onSelection);
  const isMobileRef = useRef(isMobile);
  const containerRefStable = useRef(containerRef.current);
  const lastTextRef = useRef("");
  const popoverActiveRef = useRef(false);
  const hasActiveSelectionRef = useRef(hasActiveSelection);
  const onBeforeClearRef = useRef(onBeforeClear);

  useEffect(() => { onSelectionRef.current = onSelection; }, [onSelection]);
  useEffect(() => { isMobileRef.current = isMobile; }, [isMobile]);
  useEffect(() => { containerRefStable.current = containerRef.current; }, [containerRef]);
  useEffect(() => { hasActiveSelectionRef.current = hasActiveSelection; }, [hasActiveSelection]);
  useEffect(() => { onBeforeClearRef.current = onBeforeClear; }, [onBeforeClear]);

  // Check if click is inside annotation UI
  const isInsideAnnotationUI = useCallback((target: HTMLElement | null): boolean => {
    if (!target) return false;
    return !!(
      target.closest("[data-annotation-popover]") ||
      target.closest(".selection-popover") ||
      target.closest('[data-slot="sheet-content"]') ||
      target.closest('[role="dialog"]') ||
      target.closest('[data-radix-popper-content-wrapper]')
    );
  }, []);

  // Process current selection
  const processCurrentSelection = useCallback(() => {
    const container = containerRefStable.current || containerRef.current;
    if (!container) return;

    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
      return;
    }

    const range = selection.getRangeAt(0);

    // Must be within our container
    if (!container.contains(range.commonAncestorContainer)) {
      return;
    }

    const selectedText = selection.toString().trim();
    if (!selectedText || selectedText.length < 3) {
      return;
    }

    // Skip if same text already selected
    if (selectedText === lastTextRef.current && hasActiveSelectionRef.current) {
      return;
    }

    // Guard against huge selections
    const containerText = container.textContent || "";
    if (isSelectionTooLarge(selectedText, containerText, 0.8)) {
      return;
    }

    // Compute node path
    let nodePath = computeNodePath(range.startContainer, container);
    if (!nodePath) {
      nodePath = computeNodePath(range.commonAncestorContainer, container);
    }
    if (!nodePath) {
      nodePath = "0";
    }

    // Get context
    const fullText = getFullTextContent(container);
    const selectionStart = fullText.indexOf(selectedText);
    let prefixContext = "";
    let suffixContext = "";
    if (selectionStart !== -1) {
      const ctx = getContext(fullText, selectionStart, selectionStart + selectedText.length);
      prefixContext = ctx.prefix;
      suffixContext = ctx.suffix;
    }

    const rect = range.getBoundingClientRect();
    const rects = Array.from(range.getClientRects()).filter((r) => r.width > 0 && r.height > 0);

    // Mobile: open sheet
    if (isMobileRef.current) {
      const blockData = getContentBlocksFromSelection(selection, container, 2);
      if (blockData.blocks.length > 0) {
        const allBlocks = Array.from(
          container.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li, blockquote, pre, code, div")
        ).filter((el) => {
          const text = el.textContent?.trim();
          return text && text.length > 0 && !el.querySelector("p, h1, h2, h3, h4, h5, h6, li, blockquote, pre");
        });

        const selectedIndex = blockData.selectedBlockIndex;
        const startIdx = Math.max(0, selectedIndex);
        const endIdx = Math.min(allBlocks.length - 1, selectedIndex + blockData.blocks.length - 1);

        updateExpandState({
          allBlocks,
          startIndex: startIdx,
          endIndex: endIdx,
          container,
        });

        setContentBlocks(blockData.blocks);
        setInitialMobileSelection(selectedText);
        setCanExpandUp(blockData.canExpandUp);
        setCanExpandDown(blockData.canExpandDown);
        setMobileSheetOpen(true);
        selection.removeAllRanges();
      }
      return;
    }

    // Desktop: show popover
    const selectionData: TextSelectionData = {
      nodePath,
      startOffset: range.startOffset,
      endOffset: range.endOffset,
      selectedText,
      prefixContext,
      suffixContext,
      rect,
      rects,
    };

    lastTextRef.current = selectedText;
    popoverActiveRef.current = true;
    setHasActiveSelection(true);
    onSelectionRef.current(selectionData);
  }, [containerRef, updateExpandState, setContentBlocks, setInitialMobileSelection, setCanExpandUp, setCanExpandDown, setMobileSheetOpen]);

  // Clear selection state
  const clearSelection = useCallback(() => {
    if (hasActiveSelectionRef.current) {
      // Check if caller wants to prevent clearing (e.g., unsaved content)
      if (onBeforeClearRef.current && !onBeforeClearRef.current()) {
        return; // Don't clear
      }
      setHasActiveSelection(false);
      lastTextRef.current = "";
      popoverActiveRef.current = false;
      onSelectionRef.current(null);
    }
  }, []);

  // Listen to mouseup to detect selection completion
  useEffect(() => {
    const handleMouseUp = (e: MouseEvent) => {
      const target = e.target as HTMLElement;

      // If clicking inside annotation UI, don't process
      if (isInsideAnnotationUI(target)) {
        return;
      }

      // Process selection after browser finalizes it
      requestAnimationFrame(() => {
        setTimeout(() => {
          const selection = window.getSelection();
          const selectedText = selection?.toString().trim() || "";
          const hasValidSelection = selection && !selection.isCollapsed && selectedText.length >= 3;

          if (hasValidSelection) {
            // User made a selection - process it
            processCurrentSelection();
          } else {
            // User just clicked without selecting - dismiss popover
            clearSelection();
          }
        }, 20);
      });
    };

    document.addEventListener("mouseup", handleMouseUp);
    return () => document.removeEventListener("mouseup", handleMouseUp);
  }, [isInsideAnnotationUI, processCurrentSelection, clearSelection]);


  // No-op handlers for interface compatibility
  const handleSelectionStart = useCallback(() => {}, []);
  const handleSelectionEnd = useCallback(() => {}, []);
  const handleDoubleClick = useCallback(() => {
    // Process immediately on double-click
    setTimeout(() => processCurrentSelection(), 10);
  }, [processCurrentSelection]);

  const handleMobileSelectionConfirm = useCallback((selectedText: string) => {
    const fullText = contentBlocks.map((b) => b.text).join("\n\n");
    const selectionStart = fullText.indexOf(selectedText);

    const selectionData: TextSelectionData = {
      nodePath: "0",
      startOffset: Math.max(0, selectionStart),
      endOffset: selectionStart + selectedText.length,
      selectedText,
      prefixContext: selectionStart > 0 ? fullText.substring(Math.max(0, selectionStart - 50), selectionStart) : "",
      suffixContext: fullText.substring(selectionStart + selectedText.length, selectionStart + selectedText.length + 50),
      rect: new DOMRect(0, 0, 0, 0),
      rects: [],
    };

    setHasActiveSelection(true);
    lastTextRef.current = selectedText;
    onSelectionRef.current(selectionData);
  }, [contentBlocks]);

  return {
    hasActiveSelection,
    mobileSheetOpen,
    setMobileSheetOpen,
    contentBlocks,
    initialMobileSelection,
    canExpandUp,
    canExpandDown,
    handleSelectionStart,
    handleSelectionEnd,
    handleDoubleClick,
    handleMobileSelectionConfirm,
    handleExpandUp,
    handleExpandDown,
  };
}
