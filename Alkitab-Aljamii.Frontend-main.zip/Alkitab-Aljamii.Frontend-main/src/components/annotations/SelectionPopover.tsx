'use client';

import { useEffect, useRef, useState } from 'react';
import { MobileSheet, DesktopPopover, type PopoverMode } from './selection-popover-content';
import type { SelectionRange } from './CustomSelection';

// Default highlight color for public annotations (warm yellow)
const DEFAULT_HIGHLIGHT_COLOR = '#fef08a';

interface SelectionPopoverProps {
  /** The container ref where selection is made */
  containerRef: React.RefObject<HTMLElement>;
  /** Current selection rects */
  selectionRects: DOMRect[];
  /** Bounding rect for positioning the popover */
  boundingRect: DOMRect | null;
  /** Selected text */
  selectedText: string;
  /** Callback when highlight/annotation is created */
  onHighlight: (color: string, text: string, range: SelectionRange, note?: string, notifyStudents?: boolean) => Promise<void>;
  /** Callback when bookmark is clicked (private highlight) */
  onBookmark: (text: string, range: SelectionRange, note?: string) => Promise<void>;
  /** Callback when selection changes */
  onSelectionChange: (selection: SelectionRange | null, rects: DOMRect[]) => void;
  /** Close the popover */
  onClose: () => void;
  /** Whether currently creating annotation */
  isCreating?: boolean;
  /** Current selection range data */
  selectionRange: SelectionRange | null;
  /** Whether the current user is a professor/teaching staff (shows notify option) */
  isProfessor?: boolean;
  /** Called when note text changes (for tracking unsaved content) */
  onNoteStateChange?: (hasNote: boolean) => void;
}

// Hook to detect mobile
function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return isMobile;
}

/**
 * Selection popover for annotations
 * - Desktop: floating popover above selection
 * - Mobile: bottom sheet drawer
 */
export function SelectionPopover({
  containerRef,
  selectionRects,
  boundingRect,
  selectedText,
  onHighlight,
  onBookmark,
  onClose,
  onSelectionChange,
  isCreating = false,
  selectionRange,
  isProfessor = false,
  onNoteStateChange,
}: SelectionPopoverProps) {
  const popoverRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [position, setPosition] = useState({ left: 0, top: 0 });
  const [mode, setMode] = useState<PopoverMode>('buttons');
  const [note, setNote] = useState('');
  const [notifyStudents, setNotifyStudents] = useState(false);
  const isMobile = useIsMobile();

  // Calculate position for desktop popover
  useEffect(() => {
    if (!boundingRect || isMobile) return;

    const popoverWidth = mode === 'buttons' ? 200 : 300;

    const left = Math.max(
      8,
      Math.min(
        boundingRect.left + boundingRect.width / 2 - popoverWidth / 2,
        window.innerWidth - popoverWidth - 8
      )
    );

    const topOffset = mode === 'buttons' ? 52 : 180;
    let top = boundingRect.top - topOffset;

    if (top < 8) {
      top = boundingRect.bottom + 8;
    }

    top = Math.min(top, window.innerHeight - (mode === 'buttons' ? 60 : 220));
    top = Math.max(8, top);

    setPosition({ left, top });

    requestAnimationFrame(() => {
      setIsVisible(true);
    });
  }, [boundingRect, mode, isMobile]);

  // Auto-show on mobile when there's selected text
  useEffect(() => {
    if (isMobile && selectedText) {
      setIsVisible(true);
    }
  }, [isMobile, selectedText]);

  // Notify parent when note state changes (for unsaved content detection)
  useEffect(() => {
    onNoteStateChange?.(note.trim().length > 0);
  }, [note, onNoteStateChange]);

  // Handle click outside for desktop
  useEffect(() => {
    if (isMobile) return;

    const handleInteractionOutside = (e: MouseEvent | TouchEvent) => {
      const target = (e.target || (e as TouchEvent).touches?.[0]?.target) as HTMLElement;
      if (!target) return;

      if (popoverRef.current && !popoverRef.current.contains(target)) {
        if (target.closest('.chapter-content, .ProseMirror')) {
          return;
        }
        onClose();
      }
    };

    const timeout = setTimeout(() => {
      document.addEventListener('mousedown', handleInteractionOutside);
    }, 100);

    return () => {
      clearTimeout(timeout);
      document.removeEventListener('mousedown', handleInteractionOutside);
    };
  }, [onClose, isMobile]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (mode !== 'buttons') {
          setMode('buttons');
          setNote('');
        } else {
          onClose();
        }
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && mode === 'annotate' && note.trim()) {
        handleSaveAnnotation();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [mode, note, onClose]);

  const handleAnnotateClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setMode('annotate');
  };

  const handleBookmarkClick = async () => {
    if (isCreating || !selectionRange) return;
    await onBookmark(selectedText, selectionRange);
  };

  const handleSaveAnnotation = async () => {
    if (isCreating || !selectionRange || !note.trim()) return;
    await onHighlight(DEFAULT_HIGHLIGHT_COLOR, selectedText, selectionRange, note.trim(), notifyStudents);
    // Clear note state after successful save so click-off doesn't warn
    onNoteStateChange?.(false);
  };

  const handleBackToButtons = () => {
    setMode('buttons');
    setNote('');
    setNotifyStudents(false);
    onNoteStateChange?.(false);
  };

  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
  };

  const handleSheetClose = () => {
    setMode('buttons');
    setNote('');
    onNoteStateChange?.(false);
    onClose();
  };

  // On desktop, we need boundingRect for positioning
  // On mobile, we use a bottom sheet so we don't need it
  if (!isMobile && !boundingRect) return null;

  // Shared props for both mobile and desktop
  const contentProps = {
    containerRef,
    selectionRects,
    selectedText,
    isCreating,
    selectionRange,
    isProfessor,
    mode,
    note,
    notifyStudents,
    onSelectionChange,
    onAnnotateClick: handleAnnotateClick,
    onBookmarkClick: handleBookmarkClick,
    onSaveAnnotation: handleSaveAnnotation,
    onBackToButtons: handleBackToButtons,
    onNoteChange: setNote,
    onNotifyChange: setNotifyStudents,
  };

  // Mobile: Bottom Sheet
  if (isMobile) {
    return (
      <MobileSheet
        {...contentProps}
        isVisible={isVisible}
        onClose={handleSheetClose}
      />
    );
  }

  // Desktop: Floating Popover
  return (
    <DesktopPopover
      {...contentProps}
      isVisible={isVisible}
      position={position}
      onPointerDown={handlePointerDown}
    />
  );
}

export { useCustomSelection } from './CustomSelection';
export type { SelectionRange } from './CustomSelection';
