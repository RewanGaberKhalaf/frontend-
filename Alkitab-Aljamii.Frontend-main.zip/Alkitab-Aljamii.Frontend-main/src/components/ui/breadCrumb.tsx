"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useTranslations } from "next-intl";
import { ChevronRight, Home } from "lucide-react";

interface Crumb {
  label: string;
  href?: string;
  isNavigable: boolean;
}

// Role prefixes that are dashboards themselves
const ROLE_PREFIXES = ["super-admin", "faculty-admin", "professor", "student"];

// Segments that are not standalone pages (action/context segments)
const NON_NAVIGABLE_SEGMENTS = ["new", "edit", "docs"];

// Segments that should be replaced with a parent page in breadcrumbs
// Maps: segment -> { role -> { label: translationKey, href: path } }
const SEGMENT_REPLACEMENTS: Record<string, Record<string, { label: string; href: string }>> = {
  "view": {
    "student": { label: "nav.browseContent", href: "/student/browse" },
    "professor": { label: "nav.myContent", href: "/professor/my-content" },
    "super-admin": { label: "nav.content", href: "/super-admin/content" },
    "faculty-admin": { label: "nav.contentApproval", href: "/faculty-admin/content-approval" },
  },
  "preview": {
    "super-admin": { label: "nav.content", href: "/super-admin/content" },
    "faculty-admin": { label: "nav.contentApproval", href: "/faculty-admin/content-approval" },
  },
};

// Valid routes map - segments that have actual pages
const VALID_ROUTES: Record<string, string[]> = {
  "super-admin": ["users", "faculties", "subjects", "content", "course-mappings", "analytics", "announcements", "performance"],
  "faculty-admin": ["subjects", "professors", "students", "content-approval", "course-mappings", "analytics", "announcements"],
  "professor": ["subjects", "my-content", "books", "quizzes", "question-banks", "analytics", "announcements", "performance"],
  "student": ["subjects", "browse", "books", "performance"],
};

export default function Breadcrumbs() {
  const pathname = usePathname();
  const t = useTranslations();

  if (!pathname) return null;

  const segments = pathname.split("/").filter(Boolean);

  // Don't show breadcrumbs on root dashboard pages
  if (segments.length <= 1 && ROLE_PREFIXES.includes(segments[0] ?? "")) {
    return null;
  }

  const isId = (value: string) => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const numericRegex = /^[0-9]+$/;
    return uuidRegex.test(value) || numericRegex.test(value);
  };

  const getLabel = (segment: string): string => {
    // Handle IDs
    if (isId(segment)) {
      return t("common.details");
    }

    // Handle role prefixes
    if (ROLE_PREFIXES.includes(segment)) {
      const roleKey = segment.replace("-", "_").toUpperCase();
      return t(`roles.${roleKey}`);
    }

    // Map segment to translation key
    const segmentToTranslation: Record<string, string> = {
      "users": "nav.users",
      "faculties": "nav.faculties",
      "subjects": "nav.courses",
      "content": "nav.content",
      "course-mappings": "nav.courseMappings",
      "professors": "nav.professors",
      "students": "nav.students",
      "content-approval": "nav.contentApproval",
      "my-content": "nav.myContent",
      "browse": "nav.browseContent",
      "books": "nav.books",
      "quizzes": "nav.quizzes",
      "question-banks": "nav.questionBanks",
      "analytics": "nav.analytics",
      "announcements": "nav.announcements",
      "performance": "nav.performance",
      "view": t("common.view"),
      "preview": t("common.preview"),
      "new": t("common.new"),
      "edit": t("common.edit"),
      "docs": t("common.documentation"),
    };

    const translationKey = segmentToTranslation[segment];
    if (translationKey) {
      // For view/preview/new/edit, return the value directly (already translated)
      if (["view", "preview", "new", "edit", "docs"].includes(segment)) {
        return translationKey;
      }
      return t(translationKey);
    }

    // Fallback: capitalize and format
    return segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, " ");
  };

  const isNavigable = (segment: string, index: number, allSegments: string[]): boolean => {
    // Last segment is never navigable (current page)
    if (index === allSegments.length - 1) {
      return false;
    }

    // IDs are not navigable
    if (isId(segment)) {
      return false;
    }

    // Non-navigable segments like "view", "new", "edit"
    if (NON_NAVIGABLE_SEGMENTS.includes(segment)) {
      return false;
    }

    // Role prefixes are navigable (they're dashboards)
    if (ROLE_PREFIXES.includes(segment)) {
      return true;
    }

    // Check if this segment is a valid route under its parent role
    const rolePrefix = allSegments[0];
    if (rolePrefix && VALID_ROUTES[rolePrefix]) {
      return VALID_ROUTES[rolePrefix].includes(segment);
    }

    return false;
  };

  const crumbs: Crumb[] = segments.map((segment, index) => {
    const rolePrefix = segments[0];

    // Check if this segment should be replaced with a parent page link
    const replacement = rolePrefix && SEGMENT_REPLACEMENTS[segment]?.[rolePrefix];
    if (replacement) {
      return {
        label: t(replacement.label),
        href: replacement.href,
        isNavigable: true,
      };
    }

    const href = "/" + segments.slice(0, index + 1).join("/");
    const navigable = isNavigable(segment, index, segments);
    const label = getLabel(segment);

    return {
      label,
      href: navigable ? href : undefined,
      isNavigable: navigable,
    };
  });

  return (
    <nav aria-label="Breadcrumb" className="mb-4">
      <ol className="flex items-center gap-1 text-sm">
        {/* Home */}
        <li>
          <Link
            href="/"
            className="flex items-center text-muted-foreground hover:text-foreground transition-colors"
          >
            <Home className="h-4 w-4" />
          </Link>
        </li>

        {crumbs.map((crumb, index) => {
          const isLast = index === crumbs.length - 1;

          return (
            <li key={index} className="flex items-center">
              <ChevronRight className="h-4 w-4 mx-1 text-muted-foreground/50" />

              {crumb.href ? (
                <Link
                  href={crumb.href}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  {crumb.label}
                </Link>
              ) : (
                <span
                  className={
                    isLast
                      ? "font-medium text-foreground"
                      : "text-muted-foreground/70"
                  }
                >
                  {crumb.label}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
