'use client';

import { UseFormWatch, UseFormSetValue, UseFormRegister, FieldErrors } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DateTimePicker } from '@/components/ui/date-time-picker';
import { cn } from '@/lib/utils';
import type { FacultyRole } from '@/lib/api/notifications';
import type { Faculty, Subject } from '@/types';

interface FormData {
  titleEn: string;
  titleAr?: string;
  messageEn: string;
  messageAr?: string;
  facultyId?: string;
  subjectId?: string;
  targetRole?: FacultyRole;
  useTemplate?: boolean;
  deepLink?: string;
  isDraft?: boolean;
  scheduledDate?: Date;
  expiresDate?: Date;
}

interface TitleFieldsProps {
  register: UseFormRegister<FormData>;
  errors: FieldErrors<FormData>;
  t: (key: string) => string;
  tCommon: (key: string) => string;
}

export function TitleFields({ register, errors, t, tCommon }: TitleFieldsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label htmlFor="titleEn">{t('titleEn')} *</Label>
        <Input id="titleEn" {...register('titleEn', { required: true })} placeholder="Important Update" />
        {errors.titleEn && <span className="text-xs text-destructive">{tCommon('required')}</span>}
      </div>
      <div className="space-y-2">
        <Label htmlFor="titleAr">{t('titleAr')}</Label>
        <Input id="titleAr" {...register('titleAr')} placeholder="تحديث مهم" dir="rtl" />
      </div>
    </div>
  );
}

interface MessageFieldsProps {
  register: UseFormRegister<FormData>;
  errors: FieldErrors<FormData>;
  t: (key: string) => string;
  tCommon: (key: string) => string;
}

export function MessageFields({ register, errors, t, tCommon }: MessageFieldsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label htmlFor="messageEn">{t('messageEn')} *</Label>
        <Textarea id="messageEn" {...register('messageEn', { required: true })} placeholder="Please note the following changes..." rows={4} />
        {errors.messageEn && <span className="text-xs text-destructive">{tCommon('required')}</span>}
      </div>
      <div className="space-y-2">
        <Label htmlFor="messageAr">{t('messageAr')}</Label>
        <Textarea id="messageAr" {...register('messageAr')} placeholder="يرجى ملاحظة التغييرات التالية..." rows={4} dir="rtl" />
      </div>
    </div>
  );
}

interface TargetingFieldsProps {
  watch: UseFormWatch<FormData>;
  setValue: UseFormSetValue<FormData>;
  faculties: Faculty[];
  subjects: Subject[];
  allowedRoles: FacultyRole[];
  hideFacultySelect: boolean;
  hideSubjectSelect: boolean;
  hideRoleSelect: boolean;
  t: (key: string) => string;
  tCommon: (key: string) => string;
}

export function TargetingFields({ watch, setValue, faculties, subjects, allowedRoles, hideFacultySelect, hideSubjectSelect, hideRoleSelect, t, tCommon }: TargetingFieldsProps) {
  const selectedFacultyId = watch('facultyId');
  const filteredSubjects = selectedFacultyId ? subjects.filter((s) => s.facultyId === selectedFacultyId) : subjects;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {!hideFacultySelect && faculties.length > 0 && (
        <div className="space-y-2">
          <Label>{t('targetFaculty')}</Label>
          <Select value={selectedFacultyId || 'all'} onValueChange={(v) => { setValue('facultyId', v === 'all' ? undefined : v); setValue('subjectId', undefined); }}>
            <SelectTrigger><SelectValue placeholder={tCommon('all')} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{tCommon('all')}</SelectItem>
              {faculties.map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}
      {!hideSubjectSelect && filteredSubjects.length > 0 && (
        <div className="space-y-2">
          <Label>{t('targetSubject')}</Label>
          <Select value={watch('subjectId') || 'all'} onValueChange={(v) => setValue('subjectId', v === 'all' ? undefined : v)}>
            <SelectTrigger><SelectValue placeholder={tCommon('all')} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{tCommon('all')}</SelectItem>
              {filteredSubjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}
      {!hideRoleSelect && (
        <div className="space-y-2">
          <Label>{t('targetRole')}</Label>
          <Select value={watch('targetRole') || 'all'} onValueChange={(v) => setValue('targetRole', v === 'all' ? undefined : v as FacultyRole)}>
            <SelectTrigger><SelectValue placeholder={t('allRoles')} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('allRoles')}</SelectItem>
              {allowedRoles.map((role) => <SelectItem key={role} value={role}>{role.replace('_', ' ')}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}

interface OptionsFieldsProps {
  register: UseFormRegister<FormData>;
  watch: UseFormWatch<FormData>;
  useTemplate: boolean;
  setValue: UseFormSetValue<FormData>;
  faculties: Faculty[];
  subjects: Subject[];
  t: (key: string) => string;
}

export function OptionsFields({ register, watch, useTemplate, setValue, faculties, subjects, t }: OptionsFieldsProps) {
  const selectedFacultyId = watch('facultyId');
  const selectedSubjectId = watch('subjectId');
  const currentDeepLink = watch('deepLink');

  // Generate smart link suggestions based on targeting
  const linkSuggestions: { label: string; value: string }[] = [];

  if (selectedSubjectId) {
    const subject = subjects.find(s => s.id === selectedSubjectId);
    if (subject) {
      linkSuggestions.push(
        { label: `Subject: ${subject.name}`, value: `/student/browse?subject=${selectedSubjectId}` },
      );
    }
  }

  if (selectedFacultyId) {
    const faculty = faculties.find(f => f.id === selectedFacultyId);
    if (faculty) {
      linkSuggestions.push(
        { label: `Faculty: ${faculty.name}`, value: `/student/browse?faculty=${selectedFacultyId}` },
      );
    }
  }

  // Add common links
  linkSuggestions.push(
    { label: 'Dashboard', value: '/student' },
    { label: 'Browse Content', value: '/student/browse' },
    { label: 'My Books', value: '/student/books' },
  );

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>{t('deepLink')}</Label>
        <Input
          {...register('deepLink')}
          placeholder="/student/browse"
        />
        {linkSuggestions.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {linkSuggestions.map((link, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setValue('deepLink', link.value)}
                className={cn(
                  'text-xs px-2 py-1 rounded-md transition-colors',
                  currentDeepLink === link.value
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted hover:bg-muted/80 text-muted-foreground'
                )}
              >
                {link.label}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="flex items-center gap-2">
        <Switch checked={useTemplate} onCheckedChange={(checked) => setValue('useTemplate', checked)} />
        <Label className="text-sm">{t('useTemplate')}</Label>
      </div>
    </div>
  );
}

interface SchedulingFieldsProps {
  scheduledDate?: Date;
  expiresDate?: Date;
  setValue: UseFormSetValue<FormData>;
  t: (key: string) => string;
  tCommon: (key: string) => string;
}

export function SchedulingFields({ scheduledDate, expiresDate, setValue, t, tCommon }: SchedulingFieldsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label>{t('scheduledAt')}</Label>
        <DateTimePicker
          value={scheduledDate}
          onChange={(date) => setValue('scheduledDate', date)}
          placeholder={t('schedule')}
          minDate={new Date()}
        />
      </div>
      <div className="space-y-2">
        <Label>{t('expiresAt')}</Label>
        <DateTimePicker
          value={expiresDate}
          onChange={(date) => setValue('expiresDate', date)}
          placeholder={tCommon('optional')}
          minDate={scheduledDate || new Date()}
        />
      </div>
    </div>
  );
}
