'use client';

import { Send, Edit, Trash2, BarChart3, FileText, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TableCell, TableRow } from '@/components/ui/table';
import type { Announcement } from '@/lib/api/notifications';
import type { Faculty } from '@/types';

interface AnnouncementTableRowProps {
  announcement: Announcement;
  faculties: Faculty[];
  t: (key: string) => string;
  tCommon: (key: string) => string;
  onSend: (id: string) => void;
  onEdit: (announcement: Announcement) => void;
  onDelete: (id: string) => void;
  onViewAnalytics: (id: string) => void;
}

export function AnnouncementTableRow({
  announcement,
  faculties,
  t,
  tCommon,
  onSend,
  onEdit,
  onDelete,
  onViewAnalytics,
}: AnnouncementTableRowProps) {
  return (
    <TableRow>
      <TableCell>
        <div className="font-medium line-clamp-1">{announcement.titleEn}</div>
        <div className="text-xs text-muted-foreground line-clamp-1">
          {announcement.messageEn.substring(0, 60)}...
        </div>
      </TableCell>
      <TableCell className="hidden md:table-cell">
        {announcement.facultyId ? (
          <Badge variant="outline">
            {faculties.find((f) => f.id === announcement.facultyId)?.name || 'Faculty'}
          </Badge>
        ) : (
          <span className="text-muted-foreground">{tCommon('all')}</span>
        )}
      </TableCell>
      <TableCell className="hidden lg:table-cell">
        {announcement.targetRole ? (
          <Badge variant="secondary">{announcement.targetRole}</Badge>
        ) : (
          <span className="text-muted-foreground">{t('allRoles')}</span>
        )}
      </TableCell>
      <TableCell>
        {announcement.isSent ? (
          <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
            <CheckCircle className="me-1 h-3 w-3" />
            {t('sent')}
          </Badge>
        ) : announcement.scheduledAt ? (
          <Badge variant="secondary">
            <Clock className="me-1 h-3 w-3" />
            {t('schedule')}
          </Badge>
        ) : (
          <Badge variant="outline">
            <FileText className="me-1 h-3 w-3" />
            {t('draft')}
          </Badge>
        )}
      </TableCell>
      <TableCell className="hidden md:table-cell">
        {announcement.isSent && announcement.totalRecipients ? (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onViewAnalytics(announcement.id)}
          >
            <BarChart3 className="me-1 h-4 w-4" />
            {Math.round((announcement.readRate || 0) * 100)}%
          </Button>
        ) : (
          <span className="text-muted-foreground">-</span>
        )}
      </TableCell>
      <TableCell>
        <div className="flex items-center justify-end gap-1">
          {!announcement.isSent && (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onSend(announcement.id)}
                title={t('send')}
              >
                <Send className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onEdit(announcement)}
                title={tCommon('edit')}
              >
                <Edit className="h-4 w-4" />
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(announcement.id)}
            title={tCommon('delete')}
          >
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}
