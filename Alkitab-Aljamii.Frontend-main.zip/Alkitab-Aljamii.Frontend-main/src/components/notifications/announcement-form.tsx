'use client';

import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Send, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { announcementsApi, type CreateAnnouncementRequest, type Announcement, type FacultyRole } from '@/lib/api/notifications';
import type { Faculty, Subject } from '@/types';
import { TitleFields, MessageFields, TargetingFields, OptionsFields, SchedulingFields } from './announcement-form-fields';

interface AnnouncementFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  announcement?: Announcement | null;
  faculties?: Faculty[];
  subjects?: Subject[];
  allowedRoles?: FacultyRole[];
  defaultFacultyId?: string;
  defaultSubjectId?: string;
  hideFacultySelect?: boolean;
  hideSubjectSelect?: boolean;
  hideRoleSelect?: boolean;
}

type FormData = CreateAnnouncementRequest & { scheduledDate?: Date; expiresDate?: Date };

export function AnnouncementForm({
  open, onOpenChange, onSuccess, announcement, faculties = [], subjects = [],
  allowedRoles = ['faculty_admin', 'professor', 'student'],
  defaultFacultyId, defaultSubjectId, hideFacultySelect = false, hideSubjectSelect = false, hideRoleSelect = false,
}: AnnouncementFormProps) {
  const t = useTranslations('notifications.announcements');
  const tCommon = useTranslations('common');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const isEditing = !!announcement;

  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm<FormData>({
    defaultValues: { titleEn: '', titleAr: '', messageEn: '', messageAr: '', facultyId: defaultFacultyId, subjectId: defaultSubjectId, useTemplate: false, isDraft: true },
  });

  useEffect(() => {
    if (open) {
      if (announcement) {
        reset({
          titleEn: announcement.titleEn, titleAr: announcement.titleAr || '', messageEn: announcement.messageEn, messageAr: announcement.messageAr || '',
          facultyId: announcement.facultyId || defaultFacultyId, subjectId: announcement.subjectId || defaultSubjectId,
          targetRole: announcement.targetRole || undefined, useTemplate: announcement.useTemplate, deepLink: announcement.deepLink || '', isDraft: announcement.isDraft,
          scheduledDate: announcement.scheduledAt ? new Date(announcement.scheduledAt) : undefined,
          expiresDate: announcement.expiresAt ? new Date(announcement.expiresAt) : undefined,
        });
      } else {
        reset({ titleEn: '', titleAr: '', messageEn: '', messageAr: '', facultyId: defaultFacultyId, subjectId: defaultSubjectId, useTemplate: false, isDraft: true });
      }
    }
  }, [open, announcement, defaultFacultyId, defaultSubjectId, reset]);

  const useTemplate = watch('useTemplate');
  const scheduledDate = watch('scheduledDate');
  const expiresDate = watch('expiresDate');

  const onSubmit = async (data: FormData, sendNow = false) => {
    setIsSubmitting(true);
    if (sendNow) setIsSending(true);

    try {
      const payload: CreateAnnouncementRequest = { titleEn: data.titleEn, messageEn: data.messageEn, isDraft: sendNow ? false : data.isDraft };
      if (data.titleAr) payload.titleAr = data.titleAr;
      if (data.messageAr) payload.messageAr = data.messageAr;
      if (data.facultyId) payload.facultyId = data.facultyId;
      if (data.subjectId) payload.subjectId = data.subjectId;
      if (data.targetRole) payload.targetRole = data.targetRole;
      if (data.useTemplate) payload.useTemplate = data.useTemplate;
      if (data.deepLink) payload.deepLink = data.deepLink;
      if (data.scheduledDate) payload.scheduledAt = data.scheduledDate.toISOString();
      if (data.expiresDate) payload.expiresAt = data.expiresDate.toISOString();

      let result: Announcement;
      if (isEditing && announcement) {
        result = await announcementsApi.update(announcement.id, payload);
      } else {
        result = await announcementsApi.create(payload);
      }

      if (sendNow && result.id) {
        const sendResult = await announcementsApi.send(result.id);
        toast.success(t('sendSuccess', { count: sendResult.sentCount }));
      } else {
        toast.success(t('createSuccess'));
      }

      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error('Failed to save announcement:', error);
      toast.error(sendNow ? t('sendError') : t('createError'));
    } finally {
      setIsSubmitting(false);
      setIsSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? t('edit') : t('create')}</DialogTitle>
          <DialogDescription>
            {useTemplate && <span className="text-xs text-muted-foreground">{t('useTemplate')}: {'{{user.firstName}}, {{faculty.name}}, {{subject.name}}'}</span>}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit((data) => onSubmit(data, false))} className="space-y-4">
          <TitleFields register={register} errors={errors} t={t} tCommon={tCommon} />
          <MessageFields register={register} errors={errors} t={t} tCommon={tCommon} />
          <TargetingFields watch={watch} setValue={setValue} faculties={faculties} subjects={subjects} allowedRoles={allowedRoles} hideFacultySelect={hideFacultySelect} hideSubjectSelect={hideSubjectSelect} hideRoleSelect={hideRoleSelect} t={t} tCommon={tCommon} />
          <OptionsFields register={register} watch={watch} useTemplate={useTemplate ?? false} setValue={setValue} faculties={faculties} subjects={subjects} t={t} />
          <SchedulingFields scheduledDate={scheduledDate} expiresDate={expiresDate} setValue={setValue} t={t} tCommon={tCommon} />

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{tCommon('cancel')}</Button>
            <Button type="submit" variant="secondary" disabled={isSubmitting}><Save className="me-2 h-4 w-4" />{t('draft')}</Button>
            <Button type="button" onClick={handleSubmit((data) => onSubmit(data, true))} disabled={isSubmitting || isSending}><Send className="me-2 h-4 w-4" />{t('send')}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
