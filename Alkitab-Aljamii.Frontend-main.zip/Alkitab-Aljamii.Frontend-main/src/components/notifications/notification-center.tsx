'use client';

import { useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Bell, Check, Loader2, Settings, RefreshCw, WifiOff } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useNotificationStore, useAuthStore } from '@/stores';
import type { Notification } from '@/lib/api/notifications';
import { NotificationItem } from './notification-item';

export function NotificationCenter() {
  const t = useTranslations('notifications');
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const {
    notifications,
    unreadCount,
    isLoading,
    isConnected,
    connectionError,
    hasNextPage,
    isLoadingMore,
    fetchNotifications,
    fetchMoreNotifications,
    fetchUnreadCount,
    markAsRead,
    markAllAsRead,
    connectSSE,
    disconnectSSE,
  } = useNotificationStore();

  // Initialize on mount when authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      return;
    }

    fetchNotifications();
    fetchUnreadCount();
    connectSSE();

    return () => {
      disconnectSSE();
    };
  }, [isAuthenticated, fetchNotifications, fetchUnreadCount, connectSSE, disconnectSSE]);

  const handleNotificationClick = useCallback(
    (notification: Notification) => {
      if (notification.deepLink) {
        router.push(notification.deepLink);
      }
    },
    [router]
  );

  const handleMarkAsRead = useCallback(
    (id: string) => {
      markAsRead([id]);
    },
    [markAsRead]
  );

  const handleMarkAllRead = useCallback(() => {
    markAllAsRead();
  }, [markAllAsRead]);

  const handleRefresh = useCallback(() => {
    fetchNotifications();
    fetchUnreadCount();
  }, [fetchNotifications, fetchUnreadCount]);

  const handleLoadMore = useCallback(() => {
    if (hasNextPage && !isLoadingMore) {
      fetchMoreNotifications();
    }
  }, [hasNextPage, isLoadingMore, fetchMoreNotifications]);

  // Don't render if not authenticated
  if (!isAuthenticated) {
    return null;
  }

  return (
    <Tooltip>
      <Popover>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="relative h-8 w-8 sm:h-9 sm:w-9"
              aria-label={t('title')}
            >
              <Bell className="h-4 w-4 sm:h-5 sm:w-5" />
              {unreadCount > 0 && (
                <span
                  className={cn(
                    'absolute -top-0.5 -end-0.5 flex items-center justify-center',
                    'min-w-[18px] h-[18px] px-1 rounded-full',
                    'bg-red-500 text-white text-[10px] font-semibold',
                    'animate-pulse'
                  )}
                >
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
              {!isConnected && (
                <span
                  className="absolute bottom-0 end-0 h-2 w-2 rounded-full bg-yellow-500"
                  title={connectionError || t('disconnected')}
                />
              )}
            </Button>
          </PopoverTrigger>
        </TooltipTrigger>

      <PopoverContent
        align="end"
        className="w-[calc(100vw-2rem)] sm:w-96 p-0"
        sideOffset={8}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm">{t('title')}</h3>
            {!isConnected && (
              <span title={t('disconnected')}>
                <WifiOff className="h-3.5 w-3.5 text-yellow-500" />
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={handleRefresh}
                  disabled={isLoading}
                >
                  <RefreshCw className={cn('h-3.5 w-3.5', isLoading && 'animate-spin')} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>{t('refresh')}</TooltipContent>
            </Tooltip>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-xs"
                onClick={handleMarkAllRead}
              >
                <Check className="h-3.5 w-3.5 me-1" />
                {t('markAllRead')}
              </Button>
            )}
          </div>
        </div>

        {/* Notification List */}
        <ScrollArea className="h-[min(400px,60vh)]">
          {isLoading && notifications.length === 0 ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-start gap-3">
                  <Skeleton className="h-8 w-8 rounded-full shrink-0" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <div className="p-3 rounded-full bg-muted mb-3">
                <Bell className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">{t('empty')}</p>
              <p className="text-xs text-muted-foreground/70 mt-1">{t('emptyDescription')}</p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {notifications.map((notification) => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  onClick={handleNotificationClick}
                  onMarkAsRead={handleMarkAsRead}
                />
              ))}

              {/* Load More */}
              {hasNextPage && (
                <div className="pt-2">
                  <Button
                    variant="ghost"
                    className="w-full text-xs h-8"
                    onClick={handleLoadMore}
                    disabled={isLoadingMore}
                  >
                    {isLoadingMore ? (
                      <>
                        <Loader2 className="h-3 w-3 me-2 animate-spin" />
                        {t('loading')}
                      </>
                    ) : (
                      t('loadMore')
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        <Separator />
        <div className="p-2 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 px-3 text-xs"
            onClick={() => router.push('/notifications')}
          >
            {t('viewAll')}
          </Button>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => router.push('/settings/notifications')}
              >
                <Settings className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('settings')}</TooltipContent>
          </Tooltip>
        </div>
      </PopoverContent>
      </Popover>
      <TooltipContent>{t('title')}</TooltipContent>
    </Tooltip>
  );
}
