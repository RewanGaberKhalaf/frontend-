'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { BarChart3, Users, Mail, Eye } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { announcementsApi, type AnnouncementAnalytics as AnalyticsType } from '@/lib/api/notifications';

interface AnnouncementAnalyticsProps {
  announcementId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AnnouncementAnalytics({
  announcementId,
  open,
  onOpenChange,
}: AnnouncementAnalyticsProps) {
  const t = useTranslations('notifications.announcements');
  const [analytics, setAnalytics] = useState<AnalyticsType | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (open && announcementId) {
      setIsLoading(true);
      announcementsApi
        .getAnalytics(announcementId)
        .then(setAnalytics)
        .catch(console.error)
        .finally(() => setIsLoading(false));
    }
  }, [open, announcementId]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            {t('analytics')}
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : analytics ? (
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Users className="h-8 w-8 text-muted-foreground" />
                  <div>
                    <p className="text-2xl font-bold">{analytics.totalRecipients}</p>
                    <p className="text-xs text-muted-foreground">{t('totalRecipients')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Mail className="h-8 w-8 text-muted-foreground" />
                  <div>
                    <p className="text-2xl font-bold">{analytics.delivered}</p>
                    <p className="text-xs text-muted-foreground">{t('delivered')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Eye className="h-8 w-8 text-muted-foreground" />
                  <div>
                    <p className="text-2xl font-bold">{analytics.read}</p>
                    <p className="text-xs text-muted-foreground">{t('read')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <BarChart3 className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-2xl font-bold">
                      {Math.round(analytics.readRate * 100)}%
                    </p>
                    <p className="text-xs text-muted-foreground">{t('readRate')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            {t('analytics')} not available
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}
