'use client';

import { formatDistanceToNow } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';
import { useLocale, useTranslations } from 'next-intl';
import { Bell, MessageSquare, Book, AlertTriangle, Megaphone, CheckCircle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Notification, NotificationType } from '@/lib/api/notifications';

interface NotificationItemProps {
  notification: Notification;
  onClick?: (notification: Notification) => void;
  onMarkAsRead?: (id: string) => void;
}

const notificationIcons: Record<NotificationType, React.ElementType> = {
  annotation_digest: Book,
  new_annotation: Book,
  comment_reply: MessageSquare,
  announcement: Megaphone,
  comment_response: MessageSquare,
  course_update: Bell,
  batch_import_complete: CheckCircle,
  batch_import_failed: XCircle,
  system_alert: AlertTriangle,
};

const priorityColors: Record<string, string> = {
  urgent: 'bg-destructive/10 border-destructive/30',
  high: 'bg-orange-500/10 border-orange-500/30',
  normal: 'bg-background border-border',
  low: 'bg-muted/50 border-border',
};

export function NotificationItem({ notification, onClick, onMarkAsRead }: NotificationItemProps) {
  const t = useTranslations('notifications');
  const locale = useLocale();
  const Icon = notificationIcons[notification.type] || Bell;

  const handleClick = () => {
    if (!notification.isRead && onMarkAsRead) {
      onMarkAsRead(notification.id);
    }
    onClick?.(notification);
  };

  const timeAgo = formatDistanceToNow(new Date(notification.createdAt), {
    addSuffix: true,
    locale: locale === 'ar' ? ar : enUS,
  });

  return (
    <button
      onClick={handleClick}
      className={cn(
        'w-full flex items-start gap-3 p-3 text-start rounded-lg border transition-colors',
        'hover:bg-accent/50 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
        priorityColors[notification.priority],
        !notification.isRead && 'bg-primary/5'
      )}
    >
      {/* Icon */}
      <div
        className={cn(
          'shrink-0 p-2 rounded-full',
          notification.isRead ? 'bg-muted text-muted-foreground' : 'bg-primary/10 text-primary'
        )}
      >
        <Icon className="h-4 w-4" />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <p
            className={cn(
              'text-sm font-medium line-clamp-1',
              !notification.isRead && 'text-foreground',
              notification.isRead && 'text-muted-foreground'
            )}
          >
            {notification.title}
          </p>
          {!notification.isRead && (
            <span className="shrink-0 h-2 w-2 rounded-full bg-primary" aria-label={t('unread')} />
          )}
        </div>
        <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{notification.message}</p>
        <p className="mt-1 text-xs text-muted-foreground/70">{timeAgo}</p>
      </div>
    </button>
  );
}
