'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Megaphone, Plus, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader, EmptyState } from '@/components/shared';
import { AnnouncementForm } from './announcement-form';
import { AnnouncementAnalytics } from './announcement-analytics';
import { AnnouncementTableRow } from './announcement-list-row';
import {
  announcementsApi,
  type Announcement,
  type QueryAnnouncementsParams,
  type FacultyRole,
} from '@/lib/api/notifications';
import type { Faculty, Subject } from '@/types';

interface AnnouncementListProps {
  // Scoping based on role
  faculties?: Faculty[];
  subjects?: Subject[];
  allowedRoles?: FacultyRole[];
  // Pre-selected values
  defaultFacultyId?: string;
  defaultSubjectId?: string;
  // UI options
  hideFacultySelect?: boolean;
  hideSubjectSelect?: boolean;
  hideRoleSelect?: boolean;
  // Page title/description override
  title?: string;
  description?: string;
}

export function AnnouncementList({
  faculties = [],
  subjects = [],
  allowedRoles = ['faculty_admin', 'professor', 'student'],
  defaultFacultyId,
  defaultSubjectId,
  hideFacultySelect = false,
  hideSubjectSelect = false,
  hideRoleSelect = false,
  title,
  description,
}: AnnouncementListProps) {
  const t = useTranslations('notifications.announcements');
  const tCommon = useTranslations('common');

  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [total, setTotal] = useState(0);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [facultyFilter, setFacultyFilter] = useState<string>(defaultFacultyId || 'all');
  const [subjectFilter, setSubjectFilter] = useState<string>(defaultSubjectId || 'all');

  // Dialogs
  const [formOpen, setFormOpen] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [analyticsId, setAnalyticsId] = useState<string | null>(null);

  const fetchAnnouncements = useCallback(async () => {
    setIsLoading(true);
    try {
      const params: QueryAnnouncementsParams = { limit: 50 };
      if (statusFilter === 'draft') params.isDraft = true;
      if (statusFilter === 'sent') params.isSent = true;
      if (facultyFilter !== 'all') params.facultyId = facultyFilter;
      if (subjectFilter !== 'all') params.subjectId = subjectFilter;

      const result = await announcementsApi.getAll(params);
      setAnnouncements(result.items);
      setTotal(result.meta.total);
    } catch (error) {
      console.error('Failed to fetch announcements:', error);
      toast.error(tCommon('error'));
    } finally {
      setIsLoading(false);
    }
  }, [statusFilter, facultyFilter, subjectFilter, tCommon]);

  useEffect(() => {
    fetchAnnouncements();
  }, [fetchAnnouncements]);

  const handleCreate = () => {
    setEditingAnnouncement(null);
    setFormOpen(true);
  };

  const handleEdit = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await announcementsApi.delete(deleteConfirmId);
      toast.success(t('deleteSuccess'));
      setDeleteConfirmId(null);
      fetchAnnouncements();
    } catch {
      toast.error(t('deleteError'));
    }
  };

  const handleSend = async (id: string) => {
    try {
      const result = await announcementsApi.send(id);
      toast.success(t('sendSuccess', { count: result.sentCount }));
      fetchAnnouncements();
    } catch {
      toast.error(t('sendError'));
    }
  };

  // Filter subjects based on faculty filter
  const filteredSubjects =
    facultyFilter !== 'all'
      ? subjects.filter((s) => s.facultyId === facultyFilter)
      : subjects;

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Megaphone}
        title={title || t('title')}
        description={description}
        badge={total > 0 && <Badge variant="secondary">{total}</Badge>}
        action={
          <Button onClick={handleCreate}>
            <Plus className="me-2 h-4 w-4" />
            {t('create')}
          </Button>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <Filter className="h-4 w-4 text-muted-foreground" />

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[140px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{tCommon('all')}</SelectItem>
            <SelectItem value="draft">{t('draft')}</SelectItem>
            <SelectItem value="sent">{t('sent')}</SelectItem>
          </SelectContent>
        </Select>

        {!hideFacultySelect && faculties.length > 0 && (
          <Select
            value={facultyFilter}
            onValueChange={(v) => {
              setFacultyFilter(v);
              setSubjectFilter('all');
            }}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t('targetFaculty')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{tCommon('all')}</SelectItem>
              {faculties.map((f) => (
                <SelectItem key={f.id} value={f.id}>
                  {f.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {!hideSubjectSelect && filteredSubjects.length > 0 && (
          <Select value={subjectFilter} onValueChange={setSubjectFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t('targetSubject')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{tCommon('all')}</SelectItem>
              {filteredSubjects.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      ) : announcements.length === 0 ? (
        <EmptyState
          title={t('title')}
          description={tCommon('noData')}
          icon={Megaphone}
          action={
            <Button onClick={handleCreate}>
              <Plus className="me-2 h-4 w-4" />
              {t('create')}
            </Button>
          }
        />
      ) : (
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('titleEn')}</TableHead>
                <TableHead className="hidden md:table-cell">{t('targetFaculty')}</TableHead>
                <TableHead className="hidden lg:table-cell">{t('targetRole')}</TableHead>
                <TableHead>{tCommon('status')}</TableHead>
                <TableHead className="hidden md:table-cell">{t('analytics')}</TableHead>
                <TableHead className="text-end">{tCommon('actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {announcements.map((announcement) => (
                <AnnouncementTableRow
                  key={announcement.id}
                  announcement={announcement}
                  faculties={faculties}
                  t={t}
                  tCommon={tCommon}
                  onSend={handleSend}
                  onEdit={handleEdit}
                  onDelete={setDeleteConfirmId}
                  onViewAnalytics={setAnalyticsId}
                />
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Form Dialog */}
      <AnnouncementForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSuccess={fetchAnnouncements}
        announcement={editingAnnouncement}
        faculties={faculties}
        subjects={subjects}
        allowedRoles={allowedRoles}
        defaultFacultyId={defaultFacultyId}
        defaultSubjectId={defaultSubjectId}
        hideFacultySelect={hideFacultySelect}
        hideSubjectSelect={hideSubjectSelect}
        hideRoleSelect={hideRoleSelect}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirmId} onOpenChange={() => setDeleteConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{tCommon('confirm')}</AlertDialogTitle>
            <AlertDialogDescription>
              {tCommon('delete')}?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{tCommon('cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>{tCommon('delete')}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Analytics Dialog */}
      {analyticsId && (
        <AnnouncementAnalytics
          announcementId={analyticsId}
          open={!!analyticsId}
          onOpenChange={() => setAnalyticsId(null)}
        />
      )}
    </div>
  );
}
