'use client';

import { AlertCircle, RefreshCw } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';

interface ErrorStateProps {
  title?: string;
  description?: string;
  onRetry?: () => void;
  isRetrying?: boolean;
}

export function ErrorState({
  title,
  description,
  onRetry,
  isRetrying = false,
}: ErrorStateProps) {
  const t = useTranslations();

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="relative mb-6">
        <div className="absolute inset-0 -m-4 rounded-full bg-destructive/10" />
        <div className="absolute inset-0 -m-2 rounded-full bg-destructive/20" />
        <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-destructive/30">
          <AlertCircle className="h-8 w-8 text-destructive" />
        </div>
      </div>
      <h3 className="mb-2 text-lg font-semibold">{title ?? t('common.error')}</h3>
      {description && (
        <p className="mb-6 max-w-sm text-sm text-muted-foreground">
          {description}
        </p>
      )}
      {onRetry && (
        <Button
          variant="outline"
          onClick={onRetry}
          disabled={isRetrying}
        >
          <RefreshCw className={`me-2 h-4 w-4 ${isRetrying ? 'animate-spin' : ''}`} />
          {t('common.retry')}
        </Button>
      )}
    </div>
  );
}
