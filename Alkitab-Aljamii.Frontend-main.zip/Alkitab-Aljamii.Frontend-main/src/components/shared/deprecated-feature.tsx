'use client';

import { AlertTriangle } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';

interface DeprecatedFeatureProps {
  redirectTo: string;
  redirectLabel: string;
}

export function DeprecatedFeature({ redirectTo, redirectLabel }: DeprecatedFeatureProps) {
  const t = useTranslations();

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900">
            <AlertTriangle className="h-6 w-6 text-amber-600 dark:text-amber-400" />
          </div>
          <CardTitle>{t('deprecated.title')}</CardTitle>
          <CardDescription>{t('deprecated.description')}</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button asChild>
            <Link href={redirectTo}>{redirectLabel}</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
