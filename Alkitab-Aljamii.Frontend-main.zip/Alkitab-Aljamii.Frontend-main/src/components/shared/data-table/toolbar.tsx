'use client';

import { X } from 'lucide-react';
import type { Table } from '@tanstack/react-table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface DataTableToolbarProps<TData> {
  table: Table<TData>;
  searchKey?: string | undefined;
  searchPlaceholder?: string | undefined;
  /** Global filter value (for multi-field search) */
  globalFilter?: string | undefined;
  /** Callback to update global filter */
  onGlobalFilterChange?: ((value: string) => void) | undefined;
  children?: React.ReactNode;
}

export function DataTableToolbar<TData>({
  table,
  searchKey,
  searchPlaceholder = 'Search...',
  globalFilter,
  onGlobalFilterChange,
  children,
}: DataTableToolbarProps<TData>) {
  const isFiltered =
    table.getState().columnFilters.length > 0 ||
    (globalFilter !== undefined && globalFilter.length > 0);

  const handleReset = () => {
    table.resetColumnFilters();
    if (onGlobalFilterChange) {
      onGlobalFilterChange('');
    }
  };

  // Use global filter if provided, otherwise fall back to column filter
  const useGlobalSearch = globalFilter !== undefined && onGlobalFilterChange;

  return (
    <div className="flex items-center justify-between">
      <div className="flex flex-1 items-center space-x-2">
        {useGlobalSearch && (
          <Input
            placeholder={searchPlaceholder}
            value={globalFilter}
            onChange={(event) => onGlobalFilterChange(event.target.value)}
            className="h-8 w-[150px] lg:w-[250px]"
          />
        )}
        {!useGlobalSearch && searchKey && (
          <Input
            placeholder={searchPlaceholder}
            value={(table.getColumn(searchKey)?.getFilterValue() as string) ?? ''}
            onChange={(event) =>
              table.getColumn(searchKey)?.setFilterValue(event.target.value)
            }
            className="h-8 w-[150px] lg:w-[250px]"
          />
        )}
        {isFiltered && (
          <Button
            variant="ghost"
            onClick={handleReset}
            className="h-8 px-2 lg:px-3"
          >
            Reset
            <X className="ml-2 h-4 w-4" />
          </Button>
        )}
      </div>
      <div className="flex items-center space-x-2">
        {children}
      </div>
    </div>
  );
}
