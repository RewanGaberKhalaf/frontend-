'use client';

import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
  type ColumnFiltersState,
  type FilterFn,
} from '@tanstack/react-table';
import { useState, useMemo, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { DataTablePagination } from './pagination';
import { DataTableToolbar } from './toolbar';

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  /** Single column key to search (legacy) */
  searchKey?: string;
  /** Multiple column keys to search across */
  searchKeys?: string[];
  searchPlaceholder?: string;
  toolbarActions?: React.ReactNode;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  searchKey,
  searchKeys,
  searchPlaceholder,
  toolbarActions,
}: DataTableProps<TData, TValue>) {
  const t = useTranslations('table');
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [rowSelection, setRowSelection] = useState({});
  const [globalFilter, setGlobalFilter] = useState('');

  // Determine which keys to search - use searchKeys if provided, otherwise single searchKey
  const keysToSearch = useMemo(() => {
    if (searchKeys && searchKeys.length > 0) return searchKeys;
    if (searchKey) return [searchKey];
    return [];
  }, [searchKey, searchKeys]);

  // Multi-field filter function with combined name search support
  const multiFieldFilter: FilterFn<TData> = useCallback(
    (row, _columnId, filterValue: string) => {
      const search = filterValue.trim().toLowerCase();
      if (!search) return true;

      const terms = search.split(/\s+/).filter(Boolean);

      // Get values from all search keys
      const values: Record<string, string> = {};
      for (const key of keysToSearch) {
        const val = row.getValue(key);
        values[key] = String(val ?? '').toLowerCase();
      }

      // For name searches, also build combined name if firstName/lastName exist
      const firstName = values['firstName'] || '';
      const lastName = values['lastName'] || '';
      const fullName = firstName && lastName ? `${firstName} ${lastName}` : '';

      if (terms.length === 1) {
        const term = terms[0]!;
        // Single term: match any field
        for (const val of Object.values(values)) {
          if (val.includes(term)) return true;
        }
        return false;
      }

      // Multi-term search
      const firstTerm = terms[0]!;
      const restTerms = terms.slice(1).join(' ');

      // Check firstName + lastName pattern
      if (firstName.includes(firstTerm) && lastName.includes(restTerms)) {
        return true;
      }
      // Check lastName + firstName pattern (reversed)
      if (lastName.includes(firstTerm) && firstName.includes(restTerms)) {
        return true;
      }
      // Check if full name contains the search
      if (fullName.includes(search)) {
        return true;
      }
      // Check if all terms exist somewhere
      const allValues = Object.values(values);
      return terms.every((term) => allValues.some((val) => val.includes(term)));
    },
    [keysToSearch]
  );

  const useGlobalFilter = keysToSearch.length > 1;

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onRowSelectionChange: setRowSelection,
    onGlobalFilterChange: setGlobalFilter,
    globalFilterFn: multiFieldFilter,
    state: { sorting, columnFilters, rowSelection, globalFilter },
  });

  return (
    <div className="space-y-4">
      <DataTableToolbar
        table={table}
        searchKey={useGlobalFilter ? undefined : searchKey}
        searchPlaceholder={searchPlaceholder}
        globalFilter={useGlobalFilter ? globalFilter : undefined}
        onGlobalFilterChange={useGlobalFilter ? setGlobalFilter : undefined}
      >
        {toolbarActions}
      </DataTableToolbar>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id}>
                    {header.isPlaceholder
                      ? null
                      : flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && 'selected'}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  {t('noResults')}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <DataTablePagination table={table} />
    </div>
  );
}

export { DataTableColumnHeader } from './column-header';
export { DataTablePagination } from './pagination';
export { DataTableToolbar } from './toolbar';
export { DataTableRowActions, type RowAction } from './row-actions';
export { ServerDataTable } from './server-data-table';
