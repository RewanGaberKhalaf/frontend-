import { type LucideIcon, Inbox } from 'lucide-react';

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  action,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="relative mb-6">
        {/* Decorative background circles */}
        <div className="absolute inset-0 -m-4 rounded-full bg-accent/50" />
        <div className="absolute inset-0 -m-2 rounded-full bg-accent/70" />
        <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-accent">
          <Icon className="h-8 w-8 text-accent-foreground" />
        </div>
      </div>
      <h3 className="mb-2 text-lg font-semibold">{title}</h3>
      {description && (
        <p className="mb-6 max-w-sm text-sm text-muted-foreground">
          {description}
        </p>
      )}
      {action}
    </div>
  );
}
