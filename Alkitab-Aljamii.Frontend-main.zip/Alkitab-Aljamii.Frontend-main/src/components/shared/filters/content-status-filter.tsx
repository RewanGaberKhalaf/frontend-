'use client';

import { useMemo } from 'react';
import { useTranslations } from 'next-intl';
import { SelectFilter, type FilterOption } from './select-filter';

type ContentStatus = 'pending' | 'approved' | 'rejected';

interface ContentStatusFilterProps {
  /** Current filter value (undefined means "all") */
  value: string | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: string | undefined) => void;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

/**
 * Content approval status filter (pending/approved/rejected).
 */
export function ContentStatusFilter({
  value,
  onChange,
  width = 'w-[140px] sm:w-[160px]',
  className,
  disabled,
}: ContentStatusFilterProps) {
  const t = useTranslations();

  const options: FilterOption[] = useMemo(
    () => [
      { value: 'pending', label: t('content.pending') },
      { value: 'approved', label: t('content.approved') },
      { value: 'rejected', label: t('content.rejected') },
    ],
    [t]
  );

  return (
    <SelectFilter
      value={value}
      onChange={onChange}
      options={options}
      placeholder={t('content.filterByStatus')}
      width={width}
      className={className}
      disabled={disabled}
    />
  );
}

type BookStatus = 'draft' | 'pending_review' | 'approved' | 'rejected' | 'published';

interface BookStatusFilterProps {
  /** Current filter value (undefined means "all") */
  value: string | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: string | undefined) => void;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

const bookStatusLabels: Record<BookStatus, string> = {
  draft: 'Draft',
  pending_review: 'Pending Review',
  approved: 'Approved',
  rejected: 'Rejected',
  published: 'Published',
};

/**
 * Book status filter (draft/pending_review/approved/rejected/published).
 */
export function BookStatusFilter({
  value,
  onChange,
  width = 'w-[160px] sm:w-[180px]',
  className,
  disabled,
}: BookStatusFilterProps) {
  const t = useTranslations();

  const options: FilterOption[] = useMemo(
    () => [
      { value: 'draft', label: bookStatusLabels.draft },
      { value: 'pending_review', label: bookStatusLabels.pending_review },
      { value: 'approved', label: bookStatusLabels.approved },
      { value: 'rejected', label: bookStatusLabels.rejected },
      { value: 'published', label: bookStatusLabels.published },
    ],
    []
  );

  return (
    <SelectFilter
      value={value}
      onChange={onChange}
      options={options}
      placeholder={t('content.filterByStatus')}
      width={width}
      className={className}
      disabled={disabled}
    />
  );
}
