'use client';

import { useTranslations } from 'next-intl';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

export interface FilterOption {
  value: string;
  label: string;
  labelAr?: string | null;
}

interface SelectFilterProps {
  /** Current filter value (undefined means "all") */
  value: string | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: string | undefined) => void;
  /** Available options */
  options: FilterOption[];
  /** Placeholder text shown in trigger */
  placeholder?: string;
  /** Label for the "All" option */
  allLabel?: string;
  /** Whether to show the "All" option */
  showAll?: boolean;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Loading state */
  isLoading?: boolean;
  /** Disabled state */
  disabled?: boolean;
  /** Use Arabic label if available and locale is Arabic */
  useArabicLabel?: boolean;
  /** Current locale */
  locale?: string;
}

/**
 * Generic select filter component.
 * Handles the "all" value conversion automatically.
 */
export function SelectFilter({
  value,
  onChange,
  options,
  placeholder,
  allLabel,
  showAll = true,
  width = 'w-full sm:w-[180px]',
  className,
  isLoading,
  disabled,
  useArabicLabel = false,
  locale,
}: SelectFilterProps) {
  const t = useTranslations();
  const isArabic = locale === 'ar';

  const handleChange = (val: string) => {
    onChange(val === 'all' ? undefined : val);
  };

  const getLabel = (option: FilterOption) => {
    if (useArabicLabel && isArabic && option.labelAr) {
      return option.labelAr;
    }
    return option.label;
  };

  return (
    <Select
      value={value ?? 'all'}
      onValueChange={handleChange}
      disabled={disabled || isLoading}
    >
      <SelectTrigger className={cn(width, className)}>
        <SelectValue placeholder={placeholder ?? t('common.select')} />
      </SelectTrigger>
      <SelectContent>
        {showAll && (
          <SelectItem value="all">{allLabel ?? t('common.all')}</SelectItem>
        )}
        {options.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            {getLabel(option)}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
