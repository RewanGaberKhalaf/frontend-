'use client';

import { useLocale, useTranslations } from 'next-intl';
import { ComboboxFilter } from './combobox-filter';
import { useSubjectOptions } from '@/hooks/use-filter-options';

interface SubjectFilterProps {
  /** Current filter value (undefined means "all") */
  value: string | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: string | undefined) => void;
  /** Filter subjects by faculty */
  facultyId?: string;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

/**
 * Subject filter with automatic data loading.
 * Fetches subjects from the API and displays them in a searchable combobox.
 */
export function SubjectFilter({
  value,
  onChange,
  facultyId,
  width = 'w-full sm:w-[200px]',
  className,
  disabled,
}: SubjectFilterProps) {
  const t = useTranslations();
  const locale = useLocale();
  const { options, isLoading } = useSubjectOptions({ facultyId });

  return (
    <ComboboxFilter
      value={value}
      onChange={onChange}
      options={options}
      placeholder={t('content.filterBySubject')}
      allLabel={t('content.allSubjects')}
      width={width}
      className={className}
      isLoading={isLoading}
      disabled={disabled}
      useArabicLabel
      locale={locale}
    />
  );
}
