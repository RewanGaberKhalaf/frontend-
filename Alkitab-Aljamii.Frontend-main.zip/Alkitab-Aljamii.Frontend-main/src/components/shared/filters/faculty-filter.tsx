'use client';

import { useLocale, useTranslations } from 'next-intl';
import { SelectFilter } from './select-filter';
import { useFacultyOptions } from '@/hooks/use-filter-options';

interface FacultyFilterProps {
  /** Current filter value (undefined means "all") */
  value: string | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: string | undefined) => void;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

/**
 * Faculty filter with automatic data loading.
 * Fetches faculties from the API and displays them in a select.
 */
export function FacultyFilter({
  value,
  onChange,
  width = 'w-full sm:w-[200px]',
  className,
  disabled,
}: FacultyFilterProps) {
  const t = useTranslations();
  const locale = useLocale();
  const { options, isLoading } = useFacultyOptions();

  return (
    <SelectFilter
      value={value}
      onChange={onChange}
      options={options}
      placeholder={t('faculties.filterByFaculty')}
      allLabel={t('faculties.allFaculties')}
      width={width}
      className={className}
      isLoading={isLoading}
      disabled={disabled}
      useArabicLabel
      locale={locale}
    />
  );
}
