'use client';

import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface FilterBarProps {
  children: ReactNode;
  className?: string;
}

/**
 * Container component for filter controls.
 * Provides consistent layout and styling for filter sections.
 */
export function FilterBar({ children, className }: FilterBarProps) {
  return (
    <div
      className={cn(
        'flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-3 rounded-lg border bg-card p-3 sm:p-4',
        className
      )}
    >
      {children}
    </div>
  );
}

/**
 * Groups filter controls together (e.g., multiple selects).
 */
export function FilterGroup({ children, className }: FilterBarProps) {
  return (
    <div className={cn('flex flex-wrap items-center gap-2 sm:gap-3', className)}>
      {children}
    </div>
  );
}
