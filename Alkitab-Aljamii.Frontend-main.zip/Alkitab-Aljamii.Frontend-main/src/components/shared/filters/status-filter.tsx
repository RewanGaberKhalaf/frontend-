'use client';

import { useTranslations } from 'next-intl';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface StatusFilterProps {
  /** Current filter value (undefined means "all") */
  value: boolean | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: boolean | undefined) => void;
  /** Label for active status */
  activeLabel?: string;
  /** Label for inactive status */
  inactiveLabel?: string;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

/**
 * Boolean status filter (active/inactive).
 * Common filter pattern used across many pages.
 */
export function StatusFilter({
  value,
  onChange,
  activeLabel,
  inactiveLabel,
  width = 'w-[120px] sm:w-[140px]',
  className,
  disabled,
}: StatusFilterProps) {
  const t = useTranslations();

  const handleChange = (val: string) => {
    if (val === 'all') {
      onChange(undefined);
    } else {
      onChange(val === 'active');
    }
  };

  const currentValue = value === undefined ? 'all' : value ? 'active' : 'inactive';

  return (
    <Select value={currentValue} onValueChange={handleChange} disabled={disabled}>
      <SelectTrigger className={cn(width, className)}>
        <SelectValue placeholder={t('common.status')} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">{t('common.all')}</SelectItem>
        <SelectItem value="active">{activeLabel ?? t('common.active')}</SelectItem>
        <SelectItem value="inactive">{inactiveLabel ?? t('common.inactive')}</SelectItem>
      </SelectContent>
    </Select>
  );
}
