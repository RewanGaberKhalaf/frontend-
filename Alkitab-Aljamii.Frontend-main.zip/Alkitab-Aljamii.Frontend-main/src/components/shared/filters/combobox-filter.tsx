'use client';

import * as React from 'react';
import { Check, ChevronsUpDown } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import type { FilterOption } from './select-filter';

interface ComboboxFilterProps {
  /** Current filter value (undefined means "all") */
  value: string | undefined;
  /** Callback when filter changes. Passes undefined for "all" */
  onChange: (value: string | undefined) => void;
  /** Available options */
  options: FilterOption[];
  /** Placeholder text shown when nothing selected */
  placeholder?: string;
  /** Search placeholder */
  searchPlaceholder?: string;
  /** Label for the "All" option */
  allLabel?: string;
  /** Whether to show the "All" option */
  showAll?: boolean;
  /** Width class for the trigger */
  width?: string;
  /** Additional className */
  className?: string;
  /** Loading state */
  isLoading?: boolean;
  /** Disabled state */
  disabled?: boolean;
  /** Use Arabic label if available and locale is Arabic */
  useArabicLabel?: boolean;
  /** Current locale */
  locale?: string;
}

/**
 * Combobox-based filter with search functionality.
 * Better UX for large lists of options.
 */
export function ComboboxFilter({
  value,
  onChange,
  options,
  placeholder,
  searchPlaceholder,
  allLabel,
  showAll = true,
  width = 'w-full sm:w-[200px]',
  className,
  isLoading,
  disabled,
  useArabicLabel = false,
  locale,
}: ComboboxFilterProps) {
  const t = useTranslations();
  const [open, setOpen] = React.useState(false);
  const isArabic = locale === 'ar';

  const getLabel = (option: FilterOption) => {
    if (useArabicLabel && isArabic && option.labelAr) {
      return option.labelAr;
    }
    return option.label;
  };

  // Add "All" option at the beginning if showAll is true
  const allOptions: FilterOption[] = React.useMemo(() => {
    if (!showAll) return options;
    return [
      { value: '__all__', label: allLabel ?? t('common.all') },
      ...options,
    ];
  }, [options, showAll, allLabel, t]);

  // Find the selected option
  const selectedOption = React.useMemo(() => {
    if (!value) {
      return showAll ? allOptions[0] : undefined;
    }
    return options.find((opt) => opt.value === value);
  }, [value, options, showAll, allOptions]);

  const handleSelect = (selectedValue: string) => {
    if (selectedValue === '__all__') {
      onChange(undefined);
    } else {
      onChange(selectedValue);
    }
    setOpen(false);
  };

  const displayValue = selectedOption
    ? value
      ? getLabel(selectedOption)
      : allLabel ?? t('common.all')
    : placeholder ?? t('common.select');

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            'justify-between font-normal',
            width,
            className
          )}
          disabled={disabled || isLoading}
        >
          <span className="truncate">{displayValue}</span>
          <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
        <Command>
          <CommandInput placeholder={searchPlaceholder ?? `${t('common.search')}...`} />
          <CommandList>
            <CommandEmpty>{t('common.noResults')}</CommandEmpty>
            <CommandGroup>
              {allOptions.map((option) => {
                const isSelected = option.value === '__all__'
                  ? !value
                  : value === option.value;
                const label = option.value === '__all__'
                  ? option.label
                  : getLabel(option);

                return (
                  <CommandItem
                    key={option.value}
                    value={label}
                    onSelect={() => handleSelect(option.value)}
                  >
                    <Check
                      className={cn(
                        'me-2 h-4 w-4',
                        isSelected ? 'opacity-100' : 'opacity-0'
                      )}
                    />
                    {label}
                  </CommandItem>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
