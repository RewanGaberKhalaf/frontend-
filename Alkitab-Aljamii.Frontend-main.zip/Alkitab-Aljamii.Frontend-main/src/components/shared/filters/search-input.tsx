'use client';

import { Search, X } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface SearchInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  showClear?: boolean;
}

/**
 * Standardized search input with icon.
 * Integrates with useServerTable's setSearch function.
 */
export function SearchInput({
  value,
  onChange,
  placeholder,
  className,
  showClear = true,
}: SearchInputProps) {
  const t = useTranslations();

  return (
    <div className={cn('relative flex-1 min-w-0 sm:min-w-[200px] sm:max-w-sm', className)}>
      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground pointer-events-none" />
      <Input
        type="search"
        placeholder={placeholder ?? `${t('common.search')}...`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-9 pr-9"
      />
      {showClear && value && (
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          onClick={() => onChange('')}
        >
          <X className="h-4 w-4" />
          <span className="sr-only">{t('common.clear')}</span>
        </Button>
      )}
    </div>
  );
}
