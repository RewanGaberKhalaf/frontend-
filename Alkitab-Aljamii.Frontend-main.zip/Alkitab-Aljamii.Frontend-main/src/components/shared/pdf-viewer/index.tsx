"use client";

import {
  useEffect,
  useState,
  useCallback,
  useRef,
  useMemo,
} from "react";
import { Loader2 } from "lucide-react";
import { ViewProtection } from "./protection";
import { PDFToolbar } from "./toolbar";
import { PageRenderer } from "./page-renderer";
import { FullscreenViewer } from "./fullscreen-viewer";
import { useChunkLoader } from "./use-chunk-loader";
import type { SecurePDFViewerProps } from "./types";

export function SecurePDFViewer({
  contentId,
  protectionDisabled = false,
  blockDevTools = false,
}: SecurePDFViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Page state
  const [currentPage, setCurrentPage] = useState(1);
  const [error, setError] = useState<string | null>(null);

  // UI state - userScale is only for user-initiated zoom changes
  const [userScale, setUserScale] = useState<number | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [containerWidth, setContainerWidth] = useState<number>(0);

  // Refs
  const touchStartX = useRef<number | null>(null);
  const hideControlsTimer = useRef<NodeJS.Timeout | null>(null);
  const lastPageRef = useRef<number>(1);

  // Chunk loader hook
  const {
    totalPages,
    currentChunk,
    isLoadingChunk,
    loadChunkForPage,
    isPageInCurrentChunk,
    prefetchInDirection,
  } = useChunkLoader({
    contentId,
    onError: setError,
  });

  // Check if current page is within loaded chunk
  const isCurrentPageInLoadedChunk = useMemo(() => {
    return isPageInCurrentChunk(currentPage);
  }, [currentPage, isPageInCurrentChunk]);

  // Calculate page number within current chunk (1-indexed for PageRenderer)
  const pageInChunk = useMemo(() => {
    if (!currentChunk || !isCurrentPageInLoadedChunk) return 1;
    return currentPage - 1 - currentChunk.startPage + 1;
  }, [currentPage, currentChunk, isCurrentPageInLoadedChunk]);

  // Page dimensions from current chunk
  const pageWidth = currentChunk?.pageWidth ?? 0;
  const pageHeight = currentChunk?.pageHeight ?? 0;

  // Calculate fit scale based on current mode (computed during render, not in effect)
  const calculatedFitScale = useMemo(() => {
    if (!currentChunk || currentChunk.pageWidth <= 0 || currentChunk.pageHeight <= 0) {
      return null;
    }

    if (isFullscreen) {
      const fullscreenWidth = typeof window !== "undefined" ? window.innerWidth - 32 : 800;
      const fullscreenHeight = typeof window !== "undefined" ? window.innerHeight - 32 : 600;
      const fitScale = Math.min(
        fullscreenWidth / currentChunk.pageWidth,
        fullscreenHeight / currentChunk.pageHeight
      );
      return Math.min(Math.max(fitScale, 0.5), 3);
    }

    const effectiveContainerWidth = containerWidth > 0
      ? containerWidth - 32
      : typeof window !== "undefined" ? window.innerWidth - 64 : 800;
    const effectiveContainerHeight = typeof window !== "undefined" ? window.innerHeight - 200 : 600;

    if (effectiveContainerWidth <= 0 || effectiveContainerHeight <= 0) {
      return 1;
    }

    const fitWidthScale = effectiveContainerWidth / currentChunk.pageWidth;
    const fitHeightScale = effectiveContainerHeight / currentChunk.pageHeight;
    const fitScale = Math.min(fitWidthScale, fitHeightScale);
    return Math.min(Math.max(fitScale, 0.5), 3);
  }, [currentChunk, containerWidth, isFullscreen]);

  // Effective scale: use user scale if set, otherwise use calculated fit scale
  const scale = userScale ?? calculatedFitScale;

  // Load chunk when page changes
  useEffect(() => {
    if (totalPages === 0) return;

    if (isCurrentPageInLoadedChunk) {
      prefetchInDirection(currentPage, lastPageRef.current);
      lastPageRef.current = currentPage;
      return;
    }

    const loadAndSetScale = async () => {
      await loadChunkForPage(currentPage);
      lastPageRef.current = currentPage;
    };

    loadAndSetScale();
  }, [
    currentPage,
    totalPages,
    isCurrentPageInLoadedChunk,
    loadChunkForPage,
    prefetchInDirection,
  ]);

  // Navigation handlers
  const handlePreviousPage = useCallback(() => {
    if (isLoadingChunk && currentChunk) {
      const prevPage = currentPage - 1;
      if (prevPage < 1) return;
      const prevPageIndex = prevPage - 1;
      if (prevPageIndex < currentChunk.startPage) return;
    }
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  }, [isLoadingChunk, currentChunk, currentPage]);

  const handleNextPage = useCallback(() => {
    if (isLoadingChunk && currentChunk) {
      const nextPage = currentPage + 1;
      if (nextPage > totalPages) return;
      const nextPageIndex = nextPage - 1;
      if (nextPageIndex > currentChunk.endPage) return;
    }
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
  }, [isLoadingChunk, currentChunk, currentPage, totalPages]);

  const handleGoToPage = useCallback(
    (page: number) => {
      if (page < 1 || page > totalPages) return;
      setCurrentPage(page);
    },
    [totalPages]
  );

  // Zoom handlers - these set user-initiated scale
  const handleZoomIn = useCallback(() => {
    setUserScale((prev) => {
      const current = prev ?? calculatedFitScale ?? 1;
      return Math.min(current * 1.25, 3);
    });
  }, [calculatedFitScale]);

  const handleZoomOut = useCallback(() => {
    setUserScale((prev) => {
      const current = prev ?? calculatedFitScale ?? 1;
      return Math.max(current * 0.8, 0.5);
    });
  }, [calculatedFitScale]);

  const handleFitWidth = useCallback(() => {
    if (containerRef.current && pageWidth > 0) {
      const fitContainerWidth = containerRef.current.clientWidth - 32;
      const fitScale = fitContainerWidth / pageWidth;
      setUserScale(Math.min(Math.max(fitScale, 0.5), 3));
    }
  }, [pageWidth]);

  // Content overflow check
  const contentOverflows = useMemo(() => {
    const currentScale = scale ?? 1;
    if (pageWidth <= 0) return currentScale > 1;
    const effectiveContainerWidth = isFullscreen
      ? window.innerWidth - 32
      : (containerWidth || window.innerWidth) - 32;
    const widthOverflows = currentScale * pageWidth > effectiveContainerWidth;

    if (isFullscreen && pageHeight > 0) {
      const containerHeightValue = window.innerHeight - 32;
      const heightOverflows = currentScale * pageHeight > containerHeightValue;
      return widthOverflows || heightOverflows;
    }
    return widthOverflows;
  }, [scale, pageWidth, pageHeight, isFullscreen, containerWidth]);

  // Touch handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (touch) touchStartX.current = touch.clientX;
  }, []);

  const handleTouchEnd = useCallback(
    (e: React.TouchEvent) => {
      if (touchStartX.current === null) return;
      const touch = e.changedTouches[0];
      if (!touch) return;
      const diff = touchStartX.current - touch.clientX;
      if (Math.abs(diff) > 50) {
        if (diff > 0) {
          handleNextPage();
        } else {
          handlePreviousPage();
        }
      }
      touchStartX.current = null;
    },
    [handleNextPage, handlePreviousPage]
  );

  // Fullscreen handlers
  const handleToggleFullscreen = useCallback(() => {
    setUserScale(null); // Reset to calculated fit scale when toggling fullscreen
    setIsFullscreen((prev) => {
      if (!prev) {
        setShowControls(true);
        hideControlsTimer.current = setTimeout(
          () => setShowControls(false),
          2000
        );
      }
      return !prev;
    });
  }, []);

  const handleShowControls = useCallback(() => {
    if (!isFullscreen) return;
    setShowControls(true);
    if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    hideControlsTimer.current = setTimeout(() => setShowControls(false), 3000);
  }, [isFullscreen]);

  // Keyboard handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFullscreen) setIsFullscreen(false);
      if (isFullscreen) {
        if (e.key === "ArrowLeft") {
          handlePreviousPage();
          handleShowControls();
        } else if (e.key === "ArrowRight") {
          handleNextPage();
          handleShowControls();
        }
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isFullscreen, handlePreviousPage, handleNextPage, handleShowControls]);

  // Track container width using ResizeObserver (setState in callback is allowed)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) {
        setContainerWidth(entry.contentRect.width);
      }
    });

    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  // Cleanup
  useEffect(() => {
    return () => {
      if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    };
  }, []);

  // Navigation state
  const canGoPrevious =
    currentPage > 1 &&
    (!isLoadingChunk ||
      !!(currentChunk && currentPage - 2 >= currentChunk.startPage));
  const canGoNext =
    currentPage < totalPages &&
    (!isLoadingChunk ||
      !!(currentChunk && currentPage <= currentChunk.endPage));

  // Loading state
  if ((isLoadingChunk && !currentChunk) || scale === null) {
    return (
      <div className="flex h-[400px] sm:h-[600px] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error && !currentChunk) {
    return (
      <div className="flex h-[400px] sm:h-[600px] items-center justify-center text-destructive">
        {error}
      </div>
    );
  }

  // Fullscreen viewer
  if (isFullscreen) {
    return (
      <ViewProtection disabled={protectionDisabled} blockDevTools={blockDevTools}>
        <FullscreenViewer
          currentPage={currentPage}
          totalPages={totalPages}
          scale={scale}
          currentChunk={currentChunk}
          pageInChunk={pageInChunk}
          isLoadingChunk={isLoadingChunk}
          isCurrentPageInLoadedChunk={isCurrentPageInLoadedChunk}
          showControls={showControls}
          canGoPrevious={canGoPrevious}
          canGoNext={canGoNext}
          contentOverflows={contentOverflows}
          onPreviousPage={handlePreviousPage}
          onNextPage={handleNextPage}
          onZoomIn={handleZoomIn}
          onZoomOut={handleZoomOut}
          onFitWidth={handleFitWidth}
          onClose={() => setIsFullscreen(false)}
          onShowControls={handleShowControls}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        />
      </ViewProtection>
    );
  }

  // Regular viewer
  return (
    <ViewProtection disabled={protectionDisabled} blockDevTools={blockDevTools}>
      <div
        ref={containerRef}
        className="flex h-full flex-col overflow-hidden rounded-lg border"
      >
        <PDFToolbar
          currentPage={currentPage}
          totalPages={totalPages}
          scale={scale}
          onPreviousPage={handlePreviousPage}
          onNextPage={handleNextPage}
          onGoToPage={handleGoToPage}
          onZoomIn={handleZoomIn}
          onZoomOut={handleZoomOut}
          onFitWidth={handleFitWidth}
          isFullscreen={false}
          onToggleFullscreen={handleToggleFullscreen}
          disablePrevious={!canGoPrevious}
          disableNext={!canGoNext}
        />
        <div
          ref={scrollContainerRef}
          className="relative flex-1 overflow-auto bg-muted flex justify-center"
          onTouchStart={contentOverflows ? undefined : handleTouchStart}
          onTouchEnd={contentOverflows ? undefined : handleTouchEnd}
        >
          {(isLoadingChunk || !isCurrentPageInLoadedChunk) && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          {currentChunk && isCurrentPageInLoadedChunk && (
            <PageRenderer
              key={`page-${currentPage}`}
              pdfDocument={currentChunk.pdfDocument}
              pageNumber={pageInChunk}
              scale={scale}
            />
          )}
        </div>
      </div>
    </ViewProtection>
  );
}

export { ViewProtection } from "./protection";
export { PDFToolbar } from "./toolbar";
export { PageRenderer } from "./page-renderer";
export type { ChunkData, SecurePDFViewerProps } from "./types";
