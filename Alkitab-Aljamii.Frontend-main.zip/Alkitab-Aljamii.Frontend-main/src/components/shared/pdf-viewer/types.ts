export interface ChunkData {
  startPage: number;
  endPage: number;
  pdfDocument: unknown;
  pageWidth: number;
  pageHeight: number;
}

export interface SecurePDFViewerProps {
  contentId: string;
  protectionDisabled?: boolean;
  blockDevTools?: boolean;
}

export interface FullscreenViewerProps {
  currentPage: number;
  totalPages: number;
  scale: number;
  currentChunk: ChunkData | null;
  pageInChunk: number;
  isLoadingChunk: boolean;
  isCurrentPageInLoadedChunk: boolean;
  showControls: boolean;
  canGoPrevious: boolean;
  canGoNext: boolean;
  contentOverflows: boolean;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFitWidth: () => void;
  onClose: () => void;
  onShowControls: () => void;
  onTouchStart: (e: React.TouchEvent) => void;
  onTouchEnd: (e: React.TouchEvent) => void;
}
