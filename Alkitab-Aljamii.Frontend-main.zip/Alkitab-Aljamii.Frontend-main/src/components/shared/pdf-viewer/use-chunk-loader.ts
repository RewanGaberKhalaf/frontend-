'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { getAccessToken, contentApi } from '@/lib/api';
import type { ChunkData } from './types';

// Cache for loaded chunks to avoid re-fetching
const chunkCache = new Map<string, ChunkData>();

// Prefetch threshold - start prefetching when this many pages remain in current chunk
const PREFETCH_THRESHOLD = 5;

// PDF.js singleton - initialize once
let pdfjsLib: typeof import('pdfjs-dist') | null = null;
let pdfjsInitPromise: Promise<typeof import('pdfjs-dist')> | null = null;

async function getPdfjs() {
  if (pdfjsLib) return pdfjsLib;
  if (pdfjsInitPromise) return pdfjsInitPromise;

  pdfjsInitPromise = import('pdfjs-dist').then((pdfjs) => {
    // Use local worker from public folder - cached by browser
    pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';
    pdfjsLib = pdfjs;
    return pdfjs;
  });

  return pdfjsInitPromise;
}

interface UseChunkLoaderOptions {
  contentId: string;
  onError?: (error: string) => void;
}

interface UseChunkLoaderReturn {
  totalPages: number;
  chunkSize: number;
  currentChunk: ChunkData | null;
  isLoadingChunk: boolean;
  loadChunkForPage: (page: number) => Promise<void>;
  isPageInCurrentChunk: (page: number) => boolean;
  prefetchInDirection: (page: number, lastPage: number) => void;
}

export function useChunkLoader({ contentId, onError }: UseChunkLoaderOptions): UseChunkLoaderReturn {
  const [totalPages, setTotalPages] = useState(0);
  const [chunkSize, setChunkSize] = useState(15);
  const [currentChunk, setCurrentChunk] = useState<ChunkData | null>(null);
  const [isLoadingChunk, setIsLoadingChunk] = useState(true);

  const mountedRef = useRef(true);
  const prefetchingRef = useRef<Set<string>>(new Set());
  const loadingChunkRef = useRef<string | null>(null);
  const pageCountLoadedRef = useRef(false);

  // Generate cache key for a chunk
  const getChunkCacheKey = useCallback((cId: string, start: number, count: number) => {
    return `${cId}-${start}-${count}`;
  }, []);

  // Calculate which chunk a page belongs to (0-indexed start)
  const getChunkForPage = useCallback((page: number): { start: number; end: number } => {
    const chunkIndex = Math.floor((page - 1) / chunkSize);
    const start = chunkIndex * chunkSize;
    const end = Math.min(start + chunkSize - 1, totalPages - 1);
    return { start, end };
  }, [chunkSize, totalPages]);

  // Check if page is within current chunk
  const isPageInCurrentChunk = useCallback((page: number): boolean => {
    if (!currentChunk) return false;
    const pageIndex = page - 1;
    return pageIndex >= currentChunk.startPage && pageIndex <= currentChunk.endPage;
  }, [currentChunk]);

  // Fetch a chunk of pages
  const fetchChunk = useCallback(async (start: number, count: number, isPrefetch = false): Promise<ChunkData | null> => {
    const cacheKey = getChunkCacheKey(contentId, start, count);

    // Check cache first
    if (chunkCache.has(cacheKey)) {
      return chunkCache.get(cacheKey)!;
    }

    // Prevent duplicate fetches - if already fetching, wait for it
    if (prefetchingRef.current.has(cacheKey)) {
      if (!isPrefetch) {
        // Wait for the in-progress fetch to complete (max 10 seconds)
        let attempts = 0;
        while (prefetchingRef.current.has(cacheKey) && attempts < 100) {
          await new Promise(resolve => setTimeout(resolve, 100));
          attempts++;
          // Check cache on each iteration in case it completed
          if (chunkCache.has(cacheKey)) {
            return chunkCache.get(cacheKey)!;
          }
        }
        // Final cache check
        if (chunkCache.has(cacheKey)) {
          return chunkCache.get(cacheKey)!;
        }
      }
      return null;
    }

    prefetchingRef.current.add(cacheKey);

    try {
      const url = contentApi.getPagesUrl(contentId, start, count);
      const token = getAccessToken();
      

      const response = await fetch(url, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const arrayBuffer = await response.arrayBuffer();

      const pdfjs = await getPdfjs();
      const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;

      const firstPage = await pdf.getPage(1);
      const viewport = firstPage.getViewport({ scale: 1 });

      const chunkData: ChunkData = {
        startPage: start,
        endPage: start + pdf.numPages - 1,
        pdfDocument: pdf,
        pageWidth: viewport.width,
        pageHeight: viewport.height,
      };

      chunkCache.set(cacheKey, chunkData);
      return chunkData;
    } catch (err) {
      console.error('Failed to fetch chunk:', err);
      return null;
    } finally {
      prefetchingRef.current.delete(cacheKey);
    }
  }, [contentId, getChunkCacheKey]);

  // Prefetch adjacent chunks
  const prefetchNextChunk = useCallback((currentStart: number) => {
    if (totalPages === 0) return;
    const nextStart = currentStart + chunkSize;
    if (nextStart < totalPages) {
      fetchChunk(nextStart, chunkSize, true);
    }
  }, [totalPages, chunkSize, fetchChunk]);

  const prefetchPreviousChunk = useCallback((currentStart: number) => {
    if (totalPages === 0) return;
    const prevStart = currentStart - chunkSize;
    if (prevStart >= 0) {
      fetchChunk(prevStart, chunkSize, true);
    }
  }, [totalPages, chunkSize, fetchChunk]);

  // Prefetch based on direction of movement
  const prefetchInDirection = useCallback((page: number, lastPage: number) => {
    if (!currentChunk) return;

    const pageIndexInChunk = (page - 1) - currentChunk.startPage;
    const pagesRemainingInChunk = chunkSize - pageIndexInChunk - 1;
    const direction = page - lastPage;

    if (direction >= 0 && pagesRemainingInChunk <= PREFETCH_THRESHOLD) {
      prefetchNextChunk(currentChunk.startPage);
    }

    if (direction <= 0 && pageIndexInChunk < PREFETCH_THRESHOLD) {
      prefetchPreviousChunk(currentChunk.startPage);
    }
  }, [currentChunk, chunkSize, prefetchNextChunk, prefetchPreviousChunk]);

  // Load chunk for a specific page
  const loadChunkForPage = useCallback(async (page: number) => {
    if (totalPages === 0) return;

    const { start } = getChunkForPage(page);
    const cacheKey = getChunkCacheKey(contentId, start, chunkSize);

    // Check cache FIRST - if already cached, set immediately (no loading state)
    const cachedChunk = chunkCache.get(cacheKey);
    if (cachedChunk) {
      setCurrentChunk(cachedChunk);
      setIsLoadingChunk(false);
      return;
    }

    if (loadingChunkRef.current === cacheKey) return;

    loadingChunkRef.current = cacheKey;
    setIsLoadingChunk(true);

    const chunk = await fetchChunk(start, chunkSize);

    if (mountedRef.current && chunk) {
      setCurrentChunk(chunk);
      setIsLoadingChunk(false);
      loadingChunkRef.current = null;
    } else if (mountedRef.current && !chunk) {
      if (!currentChunk) {
        onError?.('Failed to load pages');
      }
      setIsLoadingChunk(false);
      loadingChunkRef.current = null;
    }
  }, [totalPages, chunkSize, contentId, getChunkForPage, getChunkCacheKey, fetchChunk, currentChunk, onError]);

  // Load page count on mount
  useEffect(() => {
    mountedRef.current = true;

    if (pageCountLoadedRef.current) return;
    pageCountLoadedRef.current = true;

    const loadPageCount = async () => {
      try {
        const { totalPages: total, chunkSize: size } = await contentApi.getPageCount(contentId);
        if (mountedRef.current) {
          setTotalPages(total);
          setChunkSize(size);
        }
      } catch (err) {
        console.error('Failed to get page count:', err);
        if (mountedRef.current) {
          onError?.('Failed to load PDF');
          setIsLoadingChunk(false);
        }
      }
    };

    // Clear cache for this content when component mounts
    for (const key of chunkCache.keys()) {
      if (key.startsWith(contentId)) {
        chunkCache.delete(key);
      }
    }

    loadPageCount();

    return () => {
      mountedRef.current = false;
    };
  }, [contentId, onError]);

  return {
    totalPages,
    chunkSize,
    currentChunk,
    isLoadingChunk,
    loadChunkForPage,
    isPageInCurrentChunk,
    prefetchInDirection,
  };
}
