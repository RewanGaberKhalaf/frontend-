'use client';

import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface PageRendererProps {
  pdfDocument: unknown;
  pageNumber: number;
  scale: number;
}

interface RenderTask {
  promise: Promise<void>;
  cancel: () => void;
}

let renderIdCounter = 0;

export function PageRenderer({ pdfDocument, pageNumber, scale }: PageRendererProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const renderTaskRef = useRef<RenderTask | null>(null);
  const currentRenderIdRef = useRef<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const renderId = ++renderIdCounter;
    currentRenderIdRef.current = renderId;

    const renderPage = async () => {
      if (!pdfDocument || !canvasRef.current) return;

      // Cancel any ongoing render
      if (renderTaskRef.current) {
        renderTaskRef.current.cancel();
        renderTaskRef.current = null;
      }

      setIsLoading(true);
      setError(null);

      try {
        // @ts-expect-error - pdfjs types
        const page = await pdfDocument.getPage(pageNumber);

        // Check if this render is still current
        if (currentRenderIdRef.current !== renderId) return;

        // Get the CSS pixel dimensions we want to display
        const cssViewport = page.getViewport({ scale });
        const cssWidth = cssViewport.width;
        const cssHeight = cssViewport.height;

        // For the actual canvas buffer, render at higher resolution for DPI
        const dpr = window.devicePixelRatio || 1;
        const renderViewport = page.getViewport({ scale: scale * dpr });

        const canvas = canvasRef.current;
        if (!canvas) return;

        const context = canvas.getContext('2d');
        if (!context) return;

        // Reset canvas completely
        canvas.width = 0;
        canvas.height = 0;
        canvas.width = renderViewport.width;
        canvas.height = renderViewport.height;

        // Store CSS size for inline styles
        setCanvasSize({ width: cssWidth, height: cssHeight });

        // Check again if this render is still current
        if (currentRenderIdRef.current !== renderId) return;

        const renderTask = page.render({
          canvasContext: context,
          viewport: renderViewport,
        });

        renderTaskRef.current = renderTask;

        await renderTask.promise;

        // Only update state if this render is still current
        if (currentRenderIdRef.current === renderId) {
          renderTaskRef.current = null;
          setIsLoading(false);
        }
      } catch (err) {
        // Ignore cancelled render errors
        if (err instanceof Error && err.message.includes('cancelled')) {
          return;
        }
        if (currentRenderIdRef.current === renderId) {
          setError('Failed to render page');
          setIsLoading(false);
        }
        console.error('PDF render error:', err);
      }
    };

    renderPage();

    // Cleanup: cancel render on unmount or dependency change
    return () => {
      if (renderTaskRef.current) {
        renderTaskRef.current.cancel();
        renderTaskRef.current = null;
      }
    };
  }, [pdfDocument, pageNumber, scale]);

  if (error) {
    return (
      <div className="flex h-[600px] items-center justify-center text-destructive">
        {error}
      </div>
    );
  }

  return (
    <div className="relative inline-block p-2 sm:p-4" dir="ltr">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}
      <canvas
        ref={canvasRef}
        className="shadow-lg block"
        style={{
          width: canvasSize.width > 0 ? `${canvasSize.width}px` : undefined,
          height: canvasSize.height > 0 ? `${canvasSize.height}px` : undefined,
        }}
      />
    </div>
  );
}
