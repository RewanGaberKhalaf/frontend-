'use client';

import { useRef } from 'react';
import { Loader2 } from 'lucide-react';
import { PageRenderer } from './page-renderer';
import type { FullscreenViewerProps } from './types';

export function FullscreenViewer({
  currentPage,
  totalPages,
  scale,
  currentChunk,
  pageInChunk,
  isLoadingChunk,
  isCurrentPageInLoadedChunk,
  showControls,
  canGoPrevious,
  canGoNext,
  onPreviousPage,
  onNextPage,
  onZoomIn,
  onZoomOut,
  onFitWidth,
  onClose,
  onShowControls,
  onTouchStart,
  onTouchEnd,
  contentOverflows,
}: FullscreenViewerProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  return (
    <div
      className="fixed inset-0 z-50 bg-black flex flex-col"
      onClick={onShowControls}
    >
      {/* Top controls */}
      <div
        className={`absolute top-0 left-0 right-0 z-10 transition-transform duration-300 ${
          showControls ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="flex items-center justify-between bg-black/80 backdrop-blur-sm p-2 sm:p-3">
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6 6 18"/><path d="m6 6 12 12"/>
              </svg>
            </button>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onZoomOut();
              }}
              disabled={scale <= 0.5}
              className="p-2 text-white/80 hover:text-white disabled:text-white/30 rounded-full hover:bg-white/10 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="8" x2="14" y1="11" y2="11"/>
              </svg>
            </button>
            <span className="text-white/80 text-xs min-w-[40px] text-center">
              {Math.round(scale * 100)}%
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onZoomIn();
              }}
              disabled={scale >= 3}
              className="p-2 text-white/80 hover:text-white disabled:text-white/30 rounded-full hover:bg-white/10 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="11" x2="11" y1="8" y2="14"/><line x1="8" x2="14" y1="11" y2="11"/>
              </svg>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onFitWidth();
              }}
              className="p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition-colors"
              title="Fit to width"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" x2="14" y1="3" y2="10"/><line x1="3" x2="10" y1="21" y2="14"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* PDF content */}
      <div
        ref={scrollContainerRef}
        className="relative flex-1 overflow-auto flex justify-center items-start pt-4"
        onTouchStart={(e) => {
          onShowControls();
          if (!contentOverflows) onTouchStart(e);
        }}
        onTouchEnd={contentOverflows ? undefined : onTouchEnd}
      >
        {(isLoadingChunk || !isCurrentPageInLoadedChunk) && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-20">
            <Loader2 className="h-8 w-8 animate-spin text-white" />
          </div>
        )}
        {currentChunk && isCurrentPageInLoadedChunk && (
          <PageRenderer
            key={`fullscreen-page-${currentPage}`}
            pdfDocument={currentChunk.pdfDocument}
            pageNumber={pageInChunk}
            scale={scale}
          />
        )}
      </div>

      {/* Bottom page indicator and navigation */}
      <div
        className={`absolute bottom-0 left-0 right-0 z-10 transition-transform duration-300 ${
          showControls ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        <div className="flex items-center justify-center gap-4 bg-black/80 backdrop-blur-sm p-3 sm:p-4">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onPreviousPage();
            }}
            disabled={!canGoPrevious}
            className="p-3 text-white/80 hover:text-white disabled:text-white/30 rounded-full hover:bg-white/10 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m15 18-6-6 6-6"/>
            </svg>
          </button>
          <span className="text-white text-sm sm:text-base font-medium min-w-[80px] text-center">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onNextPage();
            }}
            disabled={!canGoNext}
            className="p-3 text-white/80 hover:text-white disabled:text-white/30 rounded-full hover:bg-white/10 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Always visible minimal page indicator when controls are hidden */}
      {!showControls && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/50 text-xs bg-black/50 px-3 py-1 rounded-full">
          {currentPage} / {totalPages}
        </div>
      )}
    </div>
  );
}
