'use client';

import { useEffect } from 'react';

interface ViewProtectionProps {
  children: React.ReactNode;
  disabled?: boolean;
  blockDevTools?: boolean;
}

interface WatermarkOverlayProps {
  watermark: string;
}

// Separate watermark component to be placed inside content areas
export function WatermarkOverlay({ watermark }: WatermarkOverlayProps) {
  return (
    <div className="pointer-events-none select-none absolute inset-0 overflow-hidden opacity-[0.08] z-20">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `repeating-linear-gradient(
            -45deg,
            transparent,
            transparent 100px,
            rgba(128, 128, 128, 0.1) 100px,
            rgba(128, 128, 128, 0.1) 101px
          )`,
        }}
      />
      <div className="flex h-full w-full flex-wrap items-center justify-center gap-32">
        {Array.from({ length: 6 }).map((_, i) => (
          <span
            key={i}
            className="rotate-[-45deg] whitespace-nowrap text-2xl sm:text-3xl font-semibold text-gray-500"
          >
            {watermark}
          </span>
        ))}
      </div>
    </div>
  );
}

// Protection wrapper - handles event blocking and user-select
export function ViewProtection({
  children,
  disabled = false,
  blockDevTools = false,
}: ViewProtectionProps) {
  useEffect(() => {
    if (disabled) return;

    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    const handleKeyDown = (e: KeyboardEvent) => {
      // Block Ctrl+P, Ctrl+S, Ctrl+C, PrintScreen
      if (
        (e.ctrlKey && ['p', 's', 'c'].includes(e.key.toLowerCase())) ||
        e.key === 'PrintScreen'
      ) {
        e.preventDefault();
      }

      // Block dev tools shortcuts if enabled
      if (blockDevTools) {
        // F12
        if (e.key === 'F12') {
          e.preventDefault();
        }
        // Ctrl+Shift+I (Chrome/Firefox dev tools)
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'i') {
          e.preventDefault();
        }
        // Ctrl+Shift+J (Chrome console)
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'j') {
          e.preventDefault();
        }
        // Ctrl+Shift+C (Chrome inspect element)
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'c') {
          e.preventDefault();
        }
        // Ctrl+U (view source)
        if (e.ctrlKey && e.key.toLowerCase() === 'u') {
          e.preventDefault();
        }
      }
    };
    const handleBeforePrint = (e: Event) => e.preventDefault();

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);
    window.addEventListener('beforeprint', handleBeforePrint);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('beforeprint', handleBeforePrint);
    };
  }, [disabled, blockDevTools]);

  return (
    <div
      style={{
        userSelect: disabled ? 'auto' : 'none',
        WebkitUserSelect: disabled ? 'auto' : 'none',
      }}
    >
      {children}
    </div>
  );
}
