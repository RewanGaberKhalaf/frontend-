'use client';

import { useState, useCallback } from 'react';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Maximize2, Minimize2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface PDFToolbarProps {
  currentPage: number;
  totalPages: number;
  scale: number;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onGoToPage: (page: number) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFitWidth?: () => void;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
  disablePrevious?: boolean;
  disableNext?: boolean;
}

export function PDFToolbar({
  currentPage,
  totalPages,
  scale,
  onPreviousPage,
  onNextPage,
  onGoToPage,
  onZoomIn,
  onZoomOut,
  onFitWidth,
  isFullscreen,
  onToggleFullscreen,
  disablePrevious,
  disableNext,
}: PDFToolbarProps) {
  const [pageInput, setPageInput] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const handlePageSubmit = useCallback(() => {
    const page = parseInt(pageInput, 10);
    if (!isNaN(page) && page >= 1 && page <= totalPages) {
      onGoToPage(page);
    }
    setPageInput('');
    setIsEditing(false);
  }, [pageInput, totalPages, onGoToPage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handlePageSubmit();
    } else if (e.key === 'Escape') {
      setPageInput('');
      setIsEditing(false);
    }
  }, [handlePageSubmit]);

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-background p-2">
      {/* Navigation */}
      <div className="flex items-center gap-1 sm:gap-2">
        <Button
          variant="outline"
          size="icon"
          className="h-8 w-8 sm:h-9 sm:w-9"
          onClick={onPreviousPage}
          disabled={disablePrevious ?? currentPage <= 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        {isEditing ? (
          <div className="flex items-center gap-1">
            <Input
              type="number"
              min={1}
              max={totalPages}
              value={pageInput}
              onChange={(e) => setPageInput(e.target.value)}
              onKeyDown={handleKeyDown}
              onBlur={handlePageSubmit}
              className="h-8 w-16 sm:w-20 text-center text-xs sm:text-sm"
              autoFocus
            />
            <span className="text-xs sm:text-sm text-muted-foreground">/ {totalPages}</span>
          </div>
        ) : (
          <button
            onClick={() => {
              setIsEditing(true);
              setPageInput(currentPage.toString());
            }}
            className="min-w-[70px] sm:min-w-[100px] text-center text-xs sm:text-sm hover:bg-muted rounded px-2 py-1 transition-colors"
            title="Click to go to page"
          >
            {currentPage} / {totalPages}
          </button>
        )}
        <Button
          variant="outline"
          size="icon"
          className="h-8 w-8 sm:h-9 sm:w-9"
          onClick={onNextPage}
          disabled={disableNext ?? currentPage >= totalPages}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Zoom controls */}
      <div className="flex items-center gap-1 sm:gap-2">
        <Button
          variant="outline"
          size="icon"
          className="h-8 w-8 sm:h-9 sm:w-9"
          onClick={onZoomOut}
          disabled={scale <= 0.5}
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
        <span className="min-w-[40px] sm:min-w-[60px] text-center text-xs sm:text-sm">
          {Math.round(scale * 100)}%
        </span>
        <Button
          variant="outline"
          size="icon"
          className="h-8 w-8 sm:h-9 sm:w-9"
          onClick={onZoomIn}
          disabled={scale >= 3}
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
        {onFitWidth && (
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 sm:h-9 sm:w-9"
            onClick={onFitWidth}
            title="Fit to width"
          >
            <Maximize2 className="h-4 w-4" />
          </Button>
        )}
        {onToggleFullscreen && (
          <Button
            variant={isFullscreen ? "default" : "outline"}
            size="icon"
            className="h-8 w-8 sm:h-9 sm:w-9"
            onClick={onToggleFullscreen}
            title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? <X className="h-4 w-4" /> : <Minimize2 className="h-4 w-4 rotate-45" />}
          </Button>
        )}
      </div>
    </div>
  );
}
