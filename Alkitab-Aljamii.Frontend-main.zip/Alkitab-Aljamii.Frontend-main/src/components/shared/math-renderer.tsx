"use client";

import { useEffect, useMemo, useRef } from "react";
import katex from "katex";
import "katex/dist/katex.min.css";
import { cn } from "@/lib/utils";

interface MathRendererProps {
  /** Text containing LaTeX formulas. Use $...$ for inline and $$...$$ for block math. */
  children: string;
  /** Additional CSS classes */
  className?: string;
  /** Whether to render the text as a block element (default: false) */
  block?: boolean;
}

interface ParsedSegment {
  type: "text" | "mathInline" | "mathBlock";
  content: string;
}

/**
 * Parse text to find LaTeX formulas
 * Supports:
 * - Inline math: $...$
 * - Block math: $$...$$
 */
function parseLatex(text: string): ParsedSegment[] {
  const segments: ParsedSegment[] = [];
  let remaining = text;

  // Regex to match $$...$$ (block) or $...$ (inline)
  // Block math must be matched first to avoid partial matches
  const mathRegex = /\$\$([^$]+)\$\$|\$([^$]+)\$/g;

  let lastIndex = 0;
  let match;

  while ((match = mathRegex.exec(text)) !== null) {
    // Add text before the match
    if (match.index > lastIndex) {
      segments.push({
        type: "text",
        content: text.slice(lastIndex, match.index),
      });
    }

    // Check if it's block ($$...$$) or inline ($...$)
    if (match[1] !== undefined) {
      // Block math: $$...$$
      segments.push({
        type: "mathBlock",
        content: match[1],
      });
    } else if (match[2] !== undefined) {
      // Inline math: $...$
      segments.push({
        type: "mathInline",
        content: match[2],
      });
    }

    lastIndex = match.index + match[0].length;
  }

  // Add remaining text
  if (lastIndex < text.length) {
    segments.push({
      type: "text",
      content: text.slice(lastIndex),
    });
  }

  return segments;
}

/**
 * Renders a single math segment using KaTeX
 */
function MathSegment({
  latex,
  displayMode,
  className,
}: {
  latex: string;
  displayMode: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    try {
      katex.render(latex, ref.current, {
        displayMode,
        throwOnError: false,
        errorColor: "#ef4444",
        trust: true,
        strict: false,
      });
    } catch (error) {
      // Fallback to showing the raw LaTeX on error
      if (ref.current) {
        ref.current.textContent = displayMode ? `$$${latex}$$` : `$${latex}$`;
        ref.current.classList.add("text-destructive");
      }
    }
  }, [latex, displayMode]);

  return (
    <span
      ref={ref}
      className={cn(
        displayMode ? "block my-2 text-center" : "inline align-middle",
        className
      )}
    />
  );
}

/**
 * MathRenderer - Renders text with embedded LaTeX formulas
 *
 * Parses text looking for:
 * - $...$ for inline math
 * - $$...$$ for block/display math
 *
 * @example
 * <MathRenderer>
 *   The quadratic formula is $x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}$
 * </MathRenderer>
 *
 * @example
 * <MathRenderer>
 *   Einstein's famous equation:
 *   $$E = mc^2$$
 * </MathRenderer>
 */
export function MathRenderer({ children, className, block = false }: MathRendererProps) {
  const segments = useMemo(() => parseLatex(children), [children]);

  // If no math found, return plain text
  const hasMath = segments.some((s) => s.type !== "text");
  if (!hasMath) {
    return block ? (
      <div className={className}>{children}</div>
    ) : (
      <span className={className}>{children}</span>
    );
  }

  const Wrapper = block ? "div" : "span";

  return (
    <Wrapper className={className}>
      {segments.map((segment, index) => {
        if (segment.type === "text") {
          return <span key={index}>{segment.content}</span>;
        }

        return (
          <MathSegment
            key={index}
            latex={segment.content}
            displayMode={segment.type === "mathBlock"}
          />
        );
      })}
    </Wrapper>
  );
}

/**
 * Renders pure LaTeX without parsing (for pre-parsed content)
 */
export function LatexRender({
  latex,
  displayMode = false,
  className,
}: {
  latex: string;
  displayMode?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || !latex) return;

    try {
      katex.render(latex, ref.current, {
        displayMode,
        throwOnError: false,
        errorColor: "#ef4444",
        trust: true,
        strict: false,
      });
    } catch {
      if (ref.current) {
        ref.current.textContent = latex;
      }
    }
  }, [latex, displayMode]);

  return (
    <div
      ref={ref}
      className={cn(
        displayMode ? "text-center my-2" : "inline",
        className
      )}
    />
  );
}
