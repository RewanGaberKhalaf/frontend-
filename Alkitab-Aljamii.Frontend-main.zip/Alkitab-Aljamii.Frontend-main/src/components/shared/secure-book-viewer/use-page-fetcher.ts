'use client';

import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { booksApi } from '@/lib/api/books';
import { type UsePageFetcherOptions, type UsePageFetcherReturn, isRateLimitError } from './page-fetcher-types';

export type { UsePageFetcherOptions, UsePageFetcherReturn } from './page-fetcher-types';

export function usePageFetcher(options: UsePageFetcherOptions): UsePageFetcherReturn {
  const { bookId, chapterId, useProfessorApi = false, skip = false, onInitialLoad, onPageLoad, onError, onSecurityIncident } = options;

  const [content, setContent] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [hasPagination, setHasPagination] = useState(false);
  const [title, setTitle] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [isRateLimited, setIsRateLimited] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [hasNext, setHasNext] = useState(false);
  const [hasPrevious, setHasPrevious] = useState(false);

  const accessTokenRef = useRef<string>('');
  const expiresAtRef = useRef<Date | null>(null);
  const pageCacheRef = useRef<Map<number, string>>(new Map());
  const onInitialLoadRef = useRef(onInitialLoad);
  const onPageLoadRef = useRef(onPageLoad);
  const onErrorRef = useRef(onError);
  const onSecurityIncidentRef = useRef(onSecurityIncident);

  useEffect(() => { onInitialLoadRef.current = onInitialLoad; onPageLoadRef.current = onPageLoad; onErrorRef.current = onError; onSecurityIncidentRef.current = onSecurityIncident; }, [onInitialLoad, onPageLoad, onError, onSecurityIncident]);

  const getTokenExpiresIn = useCallback(() => {
    if (!expiresAtRef.current) return 0;
    return Math.floor(Math.max(0, expiresAtRef.current.getTime() - Date.now()) / 1000);
  }, []);

  const loadInitialContent = useCallback(async () => {
    if (!bookId || !chapterId || skip) { setIsLoading(false); return; }
    setIsLoading(true); setError(null); setIsRateLimited(false);

    try {
      const response = useProfessorApi ? await booksApi.getProfessorChapterContent(bookId, chapterId) : await booksApi.getSecureChapterContent(bookId, chapterId);
      accessTokenRef.current = response.accessToken;
      expiresAtRef.current = new Date(response.expiresAt);
      setContent(response.content); setTitle(response.title); setHasPagination(response.hasPagination ?? false);
      setTotalPages(response.totalPages ?? 1); setCurrentPage(response.currentPage ?? 1);
      setHasNext((response.currentPage ?? 1) < (response.totalPages ?? 1)); setHasPrevious((response.currentPage ?? 1) > 1);
      setIsInitialized(true); setIsRateLimited(false);
      pageCacheRef.current.clear(); pageCacheRef.current.set(response.currentPage ?? 1, response.content);
      onInitialLoadRef.current?.(response);
    } catch (err) {
      const rateLimited = isRateLimitError(err);
      const error = rateLimited ? new Error('Too many requests. Please wait a moment.') : err instanceof Error ? err : new Error('Failed to load content');
      setError(error); setIsRateLimited(rateLimited); onErrorRef.current?.(error);
    } finally { setIsLoading(false); }
  }, [bookId, chapterId, useProfessorApi, skip]);

  const loadPage = useCallback(async (pageNumber: number, isRetry = false) => {
    if (!isRetry) {
      if (pageNumber < 1 || pageNumber > totalPages) return;
      if (pageNumber === currentPage && !isLoading) return;
      const cachedContent = pageCacheRef.current.get(pageNumber);
      if (cachedContent) { setContent(cachedContent); setCurrentPage(pageNumber); setHasNext(pageNumber < totalPages); setHasPrevious(pageNumber > 1); return; }
    }

    const tokenExpired = !accessTokenRef.current || (expiresAtRef.current && expiresAtRef.current.getTime() < Date.now());
    let currentHasPagination = hasPagination;
    let currentTotalPages = totalPages;

    if (tokenExpired || isRetry) {
      setIsLoading(true); setError(null);
      try {
        const response = useProfessorApi ? await booksApi.getProfessorChapterContent(bookId, chapterId) : await booksApi.getSecureChapterContent(bookId, chapterId);
        accessTokenRef.current = response.accessToken; expiresAtRef.current = new Date(response.expiresAt);
        currentHasPagination = response.hasPagination ?? false; currentTotalPages = response.totalPages ?? 1;
        setHasPagination(currentHasPagination); setTotalPages(currentTotalPages); setIsInitialized(true);
        pageCacheRef.current.set(response.currentPage ?? 1, response.content);
        if (pageNumber === 1 || !currentHasPagination) {
          setContent(response.content); setCurrentPage(response.currentPage ?? 1);
          setHasNext((response.currentPage ?? 1) < currentTotalPages); setHasPrevious((response.currentPage ?? 1) > 1);
          setIsLoading(false); return;
        }
      } catch (err) {
        const rateLimited = isRateLimitError(err);
        const error = rateLimited ? new Error('Too many requests. Please wait a moment.') : err instanceof Error ? err : new Error('Failed to refresh token');
        setError(error); setIsRateLimited(rateLimited); onErrorRef.current?.(error); setIsLoading(false); return;
      }
    }

    if (!currentHasPagination || !accessTokenRef.current) { setIsLoading(false); return; }
    if (pageNumber < 1 || pageNumber > currentTotalPages) { setIsLoading(false); return; }

    setIsLoading(true); setError(null);
    try {
      const response = useProfessorApi
        ? await booksApi.getProfessorPageContent(bookId, chapterId, pageNumber, accessTokenRef.current)
        : await booksApi.getPageContent(bookId, chapterId, pageNumber, accessTokenRef.current);
      accessTokenRef.current = response.accessToken; expiresAtRef.current = new Date(response.expiresAt);
      pageCacheRef.current.set(response.pageNumber, response.content);
      setContent(response.content); setCurrentPage(response.pageNumber); setTotalPages(response.totalPages);
      setHasNext(response.hasNext); setHasPrevious(response.hasPrevious);
      onPageLoadRef.current?.(response);
    } catch (err) {
      if ((err as { response?: { status?: number } }).response?.status === 401 && !isRetry) {
        accessTokenRef.current = ''; expiresAtRef.current = null; setIsLoading(false); return loadPage(pageNumber, true);
      }
      const rateLimited = isRateLimitError(err);
      const error = rateLimited ? new Error('Too many requests. Please wait a moment.') : err instanceof Error ? err : new Error('Failed to load page');
      setError(error); setIsRateLimited(rateLimited); onErrorRef.current?.(error);
    } finally { setIsLoading(false); }
  }, [bookId, chapterId, hasPagination, totalPages, currentPage, isLoading, useProfessorApi]);

  const nextPage = useCallback(async () => { if (hasNext) await loadPage(currentPage + 1); }, [hasNext, currentPage, loadPage]);
  const previousPage = useCallback(async () => { if (hasPrevious) await loadPage(currentPage - 1); }, [hasPrevious, currentPage, loadPage]);
  const goToPage = useCallback(async (page: number) => { await loadPage(page); }, [loadPage]);
  const refresh = useCallback(async () => { if (hasPagination && currentPage > 1) await loadPage(currentPage); else await loadInitialContent(); }, [hasPagination, currentPage, loadPage, loadInitialContent]);

  useEffect(() => { if (bookId && chapterId && !skip) loadInitialContent(); }, [bookId, chapterId, skip, loadInitialContent]);

  return useMemo(() => ({
    content, currentPage, totalPages, hasPagination, title, isLoading, error, isRateLimited, isInitialized,
    nextPage, previousPage, goToPage, refresh, hasNext, hasPrevious,
    get tokenExpiresIn() { return getTokenExpiresIn(); },
  }), [content, currentPage, totalPages, hasPagination, title, isLoading, error, isRateLimited, isInitialized, nextPage, previousPage, goToPage, refresh, hasNext, hasPrevious, getTokenExpiresIn]);
}

export default usePageFetcher;
