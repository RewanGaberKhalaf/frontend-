"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { ViewProtection } from "@/components/shared/pdf-viewer/protection";
import { cn } from "@/lib/utils";
import { stripInvisibleChars } from "@/lib/utils/html-sanitizer";
import { useDevToolsDetector } from "./use-devtools-detector";
import { usePageFetcher } from "./use-page-fetcher";
import { useViewerControls } from "./use-viewer-controls";
import { useViewerNavigation } from "./use-viewer-navigation";
import { useViewerAnnotations } from "./use-viewer-annotations";
import { useLocalPagination } from "./use-local-pagination";
import { SelectionPopover, useCustomSelection } from "@/components/annotations";
import { DevToolsBlocked } from "./devtools-blocked";
import { ViewerLoading, ViewerError } from "./viewer-loading";
import { ViewerToolbar } from "./viewer-toolbar";
import { ViewerPage } from "./viewer-page";
import type { SecureBookViewerProps, ViewerMode } from "./types";

export type { SecureBookViewerProps, ViewerMode };

export function SecureBookViewer({
  mode = "local", html = "", chapterTitles, onPaginate, onBoundariesComputed, bookId, chapterId,
  useProfessorApi = false, title: propTitle, watermarkText, showWatermark = true, enableProtection = true,
  blockDevTools = false, detectDevTools = false, showPageNumbers = true, className, onSecurityIncident,
  enableAnnotations = false, annotations = [], onAnnotationCreate, onAnnotationClick, currentPageForAnnotation,
  targetPage, onPageChange, onPageContentChange, focusedAnnotationId, currentUserId, showAllHighlights = false, isProfessor = false, readingTimeSlot,
}: SecureBookViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [devToolsBlocked, setDevToolsBlocked] = useState(false);
  const [highlightsVisible, setHighlightsVisible] = useState(showAllHighlights);
  const onSecurityIncidentRef = useRef(onSecurityIncident);
  onSecurityIncidentRef.current = onSecurityIncident;

  // Track if popover has unsaved content
  const hasUnsavedNoteRef = useRef(false);
  const handleNoteStateChange = useCallback((hasNote: boolean) => {
    hasUnsavedNoteRef.current = hasNote;
  }, []);

  // Called before clearing selection - shows warning if there's unsaved content
  const handleBeforeClear = useCallback(() => {
    if (hasUnsavedNoteRef.current) {
      const confirmed = window.confirm('You have unsaved annotation text. Are you sure you want to discard it?');
      if (confirmed) {
        hasUnsavedNoteRef.current = false;
      }
      return confirmed;
    }
    return true;
  }, []);

  const handleSecurityIncident = useCallback((type: string, details?: Record<string, unknown>) => {
    onSecurityIncidentRef.current?.(type, details);
  }, []);

  const isServerMode = mode === "server" && !!bookId && !!chapterId;

  // Server mode: page fetcher (skip when in local mode)
  const pageFetcher = usePageFetcher({ bookId: bookId || "", chapterId: chapterId || "", useProfessorApi, skip: !isServerMode, onSecurityIncident: handleSecurityIncident });

  // Local mode: pagination
  const localPagination = useLocalPagination({ html, enableProtection, isServerMode, onPaginate, onBoundariesComputed });
  const { pages, pageChapterIndices, getContentHeight } = localPagination;

  const totalPages = isServerMode ? pageFetcher.totalPages : pages.length;

  // Viewer controls
  const { zoom, isFullscreen, effectiveZoom, adjustZoom, toggleFullscreen } = useViewerControls({ containerRef });

  // Navigation
  const navigation = useViewerNavigation({ totalPages, isServerMode, serverPageFetcher: isServerMode ? pageFetcher : undefined, targetPage, onPageChange, toggleFullscreen, adjustZoom, isFullscreen });

  // Annotations
  const customSelection = useCustomSelection(contentRef as React.RefObject<HTMLElement>);
  const annotationHandlers = useViewerAnnotations({ bookId, chapterId, currentPage: currentPageForAnnotation ?? navigation.effectiveCurrentPage, onAnnotationCreate, onAnnotationClick });

  // DevTools detection
  const { isOpen: devToolsOpen } = useDevToolsDetector({
    enabled: detectDevTools, blockShortcuts: blockDevTools,
    onDetected: (result) => { setDevToolsBlocked(true); onSecurityIncident?.("devtools_opened", { method: result.method, timestamp: result.timestamp.toISOString() }); },
    onClosed: () => {},
  });

  useEffect(() => { if (devToolsOpen && detectDevTools) setDevToolsBlocked(true); }, [devToolsOpen, detectDevTools]);
  useEffect(() => { if (!isServerMode && pages.length > 0 && navigation.currentPage > pages.length) navigation.setCurrentPage(1); }, [pages.length, navigation, isServerMode]);

  const getPageTitle = useCallback((pageIndex: number) => {
    if (chapterTitles?.length) return chapterTitles[pageChapterIndices[pageIndex] || 0] || propTitle || "";
    return propTitle || "";
  }, [chapterTitles, pageChapterIndices, propTitle]);

  const rawPageContent = isServerMode ? pageFetcher.content : pages[navigation.currentPage - 1] || "";
  const currentPageContent = stripInvisibleChars(rawPageContent);
  const currentTitle = isServerMode ? pageFetcher.title : getPageTitle(navigation.currentPage - 1);

  // Notify parent of page content changes for AI context
  useEffect(() => {
    if (onPageContentChange && currentPageContent) {
      onPageContentChange(currentPageContent, chapterId);
    }
  }, [currentPageContent, chapterId, onPageContentChange]);

  const handleTextSelection = useCallback((selection: Parameters<typeof annotationHandlers.handleTextSelection>[0]) => {
    annotationHandlers.handleTextSelection(selection, { activateWithRects: customSelection.activateWithRects, clearSelection: customSelection.clearSelection });
  }, [annotationHandlers, customSelection]);

  if (devToolsBlocked) return <DevToolsBlocked className={className} />;
  if (isServerMode && !pageFetcher.isInitialized && navigation.isLoading) return <ViewerLoading className={className} />;
  if (isServerMode && pageFetcher.error) return <ViewerError className={className} isRateLimited={pageFetcher.isRateLimited} errorMessage={pageFetcher.error.message} onRetry={() => pageFetcher.refresh()} />;

  return (
    <ViewProtection disabled={!enableProtection} blockDevTools={blockDevTools}>
      <div ref={containerRef} className={cn("flex flex-col h-full", isFullscreen ? "fixed inset-0 z-50 bg-black" : "bg-muted/30", className)} onTouchStart={navigation.handleTouchStart} onTouchEnd={navigation.handleTouchEnd} style={{ touchAction: "manipulation" }}>
        <ViewerToolbar zoom={zoom} isFullscreen={isFullscreen} effectiveCurrentPage={navigation.effectiveCurrentPage} totalPages={totalPages} isLoading={navigation.isLoading} canGoPrevious={navigation.canGoPrevious} canGoNext={navigation.canGoNext} enableAnnotations={enableAnnotations} currentUserId={currentUserId} highlightsVisible={highlightsVisible} showAllHighlights={showAllHighlights} readingTimeSlot={readingTimeSlot} onZoomIn={() => adjustZoom(0.1)} onZoomOut={() => adjustZoom(-0.1)} onPreviousPage={navigation.handlePreviousPage} onNextPage={navigation.handleNextPage} onToggleHighlights={() => setHighlightsVisible(!highlightsVisible)} onToggleFullscreen={toggleFullscreen} />

        <ViewerPage effectiveZoom={effectiveZoom} currentTitle={currentTitle} effectiveCurrentPage={navigation.effectiveCurrentPage} totalPages={totalPages} currentPageContent={currentPageContent} showWatermark={showWatermark} watermarkText={watermarkText} showPageNumbers={showPageNumbers} enableProtection={enableProtection} enableAnnotations={enableAnnotations} annotations={annotations} focusedAnnotationId={focusedAnnotationId} currentUserId={currentUserId} highlightsVisible={highlightsVisible} showAllHighlights={showAllHighlights} contentRef={contentRef} getContentHeight={getContentHeight} onTextSelection={handleTextSelection} onAnnotationHighlightClick={annotationHandlers.handleAnnotationHighlightClick} selectedAnnotationId={annotationHandlers.selectedAnnotationId} onBeforeClear={handleBeforeClear} />

        {enableAnnotations && annotationHandlers.textSelection && customSelection.isActive && (
          <SelectionPopover containerRef={contentRef as React.RefObject<HTMLElement>} selectionRects={customSelection.selectionRects} boundingRect={customSelection.getBoundingRect()} selectedText={customSelection.selectionData?.selectedText || annotationHandlers.textSelection.selectedText} selectionRange={customSelection.selectionData} onHighlight={annotationHandlers.handleCreateHighlight} onBookmark={annotationHandlers.handleCreateBookmark} onSelectionChange={customSelection.handleSelectionChange} onClose={annotationHandlers.handleClosePopover} isCreating={annotationHandlers.isCreatingAnnotation} isProfessor={isProfessor} onNoteStateChange={handleNoteStateChange} />
        )}
      </div>
    </ViewProtection>
  );
}

export default SecureBookViewer;

export { useDevToolsDetector } from "./use-devtools-detector";
export { usePageFetcher } from "./use-page-fetcher";
export { useViewerControls } from "./use-viewer-controls";
export { useViewerNavigation } from "./use-viewer-navigation";
export { useViewerAnnotations } from "./use-viewer-annotations";
export type { UseDevToolsDetectorOptions, UseDevToolsDetectorReturn } from "./use-devtools-detector";
export type { UsePageFetcherOptions, UsePageFetcherReturn } from "./use-page-fetcher";
