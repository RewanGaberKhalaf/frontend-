'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  createDevToolsDetector,
  blockDevToolsShortcuts,
  type DevToolsDetectionResult,
  type DevToolsDetectorOptions,
} from './devtools-detector';

export interface UseDevToolsDetectorOptions {
  /** Enable detection (default: true) */
  enabled?: boolean;
  /** Block keyboard shortcuts (default: true) */
  blockShortcuts?: boolean;
  /** Callback when DevTools is detected */
  onDetected?: (result: DevToolsDetectionResult) => void;
  /** Callback when DevTools is closed */
  onClosed?: () => void;
  /** Check interval in ms (default: 1000) */
  checkInterval?: number;
  /** Use debugger detection method (default: false - intrusive) */
  useDebugger?: boolean;
  /** Use console detection method (default: true) */
  useConsole?: boolean;
  /** Use size detection method (default: true) */
  useSize?: boolean;
  /** Do a one-time check on mount using debugger timing (default: true) */
  checkOnMount?: boolean;
}

export interface UseDevToolsDetectorReturn {
  /** Whether DevTools is currently detected as open */
  isOpen: boolean;
  /** Detection method that triggered the last detection */
  detectionMethod: string | null;
  /** Timestamp of last detection */
  lastDetected: Date | null;
  /** Manually trigger a check */
  checkNow: () => void;
}

/**
 * React hook for DevTools detection
 *
 * Usage:
 * ```tsx
 * const { isOpen, detectionMethod } = useDevToolsDetector({
 *   onDetected: (result) => {
 *     // Log incident, blur content, etc.
 *   },
 * });
 *
 * if (isOpen) {
 *   return <div className="blur-lg">Content hidden</div>;
 * }
 * ```
 */
/**
 * Perform a one-time debugger timing check
 * This is reliable because the debugger statement only pauses when DevTools is open
 */
function checkDebuggerTiming(): boolean {
  if (typeof window === 'undefined') return false;

  const startTime = performance.now();
  // eslint-disable-next-line no-debugger
  debugger;
  const endTime = performance.now();

  // If DevTools is open, this takes >100ms due to debugger pause
  return endTime - startTime > 100;
}

export function useDevToolsDetector(
  options: UseDevToolsDetectorOptions = {}
): UseDevToolsDetectorReturn {
  const {
    enabled = true,
    blockShortcuts = true,
    onDetected,
    onClosed,
    checkInterval = 1000,
    useDebugger = false,
    // Disable console detection by default - unreliable and can cause false positives
    useConsole = false,
    // Disable size detection by default - browser chrome causes false positives
    useSize = false,
    // Do a one-time check on mount using debugger timing
    checkOnMount = true,
  } = options;

  const [isOpen, setIsOpen] = useState(false);
  const [detectionMethod, setDetectionMethod] = useState<string | null>(null);
  const [lastDetected, setLastDetected] = useState<Date | null>(null);

  const detectorRef = useRef<ReturnType<typeof createDevToolsDetector> | null>(null);
  const onDetectedRef = useRef(onDetected);
  const onClosedRef = useRef(onClosed);

  // Keep callbacks up to date
  useEffect(() => {
    onDetectedRef.current = onDetected;
    onClosedRef.current = onClosed;
  }, [onDetected, onClosed]);

  // One-time check on mount using debugger timing
  useEffect(() => {
    if (!enabled || !checkOnMount || typeof window === 'undefined') return;

    // Small delay to let the page render first
    const timeoutId = setTimeout(() => {
      if (checkDebuggerTiming()) {
        const result: DevToolsDetectionResult = {
          isOpen: true,
          method: 'debugger',
          timestamp: new Date(),
        };
        setIsOpen(true);
        setDetectionMethod('debugger');
        setLastDetected(result.timestamp);
        onDetectedRef.current?.(result);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [enabled, checkOnMount]);

  // Setup detector
  useEffect(() => {
    if (!enabled || typeof window === 'undefined') return;

    const detectorOptions: DevToolsDetectorOptions = {
      checkInterval,
      useDebugger,
      useConsole,
      useSize,
      onDetected: (result) => {
        setIsOpen(true);
        setDetectionMethod(result.method);
        setLastDetected(result.timestamp);
        onDetectedRef.current?.(result);
      },
      onClosed: () => {
        setIsOpen(false);
        onClosedRef.current?.();
      },
    };

    detectorRef.current = createDevToolsDetector(detectorOptions);
    detectorRef.current.start();

    return () => {
      detectorRef.current?.stop();
      detectorRef.current = null;
    };
  }, [enabled, checkInterval, useDebugger, useConsole, useSize]);

  // Setup shortcut blocking
  useEffect(() => {
    if (!blockShortcuts || typeof window === 'undefined') return;

    const cleanup = blockDevToolsShortcuts();
    return cleanup;
  }, [blockShortcuts]);

  // Manual check function
  const checkNow = useCallback(() => {
    if (detectorRef.current) {
      const result = detectorRef.current.check();
      if (result.isOpen) {
        setIsOpen(true);
        setDetectionMethod(result.method);
        setLastDetected(result.timestamp);
      }
    }
  }, []);

  return {
    isOpen,
    detectionMethod,
    lastDetected,
    checkNow,
  };
}

export default useDevToolsDetector;
