'use client';

import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Maximize2, Minimize2, Highlighter, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { ViewerToolbarProps } from './types';

export function ViewerToolbar({
  zoom,
  isFullscreen,
  effectiveCurrentPage,
  totalPages,
  isLoading,
  canGoPrevious,
  canGoNext,
  enableAnnotations,
  currentUserId,
  highlightsVisible,
  showAllHighlights,
  readingTimeSlot,
  onZoomIn,
  onZoomOut,
  onPreviousPage,
  onNextPage,
  onToggleHighlights,
  onToggleFullscreen,
}: ViewerToolbarProps) {
  return (
    <div className={cn(
      "flex items-center justify-between gap-1 sm:gap-2 px-2 sm:px-4 py-2 shrink-0",
      isFullscreen
        ? "bg-black/80 backdrop-blur-sm border-b border-white/10"
        : "bg-background border-b"
    )}>
      {/* Zoom controls */}
      <div className="flex items-center gap-0.5 sm:gap-1">
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "h-7 w-7 sm:h-8 sm:w-8",
            isFullscreen && "text-white/80 hover:text-white hover:bg-white/10"
          )}
          onClick={onZoomOut}
          disabled={zoom <= 0.5}
        >
          <ZoomOut className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
        </Button>
        <span className={cn(
          "text-xs w-10 sm:w-12 text-center tabular-nums",
          isFullscreen && "text-white/80"
        )}>
          {Math.round(zoom * 100)}%
        </span>
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "h-7 w-7 sm:h-8 sm:w-8",
            isFullscreen && "text-white/80 hover:text-white hover:bg-white/10"
          )}
          onClick={onZoomIn}
          disabled={zoom >= 2}
        >
          <ZoomIn className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
        </Button>
      </div>

      {/* Page navigation and reading time */}
      <div className="flex items-center gap-2 sm:gap-4">
        <div className="flex items-center gap-1 sm:gap-2">
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8",
              isFullscreen && "text-white/80 hover:text-white hover:bg-white/10"
            )}
            onClick={onPreviousPage}
            disabled={!canGoPrevious || isLoading}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className={cn(
            "text-xs sm:text-sm min-w-[60px] sm:min-w-[80px] text-center",
            isFullscreen && "text-white/80"
          )}>
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin inline" />
            ) : (
              `${effectiveCurrentPage} / ${totalPages}`
            )}
          </span>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8",
              isFullscreen && "text-white/80 hover:text-white hover:bg-white/10"
            )}
            onClick={onNextPage}
            disabled={!canGoNext || isLoading}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Reading time display slot */}
        {readingTimeSlot}
      </div>

      {/* Right side controls */}
      <div className="flex items-center gap-1">
        {/* Show highlights toggle */}
        {enableAnnotations && currentUserId && (
          <Button
            variant={highlightsVisible ? 'secondary' : 'ghost'}
            size="icon"
            className={cn(
              "h-8 w-8",
              isFullscreen && !highlightsVisible && "text-white/80 hover:text-white hover:bg-white/10"
            )}
            onClick={onToggleHighlights}
            title={highlightsVisible
              ? (showAllHighlights ? 'Hide all highlights' : 'Hide my highlights')
              : (showAllHighlights ? 'Show all highlights' : 'Show my highlights')
            }
          >
            <Highlighter className="h-4 w-4" />
          </Button>
        )}
        {/* Fullscreen toggle */}
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "h-8 w-8",
            isFullscreen && "text-white/80 hover:text-white hover:bg-white/10"
          )}
          onClick={onToggleFullscreen}
          title={isFullscreen ? 'Exit fullscreen (Esc)' : 'Enter fullscreen (F)'}
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  );
}
