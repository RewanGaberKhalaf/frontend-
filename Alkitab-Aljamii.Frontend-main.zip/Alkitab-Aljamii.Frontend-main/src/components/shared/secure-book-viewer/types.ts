import type { Annotation, TextSelectionData, CreateAnnotationDto, PageBoundary } from '@/types';
import type { SelectionRange } from '@/components/annotations';

/** Viewer mode determines content source and pagination behavior */
export type ViewerMode = 'local' | 'server';

export interface SecureBookViewerProps {
  /** Viewer mode: 'local' for client pagination, 'server' for server-side pagination */
  mode?: ViewerMode;

  // === LOCAL MODE PROPS ===
  /** HTML content to display (required for local mode) */
  html?: string;
  /** Array of chapter titles for full book mode */
  chapterTitles?: string[];
  /** Called when content is paginated (local mode) */
  onPaginate?: (pageCount: number) => void;
  /** Called with computed page boundaries (for saving to server) */
  onBoundariesComputed?: (boundaries: PageBoundary[], html: string) => void;

  // === SERVER MODE PROPS ===
  /** Book ID (required for server mode) */
  bookId?: string;
  /** Chapter ID (required for server mode) */
  chapterId?: string;
  /** Use professor API endpoints (for professors viewing their books) */
  useProfessorApi?: boolean;

  // === COMMON PROPS ===
  /** Chapter/document title */
  title?: string;
  /** User info for watermark (e.g., email or name) */
  watermarkText?: string;
  /** Show watermark overlay */
  showWatermark?: boolean;
  /** Enable copy/print protection */
  enableProtection?: boolean;
  /** Block DevTools shortcuts */
  blockDevTools?: boolean;
  /** Enable advanced DevTools detection (blur content when detected) */
  detectDevTools?: boolean;
  /** Show page numbers */
  showPageNumbers?: boolean;
  /** CSS class for container */
  className?: string;
  /** Called on security incidents */
  onSecurityIncident?: (type: string, details?: Record<string, unknown>) => void;

  // === ANNOTATION PROPS ===
  /** Enable annotation mode toggle */
  enableAnnotations?: boolean;
  /** Current annotations to display */
  annotations?: Annotation[];
  /** Called when a new annotation is created */
  onAnnotationCreate?: (data: CreateAnnotationDto) => Promise<void>;
  /** Called when an annotation highlight is clicked */
  onAnnotationClick?: (annotation: Annotation) => void;
  /** Current page number for page-based annotations */
  currentPageForAnnotation?: number;
  /** Navigate to this page (controlled from outside) */
  targetPage?: number;
  /** Called when page changes */
  onPageChange?: (page: number) => void;
  /** Called when page content changes (for AI context) */
  onPageContentChange?: (content: string, chapterId: string | undefined) => void;
  /** Annotation to highlight/focus on */
  focusedAnnotationId?: string | null;
  /** Current user ID for filtering own annotations */
  currentUserId?: string;
  /** Show all highlights (for professor view) */
  showAllHighlights?: boolean;
  /** Whether the current user is a professor/teaching staff (enables notify students option) */
  isProfessor?: boolean;

  // === READING TIME PROPS ===
  /** Optional reading time display element to show in toolbar */
  readingTimeSlot?: React.ReactNode;
}

export interface ViewerToolbarProps {
  zoom: number;
  isFullscreen: boolean;
  effectiveCurrentPage: number;
  totalPages: number;
  isLoading: boolean;
  canGoPrevious: boolean;
  canGoNext: boolean;
  enableAnnotations: boolean;
  currentUserId?: string;
  highlightsVisible: boolean;
  showAllHighlights: boolean;
  readingTimeSlot?: React.ReactNode;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onToggleHighlights: () => void;
  onToggleFullscreen: () => void;
}

export interface ViewerPageProps {
  effectiveZoom: number;
  currentTitle: string;
  effectiveCurrentPage: number;
  totalPages: number;
  currentPageContent: string;
  showWatermark: boolean;
  watermarkText?: string;
  showPageNumbers: boolean;
  enableProtection: boolean;
  enableAnnotations: boolean;
  annotations: Annotation[];
  focusedAnnotationId?: string | null;
  currentUserId?: string;
  highlightsVisible: boolean;
  showAllHighlights: boolean;
  contentRef: React.RefObject<HTMLDivElement | null>;
  getContentHeight: () => number;
  onTextSelection: (selection: TextSelectionData | null) => void;
  onAnnotationHighlightClick: (annotation: Annotation) => void;
  selectedAnnotationId: string | null;
  /** Called before clearing selection. Return false to prevent clearing (e.g., for unsaved content warning) */
  onBeforeClear?: () => boolean;
}

export interface AnnotationHandlers {
  handleTextSelection: (selection: TextSelectionData | null) => void;
  handleCreateHighlight: (
    color: string,
    text: string,
    range: SelectionRange,
    note?: string,
    notifyStudents?: boolean
  ) => Promise<void>;
  handleCreateBookmark: (text: string, range: SelectionRange, note?: string) => Promise<void>;
  handleClosePopover: () => void;
  handleAnnotationHighlightClick: (annotation: Annotation) => void;
}
