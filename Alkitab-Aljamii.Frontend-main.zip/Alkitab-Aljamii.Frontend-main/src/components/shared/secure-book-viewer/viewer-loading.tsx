'use client';

import { AlertTriangle, Loader2, Clock, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ViewerLoadingProps {
  className?: string;
}

export function ViewerLoading({ className }: ViewerLoadingProps) {
  return (
    <div className={cn('flex flex-col h-full bg-muted/30 items-center justify-center', className)}>
      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      <p className="mt-2 text-muted-foreground">Loading content...</p>
    </div>
  );
}

interface ViewerErrorProps {
  className?: string;
  isRateLimited: boolean;
  errorMessage?: string;
  onRetry: () => void;
}

export function ViewerError({ className, isRateLimited, errorMessage, onRetry }: ViewerErrorProps) {
  return (
    <div className={cn('flex flex-col h-full bg-muted/30 items-center justify-center', className)}>
      <div className="text-center p-8 max-w-md">
        {isRateLimited ? (
          <>
            <Clock className="h-12 w-12 sm:h-16 sm:w-16 text-amber-500 mx-auto mb-4" />
            <h2 className="text-lg sm:text-xl font-semibold mb-2">Too Many Requests</h2>
            <p className="text-sm text-muted-foreground mb-4">
              You&apos;re making requests too quickly. Please wait a moment and try again.
            </p>
          </>
        ) : (
          <>
            <AlertTriangle className="h-12 w-12 sm:h-16 sm:w-16 text-destructive mx-auto mb-4" />
            <h2 className="text-lg sm:text-xl font-semibold mb-2">Failed to Load Content</h2>
            <p className="text-sm text-muted-foreground mb-4">
              {errorMessage || 'Something went wrong. Please try again.'}
            </p>
          </>
        )}
        <Button onClick={onRetry} className="gap-2">
          <RefreshCw className="h-4 w-4" />
          Try Again
        </Button>
      </div>
    </div>
  );
}
