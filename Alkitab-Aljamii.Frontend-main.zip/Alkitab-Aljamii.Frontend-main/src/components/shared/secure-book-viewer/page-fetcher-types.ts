import type { SecureChapterContent, PageContent } from '@/types';

export interface UsePageFetcherOptions {
  /** Book ID */
  bookId: string;
  /** Chapter ID */
  chapterId: string;
  /** Use professor API endpoints (for professors viewing their books) */
  useProfessorApi?: boolean;
  /** Skip fetching (for local mode where content is provided directly) */
  skip?: boolean;
  /** Callback when initial content is loaded */
  onInitialLoad?: (data: SecureChapterContent) => void;
  /** Callback when a page is loaded */
  onPageLoad?: (data: PageContent) => void;
  /** Callback on error */
  onError?: (error: Error) => void;
  /** Callback for security incidents */
  onSecurityIncident?: (type: string, details?: Record<string, unknown>) => void;
}

export interface UsePageFetcherReturn {
  /** Current page content HTML */
  content: string;
  /** Current page number (1-indexed) */
  currentPage: number;
  /** Total pages */
  totalPages: number;
  /** Whether pagination is enabled */
  hasPagination: boolean;
  /** Chapter title */
  title: string;
  /** Loading state */
  isLoading: boolean;
  /** Error state */
  error: Error | null;
  /** Whether error is due to rate limiting */
  isRateLimited: boolean;
  /** Whether initial load is complete */
  isInitialized: boolean;
  /** Go to next page */
  nextPage: () => Promise<void>;
  /** Go to previous page */
  previousPage: () => Promise<void>;
  /** Go to specific page */
  goToPage: (page: number) => Promise<void>;
  /** Refresh current page */
  refresh: () => Promise<void>;
  /** Check if can go next */
  hasNext: boolean;
  /** Check if can go previous */
  hasPrevious: boolean;
  /** Time until token expires */
  tokenExpiresIn: number;
}

// Helper to detect rate limit errors
export function isRateLimitError(error: unknown): boolean {
  if (error && typeof error === 'object') {
    const axiosError = error as { response?: { status?: number } };
    if (axiosError.response?.status === 429) return true;
    const errorWithMessage = error as { message?: string };
    if (errorWithMessage.message?.includes('429') ||
        errorWithMessage.message?.toLowerCase().includes('rate limit') ||
        errorWithMessage.message?.toLowerCase().includes('too many requests')) {
      return true;
    }
  }
  return false;
}
