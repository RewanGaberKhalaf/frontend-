'use client';

import { useTranslations } from 'next-intl';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface DevToolsBlockedProps {
  className?: string;
}

export function DevToolsBlocked({ className }: DevToolsBlockedProps) {
  const t = useTranslations('security');

  return (
    <div className={cn('flex flex-col h-full bg-muted/30 items-center justify-center', className)}>
      <div className="text-center p-8 max-w-md">
        <AlertTriangle className="h-16 w-16 text-destructive mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">{t('devToolsBlocked.title')}</h2>
        <p className="text-muted-foreground mb-4">
          {t('devToolsBlocked.description')}
        </p>
        <p className="text-sm text-muted-foreground">
          {t('devToolsBlocked.instructions')}
        </p>
        <Button
          className="mt-4"
          onClick={() => window.location.reload()}
        >
          {t('devToolsBlocked.refresh')}
        </Button>
      </div>
    </div>
  );
}
