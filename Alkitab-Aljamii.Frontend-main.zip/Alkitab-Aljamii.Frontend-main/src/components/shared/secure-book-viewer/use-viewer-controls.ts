"use client";

import { useState, useCallback, useEffect, useRef, useMemo } from "react";
import { A4_WIDTH_PX, A4_HEIGHT_PX } from "@/lib/constants/page-dimensions";

interface UseViewerControlsOptions {
  containerRef: React.RefObject<HTMLDivElement | null>;
}

export function useViewerControls({ containerRef }: UseViewerControlsOptions) {
  const [zoom, setZoom] = useState(1.0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [containerWidth, setContainerWidth] = useState(0);
  const [containerHeight, setContainerHeight] = useState(0);
  const lastDimensionsRef = useRef({ width: 0, height: 0 });

  // Container dimension observer
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) {
        const newWidth = Math.round(entry.contentRect.width);
        const newHeight = Math.round(entry.contentRect.height);
        const widthDiff = Math.abs(newWidth - lastDimensionsRef.current.width);
        const heightDiff = Math.abs(newHeight - lastDimensionsRef.current.height);

        if (widthDiff > 5 || heightDiff > 5) {
          lastDimensionsRef.current = { width: newWidth, height: newHeight };
          setContainerWidth(newWidth);
          setContainerHeight(newHeight);
        }
      }
    });

    observer.observe(container);
    return () => observer.disconnect();
  }, [containerRef]);

  // Zoom controls
  const adjustZoom = useCallback((delta: number) => {
    setZoom((prev) => Math.max(0.5, Math.min(2, prev + delta)));
  }, []);

  // Fullscreen controls
  const toggleFullscreen = useCallback(async () => {
    const container = containerRef.current;
    if (!container) return;

    try {
      if (!document.fullscreenElement) {
        await container.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      setIsFullscreen((prev) => !prev);
    }
  }, [containerRef]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  // Calculate base scale
  const baseScale = useMemo(() => {
    if (!containerWidth || !containerHeight) {
      const fallbackWidth = typeof window !== "undefined" ? window.innerWidth : 800;
      return Math.min((fallbackWidth / A4_WIDTH_PX) * 0.9, 1);
    }

    const isMobile = containerWidth < 640;
    const horizontalPadding = isMobile ? 16 : 32;
    const verticalPadding = isMobile ? 16 : 32;
    const toolbarHeight = 48;
    const availableWidth = containerWidth - horizontalPadding;
    const availableHeight = containerHeight - toolbarHeight - verticalPadding;

    const widthScale = availableWidth / A4_WIDTH_PX;
    const heightScale = availableHeight / A4_HEIGHT_PX;

    return Math.min(widthScale, heightScale, 1);
  }, [containerWidth, containerHeight]);

  const effectiveZoom = baseScale * zoom;

  return {
    zoom,
    isFullscreen,
    containerWidth,
    containerHeight,
    effectiveZoom,
    adjustZoom,
    toggleFullscreen,
    setIsFullscreen,
  };
}
