"use client";

import { useState, useCallback, useRef } from "react";
import type { TextSelectionData, Annotation, CreateAnnotationDto } from "@/types";
import type { SelectionRange } from "@/components/annotations";

interface UseViewerAnnotationsOptions {
  bookId?: string;
  chapterId?: string;
  currentPage: number;
  onAnnotationCreate?: (data: CreateAnnotationDto) => Promise<void>;
  onAnnotationClick?: (annotation: Annotation) => void;
}

interface CustomSelectionRef {
  activateWithRects: (text: string, rects: DOMRect[]) => void;
  clearSelection: () => void;
}

export function useViewerAnnotations({
  bookId,
  chapterId,
  currentPage,
  onAnnotationCreate,
  onAnnotationClick,
}: UseViewerAnnotationsOptions) {
  const [textSelection, setTextSelection] = useState<TextSelectionData | null>(null);
  const [isCreatingAnnotation, setIsCreatingAnnotation] = useState(false);
  const [selectedAnnotationId, setSelectedAnnotationId] = useState<string | null>(null);
  const customSelectionRef = useRef<CustomSelectionRef | null>(null);

  const handleTextSelection = useCallback(
    (selection: TextSelectionData | null, customSelection?: CustomSelectionRef) => {
      setTextSelection(selection);
      if (customSelection) {
        customSelectionRef.current = customSelection;
        if (selection && selection.selectedText) {
          customSelection.activateWithRects(selection.selectedText, selection.rects || []);
        } else {
          customSelection.clearSelection();
        }
      }
    },
    []
  );

  const handleCreateHighlight = useCallback(
    async (
      color: string,
      text: string,
      range: SelectionRange,
      note?: string,
      notifyStudents?: boolean
    ) => {
      if (!onAnnotationCreate || !bookId) return;
      const selectedText = range.selectedText || textSelection?.selectedText || text;

      setIsCreatingAnnotation(true);
      try {
        await onAnnotationCreate({
          bookId,
          chapterId: chapterId || undefined,
          type: "text_highlight",
          content: note,
          textAnchor: {
            nodePath: textSelection?.nodePath || "",
            startOffset: textSelection?.startOffset || 0,
            endOffset: textSelection?.endOffset || 0,
            selectedText,
            prefixContext: textSelection?.prefixContext || "",
            suffixContext: textSelection?.suffixContext || "",
          },
          highlightColor: color,
          pageNumber: currentPage,
          notifyStudents: notifyStudents ?? false,
        });
        setTextSelection(null);
        customSelectionRef.current?.clearSelection();
        window.getSelection()?.removeAllRanges();
      } finally {
        setIsCreatingAnnotation(false);
      }
    },
    [textSelection, onAnnotationCreate, bookId, chapterId, currentPage]
  );

  const handleCreateBookmark = useCallback(
    async (text: string, range: SelectionRange, note?: string) => {
      if (!onAnnotationCreate || !bookId) return;
      const selectedText = range.selectedText || textSelection?.selectedText || text;

      setIsCreatingAnnotation(true);
      try {
        await onAnnotationCreate({
          bookId,
          chapterId: chapterId || undefined,
          type: "bookmark",
          content: note,
          textAnchor: {
            nodePath: textSelection?.nodePath || "",
            startOffset: textSelection?.startOffset || 0,
            endOffset: textSelection?.endOffset || 0,
            selectedText,
            prefixContext: textSelection?.prefixContext || "",
            suffixContext: textSelection?.suffixContext || "",
          },
          pageNumber: currentPage,
          visibility: "private",
        });
        setTextSelection(null);
        customSelectionRef.current?.clearSelection();
        window.getSelection()?.removeAllRanges();
      } finally {
        setIsCreatingAnnotation(false);
      }
    },
    [textSelection, onAnnotationCreate, bookId, chapterId, currentPage]
  );

  const handleClosePopover = useCallback(() => {
    setTextSelection(null);
    customSelectionRef.current?.clearSelection();
    window.getSelection()?.removeAllRanges();
  }, []);

  const handleAnnotationHighlightClick = useCallback(
    (annotation: Annotation) => {
      setSelectedAnnotationId(annotation.id);
      onAnnotationClick?.(annotation);
    },
    [onAnnotationClick]
  );

  return {
    textSelection,
    isCreatingAnnotation,
    selectedAnnotationId,
    setCustomSelectionRef: (ref: CustomSelectionRef) => {
      customSelectionRef.current = ref;
    },
    handleTextSelection,
    handleCreateHighlight,
    handleCreateBookmark,
    handleClosePopover,
    handleAnnotationHighlightClick,
  };
}
