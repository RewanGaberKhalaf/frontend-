'use client';

import { useRef, useEffect } from 'react';
import { WatermarkOverlay } from '@/components/shared/pdf-viewer/protection';
import { TextSelectionHandler, HighlightRenderer } from '@/components/annotations';
import { renderMathInContainer } from '@/hooks/use-math-renderer';
import 'katex/dist/katex.min.css';
import {
  A4_WIDTH_PX,
  A4_HEIGHT_PX,
  PAGE_MARGIN,
  HEADER_HEIGHT,
  FOOTER_HEIGHT,
} from '@/lib/constants/page-dimensions';
import type { ViewerPageProps } from './types';

export function ViewerPage({
  effectiveZoom,
  currentTitle,
  effectiveCurrentPage,
  totalPages,
  currentPageContent,
  showWatermark,
  watermarkText,
  showPageNumbers,
  enableProtection,
  enableAnnotations,
  annotations,
  focusedAnnotationId,
  currentUserId,
  highlightsVisible,
  showAllHighlights,
  contentRef,
  getContentHeight,
  onTextSelection,
  onAnnotationHighlightClick,
  selectedAnnotationId,
  onBeforeClear,
}: ViewerPageProps) {
  const mathContentRef = useRef<HTMLDivElement>(null);

  // Render math formulas after content changes
  // Use a small delay to ensure DOM is fully updated after dangerouslySetInnerHTML
  useEffect(() => {
    if (!mathContentRef.current) return;

    const timeoutId = setTimeout(() => {
      if (mathContentRef.current) {
        renderMathInContainer(mathContentRef.current);
      }
    }, 10);

    return () => clearTimeout(timeoutId);
  }, [currentPageContent]);

  return (
    <div className="flex-1 overflow-auto p-2 sm:p-4">
      {/* Centering wrapper - min-height ensures vertical centering works */}
      <div
        className="flex items-center justify-center"
        style={{
          minHeight: '100%',
          minWidth: '100%',
        }}
      >
        {/* Scaled page container */}
        <div
          className="relative overflow-hidden shrink-0"
          style={{
            width: Math.round(A4_WIDTH_PX * effectiveZoom),
            height: Math.round(A4_HEIGHT_PX * effectiveZoom),
          }}
        >
          {/* Actual page - scaled down from top-left corner */}
          <div
            className="absolute top-0 left-0 bg-white dark:bg-zinc-900 shadow-xl"
            style={{
              width: A4_WIDTH_PX,
              height: A4_HEIGHT_PX,
              transform: `scale(${effectiveZoom})`,
              transformOrigin: 'top left',
            }}
          >
            {/* Watermark */}
            {showWatermark && watermarkText && (
              <WatermarkOverlay watermark={watermarkText} />
            )}

            {/* Page content */}
            <div
              className="absolute inset-0 flex flex-col"
              style={{ padding: PAGE_MARGIN }}
            >
              {/* Header */}
              {showPageNumbers && (
                <div
                  className="flex items-center justify-between text-xs text-muted-foreground border-b pb-2 mb-4 shrink-0 select-none"
                  style={{ height: HEADER_HEIGHT - 16 }}
                >
                  <span>{currentTitle}</span>
                  <span></span>
                  <span>Page {effectiveCurrentPage}</span>
                </div>
              )}

              {/* Content */}
              <TextSelectionHandler onSelection={onTextSelection} onBeforeClear={onBeforeClear}>
                <div
                  ref={contentRef}
                  className="ProseMirror chapter-content prose prose-sm dark:prose-invert max-w-none flex-1 overflow-y-auto overflow-x-hidden relative"
                  style={{
                    maxHeight: getContentHeight(),
                    fontSize: '11pt',
                    lineHeight: 1.6,
                    // Allow text selection when annotations enabled for highlighting
                    // But TextSelectionHandler manages the actual selection behavior
                    ...(enableProtection && !enableAnnotations && {
                      WebkitUserSelect: 'none',
                      MozUserSelect: 'none',
                      msUserSelect: 'none',
                      userSelect: 'none',
                      WebkitTouchCallout: 'none',
                    }),
                  }}
                >
                  {/* Actual content */}
                  <div
                    ref={mathContentRef}
                    dangerouslySetInnerHTML={{ __html: currentPageContent }}
                  />

                  {/* Highlight overlays */}
                  {enableAnnotations && (annotations.length > 0 || focusedAnnotationId) && (
                    <HighlightRenderer
                      annotations={annotations}
                      containerRef={contentRef as React.RefObject<HTMLElement>}
                      onHighlightClick={onAnnotationHighlightClick}
                      selectedAnnotationId={selectedAnnotationId}
                      focusedAnnotationId={focusedAnnotationId}
                      currentUserId={currentUserId}
                      showOwnHighlights={showAllHighlights ? false : highlightsVisible}
                      showAllHighlights={showAllHighlights ? highlightsVisible : false}
                      currentPage={effectiveCurrentPage}
                    />
                  )}
                </div>
              </TextSelectionHandler>

              {/* Footer */}
              {showPageNumbers && (
                <div
                  className="flex items-center justify-center text-xs text-muted-foreground border-t pt-2 mt-auto shrink-0 select-none"
                  style={{ height: FOOTER_HEIGHT - 16 }}
                >
                  <span>{effectiveCurrentPage} of {totalPages}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
