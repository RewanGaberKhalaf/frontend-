"use client";

import { useState, useCallback, useEffect, useRef } from "react";

interface UseViewerNavigationOptions {
  totalPages: number;
  isServerMode: boolean;
  serverPageFetcher?: {
    currentPage: number;
    isLoading: boolean;
    hasPrevious: boolean;
    hasNext: boolean;
    previousPage: () => Promise<void>;
    nextPage: () => Promise<void>;
    goToPage: (page: number) => void;
  };
  targetPage?: number;
  onPageChange?: (page: number) => void;
  toggleFullscreen?: () => void;
  adjustZoom?: (delta: number) => void;
  isFullscreen?: boolean;
}

export function useViewerNavigation({
  totalPages,
  isServerMode,
  serverPageFetcher,
  targetPage,
  onPageChange,
  toggleFullscreen,
  adjustZoom,
  isFullscreen,
}: UseViewerNavigationOptions) {
  const [currentPage, setCurrentPage] = useState(1);
  const touchStartX = useRef<number | null>(null);
  const touchStartSelectionText = useRef<string>("");
  const onPageChangeRef = useRef(onPageChange);
  onPageChangeRef.current = onPageChange;

  const effectiveCurrentPage = isServerMode ? (serverPageFetcher?.currentPage ?? 1) : currentPage;
  const canGoPrevious = isServerMode ? (serverPageFetcher?.hasPrevious ?? false) : effectiveCurrentPage > 1;
  const canGoNext = isServerMode ? (serverPageFetcher?.hasNext ?? false) : effectiveCurrentPage < totalPages;
  const isLoading = isServerMode ? (serverPageFetcher?.isLoading ?? false) : false;

  // Handle target page navigation
  useEffect(() => {
    if (targetPage && targetPage !== effectiveCurrentPage && targetPage >= 1 && targetPage <= totalPages) {
      if (isServerMode && serverPageFetcher) {
        serverPageFetcher.goToPage(targetPage);
      } else {
        setCurrentPage(targetPage);
      }
    }
  }, [targetPage, isServerMode, serverPageFetcher, effectiveCurrentPage, totalPages]);

  // Notify page changes
  useEffect(() => {
    onPageChangeRef.current?.(effectiveCurrentPage);
  }, [effectiveCurrentPage]);

  // Page navigation handlers
  const handlePreviousPage = useCallback(async () => {
    if (isServerMode && serverPageFetcher) {
      await serverPageFetcher.previousPage();
    } else {
      setCurrentPage((p) => Math.max(1, p - 1));
    }
  }, [isServerMode, serverPageFetcher]);

  const handleNextPage = useCallback(async () => {
    if (isServerMode && serverPageFetcher) {
      await serverPageFetcher.nextPage();
    } else {
      setCurrentPage((p) => Math.min(totalPages, p + 1));
    }
  }, [isServerMode, serverPageFetcher, totalPages]);

  // Touch handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const selection = window.getSelection();
    const selectionText = selection?.toString() || "";
    touchStartSelectionText.current = selectionText;

    if (selectionText.length > 0) {
      touchStartX.current = null;
      return;
    }
    touchStartX.current = e.touches[0]?.clientX ?? null;
  }, []);

  const handleTouchEnd = useCallback(
    (e: React.TouchEvent) => {
      const selection = window.getSelection();
      const selectionText = selection?.toString() || "";

      if (selectionText.length > 0 || selectionText !== touchStartSelectionText.current) {
        touchStartX.current = null;
        touchStartSelectionText.current = "";
        return;
      }

      if (touchStartX.current === null) {
        touchStartSelectionText.current = "";
        return;
      }

      const touch = e.changedTouches[0];
      if (!touch) {
        touchStartX.current = null;
        touchStartSelectionText.current = "";
        return;
      }

      const diff = touchStartX.current - touch.clientX;
      if (Math.abs(diff) > 50) {
        if (diff > 0) handleNextPage();
        else handlePreviousPage();
      }
      touchStartX.current = null;
      touchStartSelectionText.current = "";
    },
    [handleNextPage, handlePreviousPage]
  );

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      switch (e.key) {
        case "f":
        case "F":
          if (!e.ctrlKey && !e.metaKey && toggleFullscreen) {
            e.preventDefault();
            toggleFullscreen();
          }
          break;
        case "ArrowLeft":
          if (canGoPrevious && !isLoading) {
            e.preventDefault();
            handlePreviousPage();
          }
          break;
        case "ArrowRight":
          if (canGoNext && !isLoading) {
            e.preventDefault();
            handleNextPage();
          }
          break;
        case "+":
        case "=":
          if ((e.ctrlKey || e.metaKey) && adjustZoom) {
            e.preventDefault();
            adjustZoom(0.1);
          }
          break;
        case "-":
          if ((e.ctrlKey || e.metaKey) && adjustZoom) {
            e.preventDefault();
            adjustZoom(-0.1);
          }
          break;
        case "Escape":
          if (isFullscreen && toggleFullscreen) {
            toggleFullscreen();
          }
          break;
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [
    toggleFullscreen,
    canGoPrevious,
    canGoNext,
    isLoading,
    handlePreviousPage,
    handleNextPage,
    adjustZoom,
    isFullscreen,
  ]);

  return {
    currentPage,
    setCurrentPage,
    effectiveCurrentPage,
    canGoPrevious,
    canGoNext,
    isLoading,
    handlePreviousPage,
    handleNextPage,
    handleTouchStart,
    handleTouchEnd,
  };
}
