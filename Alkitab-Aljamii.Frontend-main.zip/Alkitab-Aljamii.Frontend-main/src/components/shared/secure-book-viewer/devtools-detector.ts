'use client';

/**
 * DevTools Detector Module
 *
 * Uses multiple detection methods to identify when DevTools are opened:
 * 1. Debugger timing: The `debugger` statement takes >100ms when DevTools is open
 * 2. Console property access: Getter on object passed to console.log is triggered when DevTools inspects it
 * 3. Window size difference: DevTools docked takes screen space (outerWidth - innerWidth > threshold)
 *
 * Note: These are deterrents, not foolproof security measures. Determined users can bypass them.
 * The goal is to add friction and discourage casual copying.
 */

export type DevToolsDetectionMethod = 'debugger' | 'console' | 'size' | 'unknown';

export interface DevToolsDetectionResult {
  isOpen: boolean;
  method: DevToolsDetectionMethod;
  timestamp: Date;
}

export interface DevToolsDetectorOptions {
  /** Callback when DevTools is detected as open */
  onDetected?: (result: DevToolsDetectionResult) => void;
  /** Callback when DevTools is detected as closed */
  onClosed?: () => void;
  /** Check interval in milliseconds (default: 1000) */
  checkInterval?: number;
  /** Threshold for size detection in pixels (default: 160) */
  sizeThreshold?: number;
  /** Enable debugger detection (can be annoying, default: false) */
  useDebugger?: boolean;
  /** Enable console detection (default: true) */
  useConsole?: boolean;
  /** Enable size detection (default: true) */
  useSize?: boolean;
}

class DevToolsDetector {
  private intervalId: ReturnType<typeof setInterval> | null = null;
  private isOpen = false;
  private options: Required<DevToolsDetectorOptions>;
  private consoleCheckElement: unknown = null;
  // Require consecutive detections to avoid false positives
  private consecutiveDetections = 0;
  private readonly requiredConsecutiveDetections = 2;

  constructor(options: DevToolsDetectorOptions = {}) {
    this.options = {
      onDetected: options.onDetected || (() => {}),
      onClosed: options.onClosed || (() => {}),
      checkInterval: options.checkInterval || 1000,
      // Increased threshold - browser chrome can easily be 100-200px
      // DevTools typically adds 300-500px when docked
      sizeThreshold: options.sizeThreshold || 300,
      useDebugger: options.useDebugger ?? false,
      useConsole: options.useConsole ?? true,
      // Disable size detection by default - too many false positives
      useSize: options.useSize ?? false,
    };
  }

  /**
   * Start monitoring for DevTools
   */
  start(): void {
    if (this.intervalId) return;

    // Initial check
    this.check();

    // Periodic checks
    this.intervalId = setInterval(() => {
      this.check();
    }, this.options.checkInterval);

    // Listen for resize events (DevTools docking/undocking)
    if (typeof window !== 'undefined') {
      window.addEventListener('resize', this.handleResize);
    }
  }

  /**
   * Stop monitoring for DevTools
   */
  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    if (typeof window !== 'undefined') {
      window.removeEventListener('resize', this.handleResize);
    }
  }

  /**
   * Check if DevTools is currently open
   */
  check(): DevToolsDetectionResult {
    let detected = false;
    let method: DevToolsDetectionMethod = 'unknown';

    // Method 1: Window size detection (most reliable for docked DevTools)
    if (this.options.useSize && this.checkSize()) {
      detected = true;
      method = 'size';
    }

    // Method 2: Console detection
    if (!detected && this.options.useConsole && this.checkConsole()) {
      detected = true;
      method = 'console';
    }

    // Method 3: Debugger timing (optional, can be intrusive)
    if (!detected && this.options.useDebugger && this.checkDebugger()) {
      detected = true;
      method = 'debugger';
    }

    // Require consecutive detections to avoid false positives
    if (detected) {
      this.consecutiveDetections++;
    } else {
      this.consecutiveDetections = 0;
    }

    // Only consider DevTools open after consecutive detections
    const confirmedDetection = this.consecutiveDetections >= this.requiredConsecutiveDetections;

    const result: DevToolsDetectionResult = {
      isOpen: confirmedDetection,
      method: confirmedDetection ? method : 'unknown',
      timestamp: new Date(),
    };

    // State change handling
    if (confirmedDetection && !this.isOpen) {
      this.isOpen = true;
      this.options.onDetected(result);
    } else if (!confirmedDetection && this.isOpen) {
      this.isOpen = false;
      this.options.onClosed();
    }

    return result;
  }

  /**
   * Check using window size difference
   * When DevTools is docked, there's a significant difference between outer and inner dimensions
   */
  private checkSize(): boolean {
    if (typeof window === 'undefined') return false;

    const widthThreshold = window.outerWidth - window.innerWidth > this.options.sizeThreshold;
    const heightThreshold = window.outerHeight - window.innerHeight > this.options.sizeThreshold;

    // Account for browser chrome (toolbars, etc.) - typically 100-150px height
    // Only flag as open if the difference is unusually large
    return widthThreshold || heightThreshold;
  }

  /**
   * Check using console logging behavior
   * When DevTools is open and console panel is active, accessing properties triggers getters
   * Note: This method is not 100% reliable and can have false positives/negatives
   */
  private checkConsole(): boolean {
    if (typeof window === 'undefined') return false;

    let devtoolsOpen = false;

    // Create an object with a getter that will be triggered when DevTools inspects it
    const checkObject = Object.create(null);
    Object.defineProperty(checkObject, 'id', {
      get: function () {
        devtoolsOpen = true;
        return 'check';
      },
      configurable: true,
    });

    // Store reference to prevent garbage collection
    this.consoleCheckElement = checkObject;

    // Temporarily suppress console output
    const originalLog = console.log;
    try {
      // Only check if console.log is the native function (not wrapped by dev tools extensions)
      if (originalLog.toString().includes('[native code]')) {
        console.log(checkObject);
        // Clear the logged object to avoid memory buildup
        console.clear?.();
      }
    } catch {
      // Ignore errors
    }

    return devtoolsOpen;
  }

  /**
   * Check using debugger timing
   * The debugger statement pauses execution only when DevTools is open
   */
  private checkDebugger(): boolean {
    if (typeof window === 'undefined') return false;

    const startTime = performance.now();

    // This will pause if DevTools is open
    // eslint-disable-next-line no-debugger
    debugger;

    const endTime = performance.now();

    // If DevTools is open, this takes >100ms due to debugger pause
    return endTime - startTime > 100;
  }

  private handleResize = (): void => {
    // Debounce resize checks
    setTimeout(() => {
      this.check();
    }, 100);
  };

  /**
   * Get current detection state
   */
  getState(): boolean {
    return this.isOpen;
  }
}

/**
 * Create and return a DevTools detector instance
 */
export function createDevToolsDetector(options?: DevToolsDetectorOptions): DevToolsDetector {
  return new DevToolsDetector(options);
}

/**
 * Block common DevTools keyboard shortcuts
 */
export function blockDevToolsShortcuts(): () => void {
  if (typeof window === 'undefined') return () => {};

  const handleKeyDown = (e: KeyboardEvent): void => {
    // F12
    if (e.key === 'F12') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    // Ctrl/Cmd + Shift + I (DevTools)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'i') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    // Ctrl/Cmd + Shift + J (Console)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'j') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    // Ctrl/Cmd + Shift + C (Inspect element)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'c') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    // Ctrl/Cmd + U (View source)
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'u') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    // Ctrl/Cmd + Shift + K (Firefox console)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
  };

  document.addEventListener('keydown', handleKeyDown, { capture: true });

  return () => {
    document.removeEventListener('keydown', handleKeyDown, { capture: true });
  };
}

export default DevToolsDetector;
