'use client';

import { useState, useMemo } from 'react';
import { Filter, X, Check, Search } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

export interface FilterOption {
  value: string;
  label: string;
}

export interface FilterConfig {
  key: string;
  label: string;
  options: FilterOption[];
  multiSelect?: boolean;
}

export interface FilterValues {
  [key: string]: string | string[] | undefined;
}

interface TableFiltersProps {
  filters: FilterConfig[];
  values: FilterValues;
  onChange: (key: string, value: string | string[] | undefined) => void;
  onClear?: () => void;
}

export function TableFilters({ filters, values, onChange, onClear }: TableFiltersProps) {
  const t = useTranslations();
  const [open, setOpen] = useState(false);
  const [searchTerms, setSearchTerms] = useState<Record<string, string>>({});
  // Local state for pending changes
  const [localValues, setLocalValues] = useState<FilterValues>(values);

  // Sync local values when dialog opens
  const handleOpen = (isOpen: boolean) => {
    if (isOpen) {
      setLocalValues(values);
      setSearchTerms({});
    }
    setOpen(isOpen);
  };

  // Count active filters
  const activeFilterCount = useMemo(() => {
    return Object.entries(values).filter(([, value]) => {
      if (Array.isArray(value)) return value.length > 0;
      return value !== undefined && value !== '';
    }).length;
  }, [values]);

  const handleSingleSelect = (key: string, value: string) => {
    const currentValue = localValues[key];
    setLocalValues((prev) => ({
      ...prev,
      [key]: currentValue === value ? undefined : value,
    }));
  };

  const handleMultiSelect = (key: string, value: string) => {
    const currentValues = (localValues[key] as string[]) || [];
    if (currentValues.includes(value)) {
      const newValues = currentValues.filter((v) => v !== value);
      setLocalValues((prev) => ({
        ...prev,
        [key]: newValues.length > 0 ? newValues : undefined,
      }));
    } else {
      setLocalValues((prev) => ({
        ...prev,
        [key]: [...currentValues, value],
      }));
    }
  };

  const isSelected = (key: string, value: string, multiSelect?: boolean) => {
    if (multiSelect) {
      const currentValues = (localValues[key] as string[]) || [];
      return currentValues.includes(value);
    }
    return localValues[key] === value;
  };

  const getFilteredOptions = (filter: FilterConfig) => {
    const searchTerm = searchTerms[filter.key]?.toLowerCase() || '';
    if (!searchTerm) return filter.options;
    return filter.options.filter((option) =>
      option.label.toLowerCase().includes(searchTerm)
    );
  };

  const handleApply = () => {
    // Apply all local changes
    for (const filter of filters) {
      onChange(filter.key, localValues[filter.key]);
    }
    setOpen(false);
  };

  const handleClearAll = () => {
    const cleared: FilterValues = {};
    for (const filter of filters) {
      cleared[filter.key] = undefined;
    }
    setLocalValues(cleared);
  };

  const handleReset = () => {
    handleClearAll();
    onClear?.();
    setOpen(false);
  };

  const getSelectedCount = (filter: FilterConfig): number => {
    const value = localValues[filter.key];
    if (!value) return 0;
    if (Array.isArray(value)) return value.length;
    return 1;
  };

  return (
    <>
      <Button variant="outline" className="gap-2" onClick={() => handleOpen(true)}>
        <Filter className="h-4 w-4" />
        {t('common.filters')}
        {activeFilterCount > 0 && (
          <Badge variant="secondary" className="ml-1 px-1.5 py-0.5 text-xs">
            {activeFilterCount}
          </Badge>
        )}
      </Button>

      <Dialog open={open} onOpenChange={handleOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              {t('common.filters')}
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-1 gap-6 py-4 sm:grid-cols-2">
            {filters.map((filter) => (
              <div key={filter.key} className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">{filter.label}</Label>
                  {getSelectedCount(filter) > 0 && (
                    <Badge variant="secondary" className="text-xs">
                      {getSelectedCount(filter)} {t('common.selected')}
                    </Badge>
                  )}
                </div>

                {/* Search within filter options if more than 6 */}
                {filter.options.length > 6 && (
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder={t('common.searchOptions')}
                      value={searchTerms[filter.key] || ''}
                      onChange={(e) =>
                        setSearchTerms((prev) => ({
                          ...prev,
                          [filter.key]: e.target.value,
                        }))
                      }
                      className="h-8 pl-8 text-sm"
                    />
                  </div>
                )}

                <ScrollArea className={cn(
                  "rounded-md border",
                  filter.options.length > 6 ? "h-40" : "h-auto max-h-40"
                )}>
                  <div className="p-2 space-y-1">
                    {getFilteredOptions(filter).map((option) => {
                      const selected = isSelected(filter.key, option.value, filter.multiSelect);

                      if (filter.multiSelect) {
                        return (
                          <div
                            key={option.value}
                            className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-muted"
                          >
                            <Checkbox
                              id={`${filter.key}-${option.value}`}
                              checked={selected}
                              onCheckedChange={() =>
                                handleMultiSelect(filter.key, option.value)
                              }
                            />
                            <Label
                              htmlFor={`${filter.key}-${option.value}`}
                              className="flex-1 cursor-pointer text-sm font-normal"
                            >
                              {option.label}
                            </Label>
                          </div>
                        );
                      }

                      return (
                        <button
                          key={option.value}
                          onClick={() => handleSingleSelect(filter.key, option.value)}
                          className={cn(
                            'flex w-full items-center justify-between rounded-md px-2 py-1.5 text-sm transition-colors text-start',
                            selected
                              ? 'bg-primary/10 text-primary'
                              : 'hover:bg-muted'
                          )}
                        >
                          <span>{option.label}</span>
                          {selected && <Check className="h-4 w-4 shrink-0" />}
                        </button>
                      );
                    })}

                    {getFilteredOptions(filter).length === 0 && (
                      <p className="py-4 text-center text-sm text-muted-foreground">
                        {t('common.noResults')}
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </div>
            ))}
          </div>

          <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
            <Button
              variant="ghost"
              onClick={handleReset}
              className="text-muted-foreground"
            >
              {t('common.clearAll')}
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setOpen(false)}>
                {t('common.cancel')}
              </Button>
              <Button onClick={handleApply}>
                {t('common.apply')}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Active filter badges component
interface ActiveFiltersProps {
  filters: FilterConfig[];
  values: FilterValues;
  onChange: (key: string, value: string | string[] | undefined) => void;
  onClearAll?: () => void;
}

export function ActiveFilters({ filters, values, onChange, onClearAll }: ActiveFiltersProps) {
  const t = useTranslations();

  // Group active filters by key
  const groupedFilters = useMemo(() => {
    const groups: { key: string; label: string; values: { value: string; valueLabel: string }[] }[] = [];

    for (const filter of filters) {
      const value = values[filter.key];
      if (!value) continue;

      const filterValues: { value: string; valueLabel: string }[] = [];

      if (Array.isArray(value)) {
        for (const v of value) {
          const option = filter.options.find((o) => o.value === v);
          if (option) {
            filterValues.push({ value: v, valueLabel: option.label });
          }
        }
      } else {
        const option = filter.options.find((o) => o.value === value);
        if (option) {
          filterValues.push({ value, valueLabel: option.label });
        }
      }

      if (filterValues.length > 0) {
        groups.push({
          key: filter.key,
          label: filter.label,
          values: filterValues,
        });
      }
    }

    return groups;
  }, [filters, values]);

  const totalFilterCount = groupedFilters.reduce((acc, g) => acc + g.values.length, 0);

  const handleRemove = (key: string, value: string) => {
    const filter = filters.find((f) => f.key === key);
    if (!filter) return;

    if (filter.multiSelect) {
      const currentValues = (values[key] as string[]) || [];
      const newValues = currentValues.filter((v) => v !== value);
      onChange(key, newValues.length > 0 ? newValues : undefined);
    } else {
      onChange(key, undefined);
    }
  };

  const handleClearGroup = (key: string) => {
    onChange(key, undefined);
  };

  if (groupedFilters.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-3">
      {groupedFilters.map((group) => (
        <div key={group.key} className="flex items-center gap-1.5">
          <span className="text-sm text-muted-foreground">{group.label}:</span>
          <div className="flex flex-wrap items-center gap-1">
            {group.values.map((item) => (
              <Badge
                key={`${group.key}-${item.value}`}
                variant="secondary"
                className="gap-1 pe-1"
              >
                <span>{item.valueLabel}</span>
                <button
                  onClick={() => handleRemove(group.key, item.value)}
                  className="rounded-full p-0.5 hover:bg-muted"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
            {group.values.length > 1 && (
              <button
                onClick={() => handleClearGroup(group.key)}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>
      ))}
      {totalFilterCount > 1 && onClearAll && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearAll}
          className="h-6 px-2 text-xs text-muted-foreground hover:text-foreground"
        >
          {t('common.clearAll')}
        </Button>
      )}
    </div>
  );
}
