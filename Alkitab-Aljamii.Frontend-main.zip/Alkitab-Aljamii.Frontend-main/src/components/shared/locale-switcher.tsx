'use client';

import { useRouter } from 'next/navigation';
import { Languages } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useLocaleStore } from '@/stores/locale-store';
import { locales, localeNames, type Locale } from '@/i18n/config';

export function LocaleSwitcher() {
  const t = useTranslations();
  const router = useRouter();
  const { locale, setLocale } = useLocaleStore();

  const handleLocaleChange = (newLocale: Locale) => {
    setLocale(newLocale);
    router.refresh();
  };

  return (
    <Tooltip>
      <DropdownMenu>
        <TooltipTrigger asChild>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label={t('common.switchLanguage')}>
              <Languages className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
        </TooltipTrigger>
        <DropdownMenuContent align="end">
          {locales.map((loc) => (
            <DropdownMenuItem
              key={loc}
              onClick={() => handleLocaleChange(loc)}
              className={locale === loc ? 'bg-accent' : ''}
            >
              {localeNames[loc]}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
      <TooltipContent>{t('tooltips.header.switchLanguage')}</TooltipContent>
    </Tooltip>
  );
}
