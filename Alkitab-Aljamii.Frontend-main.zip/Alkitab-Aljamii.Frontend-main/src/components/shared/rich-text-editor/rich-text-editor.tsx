"use client";

import { useEditor, EditorContent, type Editor } from "@tiptap/react";
import { useEffect, useMemo, useImperativeHandle, forwardRef, useRef, useCallback } from "react";
import * as Y from "yjs";
import { getEditorExtensions, type EditorExtensionOptions } from "./extensions";
import { EditorToolbar } from "./editor-toolbar";
import { cn } from "@/lib/utils";

// Debounce delay for content updates (ms)
const UPDATE_DEBOUNCE_MS = 150;

export interface RichTextEditorProps {
  /** Initial HTML content */
  content?: string;
  /** Called when content changes with HTML output */
  onUpdate?: (html: string) => void;
  /** Called with full output including HTML, JSON, and Yjs state */
  onUpdateFull?: (output: EditorOutput) => void;
  /** Placeholder text */
  placeholder?: string;
  /** Whether the editor is editable */
  editable?: boolean;
  /** CSS class for the editor container */
  className?: string;
  /** CSS class for the editor content area */
  contentClassName?: string;
  /** Show/hide the toolbar */
  showToolbar?: boolean;
  /** Extension options */
  extensionOptions?: EditorExtensionOptions;
  /** External Yjs document (for collaborative editing) */
  ydoc?: Y.Doc;
  /** Fragment name in the Yjs document */
  fragmentName?: string;
  /** Minimum height of the editor */
  minHeight?: string;
  /** Enable visual page breaks (Google Docs style) - legacy decoration approach */
  enablePageBreaks?: boolean;
  /** Enable page nodes (each page is a styled container div) */
  enablePageNodes?: boolean;
  /** Called when page count changes */
  onPageCountChange?: (count: number) => void;
  /** Disable default padding (for custom containers) */
  noPadding?: boolean;
  /** Enable Yjs collaboration (default: false for better performance when not collaborating) */
  enableCollaboration?: boolean;
}

/** Ref handle for accessing the editor instance */
export interface RichTextEditorRef {
  /** The Tiptap editor instance */
  editor: Editor | null;
  /** The Yjs document */
  ydoc: Y.Doc;
  /** The Yjs XmlFragment used for content */
  yXmlFragment: Y.XmlFragment;
}

export interface EditorOutput {
  /** HTML representation of the content */
  html: string;
  /** JSON representation (ProseMirror document) */
  json: Record<string, unknown>;
  /** Plain text content */
  text: string;
  /** Yjs document state as Uint8Array (base64 encoded for storage) */
  ydocState: string;
  /** Human-readable Yjs XML structure */
  yjsStructure: YjsNode[];
  /** Character count */
  characterCount: number;
  /** Word count */
  wordCount: number;
}

export interface YjsNode {
  type: string;
  attributes?: Record<string, unknown>;
  text?: string;
  children?: YjsNode[];
}

export const RichTextEditor = forwardRef<RichTextEditorRef, RichTextEditorProps>(
  function RichTextEditor(
    {
      content = "",
      onUpdate,
      onUpdateFull,
      placeholder = "Start writing...",
      editable = true,
      className,
      contentClassName,
      showToolbar = true,
      extensionOptions = {},
      ydoc: externalYdoc,
      fragmentName = "prosemirror",
      minHeight = "200px",
      enablePageBreaks = false,
      enablePageNodes = false,
      onPageCountChange,
      noPadding = false,
      enableCollaboration = false,
    },
    ref
  ) {
    // Only create Yjs document if collaboration is enabled or external ydoc is provided
    const shouldUseYjs = enableCollaboration || !!externalYdoc;

    // Create or use external Yjs document (only when needed)
    const ydoc = useMemo(() => {
      if (!shouldUseYjs) return new Y.Doc(); // Minimal doc for ref compatibility
      return externalYdoc || new Y.Doc();
    }, [externalYdoc, shouldUseYjs]);

    // Get the XML fragment for ProseMirror content (only when Yjs is enabled)
    const yXmlFragment = useMemo(
      () => ydoc.getXmlFragment(fragmentName),
      [ydoc, fragmentName]
    );

    // Get extensions with merged options - only pass yFragment if collaboration is enabled
    const extensions = useMemo(() => {
      return getEditorExtensions({
        placeholder,
        ...extensionOptions,
        yFragment: shouldUseYjs ? yXmlFragment : undefined,
        enablePageBreaks,
        enablePageNodes,
        onPageCountChange,
      });
    }, [placeholder, extensionOptions, yXmlFragment, enablePageBreaks, enablePageNodes, onPageCountChange, shouldUseYjs]);

    // Debounced update refs
    const updateTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    // Lightweight change notification - no getHTML() call
    // Just signals that content has changed
    const notifyChange = useCallback(() => {
      // Skip entirely if no callbacks registered
      if (!onUpdate && !onUpdateFull) return;

      // Clear existing timer
      if (updateTimerRef.current) {
        clearTimeout(updateTimerRef.current);
      }

      // Schedule the actual content extraction
      updateTimerRef.current = setTimeout(() => {
        // Get editor from the closure - need to use a ref pattern
        // For now, signal with empty string - actual content can be extracted from editor ref
        onUpdate?.("");
      }, UPDATE_DEBOUNCE_MS);
    }, [onUpdate, onUpdateFull]);

    // Initialize editor
    // Note: When using Collaboration extension, content comes from Yjs, not the content prop
    // The content prop is only used for initial content when the Yjs doc is empty
    const editor = useEditor({
      extensions,
      // Don't set content here - it conflicts with Collaboration extension
      // Initial content will be set via useEffect below
      editable,
      immediatelyRender: false, // Required for SSR/Next.js to avoid hydration mismatches
      editorProps: {
        attributes: {
          class: cn(
            // Only use prose classes when NOT in paginated mode (paginated uses Word-like CSS)
            !enablePageBreaks && !enablePageNodes && "prose prose-sm sm:prose dark:prose-invert",
            "max-w-none",
            "focus:outline-none",
            !enablePageBreaks && !enablePageNodes && "min-h-[200px]",
            !enablePageBreaks && !enablePageNodes && !noPadding && "p-4",
            "[&_.is-editor-empty:first-child]:before:content-[attr(data-placeholder)]",
            "[&_.is-editor-empty:first-child]:before:text-muted-foreground",
            "[&_.is-editor-empty:first-child]:before:float-left",
            "[&_.is-editor-empty:first-child]:before:h-0",
            "[&_.is-editor-empty:first-child]:before:pointer-events-none"
          ),
          style: enablePageNodes ? "" : `min-height: ${minHeight}`,
        },
      },
      onUpdate: () => {
        notifyChange();
      },
    });

    // Cleanup timer on unmount
    useEffect(() => {
      return () => {
        if (updateTimerRef.current) {
          clearTimeout(updateTimerRef.current);
        }
      };
    }, []);

    // Set initial content when editor is ready
    // Use a ref to track if we've already initialized to prevent loops
    const hasInitialized = useRef(false);

    useEffect(() => {
      if (!editor || hasInitialized.current) return;

      // When Yjs is enabled, only set content if fragment is empty
      // When Yjs is disabled, always set content on first render
      const shouldSetContent = shouldUseYjs ? yXmlFragment.length === 0 : true;

      if (shouldSetContent) {
        hasInitialized.current = true;
        // When page nodes are enabled, wrap content in a page div
        if (enablePageNodes) {
          const wrappedContent = content
            ? `<div data-page="true">${content}</div>`
            : `<div data-page="true"><p></p></div>`;
          editor.commands.setContent(wrappedContent);
        } else if (content) {
          // Insert initial content into the editor
          editor.commands.setContent(content);
        }
      }
    }, [editor, content, yXmlFragment.length, enablePageNodes, shouldUseYjs]);

    // Cleanup
    useEffect(() => {
      return () => {
        if (!externalYdoc) {
          ydoc.destroy();
        }
      };
    }, [ydoc, externalYdoc]);

    // Expose editor instance via ref
    useImperativeHandle(
      ref,
      () => ({
        editor,
        ydoc,
        yXmlFragment,
      }),
      [editor, ydoc, yXmlFragment]
    );

    return (
      <div className={cn("rounded-md border", className)}>
        {showToolbar && (
          <EditorToolbar
            editor={editor}
            enableTable={extensionOptions.enableTable !== false}
            enableCodeBlock={extensionOptions.enableCodeBlock !== false}
            enableMedia={false}
          />
        )}
        <EditorContent
          editor={editor}
          className={cn(
            "overflow-auto",
            "[&_.ProseMirror]:outline-none",
            contentClassName
          )}
        />
      </div>
    );
  }
);

// Re-export utilities and hook
export { useEditorOutput, getEditorOutput, stripPageWrappers, getYjsStructure, xmlElementToNode } from "./rich-text-editor-utils";

// Export for standalone usage
export { getEditorExtensions } from "./extensions";
export type { EditorExtensionOptions } from "./extensions";
