"use client";

import { useState, useCallback, useMemo } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Video,
  Music,
  Upload,
  Search,
  Check,
  Loader2,
  FileIcon,
  Grid,
  List,
} from "lucide-react";
import {
  MediaGridItem,
  MediaListItem,
  generateId,
  fileToBase64,
  formatFileSize,
} from "./media-library-items";

/**
 * Media item stored in the library
 */
export interface MediaItem {
  id: string;
  name: string;
  type: "image" | "video" | "audio";
  url: string;
  thumbnailUrl?: string;
  size: number;
  mimeType: string;
  createdAt: Date;
  /** Optional tags for organization */
  tags?: string[];
}

export interface MediaLibraryProps {
  /** Whether the dialog is open */
  open: boolean;
  /** Called when dialog should close */
  onOpenChange: (open: boolean) => void;
  /** Current media items in library */
  items: MediaItem[];
  /** Called when items change (upload, delete) */
  onItemsChange: (items: MediaItem[]) => void;
  /** Called when user selects an item */
  onSelect: (item: MediaItem) => void;
  /** Filter by media type */
  filterType?: "image" | "video" | "audio" | "all";
  /** Upload handler - receives file and returns URL */
  onUpload?: (file: File) => Promise<string>;
  /** Whether uploading is in progress */
  isUploading?: boolean;
  /** Title for the dialog */
  title?: string;
}

export function MediaLibrary({
  open,
  onOpenChange,
  items,
  onItemsChange,
  onSelect,
  filterType = "all",
  onUpload,
  isUploading: externalIsUploading,
  title = "Media Library",
}: MediaLibraryProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeTab, setActiveTab] = useState<"library" | "upload">("library");
  const [isUploading, setIsUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const uploading = externalIsUploading || isUploading;

  // Filter items based on search and type
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Type filter
      if (filterType !== "all" && item.type !== filterType) return false;

      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          item.name.toLowerCase().includes(query) ||
          item.tags?.some((tag) => tag.toLowerCase().includes(query))
        );
      }

      return true;
    });
  }, [items, filterType, searchQuery]);

  // Group by type for display
  const groupedItems = useMemo(() => {
    const groups: { image: MediaItem[]; video: MediaItem[]; audio: MediaItem[] } = {
      image: [],
      video: [],
      audio: [],
    };

    filteredItems.forEach((item) => {
      groups[item.type].push(item);
    });

    return groups;
  }, [filteredItems]);

  // Handle file upload
  const handleUpload = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;

      setIsUploading(true);

      try {
        const newItems: MediaItem[] = [];

        for (const file of Array.from(files)) {
          // Determine type
          let type: MediaItem["type"] = "image";
          if (file.type.startsWith("video/")) type = "video";
          else if (file.type.startsWith("audio/")) type = "audio";
          else if (!file.type.startsWith("image/")) continue; // Skip unsupported

          let url: string;

          if (onUpload) {
            // Use external upload handler
            url = await onUpload(file);
          } else {
            // Fallback to base64 (for demo/local use)
            url = await fileToBase64(file);
          }

          const newItem: MediaItem = {
            id: generateId(),
            name: file.name,
            type,
            url,
            thumbnailUrl: type === "image" ? url : undefined,
            size: file.size,
            mimeType: file.type,
            createdAt: new Date(),
          };

          newItems.push(newItem);
        }

        onItemsChange([...newItems, ...items]);
        setActiveTab("library");
      } catch (error) {
        console.error("Upload failed:", error);
      } finally {
        setIsUploading(false);
      }
    },
    [items, onItemsChange, onUpload]
  );

  // Handle drag and drop
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      handleUpload(e.dataTransfer.files);
    },
    [handleUpload]
  );

  // Delete item
  const handleDelete = useCallback(
    (id: string) => {
      onItemsChange(items.filter((item) => item.id !== id));
      if (selectedId === id) setSelectedId(null);
    },
    [items, onItemsChange, selectedId]
  );

  // Select and insert
  const handleSelect = useCallback(() => {
    const item = items.find((i) => i.id === selectedId);
    if (item) {
      onSelect(item);
      onOpenChange(false);
      setSelectedId(null);
    }
  }, [items, selectedId, onSelect, onOpenChange]);

  const selectedItem = items.find((i) => i.id === selectedId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[80vh] flex flex-col p-0">
        <DialogHeader className="px-6 py-4 border-b shrink-0">
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        <Tabs
          value={activeTab}
          onValueChange={(v) => setActiveTab(v as "library" | "upload")}
          className="flex-1 flex flex-col min-h-0"
        >
          <div className="px-6 pt-2 shrink-0">
            <TabsList>
              <TabsTrigger value="library">Library</TabsTrigger>
              <TabsTrigger value="upload">Upload</TabsTrigger>
            </TabsList>
          </div>

          {/* Library Tab */}
          <TabsContent value="library" className="flex-1 flex flex-col min-h-0 mt-0 px-6 pb-4">
            {/* Search & View Toggle */}
            <div className="flex items-center gap-4 py-4 shrink-0">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search media..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <div className="flex items-center border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-8 px-2"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-8 px-2"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Media Grid/List */}
            <ScrollArea className="flex-1">
              {filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <FileIcon className="h-12 w-12 mb-4 opacity-50" />
                  <p>No media found</p>
                  <Button
                    variant="link"
                    onClick={() => setActiveTab("upload")}
                    className="mt-2"
                  >
                    Upload some files
                  </Button>
                </div>
              ) : viewMode === "grid" ? (
                <div className="grid grid-cols-4 gap-4">
                  {filteredItems.map((item) => (
                    <MediaGridItem
                      key={item.id}
                      item={item}
                      isSelected={selectedId === item.id}
                      onSelect={() => setSelectedId(item.id)}
                      onDelete={() => handleDelete(item.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredItems.map((item) => (
                    <MediaListItem
                      key={item.id}
                      item={item}
                      isSelected={selectedId === item.id}
                      onSelect={() => setSelectedId(item.id)}
                      onDelete={() => handleDelete(item.id)}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>

            {/* Selection Footer */}
            {selectedItem && (
              <div className="pt-4 border-t mt-4 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded bg-muted flex items-center justify-center overflow-hidden">
                    {selectedItem.type === "image" ? (
                      <img
                        src={selectedItem.url}
                        alt={selectedItem.name}
                        className="h-full w-full object-cover"
                      />
                    ) : selectedItem.type === "video" ? (
                      <Video className="h-6 w-6 text-muted-foreground" />
                    ) : (
                      <Music className="h-6 w-6 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{selectedItem.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(selectedItem.size)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" onClick={() => setSelectedId(null)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSelect}>
                    <Check className="h-4 w-4 mr-1" />
                    Insert
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Upload Tab */}
          <TabsContent value="upload" className="flex-1 px-6 pb-6 mt-0">
            <div
              className={cn(
                "h-full border-2 border-dashed rounded-lg flex flex-col items-center justify-center transition-colors",
                dragOver
                  ? "border-primary bg-primary/5"
                  : "border-muted-foreground/25 hover:border-muted-foreground/50",
                uploading && "opacity-50 pointer-events-none"
              )}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
            >
              {uploading ? (
                <>
                  <Loader2 className="h-12 w-12 mb-4 text-muted-foreground animate-spin" />
                  <p className="text-muted-foreground">Uploading...</p>
                </>
              ) : (
                <>
                  <Upload className="h-12 w-12 mb-4 text-muted-foreground" />
                  <p className="text-lg font-medium mb-2">
                    Drop files here or click to browse
                  </p>
                  <p className="text-sm text-muted-foreground mb-4">
                    Supports images, videos, and audio files
                  </p>
                  <input
                    type="file"
                    multiple
                    accept="image/*,video/*,audio/*"
                    className="hidden"
                    id="media-upload-input"
                    onChange={(e) => handleUpload(e.target.files)}
                  />
                  <Button asChild>
                    <label htmlFor="media-upload-input" className="cursor-pointer">
                      Browse Files
                    </label>
                  </Button>
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export default MediaLibrary;
