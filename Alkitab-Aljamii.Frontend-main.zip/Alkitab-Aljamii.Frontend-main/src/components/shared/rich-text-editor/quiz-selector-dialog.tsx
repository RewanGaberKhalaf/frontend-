"use client";

import { useState, useCallback, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Search,
  ClipboardList,
  Clock,
  Target,
  HelpCircle,
  BookOpen,
  Layers,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { quizApi, type Quiz, type QuestionBank } from "@/lib/api";
import type { QuizBlockAttributes } from "./quiz-extension";

interface QuizSelectorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (quiz: QuizBlockAttributes) => void;
  chapterId?: string; // If provided, shows chapter quiz option
}

export function QuizSelectorDialog({
  open,
  onOpenChange,
  onSelect,
  chapterId,
}: QuizSelectorDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedBankId, setSelectedBankId] = useState<string>("all");
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(false);
  const [banksLoading, setBanksLoading] = useState(false);
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [isChapterQuiz, setIsChapterQuiz] = useState(false);

  // Load question banks
  useEffect(() => {
    if (!open) return;

    const loadBanks = async () => {
      setBanksLoading(true);
      try {
        const response = await quizApi.getQuestionBanks({ limit: 100, isActive: true });
        setBanks(response.items);
      } catch (error) {
        console.error("Failed to load question banks:", error);
      } finally {
        setBanksLoading(false);
      }
    };

    loadBanks();
  }, [open]);

  // Load quizzes based on filters
  useEffect(() => {
    if (!open) return;

    const loadQuizzes = async () => {
      setLoading(true);
      try {
        const params: { search?: string; bankId?: string; isActive: boolean } = {
          isActive: true,
        };

        if (searchQuery) {
          params.search = searchQuery;
        }

        if (selectedBankId && selectedBankId !== "all") {
          params.bankId = selectedBankId;
        }

        const response = await quizApi.getQuizzes(params);
        setQuizzes(response.items);
      } catch (error) {
        console.error("Failed to load quizzes:", error);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(loadQuizzes, 300);
    return () => clearTimeout(debounce);
  }, [open, searchQuery, selectedBankId]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setSearchQuery("");
      setSelectedBankId("all");
      setSelectedQuiz(null);
      setIsChapterQuiz(false);
    }
  }, [open]);

  const handleSelect = useCallback(() => {
    if (!selectedQuiz) return;

    const quizAttrs: QuizBlockAttributes = {
      quizId: selectedQuiz.id,
      quizTitle: selectedQuiz.title,
      quizTitleAr: selectedQuiz.titleAr,
      questionCount: selectedQuiz.totalQuestions,
      passingScore: selectedQuiz.passingScore,
      timeLimit: selectedQuiz.timeLimit,
      isChapterQuiz: isChapterQuiz && !!chapterId,
      chapterId: isChapterQuiz ? chapterId : null,
    };

    onSelect(quizAttrs);
    onOpenChange(false);
  }, [selectedQuiz, isChapterQuiz, chapterId, onSelect, onOpenChange]);

  const formatTime = (minutes: number | null) => {
    if (!minutes) return "No limit";
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
    }
    return `${minutes} min`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardList className="h-5 w-5" />
            Insert Quiz
          </DialogTitle>
          <DialogDescription>
            Select a quiz to embed in your chapter content
          </DialogDescription>
        </DialogHeader>

        {/* Filters */}
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search quizzes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={selectedBankId} onValueChange={setSelectedBankId}>
            <SelectTrigger className="w-[200px]">
              <Layers className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Question Bank" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Banks</SelectItem>
              {banksLoading ? (
                <SelectItem value="loading" disabled>
                  Loading...
                </SelectItem>
              ) : (
                banks.map((bank) => (
                  <SelectItem key={bank.id} value={bank.id}>
                    {bank.name}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>

        {/* Quiz List */}
        <ScrollArea className="h-[350px] rounded-md border">
          {loading ? (
            <div className="space-y-3 p-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center gap-3">
                  <Skeleton className="h-12 w-12 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-3 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : quizzes.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center py-12 text-center">
              <ClipboardList className="h-12 w-12 text-muted-foreground/50" />
              <p className="mt-3 text-sm text-muted-foreground">
                No quizzes found
              </p>
              <p className="text-xs text-muted-foreground">
                Try adjusting your search or filter
              </p>
            </div>
          ) : (
            <div className="space-y-2 p-2">
              {quizzes.map((quiz) => (
                <button
                  key={quiz.id}
                  onClick={() => setSelectedQuiz(quiz)}
                  className={cn(
                    "w-full rounded-lg border p-3 text-left transition-all hover:border-primary/50 hover:bg-accent/50",
                    selectedQuiz?.id === quiz.id &&
                      "border-primary bg-primary/5 ring-1 ring-primary"
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <ClipboardList className="h-5 w-5" />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="truncate font-medium">{quiz.title}</h4>
                        {selectedQuiz?.id === quiz.id && (
                          <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
                        )}
                      </div>

                      {quiz.titleAr && (
                        <p
                          className="truncate text-sm text-muted-foreground"
                          dir="rtl"
                        >
                          {quiz.titleAr}
                        </p>
                      )}

                      <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <HelpCircle className="h-3 w-3" />
                          {quiz.totalQuestions} questions
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="h-3 w-3" />
                          {quiz.passingScore}%
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatTime(quiz.timeLimit)}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {quiz.bankName}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </ScrollArea>

        {/* Chapter Quiz Toggle (only if chapterId provided) */}
        {chapterId && selectedQuiz && (
          <div className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3 dark:border-amber-800 dark:bg-amber-950/30">
            <input
              type="checkbox"
              id="chapter-quiz"
              checked={isChapterQuiz}
              onChange={(e) => setIsChapterQuiz(e.target.checked)}
              className="h-4 w-4 rounded border-amber-300 text-amber-500 focus:ring-amber-500"
            />
            <label
              htmlFor="chapter-quiz"
              className="flex-1 cursor-pointer text-sm"
            >
              <span className="font-medium text-amber-700 dark:text-amber-400">
                Set as chapter quiz
              </span>
              <p className="text-xs text-amber-600 dark:text-amber-500">
                Students must pass this quiz to unlock the next chapter
              </p>
            </label>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSelect} disabled={!selectedQuiz}>
            Insert Quiz
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
