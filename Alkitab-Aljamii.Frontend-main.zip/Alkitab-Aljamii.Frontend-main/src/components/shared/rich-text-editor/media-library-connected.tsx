"use client";

import { useState, useCallback, useEffect, useMemo } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Video,
  Music,
  Upload,
  Search,
  Trash2,
  Check,
  Loader2,
  FileIcon,
  FileText,
  Grid,
  List,
  RefreshCw,
} from "lucide-react";
import { useMedia } from "@/hooks";
import { useAuthStore } from "@/stores/auth-store";
import { type MediaItem as ApiMediaItem, type MediaType, resolveMediaUrl } from "@/lib/api";
import {
  MediaGridItemConnected as MediaGridItem,
  MediaListItemConnected as MediaListItem,
  formatFileSize,
} from "./media-library-connected-items";

/**
 * Props for connected media library
 */
export interface MediaLibraryConnectedProps {
  /** Whether the dialog is open */
  open: boolean;
  /** Called when dialog should close */
  onOpenChange: (open: boolean) => void;
  /** Called when user selects an item */
  onSelect: (item: ApiMediaItem) => void;
  /** Filter by media type */
  filterType?: MediaType | "all";
  /** Restrict to only these media types (for TipTap editor: image, video, audio only) */
  allowedTypes?: MediaType[];
  /** Title for the dialog */
  title?: string;
}

/**
 * Media Library component connected to the backend API
 * Uses the useMedia hook for all operations
 */
// Default allowed types for TipTap editor (no documents)
const TIPTAP_ALLOWED_TYPES: MediaType[] = ["image", "video", "audio"];

export function MediaLibraryConnected({
  open,
  onOpenChange,
  onSelect,
  filterType: initialFilterType = "all",
  allowedTypes = TIPTAP_ALLOWED_TYPES,
  title = "Media Library",
}: MediaLibraryConnectedProps) {
  const {
    items,
    total,
    page,
    totalPages,
    isLoading,
    isUploading,
    filterType,
    searchQuery,
    fetchMedia,
    uploadMedia,
    deleteMedia,
    setFilterType,
    setSearchQuery,
    setPage,
  } = useMedia({ initialType: initialFilterType });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeTab, setActiveTab] = useState<"library" | "upload">("library");
  const [dragOver, setDragOver] = useState(false);
  const [localSearchQuery, setLocalSearchQuery] = useState("");

  // Get auth state to ensure we're authenticated before fetching
  const { isAuthenticated, isHydrated } = useAuthStore();

  // Filter items to only show allowed types
  const filteredItems = useMemo(() => {
    if (!items) return [];
    return items.filter((item) => allowedTypes.includes(item.type));
  }, [items, allowedTypes]);

  // Generate accept string for file input based on allowed types
  const acceptFileTypes = useMemo(() => {
    const mimeTypes: string[] = [];
    if (allowedTypes.includes("image")) mimeTypes.push("image/*");
    if (allowedTypes.includes("video")) mimeTypes.push("video/*");
    if (allowedTypes.includes("audio")) mimeTypes.push("audio/*");
    return mimeTypes.join(",");
  }, [allowedTypes]);

  // Helper to check if a file type is allowed
  const isFileTypeAllowed = useCallback((file: File): boolean => {
    if (file.type.startsWith("image/") && allowedTypes.includes("image")) return true;
    if (file.type.startsWith("video/") && allowedTypes.includes("video")) return true;
    if (file.type.startsWith("audio/") && allowedTypes.includes("audio")) return true;
    return false;
  }, [allowedTypes]);

  // Fetch media when dialog opens or filters change (only if authenticated)
  useEffect(() => {
    if (open && isHydrated && isAuthenticated) {
      fetchMedia();
    }
  }, [open, filterType, page, isHydrated, isAuthenticated]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (localSearchQuery !== searchQuery) {
        setSearchQuery(localSearchQuery);
        fetchMedia({ search: localSearchQuery, page: 1 });
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [localSearchQuery]);

  // Handle file upload - only upload allowed file types
  const handleUpload = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;

      const validFiles = Array.from(files).filter(isFileTypeAllowed);

      if (validFiles.length === 0) {
        // Could show a toast here, but files are already filtered by input
        return;
      }

      for (const file of validFiles) {
        await uploadMedia(file);
      }

      setActiveTab("library");
    },
    [uploadMedia, isFileTypeAllowed]
  );

  // Handle drag and drop
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      handleUpload(e.dataTransfer.files);
    },
    [handleUpload]
  );

  // Delete item
  const handleDelete = useCallback(
    async (id: string) => {
      await deleteMedia(id);
      if (selectedId === id) setSelectedId(null);
    },
    [deleteMedia, selectedId]
  );

  // Select and insert
  const handleSelect = useCallback(() => {
    const item = filteredItems?.find((i) => i.id === selectedId);
    if (item) {
      onSelect(item);
      onOpenChange(false);
      setSelectedId(null);
    }
  }, [filteredItems, selectedId, onSelect, onOpenChange]);

  const selectedItem = filteredItems?.find((i) => i.id === selectedId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="!max-w-5xl w-[90vw] max-h-[85vh] h-auto flex flex-col p-0 sm:!max-w-5xl">
        <DialogHeader className="px-6 py-3 border-b shrink-0">
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-lg font-semibold">{title}</span>
              {filteredItems.length > 0 && (
                <span className="text-sm font-normal text-muted-foreground">
                  ({filteredItems.length} items)
                </span>
              )}
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs
          value={activeTab}
          onValueChange={(v) => setActiveTab(v as "library" | "upload")}
          className="flex-1 flex flex-col min-h-0"
        >
          <div className="px-6 pt-3 shrink-0 flex items-center justify-between">
            <TabsList className="h-9">
              <TabsTrigger value="library" className="px-5 text-sm">Library</TabsTrigger>
              <TabsTrigger value="upload" className="px-5 text-sm">Upload</TabsTrigger>
            </TabsList>
          </div>

          {/* Library Tab */}
          <TabsContent value="library" className="flex-1 flex flex-col min-h-0 mt-0 px-6 pb-4">
            {/* Search & View Toggle */}
            <div className="flex items-center gap-4 py-4 shrink-0">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search media..."
                  value={localSearchQuery}
                  onChange={(e) => setLocalSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => fetchMedia()}
                disabled={isLoading}
              >
                <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
              </Button>
              <div className="flex items-center border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-8 px-2"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-8 px-2"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Media Grid/List */}
            <ScrollArea className="flex-1 min-h-[300px] max-h-[400px]">
              {isLoading && filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Loader2 className="h-8 w-8 mb-3 animate-spin" />
                  <p className="text-sm">Loading media...</p>
                </div>
              ) : filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <FileIcon className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No media found</p>
                  <p className="text-sm mt-1">Upload images, videos, or audio to get started</p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab("upload")}
                    className="mt-3"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Upload
                  </Button>
                </div>
              ) : viewMode === "grid" ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                  {filteredItems.map((item) => (
                    <MediaGridItem
                      key={item.id}
                      item={item}
                      isSelected={selectedId === item.id}
                      onSelect={() => setSelectedId(item.id)}
                      onDelete={() => handleDelete(item.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="space-y-1">
                  {filteredItems.map((item) => (
                    <MediaListItem
                      key={item.id}
                      item={item}
                      isSelected={selectedId === item.id}
                      onSelect={() => setSelectedId(item.id)}
                      onDelete={() => handleDelete(item.id)}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 pt-4 border-t mt-4 shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page <= 1}
                  onClick={() => {
                    setPage(page - 1);
                    fetchMedia({ page: page - 1 });
                  }}
                >
                  Previous
                </Button>
                <span className="text-sm text-muted-foreground">
                  Page {page} of {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page >= totalPages}
                  onClick={() => {
                    setPage(page + 1);
                    fetchMedia({ page: page + 1 });
                  }}
                >
                  Next
                </Button>
              </div>
            )}

            {/* Selection Footer */}
            {selectedItem && (
              <div className="pt-3 border-t mt-3 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                    {selectedItem.type === "image" ? (
                      <img
                        src={resolveMediaUrl(selectedItem.url)}
                        alt={selectedItem.name}
                        className="h-full w-full object-cover"
                      />
                    ) : selectedItem.type === "video" ? (
                      <Video className="h-5 w-5 text-muted-foreground" />
                    ) : selectedItem.type === "document" ? (
                      <FileText className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <Music className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{selectedItem.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(selectedItem.size)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setSelectedId(null)}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSelect}>
                    <Check className="h-4 w-4 mr-1" />
                    Insert
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Upload Tab */}
          <TabsContent value="upload" className="flex-1 px-6 pb-4 mt-0 min-h-[300px]">
            <div
              className={cn(
                "h-full min-h-[280px] border-2 border-dashed rounded-lg flex flex-col items-center justify-center transition-all",
                dragOver
                  ? "border-primary bg-primary/5"
                  : "border-muted-foreground/20 hover:border-muted-foreground/40",
                isUploading && "opacity-50 pointer-events-none"
              )}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
            >
              {isUploading ? (
                <div className="text-center">
                  <Loader2 className="h-10 w-10 text-primary animate-spin mx-auto mb-4" />
                  <p className="font-medium">Uploading...</p>
                </div>
              ) : (
                <div className="text-center">
                  <Upload className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium mb-1">
                    Drop files here
                  </p>
                  <p className="text-sm text-muted-foreground mb-4">
                    or click to browse
                  </p>
                  <input
                    type="file"
                    multiple
                    accept={acceptFileTypes}
                    className="hidden"
                    id="media-upload-input-connected"
                    onChange={(e) => handleUpload(e.target.files)}
                  />
                  <Button asChild>
                    <label htmlFor="media-upload-input-connected" className="cursor-pointer">
                      Browse Files
                    </label>
                  </Button>
                  <p className="text-xs text-muted-foreground mt-4">
                    Images (10MB) • Videos (100MB) • Audio (50MB)
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export default MediaLibraryConnected;
