import type { DocumentStructure } from "../types";

// A4 dimensions at 96 DPI (matching Microsoft Word defaults)
// A4 = 210mm × 297mm = 794px × 1123px
// Word default margins: 1 inch (96px) top/bottom, 1 inch (96px) left/right
export const A4_WIDTH_PX = 794;
export const A4_HEIGHT_PX = 1123;
export const PAGE_MARGIN = 96; // 1 inch all sides (matching Word default)
export const CONTENT_HEIGHT = A4_HEIGHT_PX - PAGE_MARGIN * 2; // 931px

export interface ChapterEditorProps {
  /** Initial document structure */
  document: DocumentStructure;
  /** Called when document changes */
  onDocumentChange?: (doc: DocumentStructure) => void;
  /** CSS class for the container */
  className?: string;
  /** Show visual page breaks in editor */
  showPageBreaks?: boolean;
  /** Enable auto-save to localStorage (requires document ID) */
  enableAutoSave?: boolean;
  /** Called when draft is auto-saved */
  onAutoSave?: (timestamp: Date) => void;
  /** Called when user discards all changes */
  onDiscardChanges?: () => void;
  /** Enable version history (default: true) */
  enableVersionHistory?: boolean;
}
