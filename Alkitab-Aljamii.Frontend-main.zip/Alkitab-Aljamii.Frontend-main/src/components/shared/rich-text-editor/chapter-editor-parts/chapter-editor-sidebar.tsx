"use client";

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Plus,
  ChevronDown,
  ChevronRight,
  Trash2,
  FileText,
  BookOpen,
  Pencil,
  Check,
  X,
  Cloud,
  CloudOff,
  History,
  Undo2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { DocumentStructure, Chapter } from "../types";
import type { DocumentVersion } from "../use-version-history";

interface ChapterEditorSidebarProps {
  document: DocumentStructure;
  activeChapterId: string;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
  editingChapterId: string | null;
  setEditingChapterId: (id: string | null) => void;
  editingTitle: string;
  setEditingTitle: (title: string) => void;
  chapterPageStarts: Record<string, number>;
  switchToChapter: (chapterId: string) => void;
  addChapter: () => void;
  deleteChapter: (chapterId: string) => void;
  startEditingTitle: (chapter: Chapter) => void;
  saveChapterTitle: () => void;
  // Auto-save state
  enableAutoSave: boolean;
  isSaving: boolean;
  autoSaveTime: Date | null;
  // Version history
  enableVersionHistory: boolean;
  versions: DocumentVersion[];
  handleRestoreVersion: (versionId: string) => void;
  // Discard changes
  hasChangesFromOriginal: boolean;
  setShowDiscardDialog: (show: boolean) => void;
}

export function ChapterEditorSidebar({
  document,
  activeChapterId,
  sidebarCollapsed,
  setSidebarCollapsed,
  editingChapterId,
  setEditingChapterId,
  editingTitle,
  setEditingTitle,
  chapterPageStarts,
  switchToChapter,
  addChapter,
  deleteChapter,
  startEditingTitle,
  saveChapterTitle,
  enableAutoSave,
  isSaving,
  autoSaveTime,
  enableVersionHistory,
  versions,
  handleRestoreVersion,
  hasChangesFromOriginal,
  setShowDiscardDialog,
}: ChapterEditorSidebarProps) {
  return (
    <div
      className={cn(
        "border-r bg-muted/30 flex flex-col transition-all duration-200",
        sidebarCollapsed ? "w-12" : "w-64"
      )}
    >
      {/* Sidebar Header */}
      <div className="p-3 border-b flex items-center justify-between">
        {!sidebarCollapsed && (
          <div className="flex items-center gap-2 min-w-0">
            <BookOpen className="h-4 w-4 shrink-0 text-muted-foreground" />
            <span className="font-medium text-sm truncate">{document.meta.title}</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="shrink-0"
        >
          {sidebarCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronDown className="h-4 w-4" />
          )}
        </Button>
      </div>

      {/* Chapter List */}
      {!sidebarCollapsed && (
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {document.chapters.map((chapter) => {
              const isActive = chapter.id === activeChapterId;
              const isEditing = chapter.id === editingChapterId;

              return (
                <div
                  key={chapter.id}
                  className={cn(
                    "group rounded-md transition-colors",
                    isActive ? "bg-primary/10" : "hover:bg-muted"
                  )}
                >
                  {isEditing ? (
                    <div className="flex items-center gap-1 p-2 min-w-0">
                      <input
                        type="text"
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") saveChapterTitle();
                          if (e.key === "Escape") setEditingChapterId(null);
                        }}
                        className="flex-1 text-sm px-2 py-1 rounded border bg-background min-w-0"
                        autoFocus
                      />
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        onClick={saveChapterTitle}
                        className="h-6 w-6 shrink-0"
                      >
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        onClick={() => setEditingChapterId(null)}
                        className="h-6 w-6 shrink-0"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <div
                      className="flex items-center gap-2 p-2 cursor-pointer min-w-0"
                      onClick={() => {
                        switchToChapter(chapter.id);
                        const el = window.document.getElementById(`chapter-${chapter.id}`);
                        el?.scrollIntoView({ behavior: "smooth", block: "start" });
                      }}
                    >
                      <FileText
                        className={cn(
                          "h-4 w-4 shrink-0",
                          isActive ? "text-primary" : "text-muted-foreground"
                        )}
                      />
                      <div className="flex-1 min-w-0 overflow-hidden">
                        <p className={cn("text-sm truncate", isActive && "font-medium")}>
                          {chapter.title}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {chapter.pages.length} page{chapter.pages.length !== 1 ? "s" : ""} •{" "}
                          {chapter.wordCount} words
                        </p>
                      </div>
                      <div className="flex items-center gap-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="icon-sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            startEditingTitle(chapter);
                          }}
                          className="h-6 w-6"
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                        {document.chapters.length > 1 && (
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteChapter(chapter.id);
                            }}
                            className="h-6 w-6 hover:text-destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </ScrollArea>
      )}

      {/* Add Chapter Button */}
      {!sidebarCollapsed && (
        <div className="p-2 border-t">
          <Button variant="outline" size="sm" onClick={addChapter} className="w-full gap-1">
            <Plus className="h-4 w-4" />
            Add Chapter
          </Button>
        </div>
      )}

      {/* Stats Footer with Auto-save Status */}
      {!sidebarCollapsed && (
        <SidebarFooter
          document={document}
          enableAutoSave={enableAutoSave}
          isSaving={isSaving}
          autoSaveTime={autoSaveTime}
          enableVersionHistory={enableVersionHistory}
          versions={versions}
          handleRestoreVersion={handleRestoreVersion}
          hasChangesFromOriginal={hasChangesFromOriginal}
          setShowDiscardDialog={setShowDiscardDialog}
        />
      )}
    </div>
  );
}

interface SidebarFooterProps {
  document: DocumentStructure;
  enableAutoSave: boolean;
  isSaving: boolean;
  autoSaveTime: Date | null;
  enableVersionHistory: boolean;
  versions: DocumentVersion[];
  handleRestoreVersion: (versionId: string) => void;
  hasChangesFromOriginal: boolean;
  setShowDiscardDialog: (show: boolean) => void;
}

function SidebarFooter({
  document,
  enableAutoSave,
  isSaving,
  autoSaveTime,
  enableVersionHistory,
  versions,
  handleRestoreVersion,
  hasChangesFromOriginal,
  setShowDiscardDialog,
}: SidebarFooterProps) {
  return (
    <div className="p-3 border-t bg-muted/50 text-xs text-muted-foreground">
      <div className="flex justify-between">
        <span>{document.chapters.length} chapters</span>
        <span>{document.totalPages} pages</span>
      </div>
      <div className="mt-1">{document.totalWords.toLocaleString()} words</div>
      {enableAutoSave && (
        <div className="mt-2 pt-2 border-t border-border/50 flex items-center gap-1.5">
          {isSaving ? (
            <>
              <CloudOff className="h-3 w-3 animate-pulse" />
              <span>Saving...</span>
            </>
          ) : autoSaveTime ? (
            <>
              <Cloud className="h-3 w-3 text-green-600" />
              <span>Saved {autoSaveTime.toLocaleTimeString()}</span>
            </>
          ) : (
            <>
              <CloudOff className="h-3 w-3" />
              <span>Not saved</span>
            </>
          )}
        </div>
      )}

      {/* Version History and Discard Actions */}
      <div className="mt-3 pt-2 border-t border-border/50 flex items-center gap-2">
        {/* Version History Dropdown */}
        {enableVersionHistory && versions.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs px-2">
                <History className="h-3 w-3" />
                History ({versions.length})
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              {versions.slice(0, 10).map((version, index) => (
                <DropdownMenuItem
                  key={version.id}
                  onClick={() => handleRestoreVersion(version.id)}
                  className="flex flex-col items-start gap-0.5"
                >
                  <div className="flex items-center gap-2 w-full">
                    <span className="font-medium">
                      {version.label || `Version ${versions.length - index}`}
                    </span>
                    <span className="text-muted-foreground ml-auto text-xs">
                      {version.wordCount} words
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {version.timestamp.toLocaleString()}
                  </span>
                </DropdownMenuItem>
              ))}
              {versions.length > 10 && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem disabled className="text-xs text-muted-foreground">
                    +{versions.length - 10} older versions
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {/* Discard Changes Button */}
        {hasChangesFromOriginal && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 gap-1 text-xs px-2 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={() => setShowDiscardDialog(true)}
          >
            <Undo2 className="h-3 w-3" />
            Discard
          </Button>
        )}
      </div>
    </div>
  );
}
