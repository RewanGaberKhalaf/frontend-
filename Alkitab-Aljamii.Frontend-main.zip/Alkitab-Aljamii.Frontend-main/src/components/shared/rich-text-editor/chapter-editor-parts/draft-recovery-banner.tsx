"use client";

import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DraftRecoveryBannerProps {
  onRecover: () => void;
  onDiscard: () => void;
}

export function DraftRecoveryBanner({ onRecover, onDiscard }: DraftRecoveryBannerProps) {
  return (
    <div className="bg-amber-50 dark:bg-amber-950/30 border-b border-amber-200 dark:border-amber-800 px-4 py-2 flex items-center justify-between">
      <div className="flex items-center gap-2 text-sm">
        <RotateCcw className="h-4 w-4 text-amber-600" />
        <span className="text-amber-800 dark:text-amber-200">
          Unsaved changes found from a previous session
        </span>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={onDiscard} className="h-7 text-xs">
          Discard
        </Button>
        <Button
          size="sm"
          onClick={onRecover}
          className="h-7 text-xs bg-amber-600 hover:bg-amber-700"
        >
          Recover
        </Button>
      </div>
    </div>
  );
}
