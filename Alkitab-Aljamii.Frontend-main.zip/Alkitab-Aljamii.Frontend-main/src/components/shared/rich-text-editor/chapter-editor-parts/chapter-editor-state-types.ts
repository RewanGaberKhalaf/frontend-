import type { Editor } from "@tiptap/react";
import type { DocumentStructure } from "../types";
import type { RichTextEditorRef } from "../rich-text-editor";

export interface UseChapterEditorStateOptions {
  initialDocument: DocumentStructure;
  onDocumentChange?: (doc: DocumentStructure) => void;
  enableAutoSave?: boolean;
  onAutoSave?: (timestamp: Date) => void;
  onDiscardChanges?: () => void;
  enableVersionHistory?: boolean;
}

export interface ChapterEditorRefs {
  editorRefsMap: React.MutableRefObject<Map<string, RichTextEditorRef>>;
  pendingContentRef: React.MutableRefObject<Map<string, { html: string; wordCount: number }>>;
  syncTimeoutRef: React.MutableRefObject<ReturnType<typeof setTimeout> | null>;
  originalDocumentRef: React.MutableRefObject<DocumentStructure>;
}

export interface ChapterEditorDialogState {
  showDraftRecovery: boolean;
  setShowDraftRecovery: (show: boolean) => void;
  showDiscardDialog: boolean;
  setShowDiscardDialog: (show: boolean) => void;
}

export interface ChapterEditorEditingState {
  editingChapterId: string | null;
  setEditingChapterId: (id: string | null) => void;
  editingTitle: string;
  setEditingTitle: (title: string) => void;
}

export interface ChapterEditorCoreState {
  document: DocumentStructure;
  setDocument: React.Dispatch<React.SetStateAction<DocumentStructure>>;
  activeChapterId: string;
  setActiveChapterId: (id: string) => void;
  activeEditor: Editor | null;
  setActiveEditor: (editor: Editor | null) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

export const SYNC_IDLE_DELAY = 2000;
