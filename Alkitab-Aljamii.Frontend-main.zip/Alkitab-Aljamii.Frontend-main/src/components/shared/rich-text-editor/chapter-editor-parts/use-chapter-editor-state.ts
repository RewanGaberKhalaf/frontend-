"use client";

import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import { useAutoSave } from "../use-auto-save";
import { useVersionHistory } from "../use-version-history";
import {
  type DocumentStructure,
  type Chapter,
  createChapter,
  calculateWordCount,
  updateDocumentTotals,
} from "../types";
import type { Editor } from "@tiptap/react";
import type { RichTextEditorRef } from "../rich-text-editor";
import { type UseChapterEditorStateOptions, SYNC_IDLE_DELAY } from "./chapter-editor-state-types";

// Re-export types for backwards compatibility
export type { UseChapterEditorStateOptions } from "./chapter-editor-state-types";

export function useChapterEditorState({
  initialDocument,
  onDocumentChange,
  enableAutoSave = true,
  onAutoSave,
  onDiscardChanges,
  enableVersionHistory = true,
}: UseChapterEditorStateOptions) {
  const [document, setDocument] = useState<DocumentStructure>(initialDocument);
  const [activeChapterId, setActiveChapterId] = useState<string>(
    initialDocument.chapters[0]?.id || ""
  );
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState("");
  const [showDraftRecovery, setShowDraftRecovery] = useState(false);
  const [activeEditor, setActiveEditor] = useState<Editor | null>(null);
  const [showDiscardDialog, setShowDiscardDialog] = useState(false);

  const originalDocumentRef = useRef<DocumentStructure>(initialDocument);
  const editorRefsMap = useRef<Map<string, RichTextEditorRef>>(new Map());
  const pendingContentRef = useRef<Map<string, { html: string; wordCount: number }>>(
    new Map()
  );
  const syncTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Sync pending content to document state
  const syncPendingContent = useCallback(() => {
    if (pendingContentRef.current.size === 0) return;

    setDocument((prev) => {
      let updated = { ...prev };
      let hasChanges = false;

      pendingContentRef.current.forEach((content, chapterId) => {
        updated = {
          ...updated,
          chapters: updated.chapters.map((ch) => {
            if (ch.id !== chapterId) return ch;
            hasChanges = true;

            const firstPage = ch.pages[0];
            const updatedPage = firstPage
              ? { ...firstPage, content: content.html, wordCount: content.wordCount }
              : {
                  id: `page-${ch.id}-0`,
                  order: 0,
                  content: content.html,
                  wordCount: content.wordCount,
                };

            return {
              ...ch,
              pages: [updatedPage],
              wordCount: content.wordCount,
              updatedAt: new Date(),
            };
          }),
        };
      });

      pendingContentRef.current.clear();
      return hasChanges ? updateDocumentTotals(updated) : prev;
    });
  }, []);

  // Auto-save the entire document as JSON
  const documentJson = useMemo(() => JSON.stringify(document), [document]);

  const {
    hasDraft,
    lastSaved: autoSaveTime,
    isSaving,
    loadDraft,
    clearDraft,
    getDraftInfo,
  } = useAutoSave(documentJson, {
    storageKey: `chapter-doc-${initialDocument.meta.id}`,
    debounceMs: 2000,
    onSave: onAutoSave,
  });

  // Version history for the document
  const {
    versions,
    saveVersion,
    restoreVersion,
    clearHistory: clearVersionHistory,
    hasUnsavedChanges,
    markDirty,
  } = useVersionHistory({
    storageKey: `chapter-versions-${initialDocument.meta.id}`,
    maxVersions: 20,
    minIntervalMs: 60000,
  });

  // Save initial version on mount
  useEffect(() => {
    if (enableVersionHistory && versions.length === 0) {
      saveVersion(documentJson, "Initial");
    }
  }, [enableVersionHistory, versions.length, saveVersion, documentJson]);

  // Mark as dirty when document changes
  useEffect(() => {
    if (enableVersionHistory && versions.length > 0) {
      markDirty();
    }
  }, [documentJson, enableVersionHistory, versions.length, markDirty]);

  // Check for draft on mount
  useEffect(() => {
    if (enableAutoSave && hasDraft) {
      const draftInfo = getDraftInfo();
      if (draftInfo) {
        const draftTime = draftInfo.savedAt.getTime();
        const docTime = initialDocument.meta.updatedAt.getTime();
        if (draftTime > docTime) {
          setShowDraftRecovery(true);
        }
      }
    }
  }, [enableAutoSave, hasDraft, getDraftInfo, initialDocument.meta.updatedAt]);

  // Recover draft
  const recoverDraft = useCallback(() => {
    const draftContent = loadDraft();
    if (draftContent) {
      try {
        const recoveredDoc: DocumentStructure = JSON.parse(draftContent);
        setDocument(recoveredDoc);
        setActiveChapterId(recoveredDoc.chapters[0]?.id || "");
        setShowDraftRecovery(false);
      } catch {
        clearDraft();
        setShowDraftRecovery(false);
      }
    }
  }, [loadDraft, clearDraft]);

  // Dismiss draft recovery
  const dismissDraftRecovery = useCallback(() => {
    clearDraft();
    setShowDraftRecovery(false);
  }, [clearDraft]);

  // Restore a specific version
  const handleRestoreVersion = useCallback(
    (versionId: string) => {
      const versionContent = restoreVersion(versionId);
      if (versionContent) {
        try {
          const restoredDoc: DocumentStructure = JSON.parse(versionContent);
          setDocument(restoredDoc);
          setActiveChapterId(restoredDoc.chapters[0]?.id || "");
          pendingContentRef.current.clear();
          restoredDoc.chapters.forEach((chapter) => {
            const ref = editorRefsMap.current.get(chapter.id);
            if (ref?.editor) {
              ref.editor.commands.setContent(chapter.pages[0]?.content || "");
            }
          });
        } catch {
          console.error("Failed to restore version");
        }
      }
    },
    [restoreVersion]
  );

  // Discard all changes
  const handleDiscardChanges = useCallback(() => {
    setDocument(originalDocumentRef.current);
    setActiveChapterId(originalDocumentRef.current.chapters[0]?.id || "");
    pendingContentRef.current.clear();
    clearDraft();

    originalDocumentRef.current.chapters.forEach((chapter) => {
      const ref = editorRefsMap.current.get(chapter.id);
      if (ref?.editor) {
        ref.editor.commands.setContent(chapter.pages[0]?.content || "");
      }
    });

    setShowDiscardDialog(false);
    onDiscardChanges?.();
  }, [clearDraft, onDiscardChanges]);

  // Check if there are any changes from the original
  const hasChangesFromOriginal = useMemo(() => {
    return JSON.stringify(document) !== JSON.stringify(originalDocumentRef.current);
  }, [document]);

  // Get active chapter
  const activeChapter = useMemo(
    () => document.chapters.find((ch) => ch.id === activeChapterId),
    [document.chapters, activeChapterId]
  );

  // Calculate cumulative page numbers for chapters
  const chapterPageStarts = useMemo(() => {
    const starts: Record<string, number> = {};
    let pageNum = 1;
    document.chapters.forEach((ch) => {
      starts[ch.id] = pageNum;
      pageNum += ch.pages.length;
    });
    return starts;
  }, [document.chapters]);

  // Extract content from editor and sync to state
  const extractAndSyncContent = useCallback(
    (chapterId: string) => {
      const ref = editorRefsMap.current.get(chapterId);
      if (!ref?.editor) return;

      const html = ref.editor.getHTML();
      const wordCount = calculateWordCount(html);
      pendingContentRef.current.set(chapterId, { html, wordCount });
      syncPendingContent();
    },
    [syncPendingContent]
  );

  // Schedule content extraction after idle period
  const scheduleContentSync = useCallback(() => {
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
    }

    syncTimeoutRef.current = setTimeout(() => {
      if (activeChapterId) {
        extractAndSyncContent(activeChapterId);
      }
    }, SYNC_IDLE_DELAY);
  }, [activeChapterId, extractAndSyncContent]);

  // Minimal onUpdate - just schedules content sync
  const handleChapterUpdate = useCallback(() => {
    scheduleContentSync();
  }, [scheduleContentSync]);

  // Cleanup sync timeout on unmount
  useEffect(() => {
    return () => {
      if (syncTimeoutRef.current) {
        clearTimeout(syncTimeoutRef.current);
      }
      if (activeChapterId) {
        extractAndSyncContent(activeChapterId);
      }
    };
  }, [activeChapterId, extractAndSyncContent]);

  // Notify parent of changes
  useEffect(() => {
    onDocumentChange?.(document);
  }, [document, onDocumentChange]);

  // Update active editor when chapter changes
  useEffect(() => {
    const ref = editorRefsMap.current.get(activeChapterId);
    if (ref?.editor) {
      setActiveEditor(ref.editor);
    }
  }, [activeChapterId]);

  // Switch to a different chapter
  const switchToChapter = useCallback(
    (chapterId: string) => {
      if (chapterId === activeChapterId) return;
      syncPendingContent();
      setActiveChapterId(chapterId);
    },
    [activeChapterId, syncPendingContent]
  );

  // Add new chapter
  const addChapter = useCallback(() => {
    syncPendingContent();
    const newChapter = createChapter(document.chapters.length);
    setDocument((prev) => ({
      ...prev,
      chapters: [...prev.chapters, newChapter],
    }));
    setActiveChapterId(newChapter.id);
  }, [document.chapters.length, syncPendingContent]);

  // Delete chapter
  const deleteChapter = useCallback(
    (chapterId: string) => {
      if (document.chapters.length <= 1) return;
      syncPendingContent();
      pendingContentRef.current.delete(chapterId);

      setDocument((prev) => {
        const filtered = prev.chapters
          .filter((ch) => ch.id !== chapterId)
          .map((ch, idx) => ({ ...ch, order: idx }));

        return updateDocumentTotals({
          ...prev,
          chapters: filtered,
        });
      });

      if (chapterId === activeChapterId) {
        const remaining = document.chapters.filter((ch) => ch.id !== chapterId);
        setActiveChapterId(remaining[0]?.id || "");
      }
    },
    [document.chapters, activeChapterId, syncPendingContent]
  );

  // Start editing chapter title
  const startEditingTitle = useCallback((chapter: Chapter) => {
    setEditingChapterId(chapter.id);
    setEditingTitle(chapter.title);
  }, []);

  // Save chapter title
  const saveChapterTitle = useCallback(() => {
    if (!editingChapterId || !editingTitle.trim()) {
      setEditingChapterId(null);
      return;
    }

    setDocument((prev) => ({
      ...prev,
      chapters: prev.chapters.map((ch) =>
        ch.id === editingChapterId
          ? { ...ch, title: editingTitle.trim(), updatedAt: new Date() }
          : ch
      ),
    }));
    setEditingChapterId(null);
  }, [editingChapterId, editingTitle]);

  return {
    document,
    activeChapterId,
    activeChapter,
    activeEditor,
    setActiveEditor,
    sidebarCollapsed,
    setSidebarCollapsed,
    editingChapterId,
    setEditingChapterId,
    editingTitle,
    setEditingTitle,
    showDraftRecovery,
    showDiscardDialog,
    setShowDiscardDialog,
    chapterPageStarts,
    hasChangesFromOriginal,
    editorRefsMap,
    // Auto-save state
    isSaving,
    autoSaveTime,
    // Version history
    versions,
    // Actions
    switchToChapter,
    addChapter,
    deleteChapter,
    startEditingTitle,
    saveChapterTitle,
    recoverDraft,
    dismissDraftRecovery,
    handleRestoreVersion,
    handleDiscardChanges,
    handleChapterUpdate,
    syncPendingContent,
  };
}
