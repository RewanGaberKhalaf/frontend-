"use client";

import { useCallback, useRef, useEffect } from "react";
import { RichTextEditor, type RichTextEditorRef } from "../rich-text-editor";
import { EditorToolbar } from "../editor-toolbar";
import { cn } from "@/lib/utils";
import { renderMathInContainer } from "@/hooks/use-math-renderer";
import "katex/dist/katex.min.css";
import type { DocumentStructure } from "../types";
import type { Editor } from "@tiptap/react";

interface ChapterEditorCanvasProps {
  document: DocumentStructure;
  activeChapterId: string;
  activeEditor: Editor | null;
  setActiveEditor: (editor: Editor | null) => void;
  showPageBreaks: boolean;
  chapterPageStarts: Record<string, number>;
  editorRefsMap: React.MutableRefObject<Map<string, RichTextEditorRef>>;
  handleChapterUpdate: () => void;
  switchToChapter: (chapterId: string) => void;
}

export function ChapterEditorCanvas({
  document,
  activeChapterId,
  activeEditor,
  setActiveEditor,
  showPageBreaks,
  chapterPageStarts,
  editorRefsMap,
  handleChapterUpdate,
  switchToChapter,
}: ChapterEditorCanvasProps) {
  const handlePageCountChange = useCallback(
    (count: number) => {
      // In the new structure, page count comes from pages.length
      // This is kept for compatibility
      console.log(`Page count changed to ${count} for chapter ${activeChapterId}`);
    },
    [activeChapterId]
  );

  const chaptersContainerRef = useRef<HTMLDivElement>(null);

  // Render math formulas in inactive chapters after content changes
  // Use a small delay to ensure DOM is fully updated
  useEffect(() => {
    if (!chaptersContainerRef.current) return;

    const timeoutId = setTimeout(() => {
      if (chaptersContainerRef.current) {
        renderMathInContainer(chaptersContainerRef.current);
      }
    }, 10);

    return () => clearTimeout(timeoutId);
  }, [document.chapters, activeChapterId]);

  return (
    <div className="flex-1 flex flex-col min-w-0">
      {/* Sticky Toolbar - connected to the active editor */}
      <div className="sticky top-0 z-20 bg-background border-b shadow-sm">
        <EditorToolbar
          editor={activeEditor}
          enableTable={true}
          enableCodeBlock={true}
          enableMedia={false}
        />
      </div>

      {/* Scrollable Canvas with all chapters/pages */}
      <div
        className={cn(
          "flex-1 overflow-auto",
          showPageBreaks ? "paginated-document" : "bg-muted/30"
        )}
      >
        <div className="mx-auto" style={{ maxWidth: showPageBreaks ? "900px" : "none" }}>
          <div className={cn(showPageBreaks ? "py-8 px-4" : "p-4")}>
            {/* All chapters flow vertically */}
            <div ref={chaptersContainerRef} className="space-y-8">
              {document.chapters.map((chapter) => {
                const isActive = chapter.id === activeChapterId;

                return (
                  <div key={chapter.id} id={`chapter-${chapter.id}`} className="scroll-mt-20">
                    {/* Chapter label */}
                    {showPageBreaks && (
                      <div className="flex items-center gap-3 mb-3">
                        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                          {chapter.title}
                        </span>
                        <div className="flex-1 h-px bg-border/60" />
                        <span className="text-xs text-muted-foreground">
                          {chapter.wordCount} words • p.{chapterPageStarts[chapter.id]}
                        </span>
                      </div>
                    )}

                    {/* Editor container - page nodes handle page styling when enabled */}
                    <div
                      className={cn(
                        "mx-auto cursor-text",
                        !showPageBreaks && "bg-background border rounded-lg"
                      )}
                      style={{
                        width: showPageBreaks ? undefined : "100%",
                      }}
                      onClick={() => !isActive && switchToChapter(chapter.id)}
                    >
                      {isActive ? (
                        <RichTextEditor
                          key={chapter.id}
                          ref={(ref) => {
                            if (ref) {
                              editorRefsMap.current.set(chapter.id, ref);
                              // Update active editor when this editor mounts
                              if (ref.editor && ref.editor !== activeEditor) {
                                setActiveEditor(ref.editor);
                              }
                            }
                          }}
                          content={chapter.pages[0]?.content || ""}
                          onUpdate={handleChapterUpdate}
                          showToolbar={false}
                          enablePageNodes={showPageBreaks}
                          onPageCountChange={handlePageCountChange}
                          className="border-0 bg-transparent"
                          contentClassName={
                            showPageBreaks ? "paginated-editor-container" : "min-h-[200px] p-6"
                          }
                          minHeight={showPageBreaks ? undefined : "200px"}
                        />
                      ) : (
                        <div
                          className={cn(
                            "ProseMirror max-w-none cursor-text",
                            showPageBreaks && "editor-page",
                            !showPageBreaks && "prose prose-sm dark:prose-invert p-6"
                          )}
                          style={{
                            minHeight: !showPageBreaks ? "200px" : undefined,
                          }}
                          dangerouslySetInnerHTML={{ __html: chapter.pages[0]?.content || "" }}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom padding */}
            <div className="h-12" />
          </div>
        </div>
      </div>
    </div>
  );
}
