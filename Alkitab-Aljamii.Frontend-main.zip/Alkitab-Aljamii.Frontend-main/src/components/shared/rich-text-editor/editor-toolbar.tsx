/**
 * Re-export from toolbar folder for backward compatibility
 * The actual implementation is now in ./toolbar/editor-toolbar.tsx
 */
export { EditorToolbar } from "./toolbar";
export type { EditorToolbarProps } from "./toolbar";

// Also re-export sub-components and constants for consumers who need them
export {
  ToolbarButton,
  ColorButton,
  TableGridPicker,
  getEmbedSrc,
  PARAGRAPH_STYLES,
  FONTS,
  FONT_SIZES,
  TEXT_COLORS,
  HIGHLIGHT_COLORS,
  CELL_COLORS,
} from "./toolbar";

export type {
  ToolbarButtonProps,
  ColorButtonProps,
  TableGridPickerProps,
  ParagraphStyle,
  FontOption,
  FontSizeOption,
  ColorOption,
} from "./toolbar";
