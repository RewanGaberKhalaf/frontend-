"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Plus,
  ChevronDown,
  ChevronRight,
  Trash2,
  FileText,
  BookOpen,
  Pencil,
  Check,
  X,
  File,
  Link as LinkIcon,
  Video,
  Music,
  FileDown,
  ImageIcon,
} from "lucide-react";
import type { DocumentStructure, Chapter } from "../types";

interface ChapterSidebarProps {
  document: DocumentStructure;
  activeChapterId: string;
  expandedChapters: Set<string>;
  editingChapterId: string | null;
  editingTitle: string;
  onEditingTitleChange: (title: string) => void;
  onToggleChapter: (chapterId: string) => void;
  onNavigateToChapter: (chapterId: string) => void;
  onAddChapter: () => void;
  onDeleteChapter: (chapterId: string) => void;
  onStartEditingTitle: (chapter: Chapter) => void;
  onSaveChapterTitle: () => void;
  onCancelEditingTitle: () => void;
}

export function ChapterSidebar({
  document,
  activeChapterId,
  expandedChapters,
  editingChapterId,
  editingTitle,
  onEditingTitleChange,
  onToggleChapter,
  onNavigateToChapter,
  onAddChapter,
  onDeleteChapter,
  onStartEditingTitle,
  onSaveChapterTitle,
  onCancelEditingTitle,
}: ChapterSidebarProps) {
  return (
    <div className="w-64 border-r bg-muted/30 flex flex-col">
      {/* Header */}
      <div className="p-3 border-b">
        <div className="flex items-center gap-2 min-w-0">
          <BookOpen className="h-4 w-4 text-muted-foreground shrink-0" />
          <span className="font-medium text-sm truncate min-w-0">{document.meta.title}</span>
        </div>
        <div className="text-xs text-muted-foreground mt-1">
          {document.chapters.length} chapters • {document.totalWords.toLocaleString()}{" "}
          words
        </div>
      </div>

      {/* Chapter Tree */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {document.chapters.map((chapter) => {
            const isExpanded = expandedChapters.has(chapter.id);
            const isActiveChapter = chapter.id === activeChapterId;
            const isEditing = chapter.id === editingChapterId;

            return (
              <div key={chapter.id} className="mb-1">
                {/* Chapter Header */}
                <div
                  className={cn(
                    "group flex items-center gap-1 rounded-md px-2 py-1.5 cursor-pointer transition-colors min-w-0",
                    isActiveChapter ? "bg-primary/10" : "hover:bg-muted"
                  )}
                >
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 p-0 shrink-0"
                    onClick={() => onToggleChapter(chapter.id)}
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronRight className="h-3.5 w-3.5" />
                    )}
                  </Button>

                  {isEditing ? (
                    <div className="flex-1 flex items-center gap-1 min-w-0">
                      <input
                        type="text"
                        value={editingTitle}
                        onChange={(e) => onEditingTitleChange(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") onSaveChapterTitle();
                          if (e.key === "Escape") onCancelEditingTitle();
                        }}
                        className="flex-1 text-sm px-1 py-0.5 rounded border bg-background min-w-0"
                        autoFocus
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 p-0 shrink-0"
                        onClick={onSaveChapterTitle}
                      >
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 p-0 shrink-0"
                        onClick={onCancelEditingTitle}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                      <span
                        className="flex-1 text-sm truncate min-w-0"
                        onClick={() => onNavigateToChapter(chapter.id)}
                      >
                        {chapter.title}
                      </span>
                      <span className="text-xs text-muted-foreground shrink-0 ml-1">
                        {chapter.wordCount}w
                      </span>
                      <div className="flex items-center shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-5 w-5 p-0"
                          onClick={(e) => {
                            e.stopPropagation();
                            onStartEditingTitle(chapter);
                          }}
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                        {document.chapters.length > 1 && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-5 w-5 p-0 hover:text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteChapter(chapter.id);
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </>
                  )}
                </div>

                {/* Resources (collapsible) */}
                {isExpanded && chapter.resources && chapter.resources.length > 0 && (
                  <div className="ml-4 mt-0.5 space-y-0.5">
                    {chapter.resources.map((resource) => (
                      <div
                        key={resource.id}
                        className="flex items-center gap-2 rounded-md px-2 py-1 text-xs text-muted-foreground min-w-0"
                      >
                        {resource.type === "link" && <LinkIcon className="h-3 w-3 shrink-0" />}
                        {resource.type === "video" && <Video className="h-3 w-3 shrink-0" />}
                        {resource.type === "audio" && <Music className="h-3 w-3 shrink-0" />}
                        {resource.type === "document" && <FileDown className="h-3 w-3 shrink-0" />}
                        {resource.type === "image" && <ImageIcon className="h-3 w-3 shrink-0" />}
                        {resource.type === "file" && <File className="h-3 w-3 shrink-0" />}
                        <span className="truncate min-w-0">{resource.title}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>

      {/* Add Chapter Button */}
      <div className="p-2 border-t">
        <Button variant="outline" size="sm" onClick={onAddChapter} className="w-full gap-1">
          <Plus className="h-4 w-4" />
          Add Chapter
        </Button>
      </div>
    </div>
  );
}
