import type { DocumentStructure } from "../types";

// A4 dimensions in mm: 210mm × 297mm
// Screen display: 794px × 1123px at 96 DPI
export const A4_WIDTH_PX = 794;
export const A4_HEIGHT_PX = 1123;
export const PAGE_MARGIN = 96; // 1 inch margins
export const PAGE_GAP = 40; // Gap between visual pages

export interface PaginatedBookEditorProps {
  /** Initial document structure */
  document: DocumentStructure;
  /** Called when document changes */
  onDocumentChange?: (doc: DocumentStructure) => void;
  /** CSS class for the container */
  className?: string;
}

export interface ActiveChapter {
  chapterId: string;
}
