export { ChapterSidebar } from "./chapter-sidebar";
export { PaginatedResourcesPanel } from "./paginated-resources-panel";
export { ResourceForm } from "./resource-form";
export { usePaginatedDocument } from "./use-paginated-document";
export {
  A4_WIDTH_PX,
  A4_HEIGHT_PX,
  PAGE_MARGIN,
  PAGE_GAP,
  type PaginatedBookEditorProps,
  type ActiveChapter,
} from "./paginated-book-editor-types";
