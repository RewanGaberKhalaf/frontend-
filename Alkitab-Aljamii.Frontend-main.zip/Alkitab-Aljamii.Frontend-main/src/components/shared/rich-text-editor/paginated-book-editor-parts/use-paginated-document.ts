"use client";

import { useState, useCallback, useMemo, useEffect } from "react";
import {
  type DocumentStructure,
  type Chapter,
  type PageHeaderFooter,
  createChapter,
  calculateWordCount,
  updateDocumentTotals,
} from "../types";
import type { ActiveChapter } from "./paginated-book-editor-types";

interface UsePaginatedDocumentOptions {
  initialDocument: DocumentStructure;
  onDocumentChange?: (doc: DocumentStructure) => void;
}

export function usePaginatedDocument({
  initialDocument,
  onDocumentChange,
}: UsePaginatedDocumentOptions) {
  const [document, setDocument] = useState<DocumentStructure>(initialDocument);
  const [activeChapter, setActiveChapter] = useState<ActiveChapter>(() => ({
    chapterId: initialDocument.chapters[0]?.id || "",
  }));
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(
    () => new Set(initialDocument.chapters.map((ch) => ch.id))
  );
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState("");

  // Get the currently active chapter data
  const currentChapter = useMemo(
    () => document.chapters.find((ch) => ch.id === activeChapter.chapterId),
    [document.chapters, activeChapter.chapterId]
  );

  // Combine all pages content for the chapter into a single HTML string
  const chapterContent = useMemo(() => {
    if (!currentChapter) return "";
    return currentChapter.pages.map((p) => p.content).join("");
  }, [currentChapter]);

  // Update book header
  const updateBookHeader = useCallback((updates: Partial<PageHeaderFooter>) => {
    setDocument((prev) => ({
      ...prev,
      header: { ...prev.header, enabled: true, ...updates } as PageHeaderFooter,
    }));
  }, []);

  // Update book footer
  const updateBookFooter = useCallback((updates: Partial<PageHeaderFooter>) => {
    setDocument((prev) => ({
      ...prev,
      footer: { ...prev.footer, enabled: true, ...updates } as PageHeaderFooter,
    }));
  }, []);

  // Toggle chapter expansion
  const toggleChapter = useCallback((chapterId: string) => {
    setExpandedChapters((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) {
        next.delete(chapterId);
      } else {
        next.add(chapterId);
      }
      return next;
    });
  }, []);

  // Navigate to a chapter
  const navigateToChapter = useCallback((chapterId: string) => {
    setActiveChapter({ chapterId });
    setExpandedChapters((prev) => new Set([...prev, chapterId]));
  }, []);

  // Update chapter content (stores as single page)
  const handleChapterUpdate = useCallback(
    (html: string) => {
      const wordCount = calculateWordCount(html);

      setDocument((prev) => {
        const updated = {
          ...prev,
          chapters: prev.chapters.map((ch) => {
            if (ch.id !== activeChapter.chapterId) return ch;

            const existingPage = ch.pages[0];

            const updatedChapter = {
              ...ch,
              pages: [
                {
                  id: existingPage?.id || `page-${Date.now()}`,
                  order: 0,
                  content: html,
                  wordCount,
                },
              ],
              wordCount,
              updatedAt: new Date(),
            };

            return updatedChapter;
          }),
        };

        return updateDocumentTotals(updated);
      });
    },
    [activeChapter.chapterId]
  );

  // Add new chapter
  const addChapter = useCallback(() => {
    const newChapter = createChapter(document.chapters.length);
    setDocument((prev) =>
      updateDocumentTotals({
        ...prev,
        chapters: [...prev.chapters, newChapter],
      })
    );
    navigateToChapter(newChapter.id);
  }, [document.chapters.length, navigateToChapter]);

  // Delete chapter
  const deleteChapter = useCallback(
    (chapterId: string) => {
      if (document.chapters.length <= 1) return;

      const chapterIndex = document.chapters.findIndex((ch) => ch.id === chapterId);

      setDocument((prev) => {
        const filtered = prev.chapters
          .filter((ch) => ch.id !== chapterId)
          .map((ch, idx) => ({ ...ch, order: idx }));

        return updateDocumentTotals({
          ...prev,
          chapters: filtered,
        });
      });

      if (chapterId === activeChapter.chapterId) {
        const nextChapter =
          document.chapters[chapterIndex + 1] || document.chapters[chapterIndex - 1];
        if (nextChapter) {
          navigateToChapter(nextChapter.id);
        }
      }
    },
    [document.chapters, activeChapter.chapterId, navigateToChapter]
  );

  // Start editing chapter title
  const startEditingTitle = useCallback((chapter: Chapter) => {
    setEditingChapterId(chapter.id);
    setEditingTitle(chapter.title);
  }, []);

  // Save chapter title
  const saveChapterTitle = useCallback(() => {
    if (!editingChapterId || !editingTitle.trim()) {
      setEditingChapterId(null);
      return;
    }

    setDocument((prev) => ({
      ...prev,
      chapters: prev.chapters.map((ch) =>
        ch.id === editingChapterId
          ? { ...ch, title: editingTitle.trim(), updatedAt: new Date() }
          : ch
      ),
    }));
    setEditingChapterId(null);
  }, [editingChapterId, editingTitle]);

  // Cancel editing
  const cancelEditingTitle = useCallback(() => {
    setEditingChapterId(null);
  }, []);

  // Add resource to chapter
  const addResource = useCallback(
    (chapterId: string, resource: any) => {
      setDocument((prev) => ({
        ...prev,
        chapters: prev.chapters.map((ch) =>
          ch.id === chapterId
            ? {
                ...ch,
                resources: [
                  ...(ch.resources || []),
                  { ...resource, order: ch.resources?.length || 0 },
                ],
              }
            : ch
        ),
      }));
    },
    []
  );

  // Delete resource from chapter
  const deleteResource = useCallback((chapterId: string, resourceId: string) => {
    setDocument((prev) => ({
      ...prev,
      chapters: prev.chapters.map((ch) =>
        ch.id === chapterId
          ? {
              ...ch,
              resources: ch.resources?.filter((r) => r.id !== resourceId),
            }
          : ch
      ),
    }));
  }, []);

  // Notify parent of changes
  useEffect(() => {
    onDocumentChange?.(document);
  }, [document, onDocumentChange]);

  return {
    document,
    activeChapter,
    currentChapter,
    chapterContent,
    expandedChapters,
    editingChapterId,
    editingTitle,
    setEditingTitle,
    updateBookHeader,
    updateBookFooter,
    toggleChapter,
    navigateToChapter,
    handleChapterUpdate,
    addChapter,
    deleteChapter,
    startEditingTitle,
    saveChapterTitle,
    cancelEditingTitle,
    addResource,
    deleteResource,
  };
}
