"use client";

import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import {
  type DocumentStructure,
  type Chapter,
  type PageHeaderFooter,
  createChapter,
  createPage,
  calculateWordCount,
  updateDocumentTotals,
  updateChapterWordCount,
} from "../types";
import type { ActiveLocation } from "./book-editor-types";

interface UseDocumentStateOptions {
  initialDocument: DocumentStructure;
  onDocumentChange?: (doc: DocumentStructure) => void;
}

export function useDocumentState({
  initialDocument,
  onDocumentChange,
}: UseDocumentStateOptions) {
  const [document, setDocument] = useState<DocumentStructure>(initialDocument);
  const [activeLocation, setActiveLocation] = useState<ActiveLocation>(() => {
    const firstChapter = initialDocument.chapters[0];
    const firstPage = firstChapter?.pages[0];
    return {
      chapterId: firstChapter?.id || "",
      pageId: firstPage?.id || "",
    };
  });
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(
    () => new Set(initialDocument.chapters.map((ch) => ch.id))
  );

  const updateDebounceRef = useRef<NodeJS.Timeout | null>(null);
  const pendingContentRef = useRef<string | null>(null);

  // Cleanup debounce on unmount
  useEffect(() => {
    return () => {
      if (updateDebounceRef.current) {
        clearTimeout(updateDebounceRef.current);
      }
    };
  }, []);

  // Get active chapter and page
  const activeChapter = useMemo(
    () => document.chapters.find((ch) => ch.id === activeLocation.chapterId),
    [document.chapters, activeLocation.chapterId]
  );

  const activePage = useMemo(
    () => activeChapter?.pages.find((p) => p.id === activeLocation.pageId),
    [activeChapter, activeLocation.pageId]
  );

  // Calculate global page number for current page
  const globalPageNumber = useMemo(() => {
    let pageNum = 0;
    for (const chapter of document.chapters) {
      for (const page of chapter.pages) {
        pageNum++;
        if (
          chapter.id === activeLocation.chapterId &&
          page.id === activeLocation.pageId
        ) {
          return pageNum;
        }
      }
    }
    return 1;
  }, [document.chapters, activeLocation]);

  // Get effective header (chapter-specific or book-level)
  const getEffectiveHeader = useCallback(
    (chapter: Chapter, isFirstPage: boolean): PageHeaderFooter | undefined => {
      const header = chapter.header?.enabled ? chapter.header : document.header;
      if (!header?.enabled) return undefined;
      if (header.differentFirstPage && isFirstPage) return undefined;
      return header;
    },
    [document.header]
  );

  // Get effective footer
  const getEffectiveFooter = useCallback(
    (chapter: Chapter, isFirstPage: boolean): PageHeaderFooter | undefined => {
      const footer = document.footer;
      if (!footer?.enabled) return undefined;
      if (footer.differentFirstPage && isFirstPage) return undefined;
      return footer;
    },
    [document.footer]
  );

  // Update book header
  const updateBookHeader = useCallback((updates: Partial<PageHeaderFooter>) => {
    setDocument((prev) => ({
      ...prev,
      header: { ...prev.header, enabled: true, ...updates } as PageHeaderFooter,
    }));
  }, []);

  // Update book footer
  const updateBookFooter = useCallback((updates: Partial<PageHeaderFooter>) => {
    setDocument((prev) => ({
      ...prev,
      footer: { ...prev.footer, enabled: true, ...updates } as PageHeaderFooter,
    }));
  }, []);

  // Toggle chapter expansion
  const toggleChapter = useCallback((chapterId: string) => {
    setExpandedChapters((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) {
        next.delete(chapterId);
      } else {
        next.add(chapterId);
      }
      return next;
    });
  }, []);

  // Navigate to a specific page
  const navigateToPage = useCallback((chapterId: string, pageId: string) => {
    setActiveLocation({ chapterId, pageId });
    setExpandedChapters((prev) => new Set([...prev, chapterId]));
  }, []);

  // Navigate to previous page
  const navigatePrevious = useCallback(() => {
    let prevChapterId: string | null = null;
    let prevPageId: string | null = null;

    for (const chapter of document.chapters) {
      for (const page of chapter.pages) {
        if (
          chapter.id === activeLocation.chapterId &&
          page.id === activeLocation.pageId
        ) {
          if (prevPageId) {
            navigateToPage(prevChapterId!, prevPageId);
            return;
          }
        }
        prevChapterId = chapter.id;
        prevPageId = page.id;
      }
    }
  }, [document.chapters, activeLocation, navigateToPage]);

  // Navigate to next page
  const navigateNext = useCallback(() => {
    let foundCurrent = false;

    for (const chapter of document.chapters) {
      for (const page of chapter.pages) {
        if (foundCurrent) {
          navigateToPage(chapter.id, page.id);
          return;
        }
        if (
          chapter.id === activeLocation.chapterId &&
          page.id === activeLocation.pageId
        ) {
          foundCurrent = true;
        }
      }
    }
  }, [document.chapters, activeLocation, navigateToPage]);

  // Check if we can navigate
  const canNavigatePrevious = globalPageNumber > 1;
  const canNavigateNext = globalPageNumber < document.totalPages;

  // Update page content
  const handlePageUpdate = useCallback(
    (html: string) => {
      pendingContentRef.current = html;

      if (updateDebounceRef.current) {
        clearTimeout(updateDebounceRef.current);
      }

      updateDebounceRef.current = setTimeout(() => {
        const wordCount = calculateWordCount(html);

        setDocument((prev) => {
          const updated = {
            ...prev,
            chapters: prev.chapters.map((ch) => {
              if (ch.id !== activeLocation.chapterId) return ch;

              const updatedChapter = {
                ...ch,
                pages: ch.pages.map((p) =>
                  p.id === activeLocation.pageId
                    ? { ...p, content: html, wordCount }
                    : p
                ),
                updatedAt: new Date(),
              };

              return updateChapterWordCount(updatedChapter);
            }),
          };

          return updateDocumentTotals(updated);
        });

        pendingContentRef.current = null;
      }, 300);
    },
    [activeLocation]
  );

  // Add new chapter
  const addChapter = useCallback(() => {
    const newChapter = createChapter(document.chapters.length);
    setDocument((prev) =>
      updateDocumentTotals({
        ...prev,
        chapters: [...prev.chapters, newChapter],
      })
    );
    const firstPage = newChapter.pages[0];
    if (firstPage) {
      navigateToPage(newChapter.id, firstPage.id);
    }
  }, [document.chapters.length, navigateToPage]);

  // Delete chapter
  const deleteChapter = useCallback(
    (chapterId: string) => {
      if (document.chapters.length <= 1) return;

      const chapterIndex = document.chapters.findIndex((ch) => ch.id === chapterId);

      setDocument((prev) => {
        const filtered = prev.chapters
          .filter((ch) => ch.id !== chapterId)
          .map((ch, idx) => ({ ...ch, order: idx }));

        return updateDocumentTotals({
          ...prev,
          chapters: filtered,
        });
      });

      if (chapterId === activeLocation.chapterId) {
        const nextChapter =
          document.chapters[chapterIndex + 1] || document.chapters[chapterIndex - 1];
        const nextPage = nextChapter?.pages[0];
        if (nextChapter && nextPage) {
          navigateToPage(nextChapter.id, nextPage.id);
        }
      }
    },
    [document.chapters, activeLocation.chapterId, navigateToPage]
  );

  // Add new page to chapter
  const addPage = useCallback(
    (chapterId: string) => {
      const chapter = document.chapters.find((ch) => ch.id === chapterId);
      if (!chapter) return;

      const newPage = createPage(chapter.pages.length);

      setDocument((prev) =>
        updateDocumentTotals({
          ...prev,
          chapters: prev.chapters.map((ch) =>
            ch.id === chapterId
              ? { ...ch, pages: [...ch.pages, newPage], updatedAt: new Date() }
              : ch
          ),
        })
      );

      navigateToPage(chapterId, newPage.id);
    },
    [document.chapters, navigateToPage]
  );

  // Delete page
  const deletePage = useCallback(
    (chapterId: string, pageId: string) => {
      const chapter = document.chapters.find((ch) => ch.id === chapterId);
      if (!chapter || chapter.pages.length <= 1) return;

      const pageIndex = chapter.pages.findIndex((p) => p.id === pageId);

      setDocument((prev) =>
        updateDocumentTotals({
          ...prev,
          chapters: prev.chapters.map((ch) => {
            if (ch.id !== chapterId) return ch;

            const updatedChapter = {
              ...ch,
              pages: ch.pages
                .filter((p) => p.id !== pageId)
                .map((p, idx) => ({ ...p, order: idx })),
              updatedAt: new Date(),
            };

            return updateChapterWordCount(updatedChapter);
          }),
        })
      );

      if (pageId === activeLocation.pageId) {
        const nextPage = chapter.pages[pageIndex + 1] || chapter.pages[pageIndex - 1];
        if (nextPage) {
          navigateToPage(chapterId, nextPage.id);
        }
      }
    },
    [document.chapters, activeLocation.pageId, navigateToPage]
  );

  // Rename chapter
  const renameChapter = useCallback((chapterId: string, newTitle: string) => {
    setDocument((prev) => ({
      ...prev,
      chapters: prev.chapters.map((ch) =>
        ch.id === chapterId
          ? { ...ch, title: newTitle, updatedAt: new Date() }
          : ch
      ),
    }));
  }, []);

  // Notify parent of changes
  useEffect(() => {
    onDocumentChange?.(document);
  }, [document, onDocumentChange]);

  return {
    document,
    setDocument,
    activeLocation,
    activeChapter,
    activePage,
    globalPageNumber,
    expandedChapters,
    canNavigatePrevious,
    canNavigateNext,
    getEffectiveHeader,
    getEffectiveFooter,
    updateBookHeader,
    updateBookFooter,
    toggleChapter,
    navigateToPage,
    navigatePrevious,
    navigateNext,
    handlePageUpdate,
    addChapter,
    deleteChapter,
    addPage,
    deletePage,
    renameChapter,
  };
}
