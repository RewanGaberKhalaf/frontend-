"use client";

import { useRef, useEffect } from "react";
import type { Chapter, Page, PageHeaderFooter } from "../types";
import { renderMathInContainer } from "@/hooks/use-math-renderer";
import "katex/dist/katex.min.css";
import {
  A4_WIDTH_PX,
  A4_HEIGHT_PX,
  PAGE_MARGIN as PAGE_PADDING,
} from "@/lib/constants/page-dimensions";

interface BookPagePreviewProps {
  chapter: Chapter;
  page: Page;
  globalPageNumber: number;
  getEffectiveHeader: (chapter: Chapter, isFirstPage: boolean) => PageHeaderFooter | undefined;
  getEffectiveFooter: (chapter: Chapter, isFirstPage: boolean) => PageHeaderFooter | undefined;
}

export function BookPagePreview({
  chapter,
  page,
  globalPageNumber,
  getEffectiveHeader,
  getEffectiveFooter,
}: BookPagePreviewProps) {
  const contentRef = useRef<HTMLDivElement>(null);
  const isFirstPage = chapter.pages.indexOf(page) === 0;
  const header = getEffectiveHeader(chapter, isFirstPage);
  const footer = getEffectiveFooter(chapter, isFirstPage);

  // Render math formulas after content changes
  // Use a small delay to ensure DOM is fully updated
  useEffect(() => {
    if (!contentRef.current) return;

    const timeoutId = setTimeout(() => {
      if (contentRef.current) {
        renderMathInContainer(contentRef.current);
      }
    }, 10);

    return () => clearTimeout(timeoutId);
  }, [page.content]);

  return (
    <div
      className="bg-background shadow-xl rounded-sm overflow-hidden"
      style={{
        width: A4_WIDTH_PX,
        minHeight: A4_HEIGHT_PX,
        padding: PAGE_PADDING,
        transform: "scale(0.75)",
        transformOrigin: "top center",
      }}
    >
      {/* Preview Header */}
      {header && (
        <div className="pb-6 mb-4 border-b border-dashed border-muted-foreground/20 text-xs text-muted-foreground flex items-center justify-between -mt-12">
          <span>{header.leftContent || ""}</span>
          <span className="font-medium">{header.centerContent || chapter.title}</span>
          <span>{header.rightContent || ""}</span>
        </div>
      )}

      {/* Preview Content */}
      <div
        ref={contentRef}
        className="prose prose-sm dark:prose-invert max-w-none chapter-content"
        dangerouslySetInnerHTML={{ __html: page.content || "" }}
      />

      {/* Preview Footer */}
      {footer && (
        <div className="pt-6 mt-4 border-t border-dashed border-muted-foreground/20 text-xs text-muted-foreground flex items-center justify-between -mb-12">
          <span>
            {footer.leftContent || ""}
            {footer.showPageNumber !== false &&
              footer.pageNumberPosition === "left" &&
              ` Page ${globalPageNumber}`}
          </span>
          <span>
            {footer.centerContent || ""}
            {footer.showPageNumber !== false &&
              (footer.pageNumberPosition || "center") === "center" &&
              `Page ${globalPageNumber}`}
          </span>
          <span>
            {footer.showPageNumber !== false &&
              footer.pageNumberPosition === "right" &&
              `Page ${globalPageNumber} `}
            {footer.rightContent || ""}
          </span>
        </div>
      )}
    </div>
  );
}
