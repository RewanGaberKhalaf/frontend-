import type { DocumentStructure } from "../types";

export interface BookEditorProps {
  /** Initial document structure */
  document: DocumentStructure;
  /** Called when document changes */
  onDocumentChange?: (doc: DocumentStructure) => void;
  /** CSS class for the container */
  className?: string;
  /** Enable offline mode with local storage fallback */
  enableOfflineMode?: boolean;
}

export interface ActiveLocation {
  chapterId: string;
  pageId: string;
}
