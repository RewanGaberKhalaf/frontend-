"use client";

import { Eye, EyeOff, Printer, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageSetupDialog } from "../page-setup-dialog";
import type { PageHeaderFooter, Chapter } from "../types";

interface BookEditorToolbarActionsProps {
  showPreview: boolean;
  onTogglePreview: () => void;
  resourcesExpanded: boolean;
  onToggleResources: () => void;
  activeChapter: Chapter | undefined;
  settingsOpen: boolean;
  onSettingsOpenChange: (open: boolean) => void;
  header: PageHeaderFooter | undefined;
  footer: PageHeaderFooter | undefined;
  onUpdateHeader: (updates: Partial<PageHeaderFooter>) => void;
  onUpdateFooter: (updates: Partial<PageHeaderFooter>) => void;
}

export function BookEditorToolbarActions({
  showPreview,
  onTogglePreview,
  resourcesExpanded,
  onToggleResources,
  activeChapter,
  settingsOpen,
  onSettingsOpenChange,
  header,
  footer,
  onUpdateHeader,
  onUpdateFooter,
}: BookEditorToolbarActionsProps) {
  return (
    <div className="ml-auto flex items-center gap-1 mr-2 shrink-0">
      {/* Preview Toggle */}
      <Button
        variant={showPreview ? "default" : "ghost"}
        size="sm"
        onClick={onTogglePreview}
        title={showPreview ? "Hide Preview" : "Show Preview"}
      >
        {showPreview ? (
          <EyeOff className="h-4 w-4 mr-1" />
        ) : (
          <Eye className="h-4 w-4 mr-1" />
        )}
        Preview
      </Button>

      {/* Print Button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => window.print()}
        title="Print"
      >
        <Printer className="h-4 w-4" />
      </Button>

      {/* Resources Toggle */}
      <Button
        variant={resourcesExpanded ? "default" : "ghost"}
        size="sm"
        onClick={onToggleResources}
      >
        <BookOpen className="h-4 w-4 mr-1" />
        Resources
        {activeChapter?.resources?.length ? (
          <span className="ml-1 text-xs bg-primary-foreground/20 px-1.5 rounded">
            {activeChapter.resources.length}
          </span>
        ) : null}
      </Button>

      {/* Page Setup */}
      <PageSetupDialog
        open={settingsOpen}
        onOpenChange={onSettingsOpenChange}
        header={header}
        footer={footer}
        onUpdateHeader={onUpdateHeader}
        onUpdateFooter={onUpdateFooter}
      />
    </div>
  );
}
