"use client";

import { useCallback, useRef, useEffect, useState } from "react";
import type { Editor } from "@tiptap/react";
import { toast } from "sonner";
import {
  type DocumentStructure,
  createPage,
  calculateWordCount,
  updateDocumentTotals,
} from "../types";
import { BASE_CONTENT_HEIGHT as CONTENT_HEIGHT } from "@/lib/constants/page-dimensions";
import type { ActiveLocation } from "./book-editor-types";

interface UseOverflowDetectionOptions {
  activeEditor: Editor | null;
  activeLocation: ActiveLocation;
  document: DocumentStructure;
  setDocument: React.Dispatch<React.SetStateAction<DocumentStructure>>;
  navigateToPage: (chapterId: string, pageId: string) => void;
  pageContentRef: React.RefObject<HTMLDivElement>;
}

export function useOverflowDetection({
  activeEditor,
  activeLocation,
  document,
  setDocument,
  navigateToPage,
  pageContentRef,
}: UseOverflowDetectionOptions) {
  const [isOverflowing, setIsOverflowing] = useState(false);
  const overflowCheckTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastContentHeightRef = useRef(0);

  // Find the block index where overflow starts
  const findOverflowBlockIndex = useCallback((editorElement: HTMLElement): number => {
    const children = editorElement.children;

    for (let i = 0; i < children.length; i++) {
      const child = children[i] as HTMLElement;
      const rect = child.getBoundingClientRect();
      const editorRect = editorElement.getBoundingClientRect();
      const relativeTop = rect.top - editorRect.top;
      const relativeBottom = relativeTop + rect.height;

      if (relativeBottom > CONTENT_HEIGHT) {
        return i;
      }
    }

    return -1;
  }, []);

  // Split content and move overflow to next page
  const splitAndMoveContent = useCallback(() => {
    if (!pageContentRef.current || !activeEditor) return;

    const editorElement = pageContentRef.current.querySelector(
      ".ProseMirror"
    ) as HTMLElement;
    if (!editorElement) return;

    const overflowIndex = findOverflowBlockIndex(editorElement);
    if (overflowIndex <= 0) return;

    const json = activeEditor.getJSON();
    if (!json.content || json.content.length === 0) return;

    const contentThatFits = json.content.slice(0, overflowIndex);
    const contentThatOverflows = json.content.slice(overflowIndex);

    if (contentThatOverflows.length === 0) return;

    const chapter = document.chapters.find(
      (ch) => ch.id === activeLocation.chapterId
    );
    if (!chapter) return;

    const currentPageIndex = chapter.pages.findIndex(
      (p) => p.id === activeLocation.pageId
    );
    const nextPage = chapter.pages[currentPageIndex + 1];

    activeEditor.commands.setContent({ type: "doc", content: contentThatFits });
    const fittingHtml = activeEditor.getHTML();

    activeEditor.commands.setContent({ type: "doc", content: contentThatOverflows });
    const overflowHtml = activeEditor.getHTML();

    activeEditor.commands.setContent({ type: "doc", content: contentThatFits });

    if (nextPage) {
      setDocument((prev) => {
        const updatedChapters = prev.chapters.map((ch) => {
          if (ch.id !== activeLocation.chapterId) return ch;

          return {
            ...ch,
            pages: ch.pages.map((p, idx) => {
              if (idx === currentPageIndex) {
                return {
                  ...p,
                  content: fittingHtml,
                  wordCount: calculateWordCount(fittingHtml),
                };
              }
              if (idx === currentPageIndex + 1) {
                const mergedContent = overflowHtml + (p.content || "");
                return {
                  ...p,
                  content: mergedContent,
                  wordCount: calculateWordCount(mergedContent),
                };
              }
              return p;
            }),
            updatedAt: new Date(),
          };
        });

        return updateDocumentTotals({ ...prev, chapters: updatedChapters });
      });

      navigateToPage(activeLocation.chapterId, nextPage.id);
      toast.success("Content moved to next page");
    } else {
      const newPage = createPage(chapter.pages.length);
      newPage.content = overflowHtml;
      newPage.wordCount = calculateWordCount(overflowHtml);

      setDocument((prev) => {
        const updatedChapters = prev.chapters.map((ch) => {
          if (ch.id !== activeLocation.chapterId) return ch;

          return {
            ...ch,
            pages: [
              ...ch.pages.map((p, idx) => {
                if (idx === currentPageIndex) {
                  return {
                    ...p,
                    content: fittingHtml,
                    wordCount: calculateWordCount(fittingHtml),
                  };
                }
                return p;
              }),
              newPage,
            ],
            updatedAt: new Date(),
          };
        });

        return updateDocumentTotals({ ...prev, chapters: updatedChapters });
      });

      navigateToPage(activeLocation.chapterId, newPage.id);
      toast.success("New page created with overflow content");
    }

    setIsOverflowing(false);
  }, [
    activeEditor,
    activeLocation,
    document.chapters,
    findOverflowBlockIndex,
    navigateToPage,
    pageContentRef,
    setDocument,
  ]);

  // Check for content overflow
  const checkOverflow = useCallback(() => {
    if (!pageContentRef.current) return;

    const editorElement = pageContentRef.current.querySelector(
      ".ProseMirror"
    ) as HTMLElement;
    if (!editorElement) return;

    const contentHeight = editorElement.scrollHeight;
    const OVERFLOW_BUFFER = 5;
    const wasOverflowing = lastContentHeightRef.current > CONTENT_HEIGHT + OVERFLOW_BUFFER;
    const nowOverflowing = contentHeight > CONTENT_HEIGHT + OVERFLOW_BUFFER;

    lastContentHeightRef.current = contentHeight;

    if (wasOverflowing !== nowOverflowing) {
      setIsOverflowing(nowOverflowing);
    }
  }, [pageContentRef]);

  // Overflow check on editor update - debounced
  useEffect(() => {
    if (!activeEditor) return;

    const handleUpdate = () => {
      if (overflowCheckTimeoutRef.current) {
        clearTimeout(overflowCheckTimeoutRef.current);
      }
      overflowCheckTimeoutRef.current = setTimeout(() => {
        if (!pageContentRef.current) return;

        const editorElement = pageContentRef.current.querySelector(
          ".ProseMirror"
        ) as HTMLElement;
        if (!editorElement) return;

        const contentHeight = editorElement.scrollHeight;
        const OVERFLOW_BUFFER = 5;
        const nowOverflowing = contentHeight > CONTENT_HEIGHT + OVERFLOW_BUFFER;

        if (nowOverflowing !== isOverflowing) {
          setIsOverflowing(nowOverflowing);
        }
      }, 300);
    };

    activeEditor.on("update", handleUpdate);

    return () => {
      activeEditor.off("update", handleUpdate);
      if (overflowCheckTimeoutRef.current) {
        clearTimeout(overflowCheckTimeoutRef.current);
      }
    };
  }, [activeEditor, isOverflowing, pageContentRef]);

  // Reset overflow state when page changes
  useEffect(() => {
    setIsOverflowing(false);
    const timeout = setTimeout(checkOverflow, 100);
    return () => clearTimeout(timeout);
  }, [activeLocation.pageId, checkOverflow]);

  return {
    isOverflowing,
    splitAndMoveContent,
  };
}
