"use client";

import { cn } from "@/lib/utils";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RichTextEditor, type RichTextEditorRef } from "../rich-text-editor";
import type { Chapter, Page, PageHeaderFooter } from "../types";
import {
  A4_WIDTH_PX,
  A4_HEIGHT_PX,
  PAGE_MARGIN as PAGE_PADDING,
  BASE_CONTENT_HEIGHT as CONTENT_HEIGHT,
} from "@/lib/constants/page-dimensions";

interface BookPageProps {
  chapter: Chapter;
  page: Page;
  globalPageNumber: number;
  isOverflowing: boolean;
  pageContentRef: React.RefObject<HTMLDivElement>;
  getEffectiveHeader: (chapter: Chapter, isFirstPage: boolean) => PageHeaderFooter | undefined;
  getEffectiveFooter: (chapter: Chapter, isFirstPage: boolean) => PageHeaderFooter | undefined;
  onEditorRef: (ref: RichTextEditorRef | null) => void;
  onPageUpdate: (html: string) => void;
  onNavigateToNextPage: () => void;
}

export function BookPage({
  chapter,
  page,
  globalPageNumber,
  isOverflowing,
  pageContentRef,
  getEffectiveHeader,
  getEffectiveFooter,
  onEditorRef,
  onPageUpdate,
  onNavigateToNextPage,
}: BookPageProps) {
  const isFirstPage = chapter.pages.indexOf(page) === 0;
  const header = getEffectiveHeader(chapter, isFirstPage);
  const footer = getEffectiveFooter(chapter, isFirstPage);

  return (
    <div
      className="bg-background shadow-xl flex flex-col rounded-sm overflow-hidden"
      style={{
        width: A4_WIDTH_PX,
        height: A4_HEIGHT_PX,
        padding: PAGE_PADDING,
      }}
    >
      {/* Page Header */}
      {header && (
        <div className="pb-6 mb-4 border-b border-dashed border-muted-foreground/20 text-xs text-muted-foreground flex items-center justify-between shrink-0 -mt-12">
          <span>{header.leftContent || ""}</span>
          <span className="font-medium">{header.centerContent || chapter.title}</span>
          <span>{header.rightContent || ""}</span>
        </div>
      )}

      {/* Page Content */}
      <div
        ref={pageContentRef}
        className="flex-1 relative overflow-hidden book-editor-page"
        style={{ maxHeight: CONTENT_HEIGHT }}
      >
        <RichTextEditor
          key={page.id}
          ref={onEditorRef}
          content={page.content}
          onUpdate={onPageUpdate}
          showToolbar={false}
          className="border-0 rounded-none h-full"
          contentClassName={cn(isOverflowing && "overflow-indicator")}
          noPadding={true}
        />

        {/* Page full indicator */}
        {isOverflowing && (
          <div className="absolute bottom-0 left-0 right-0 bg-amber-500/10 border-t-2 border-amber-500 pointer-events-none flex items-center justify-center py-3">
            <div className="flex items-center gap-3 text-amber-700 dark:text-amber-400 text-sm bg-background/95 px-4 py-2 rounded-lg shadow-md pointer-events-auto border border-amber-500/30">
              <AlertCircle className="h-4 w-4" />
              <span className="font-medium">Page is full</span>
              <Button
                variant="default"
                size="sm"
                className="h-7 px-3 text-xs bg-amber-600 hover:bg-amber-700"
                onClick={onNavigateToNextPage}
              >
                Go to next page →
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Page Footer */}
      {footer && (
        <div className="pt-6 mt-4 border-t border-dashed border-muted-foreground/20 text-xs text-muted-foreground flex items-center justify-between shrink-0 -mb-12">
          <span>
            {footer.leftContent || ""}
            {footer.showPageNumber !== false &&
              footer.pageNumberPosition === "left" &&
              ` Page ${globalPageNumber}`}
          </span>
          <span>
            {footer.centerContent || ""}
            {footer.showPageNumber !== false &&
              (footer.pageNumberPosition || "center") === "center" &&
              `Page ${globalPageNumber}`}
          </span>
          <span>
            {footer.showPageNumber !== false &&
              footer.pageNumberPosition === "right" &&
              `Page ${globalPageNumber} `}
            {footer.rightContent || ""}
          </span>
        </div>
      )}
    </div>
  );
}
