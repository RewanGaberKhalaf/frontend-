"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { ChapterResource } from "./types";

interface ResourceFormProps {
  onAdd: (resource: ChapterResource) => void;
}

export function ResourceForm({ onAdd }: ResourceFormProps) {
  const [title, setTitle] = useState("");
  const [type, setType] = useState<ChapterResource["type"]>("link");
  const [url, setUrl] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = () => {
    if (!title || !url) return;

    onAdd({
      id: Math.random().toString(36).substring(2, 9),
      title,
      type,
      url,
      description: description || undefined,
      order: 0,
      createdAt: new Date(),
    });

    // Reset form
    setTitle("");
    setType("link");
    setUrl("");
    setDescription("");
  };

  return (
    <div className="space-y-4 pt-4">
      <div className="space-y-2">
        <Label htmlFor="resource-title">Title</Label>
        <Input
          id="resource-title"
          placeholder="e.g., Course Slides"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="resource-type">Type</Label>
        <Select value={type} onValueChange={(v) => setType(v as ChapterResource["type"])}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="link">Link</SelectItem>
            <SelectItem value="video">Video</SelectItem>
            <SelectItem value="audio">Audio</SelectItem>
            <SelectItem value="document">Document</SelectItem>
            <SelectItem value="image">Image</SelectItem>
            <SelectItem value="file">Other File</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="resource-url">URL</Label>
        <Input
          id="resource-url"
          placeholder="https://..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="resource-description">Description (optional)</Label>
        <Input
          id="resource-description"
          placeholder="Brief description..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>

      <Button onClick={handleSubmit} disabled={!title || !url} className="w-full">
        Add Resource
      </Button>
    </div>
  );
}
