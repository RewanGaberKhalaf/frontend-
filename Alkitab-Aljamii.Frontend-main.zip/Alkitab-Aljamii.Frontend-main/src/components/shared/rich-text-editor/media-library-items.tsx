"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Video, Music, Trash2, Check } from "lucide-react";
import type { MediaItem } from "./media-library";

// Grid Item Component
export function MediaGridItem({
  item,
  isSelected,
  onSelect,
  onDelete,
}: {
  item: MediaItem;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className={cn(
        "group relative aspect-square rounded-lg border-2 overflow-hidden cursor-pointer transition-all",
        isSelected
          ? "border-primary ring-2 ring-primary/30"
          : "border-transparent hover:border-muted-foreground/30"
      )}
      onClick={onSelect}
    >
      {item.type === "image" ? (
        <img
          src={item.url}
          alt={item.name}
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="h-full w-full bg-muted flex flex-col items-center justify-center">
          {item.type === "video" ? (
            <Video className="h-8 w-8 text-muted-foreground mb-2" />
          ) : (
            <Music className="h-8 w-8 text-muted-foreground mb-2" />
          )}
          <span className="text-xs text-muted-foreground px-2 text-center truncate w-full">
            {item.name}
          </span>
        </div>
      )}

      {/* Selection indicator */}
      {isSelected && (
        <div className="absolute top-2 left-2 h-5 w-5 rounded-full bg-primary flex items-center justify-center">
          <Check className="h-3 w-3 text-primary-foreground" />
        </div>
      )}

      {/* Delete button */}
      <Button
        variant="destructive"
        size="icon"
        className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
      >
        <Trash2 className="h-3 w-3" />
      </Button>

      {/* Name overlay */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2">
        <p className="text-xs text-white truncate">{item.name}</p>
      </div>
    </div>
  );
}

// List Item Component
export function MediaListItem({
  item,
  isSelected,
  onSelect,
  onDelete,
}: {
  item: MediaItem;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all",
        isSelected
          ? "border-primary bg-primary/5"
          : "border-transparent hover:bg-muted/50"
      )}
      onClick={onSelect}
    >
      <div className="h-12 w-12 rounded bg-muted flex items-center justify-center overflow-hidden shrink-0">
        {item.type === "image" ? (
          <img
            src={item.url}
            alt={item.name}
            className="h-full w-full object-cover"
          />
        ) : item.type === "video" ? (
          <Video className="h-6 w-6 text-muted-foreground" />
        ) : (
          <Music className="h-6 w-6 text-muted-foreground" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{item.name}</p>
        <p className="text-xs text-muted-foreground">
          {item.type} • {formatFileSize(item.size)}
        </p>
      </div>

      {isSelected && <Check className="h-5 w-5 text-primary shrink-0" />}

      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}

// Utility functions
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
