"use client";

import { useCallback, useState } from "react";
import { NodeViewWrapper, type NodeViewProps } from "@tiptap/react";
import { cn } from "@/lib/utils";
import {
  ClipboardList,
  Trash2,
  Settings2,
  Clock,
  Target,
  HelpCircle,
  GripVertical,
  ExternalLink,
  Play,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import type { QuizBlockAttributes } from "./quiz-extension";

interface QuizNodeComponentProps extends NodeViewProps {
  // Additional props if needed
}

export function QuizNodeComponent({
  node,
  updateAttributes,
  deleteNode,
  selected,
  editor,
}: QuizNodeComponentProps) {
  const attrs = node.attrs as QuizBlockAttributes;
  const {
    quizId,
    quizTitle,
    quizTitleAr,
    questionCount,
    passingScore,
    timeLimit,
    isChapterQuiz,
  } = attrs;

  const [showControls, setShowControls] = useState(false);
  const isEditable = editor?.isEditable ?? false;

  const handleMouseEnter = useCallback(() => {
    if (isEditable) {
      setShowControls(true);
    }
  }, [isEditable]);

  const handleMouseLeave = useCallback(() => {
    setShowControls(false);
  }, []);

  const handleDelete = useCallback(() => {
    deleteNode();
  }, [deleteNode]);

  // Format time display
  const formatTime = (minutes: number | null | undefined) => {
    if (!minutes) return null;
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
    }
    return `${minutes}m`;
  };

  return (
    <NodeViewWrapper
      className={cn(
        "quiz-block-wrapper my-4",
        selected && "ring-2 ring-primary ring-offset-2"
      )}
      data-drag-handle
    >
      <div
        className={cn(
          "relative rounded-lg border-2 border-dashed transition-all",
          isChapterQuiz
            ? "border-amber-400 bg-amber-50 dark:bg-amber-950/20"
            : "border-primary/40 bg-primary/5",
          selected && "border-primary",
          !isEditable && "cursor-pointer hover:border-primary/60"
        )}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {/* Control bar (editor mode only) */}
        {isEditable && showControls && (
          <div className="absolute -top-3 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1 rounded-md border bg-background px-2 py-1 shadow-sm">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 cursor-grab"
                  data-drag-handle
                >
                  <GripVertical className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Drag to move</TooltipContent>
            </Tooltip>

            <div className="h-4 w-px bg-border" />

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-destructive hover:text-destructive"
                  onClick={handleDelete}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Remove quiz</TooltipContent>
            </Tooltip>
          </div>
        )}

        {/* Quiz content */}
        <div className="flex items-start gap-4 p-4">
          {/* Icon */}
          <div
            className={cn(
              "flex h-12 w-12 shrink-0 items-center justify-center rounded-lg",
              isChapterQuiz
                ? "bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400"
                : "bg-primary/10 text-primary"
            )}
          >
            <ClipboardList className="h-6 w-6" />
          </div>

          {/* Info */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h4 className="truncate font-semibold text-foreground">
                {quizTitle || "Untitled Quiz"}
              </h4>
              {isChapterQuiz && (
                <Badge variant="outline" className="border-amber-400 text-amber-600 dark:text-amber-400">
                  Chapter Quiz
                </Badge>
              )}
            </div>

            {quizTitleAr && (
              <p className="mt-0.5 truncate text-sm text-muted-foreground" dir="rtl">
                {quizTitleAr}
              </p>
            )}

            {/* Stats row */}
            <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <HelpCircle className="h-3.5 w-3.5" />
                {questionCount} question{questionCount !== 1 ? "s" : ""}
              </span>

              <span className="flex items-center gap-1">
                <Target className="h-3.5 w-3.5" />
                {passingScore}% to pass
              </span>

              {timeLimit && (
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  {formatTime(timeLimit)}
                </span>
              )}
            </div>
          </div>

          {/* Action button (preview mode - for students) */}
          {!isEditable && (
            <Button
              variant={isChapterQuiz ? "default" : "outline"}
              size="sm"
              className={cn(
                "shrink-0",
                isChapterQuiz && "bg-amber-500 hover:bg-amber-600 text-white"
              )}
            >
              <Play className="mr-1.5 h-3.5 w-3.5" />
              Start Quiz
            </Button>
          )}
        </div>

        {/* Chapter quiz indicator bar */}
        {isChapterQuiz && (
          <div className="border-t border-amber-200 bg-amber-100/50 px-4 py-2 text-xs text-amber-700 dark:border-amber-800 dark:bg-amber-900/20 dark:text-amber-400">
            Complete this quiz to unlock the next chapter
          </div>
        )}
      </div>
    </NodeViewWrapper>
  );
}
