"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { MediaAlignment } from "../resizable-media-extension";
import {
  MAX_MEDIA_WIDTH_PX,
  MAX_MEDIA_HEIGHT_PX,
  type ResizeDirection,
  type ResizeState,
} from "./media-resize-constants";

interface UseMediaResizeOptions {
  width: string;
  height: string;
  alignment: MediaAlignment;
  containerRef: React.RefObject<HTMLDivElement>;
  updateAttributes: (attrs: Record<string, unknown>) => void;
}

export function useMediaResize({
  width,
  height,
  alignment,
  containerRef,
  updateAttributes,
}: UseMediaResizeOptions) {
  const [isResizing, setIsResizing] = useState(false);
  const [currentWidth, setCurrentWidth] = useState(width);
  const [currentHeight, setCurrentHeight] = useState(height || "auto");

  const resizeStateRef = useRef<ResizeState>({
    startX: 0,
    startY: 0,
    startWidth: 0,
    startHeight: 0,
    maxWidth: 600,
    direction: "right",
    currentWidth: width,
    currentHeight: height || "auto",
  });

  // Clamp dimension to max pixels
  const clampToMax = useCallback((value: number, max: number): number => {
    return Math.min(Math.max(50, value), max);
  }, []);

  // Get the editor/parent container width for percentage calculations
  // Capped at MAX_MEDIA_WIDTH_PX to ensure media fits on printed page
  const getEditorWidth = useCallback(() => {
    if (!containerRef.current) return MAX_MEDIA_WIDTH_PX;
    // Go up to find the ProseMirror editor container
    let parent: HTMLElement | null = containerRef.current.parentElement;
    while (parent && !parent.classList.contains("ProseMirror")) {
      parent = parent.parentElement;
    }
    const editorWidth =
      parent?.clientWidth ||
      containerRef.current.parentElement?.parentElement?.clientWidth ||
      MAX_MEDIA_WIDTH_PX;
    // Cap at max page width to ensure WYSIWYG with print
    return Math.min(editorWidth, MAX_MEDIA_WIDTH_PX);
  }, [containerRef]);

  // Resolve a dimension value to pixels
  // Accepts: "300px", "80%", "auto", or plain number "300"
  // Rejects invalid strings and returns null
  const resolveDimension = useCallback(
    (value: string, maxPx: number, allowAuto: boolean = true): string | null => {
      const trimmed = value.trim().toLowerCase();

      // Allow "auto" for height
      if (trimmed === "auto" && allowAuto) {
        return "auto";
      }

      // Handle percentage - resolve to pixels
      if (trimmed.endsWith("%")) {
        const percent = parseFloat(trimmed);
        if (isNaN(percent) || percent <= 0) return null;
        const resolved = Math.round((percent / 100) * maxPx);
        return `${clampToMax(resolved, maxPx)}px`;
      }

      // Handle pixel value
      if (trimmed.endsWith("px")) {
        const px = parseFloat(trimmed);
        if (isNaN(px) || px <= 0) return null;
        return `${clampToMax(Math.round(px), maxPx)}px`;
      }

      // Handle plain number (treat as pixels)
      const num = parseFloat(trimmed);
      if (!isNaN(num) && num > 0) {
        return `${clampToMax(Math.round(num), maxPx)}px`;
      }

      // Invalid value
      return null;
    },
    [clampToMax]
  );

  // Apply size with validation and resolution
  const applySize = useCallback(
    (newWidth: string, newHeight: string) => {
      const editorWidth = getEditorWidth();

      // Resolve width (no auto allowed for width)
      const resolvedWidth = resolveDimension(newWidth, editorWidth, false);
      // Resolve height (auto allowed)
      const resolvedHeight = resolveDimension(newHeight, MAX_MEDIA_HEIGHT_PX, true);

      // Use resolved values or keep current if invalid
      const finalWidth = resolvedWidth || currentWidth;
      const finalHeight = resolvedHeight || currentHeight;

      setCurrentWidth(finalWidth);
      setCurrentHeight(finalHeight);
      updateAttributes({ width: finalWidth, height: finalHeight });
    },
    [resolveDimension, getEditorWidth, currentWidth, currentHeight, updateAttributes]
  );

  // Parse dimension to pixels for resizing
  const parseDimension = useCallback(
    (value: string, maxValue: number) => {
      if (value.endsWith("%")) {
        const percent = parseFloat(value) / 100;
        return maxValue * percent;
      }
      if (value === "auto") {
        // Get actual rendered height
        const mediaEl = containerRef.current?.querySelector("img, video, iframe");
        return mediaEl?.getBoundingClientRect().height || 300;
      }
      return parseFloat(value) || 300;
    },
    [containerRef]
  );

  // Mouse move handler
  const handleMouseMove = useCallback(
    (moveEvent: MouseEvent) => {
      const state = resizeStateRef.current;
      const deltaX = moveEvent.clientX - state.startX;
      const deltaY = moveEvent.clientY - state.startY;
      const dir = state.direction;

      // Handle width changes - capped to page width
      if (
        dir === "left" ||
        dir === "right" ||
        dir.includes("left") ||
        dir.includes("right")
      ) {
        const xMultiplier =
          dir === "left" || dir === "top-left" || dir === "bottom-left" ? -1 : 1;
        const centerMultiplier = alignment === "center" ? 2 : 1;
        const maxWidth = Math.min(state.maxWidth, MAX_MEDIA_WIDTH_PX);
        const newWidth = Math.max(
          100,
          Math.min(maxWidth, state.startWidth + deltaX * xMultiplier * centerMultiplier)
        );
        const newWidthStr = `${Math.round(newWidth)}px`;
        setCurrentWidth(newWidthStr);
        state.currentWidth = newWidthStr;
      }

      // Handle height changes - capped to fit on a page
      if (dir === "bottom" || dir.includes("bottom") || dir.includes("top")) {
        const yMultiplier = dir.includes("top") ? -1 : 1;
        const newHeight = Math.max(
          50,
          Math.min(MAX_MEDIA_HEIGHT_PX, state.startHeight + deltaY * yMultiplier)
        );
        const newHeightStr = `${Math.round(newHeight)}px`;
        setCurrentHeight(newHeightStr);
        state.currentHeight = newHeightStr;
      }
    },
    [alignment]
  );

  // Mouse up handler
  const handleMouseUp = useCallback(() => {
    setIsResizing(false);
    const state = resizeStateRef.current;
    const updates: Record<string, string> = {};

    if (state.currentWidth !== width) {
      updates["width"] = state.currentWidth;
    }
    if (state.currentHeight !== height) {
      updates["height"] = state.currentHeight;
    }

    if (Object.keys(updates).length > 0) {
      updateAttributes(updates);
    }

    document.removeEventListener("mousemove", handleMouseMove);
    document.removeEventListener("mouseup", handleMouseUp);
  }, [updateAttributes, handleMouseMove, width, height]);

  // Start resize
  const handleResizeStart = useCallback(
    (e: React.MouseEvent, direction: ResizeDirection) => {
      e.preventDefault();
      e.stopPropagation();

      const editorWidth = getEditorWidth();

      // Store initial state in ref
      resizeStateRef.current = {
        startX: e.clientX,
        startY: e.clientY,
        startWidth: parseDimension(currentWidth, editorWidth),
        startHeight: parseDimension(currentHeight, 1000),
        maxWidth: editorWidth,
        direction,
        currentWidth: currentWidth,
        currentHeight: currentHeight,
      };

      setIsResizing(true);

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [parseDimension, getEditorWidth, currentWidth, currentHeight, handleMouseMove, handleMouseUp]
  );

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  // Sync and resolve currentWidth/currentHeight with props
  // This converts % and validates values on mount and prop changes
  useEffect(() => {
    const editorWidth = getEditorWidth();
    const resolved = resolveDimension(width, editorWidth, false);
    const finalWidth = resolved || `${MAX_MEDIA_WIDTH_PX}px`;
    setCurrentWidth(finalWidth);
    resizeStateRef.current.currentWidth = finalWidth;
    // Update attribute if it was resolved differently
    if (resolved && resolved !== width) {
      updateAttributes({ width: resolved });
    }
  }, [width, getEditorWidth, resolveDimension, updateAttributes]);

  useEffect(() => {
    const resolved = resolveDimension(height || "auto", MAX_MEDIA_HEIGHT_PX, true);
    const finalHeight = resolved || "auto";
    setCurrentHeight(finalHeight);
    // Update attribute if it was resolved differently
    if (resolved && resolved !== height) {
      updateAttributes({ height: resolved });
    }
  }, [height, resolveDimension, updateAttributes]);

  return {
    isResizing,
    currentWidth,
    currentHeight,
    setCurrentWidth,
    setCurrentHeight,
    handleResizeStart,
    applySize,
  };
}
