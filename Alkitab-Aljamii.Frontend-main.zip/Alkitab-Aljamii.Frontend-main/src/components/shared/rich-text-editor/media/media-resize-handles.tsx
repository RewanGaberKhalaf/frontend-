"use client";

import { cn } from "@/lib/utils";
import type { ResizeDirection } from "./media-resize-constants";

interface MediaResizeHandlesProps {
  visible: boolean;
  isResizing: boolean;
  onResizeStart: (e: React.MouseEvent, direction: ResizeDirection) => void;
}

export function MediaResizeHandles({
  visible,
  isResizing,
  onResizeStart,
}: MediaResizeHandlesProps) {
  if (!visible) return null;

  return (
    <>
      {/* Left Handle - width only */}
      <div
        className={cn(
          "absolute left-0 top-0 bottom-0 w-3 cursor-ew-resize",
          "flex items-center justify-center",
          "opacity-0 group-hover:opacity-100 transition-opacity",
          isResizing && "opacity-100"
        )}
        onMouseDown={(e) => onResizeStart(e, "left")}
      >
        <div className="h-12 w-1.5 bg-primary/50 rounded-full hover:bg-primary" />
      </div>

      {/* Right Handle - width only */}
      <div
        className={cn(
          "absolute right-0 top-0 bottom-0 w-3 cursor-ew-resize",
          "flex items-center justify-center",
          "opacity-0 group-hover:opacity-100 transition-opacity",
          isResizing && "opacity-100"
        )}
        onMouseDown={(e) => onResizeStart(e, "right")}
      >
        <div className="h-12 w-1.5 bg-primary/50 rounded-full hover:bg-primary" />
      </div>

      {/* Bottom Handle - height only */}
      <div
        className={cn(
          "absolute bottom-0 left-0 right-0 h-3 cursor-ns-resize",
          "flex items-center justify-center",
          "opacity-0 group-hover:opacity-100 transition-opacity",
          isResizing && "opacity-100"
        )}
        onMouseDown={(e) => onResizeStart(e, "bottom")}
      >
        <div className="w-12 h-1.5 bg-primary/50 rounded-full hover:bg-primary" />
      </div>

      {/* Bottom-Right Corner */}
      <div
        className={cn(
          "absolute bottom-0 right-0 w-4 h-4 cursor-nwse-resize",
          "opacity-0 group-hover:opacity-100 transition-opacity",
          isResizing && "opacity-100"
        )}
        onMouseDown={(e) => onResizeStart(e, "bottom-right")}
      >
        <div className="absolute bottom-1 right-1 w-2.5 h-2.5 bg-primary/70 rounded-sm hover:bg-primary" />
      </div>

      {/* Bottom-Left Corner */}
      <div
        className={cn(
          "absolute bottom-0 left-0 w-4 h-4 cursor-nesw-resize",
          "opacity-0 group-hover:opacity-100 transition-opacity",
          isResizing && "opacity-100"
        )}
        onMouseDown={(e) => onResizeStart(e, "bottom-left")}
      >
        <div className="absolute bottom-1 left-1 w-2.5 h-2.5 bg-primary/70 rounded-sm hover:bg-primary" />
      </div>
    </>
  );
}
