"use client";

import { cn } from "@/lib/utils";
import {
  AlignLeft,
  AlignCenter,
  AlignRight,
  Trash2,
  GripVertical,
  PanelLeft,
  PanelRight,
  Square,
  Settings2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { MediaAlignment, MediaFloat } from "../resizable-media-extension";
import { MAX_MEDIA_WIDTH_PX, MAX_MEDIA_HEIGHT_PX } from "./media-resize-constants";

interface MediaControlBarProps {
  visible: boolean;
  alignment: MediaAlignment;
  float: MediaFloat;
  currentWidth: string;
  currentHeight: string;
  sizePopoverOpen: boolean;
  onSizePopoverOpenChange: (open: boolean) => void;
  onAlignmentChange: (alignment: MediaAlignment, float: MediaFloat) => void;
  onFloatChange: (float: MediaFloat, alignment?: MediaAlignment) => void;
  onWidthChange: (width: string) => void;
  onHeightChange: (height: string) => void;
  onApplySize: (width: string, height: string) => void;
  onDelete: () => void;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
}

export function MediaControlBar({
  visible,
  alignment,
  float,
  currentWidth,
  currentHeight,
  sizePopoverOpen,
  onSizePopoverOpenChange,
  onAlignmentChange,
  onFloatChange,
  onWidthChange,
  onHeightChange,
  onApplySize,
  onDelete,
  onMouseEnter,
  onMouseLeave,
}: MediaControlBarProps) {
  if (!visible) return null;

  return (
    <div
      className={cn(
        "absolute top-2 left-1/2 -translate-x-1/2 z-10",
        "flex items-center gap-1 p-1 rounded-lg",
        "bg-background/95 backdrop-blur-sm border shadow-lg",
        "transition-opacity",
        visible ? "opacity-100" : "opacity-0"
      )}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      {/* Alignment Controls */}
      <div className="flex items-center border-r pr-1 mr-1">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={alignment === "left" && float === "none" ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => onAlignmentChange("left", "none")}
            >
              <AlignLeft className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Align Left</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={alignment === "center" && float === "none" ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => onAlignmentChange("center", "none")}
            >
              <AlignCenter className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Center</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={alignment === "right" && float === "none" ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => onAlignmentChange("right", "none")}
            >
              <AlignRight className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Align Right</TooltipContent>
        </Tooltip>
      </div>

      {/* Float Controls */}
      <div className="flex items-center border-r pr-1 mr-1">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={float === "left" ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => onFloatChange("left", "left")}
            >
              <PanelLeft className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Float Left (text wraps)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={float === "none" ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => onFloatChange("none")}
            >
              <Square className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>No Float (inline)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={float === "right" ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => onFloatChange("right", "right")}
            >
              <PanelRight className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Float Right (text wraps)</TooltipContent>
        </Tooltip>
      </div>

      {/* Size Settings */}
      <Popover open={sizePopoverOpen} onOpenChange={onSizePopoverOpenChange}>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" className="h-7 px-2 gap-1 text-xs">
            <Settings2 className="h-3.5 w-3.5" />
            <span className="text-muted-foreground">
              {currentWidth}
              {currentHeight !== "auto" ? ` × ${currentHeight}` : ""}
            </span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64" align="center" side="top" sideOffset={8}>
          <div className="space-y-3">
            <div>
              <div className="text-sm font-medium">Size</div>
              <div className="text-xs text-muted-foreground">
                Max: {MAX_MEDIA_WIDTH_PX}×{MAX_MEDIA_HEIGHT_PX}px
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label htmlFor="media-width" className="text-xs">
                  Width
                </Label>
                <Input
                  id="media-width"
                  value={currentWidth}
                  onChange={(e) => onWidthChange(e.target.value)}
                  onBlur={() => onApplySize(currentWidth, currentHeight)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      onApplySize(currentWidth, currentHeight);
                      onSizePopoverOpenChange(false);
                    }
                  }}
                  placeholder="100%, 300px"
                  className="h-8 text-sm"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="media-height" className="text-xs">
                  Height
                </Label>
                <Input
                  id="media-height"
                  value={currentHeight}
                  onChange={(e) => onHeightChange(e.target.value)}
                  onBlur={() => onApplySize(currentWidth, currentHeight)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      onApplySize(currentWidth, currentHeight);
                      onSizePopoverOpenChange(false);
                    }
                  }}
                  placeholder="auto, 200px"
                  className="h-8 text-sm"
                />
              </div>
            </div>
            <div className="flex gap-1 flex-wrap">
              <Button
                variant="outline"
                size="sm"
                className="h-6 text-xs px-2"
                onClick={() =>
                  onApplySize(`${MAX_MEDIA_WIDTH_PX}px`, `${MAX_MEDIA_HEIGHT_PX}px`)
                }
              >
                Full Page
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-6 text-xs px-2"
                onClick={() => onApplySize(`${MAX_MEDIA_WIDTH_PX}px`, "361px")}
              >
                Wide 16:9
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-6 text-xs px-2"
                onClick={() => onApplySize("320px", "180px")}
              >
                Small
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-6 text-xs px-2"
                onClick={() => onApplySize("480px", "270px")}
              >
                Medium
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {/* Delete Button */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-destructive hover:text-destructive"
            onClick={onDelete}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>Delete</TooltipContent>
      </Tooltip>

      {/* Drag Handle */}
      <div className="cursor-grab active:cursor-grabbing px-1">
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </div>
    </div>
  );
}
