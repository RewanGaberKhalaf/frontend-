"use client";

import { AlertTriangle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { resolveMediaUrl } from "@/lib/api";
import { MAX_MEDIA_WIDTH_PX, MAX_MEDIA_HEIGHT_PX } from "./media-resize-constants";

interface MediaContentProps {
  src: string;
  mediaId?: string;
  mediaType: "image" | "video" | "audio" | "iframe";
  alt?: string;
  title?: string;
  currentHeight: string;
  isLoadError: boolean;
  isRefreshing: boolean;
  onRefreshUrl: () => void;
  onMediaError: () => void;
}

export function MediaContent({
  src,
  mediaId,
  mediaType,
  alt,
  title,
  currentHeight,
  isLoadError,
  isRefreshing,
  onRefreshUrl,
  onMediaError,
}: MediaContentProps) {
  // Resolve relative URLs to full backend URLs
  const resolvedSrc = resolveMediaUrl(src);

  // When height is "auto", let media use natural aspect ratio
  // but still enforce max dimensions
  const isAutoHeight = currentHeight === "auto";
  const mediaStyle: React.CSSProperties = {
    width: "100%",
    height: isAutoHeight ? "auto" : "100%",
    maxWidth: MAX_MEDIA_WIDTH_PX,
    maxHeight: MAX_MEDIA_HEIGHT_PX,
    objectFit: isAutoHeight ? "contain" : "fill",
    display: "block", // Prevent inline spacing issues
  };

  // Show error state with refresh option
  if (isLoadError && !isRefreshing) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 p-6 bg-muted/50 rounded-lg min-h-[100px]">
        <AlertTriangle className="h-8 w-8 text-amber-500" />
        <span className="text-sm text-muted-foreground text-center">
          {mediaId
            ? "Media failed to load. Click to refresh the URL."
            : "Media URL expired. Please delete and re-insert from media library."}
        </span>
        {mediaId ? (
          <Button variant="outline" size="sm" onClick={onRefreshUrl} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Refresh URL
          </Button>
        ) : (
          <span className="text-xs text-muted-foreground">
            (Old media without refresh capability)
          </span>
        )}
      </div>
    );
  }

  // Show loading state while refreshing
  if (isRefreshing) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 p-6 bg-muted/50 rounded-lg min-h-[100px]">
        <RefreshCw className="h-8 w-8 text-primary animate-spin" />
        <span className="text-sm text-muted-foreground">Refreshing URL...</span>
      </div>
    );
  }

  switch (mediaType) {
    case "image":
      return (
        <img
          src={resolvedSrc}
          alt={alt || ""}
          title={title}
          className="rounded"
          style={mediaStyle}
          draggable={false}
          onError={onMediaError}
        />
      );
    case "video":
      return (
        <video
          src={resolvedSrc}
          controls
          className="rounded"
          style={mediaStyle}
          draggable={false}
          onError={onMediaError}
        />
      );
    case "audio":
      return (
        <audio
          src={resolvedSrc}
          controls
          className="w-full"
          draggable={false}
          onError={onMediaError}
        />
      );
    case "iframe":
      return (
        <iframe
          src={resolvedSrc}
          frameBorder="0"
          allowFullScreen
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          className="rounded"
          style={mediaStyle}
          draggable={false}
          onError={onMediaError}
        />
      );
    default:
      return null;
  }
}
