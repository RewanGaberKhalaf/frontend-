// Max dimensions to fit within a printed page (A4 with margins)
// A4: 210mm x 297mm, with 20mm side margins and 25mm top/bottom
// Content area: 170mm x 247mm
// At 96 DPI: 1mm = 3.7795px
export const MAX_MEDIA_WIDTH_PX = 642; // 170mm
export const MAX_MEDIA_HEIGHT_PX = 933; // 247mm (297 - 25 - 25)

export type ResizeDirection =
  | "left"
  | "right"
  | "bottom"
  | "top-left"
  | "top-right"
  | "bottom-left"
  | "bottom-right";

export interface ResizeState {
  startX: number;
  startY: number;
  startWidth: number;
  startHeight: number;
  maxWidth: number;
  direction: ResizeDirection;
  currentWidth: string;
  currentHeight: string;
}
