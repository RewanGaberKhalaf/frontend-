"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { mediaUrlManager } from "@/lib/media-url-manager";

interface UseMediaUrlRefreshOptions {
  mediaId?: string;
  src: string;
  updateAttributes: (attrs: Record<string, unknown>) => void;
}

export function useMediaUrlRefresh({
  mediaId,
  src,
  updateAttributes,
}: UseMediaUrlRefreshOptions) {
  const [isLoadError, setIsLoadError] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const refreshAttempts = useRef(0);
  const maxRefreshAttempts = 2;

  // Refresh signed URL when it expires - uses centralized manager for deduplication/rate limiting
  const refreshSignedUrl = useCallback(async () => {
    if (!mediaId || isRefreshing) return;

    setIsRefreshing(true);
    try {
      // Use the centralized manager which handles deduplication and rate limiting
      const newUrl = await mediaUrlManager.refreshUrl(mediaId);
      if (newUrl && newUrl !== src) {
        updateAttributes({ src: newUrl });
        setIsLoadError(false);
      } else if (!newUrl) {
        // Refresh failed (rate limited or max attempts)
        // Keep error state but don't retry
        console.log(`[ResizableMedia] URL refresh failed for ${mediaId}`);
      }
    } catch (error) {
      console.error("Failed to refresh signed URL:", error);
      // Keep error state if refresh fails
    } finally {
      setIsRefreshing(false);
    }
  }, [mediaId, isRefreshing, updateAttributes, src]);

  // Handle media load error - try to refresh URL if mediaId is available
  const handleMediaError = useCallback(() => {
    // Don't set error or retry if we're currently refreshing
    if (isRefreshing) return;

    setIsLoadError(true);
    // Auto-refresh if we have mediaId and haven't exceeded max attempts
    if (mediaId && refreshAttempts.current < maxRefreshAttempts) {
      refreshAttempts.current += 1;
      refreshSignedUrl();
    }
  }, [mediaId, refreshSignedUrl, isRefreshing]);

  // Reset error state when src changes (e.g., after successful refresh)
  // Also pre-cache the URL if we have a mediaId
  useEffect(() => {
    setIsLoadError(false);
    // Pre-cache the current URL so other components with same mediaId can use it
    if (mediaId && src) {
      mediaUrlManager.cacheUrl(mediaId, src);
    }
    // Don't reset attempts here - we want to limit total attempts per session
  }, [src, mediaId]);

  return {
    isLoadError,
    isRefreshing,
    refreshSignedUrl,
    handleMediaError,
  };
}
