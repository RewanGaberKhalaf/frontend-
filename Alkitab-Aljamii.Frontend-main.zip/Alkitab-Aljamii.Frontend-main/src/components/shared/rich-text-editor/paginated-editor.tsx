"use client";

import { useEditor, EditorContent, type Editor } from "@tiptap/react";
import { useEffect, useMemo, useRef, useState, forwardRef, useImperativeHandle } from "react";
import * as Y from "yjs";
import { getEditorExtensions } from "./extensions";
import { EditorToolbar } from "./editor-toolbar";
import { cn } from "@/lib/utils";

// A4 at 96 DPI: 794 x 1123 pixels
// 1 inch margins = 96px
const PAGE_WIDTH = 794;
const PAGE_HEIGHT = 1123;
const PAGE_MARGIN = 96;

export interface PaginatedEditorProps {
  content?: string;
  onUpdate?: (html: string) => void;
  placeholder?: string;
  editable?: boolean;
  className?: string;
  ydoc?: Y.Doc;
  fragmentName?: string;
  onPageCountChange?: (count: number) => void;
}

export interface PaginatedEditorRef {
  editor: Editor | null;
  ydoc: Y.Doc;
}

/**
 * Google Docs-style paginated editor
 *
 * Approach: Single continuous editor with page frame backgrounds.
 * Content flows naturally, and we visually render page backgrounds
 * at the appropriate positions. The editor content sits on top of
 * the page backgrounds and is allowed to overflow.
 *
 * To create the "gap" between pages visually, we use CSS to add
 * padding/margin at page boundaries via the PageBreakExtension decorations.
 */
export const PaginatedEditor = forwardRef<PaginatedEditorRef, PaginatedEditorProps>(
  function PaginatedEditor(
    {
      content = "",
      onUpdate,
      placeholder = "Start writing...",
      editable = true,
      className,
      ydoc: externalYdoc,
      fragmentName = "prosemirror",
      onPageCountChange,
    },
    ref
  ) {
    const [pageCount, setPageCount] = useState(1);
    const contentRef = useRef<HTMLDivElement>(null);

    // Create or use external Yjs document
    const ydoc = useMemo(() => externalYdoc || new Y.Doc(), [externalYdoc]);
    const yXmlFragment = useMemo(
      () => ydoc.getXmlFragment(fragmentName),
      [ydoc, fragmentName]
    );

    // Get extensions with page breaks enabled for visual decoration
    const extensions = useMemo(() => {
      return getEditorExtensions({
        placeholder,
        yFragment: yXmlFragment,
        enablePageBreaks: true,
        onPageCountChange: (count) => {
          setPageCount(count);
          onPageCountChange?.(count);
        },
      });
    }, [placeholder, yXmlFragment, onPageCountChange]);

    const editor = useEditor({
      extensions,
      editable,
      immediatelyRender: false,
      editorProps: {
        attributes: {
          class: "outline-none paginated-editor-content",
        },
      },
      onUpdate: ({ editor }) => {
        const html = editor.getHTML();
        onUpdate?.(html);
      },
    });

    // Expose editor via ref
    useImperativeHandle(ref, () => ({ editor, ydoc }), [editor, ydoc]);

    // Set initial content
    useEffect(() => {
      if (editor && content && yXmlFragment.length === 0) {
        editor.commands.setContent(content);
      }
    }, [editor, content, yXmlFragment]);

    // Cleanup Yjs
    useEffect(() => {
      return () => {
        if (!externalYdoc) {
          ydoc.destroy();
        }
      };
    }, [ydoc, externalYdoc]);

    return (
      <div className={cn("flex flex-col h-full", className)}>
        {/* Toolbar */}
        <div className="sticky top-0 z-20 bg-background border-b shadow-sm">
          <EditorToolbar editor={editor} />
        </div>

        {/* Page canvas - scrollable area with gray background */}
        <div className="flex-1 overflow-auto paginated-canvas">
          <div className="py-8 flex justify-center">
            {/* Single page paper container */}
            <div
              className="paginated-document"
              style={{ width: PAGE_WIDTH }}
            >
              {/* The page paper with shadow */}
              <div
                ref={contentRef}
                className="page-paper bg-white dark:bg-zinc-950"
                style={{
                  width: PAGE_WIDTH,
                  minHeight: PAGE_HEIGHT,
                  padding: `${PAGE_MARGIN}px`,
                  boxShadow: "0 1px 3px rgba(0,0,0,0.12), 0 2px 6px rgba(0,0,0,0.08)",
                }}
              >
                <EditorContent
                  editor={editor}
                  className="paginated-editor"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Page count indicator */}
        <div className="absolute bottom-4 right-4 text-xs text-muted-foreground bg-background/80 px-2 py-1 rounded">
          {pageCount} {pageCount === 1 ? "page" : "pages"}
        </div>
      </div>
    );
  }
);

export default PaginatedEditor;
