"use client";

import { Extension } from "@tiptap/core";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";
import type { EditorView } from "@tiptap/pm/view";

// A4 dimensions at 96 DPI
// A4 = 210mm × 297mm = 794px × 1123px
// Word default margins: 1 inch (96px) all sides
const PAGE_HEIGHT = 1123;
const PAGE_MARGIN = 96; // 1 inch margins
const CONTENT_HEIGHT_PER_PAGE = PAGE_HEIGHT - PAGE_MARGIN * 2; // 931px
const PAGE_GAP = 40;

export interface PageBreakOptions {
  enabled: boolean;
  pageContentHeight?: number;
  pageGap?: number;
  onPageCountChange?: (count: number) => void;
}

const pluginKey = new PluginKey("pageBreak");

export const PageBreakExtension = Extension.create<PageBreakOptions>({
  name: "pageBreak",

  addOptions() {
    return {
      enabled: true,
      pageContentHeight: CONTENT_HEIGHT_PER_PAGE,
      pageGap: PAGE_GAP,
      onPageCountChange: undefined,
    };
  },

  addProseMirrorPlugins() {
    const options = this.options;

    return [
      new Plugin({
        key: pluginKey,
        state: {
          init() {
            return { decorations: DecorationSet.empty, pageCount: 1 };
          },
          apply(tr, value) {
            const meta = tr.getMeta(pluginKey);
            if (meta) {
              return meta;
            }
            // Map decorations through document changes
            return {
              decorations: value.decorations.map(tr.mapping, tr.doc),
              pageCount: value.pageCount,
            };
          },
        },
        props: {
          decorations(state) {
            return this.getState(state)?.decorations ?? DecorationSet.empty;
          },
        },
        view(editorView: EditorView) {
          let rafId: number | null = null;
          let lastPageCount = 1;

          const calculatePageBreaks = () => {
            if (!options.enabled) return;

            const { state } = editorView;
            const decorations: Decoration[] = [];
            const editorDom = editorView.dom;

            if (!editorDom || typeof window === "undefined") return;

            const { pageContentHeight = CONTENT_HEIGHT_PER_PAGE, pageGap = PAGE_GAP } = options;

            // Get all top-level block elements
            const children = Array.from(editorDom.children).filter(
              (el) => !el.classList.contains("page-break-widget")
            );

            let accumulatedHeight = 0;
            let currentPage = 1;
            const breakPositions: { pos: number; page: number }[] = [];

            for (const child of children) {
              const el = child as HTMLElement;

              // Skip page break widgets we've inserted
              if (el.dataset["pageBreak"]) continue;

              const style = getComputedStyle(el);
              const marginTop = parseFloat(style.marginTop) || 0;
              const marginBottom = parseFloat(style.marginBottom) || 0;
              const height = el.offsetHeight + marginTop + marginBottom;

              // Would this element overflow the current page?
              if (accumulatedHeight > 0 && accumulatedHeight + height > pageContentHeight) {
                // Get document position for this element
                try {
                  const pos = editorView.posAtDOM(el, 0);
                  if (pos > 0 && pos < state.doc.content.size) {
                    breakPositions.push({ pos, page: currentPage + 1 });
                    currentPage++;
                    accumulatedHeight = height;
                  }
                } catch {
                  // posAtDOM can fail for some elements
                  accumulatedHeight += height;
                }
              } else {
                accumulatedHeight += height;
              }
            }

            // Create decorations for page breaks
            for (const { pos, page } of breakPositions) {
              const widget = createPageBreakWidget(page, pageGap);
              decorations.push(
                Decoration.widget(pos, widget, {
                  side: -1,
                  key: `page-break-${page}`,
                })
              );
            }

            const newPageCount = Math.max(1, currentPage);
            const newDecorations = DecorationSet.create(state.doc, decorations);

            // Only update if something changed
            const currentState = pluginKey.getState(state);
            if (
              !currentState?.decorations.eq(newDecorations) ||
              lastPageCount !== newPageCount
            ) {
              lastPageCount = newPageCount;
              options.onPageCountChange?.(newPageCount);

              editorView.dispatch(
                state.tr.setMeta(pluginKey, {
                  decorations: newDecorations,
                  pageCount: newPageCount,
                })
              );
            }
          };

          let debounceTimer: ReturnType<typeof setTimeout> | null = null;

          const scheduleCalculation = () => {
            // Debounce to avoid recalculating on every keystroke
            if (debounceTimer) clearTimeout(debounceTimer);
            if (rafId) cancelAnimationFrame(rafId);

            debounceTimer = setTimeout(() => {
              rafId = requestAnimationFrame(calculatePageBreaks);
            }, 300); // 300ms debounce for page break calculation
          };

          // Initial calculation
          setTimeout(scheduleCalculation, 100);

          return {
            update() {
              scheduleCalculation();
            },
            destroy() {
              if (rafId) cancelAnimationFrame(rafId);
              if (debounceTimer) clearTimeout(debounceTimer);
            },
          };
        },
      }),
    ];
  },
});

/**
 * Creates a visual page break widget like Google Docs.
 * Shows: end of current page (with page number) -> gap -> start of next page
 */
function createPageBreakWidget(pageNumber: number, gap: number): HTMLElement {
  const PAGE_MARGIN = 96;
  const PAGE_WIDTH = 794;

  const widget = document.createElement("div");
  widget.className = "page-break-widget";
  widget.dataset["pageBreak"] = "true";
  widget.contentEditable = "false";

  // Total height: bottom margin + gap + top margin
  const totalHeight = PAGE_MARGIN + gap + PAGE_MARGIN;

  widget.style.cssText = `
    height: ${totalHeight}px;
    margin-left: -${PAGE_MARGIN}px;
    margin-right: -${PAGE_MARGIN}px;
    width: ${PAGE_WIDTH}px;
    position: relative;
    user-select: none;
    pointer-events: none;
    background: var(--canvas-bg, #f3f4f6);
    display: block;
    box-sizing: border-box;
    border: none;
    outline: none;
    overflow: hidden;
  `;

  // Previous page's bottom margin (white area at bottom of page)
  const bottomMargin = document.createElement("div");
  bottomMargin.style.cssText = `
    position: absolute;
    top: 0;
    left: 0;
    width: ${PAGE_WIDTH}px;
    height: ${PAGE_MARGIN}px;
    background: var(--page-bg, white);
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    border: none;
  `;

  // Page number for previous page (centered at bottom)
  const prevPageNum = document.createElement("div");
  prevPageNum.textContent = String(pageNumber - 1);
  prevPageNum.style.cssText = `
    position: absolute;
    bottom: 16px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 12px;
    color: #9ca3af;
    font-family: Arial, sans-serif;
  `;
  bottomMargin.appendChild(prevPageNum);
  widget.appendChild(bottomMargin);

  // Next page's top margin (white area at top of next page)
  const topMargin = document.createElement("div");
  topMargin.style.cssText = `
    position: absolute;
    bottom: 0;
    left: 0;
    width: ${PAGE_WIDTH}px;
    height: ${PAGE_MARGIN}px;
    background: var(--page-bg, white);
    box-shadow: 0 -1px 3px rgba(0,0,0,0.05);
    border: none;
  `;
  widget.appendChild(topMargin);

  return widget;
}

export default PageBreakExtension;
