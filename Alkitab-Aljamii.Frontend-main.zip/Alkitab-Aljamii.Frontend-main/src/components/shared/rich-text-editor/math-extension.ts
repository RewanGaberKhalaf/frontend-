import { Node, mergeAttributes, nodeInputRule } from "@tiptap/core";
import { ReactNodeViewRenderer } from "@tiptap/react";
import { MathNodeView } from "./math-node-view";

// Regex patterns for math input rules
const INLINE_MATH_INPUT_REGEX = /\$([^$]+)\$$/;
const BLOCK_MATH_INPUT_REGEX = /\$\$([^$]+)\$\$$/;

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    mathInline: {
      /**
       * Insert an inline math formula
       */
      insertMathInline: (latex: string) => ReturnType;
      /**
       * Update an inline math formula
       */
      updateMathInline: (latex: string) => ReturnType;
    };
    mathBlock: {
      /**
       * Insert a block math formula
       */
      insertMathBlock: (latex: string) => ReturnType;
      /**
       * Update a block math formula
       */
      updateMathBlock: (latex: string) => ReturnType;
    };
  }
}

/**
 * Inline math extension for TipTap
 * Renders LaTeX formulas inline with text using KaTeX
 */
export const MathInline = Node.create({
  name: "mathInline",

  group: "inline",

  inline: true,

  atom: true,

  addAttributes() {
    return {
      latex: {
        default: "",
        parseHTML: (element) => element.getAttribute("data-latex") || "",
        renderHTML: (attributes) => ({
          "data-latex": attributes["latex"],
        }),
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'span[data-type="math-inline"]',
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      "span",
      mergeAttributes(HTMLAttributes, {
        "data-type": "math-inline",
        class: "math-inline",
      }),
    ];
  },

  addNodeView() {
    return ReactNodeViewRenderer(MathNodeView);
  },

  addCommands() {
    return {
      insertMathInline:
        (latex: string) =>
        ({ commands }) => {
          return commands.insertContent({
            type: this.name,
            attrs: { latex },
          });
        },
      updateMathInline:
        (latex: string) =>
        ({ commands }) => {
          return commands.updateAttributes(this.name, { latex });
        },
    };
  },

  addInputRules() {
    return [
      nodeInputRule({
        find: INLINE_MATH_INPUT_REGEX,
        type: this.type,
        getAttributes: (match) => ({
          latex: match[1],
        }),
      }),
    ];
  },
});

/**
 * Block math extension for TipTap
 * Renders LaTeX formulas as display blocks using KaTeX
 */
export const MathBlock = Node.create({
  name: "mathBlock",

  group: "block",

  atom: true,

  addAttributes() {
    return {
      latex: {
        default: "",
        parseHTML: (element) => element.getAttribute("data-latex") || "",
        renderHTML: (attributes) => ({
          "data-latex": attributes["latex"],
        }),
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'div[data-type="math-block"]',
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      "div",
      mergeAttributes(HTMLAttributes, {
        "data-type": "math-block",
        class: "math-block",
      }),
    ];
  },

  addNodeView() {
    return ReactNodeViewRenderer(MathNodeView);
  },

  addCommands() {
    return {
      insertMathBlock:
        (latex: string) =>
        ({ commands }) => {
          return commands.insertContent({
            type: this.name,
            attrs: { latex },
          });
        },
      updateMathBlock:
        (latex: string) =>
        ({ commands }) => {
          return commands.updateAttributes(this.name, { latex });
        },
    };
  },

  addInputRules() {
    return [
      nodeInputRule({
        find: BLOCK_MATH_INPUT_REGEX,
        type: this.type,
        getAttributes: (match) => ({
          latex: match[1],
        }),
      }),
    ];
  },
});
