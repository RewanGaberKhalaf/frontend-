import * as Y from "yjs";

/**
 * Document structure for chapter-based content
 *
 * Structure: Document > Chapters > Pages > Content
 *
 * Each chapter contains multiple pages, similar to PowerPoint slides.
 * Users edit one page at a time for a focused writing experience.
 */

/**
 * Header/Footer configuration for pages
 * Similar to Word's header/footer system
 */
export interface PageHeaderFooter {
  /** Show header on all pages */
  enabled: boolean;
  /** Header content (HTML) - left aligned text */
  leftContent?: string;
  /** Header content (HTML) - center aligned text */
  centerContent?: string;
  /** Header content (HTML) - right aligned text */
  rightContent?: string;
  /** Show page numbers */
  showPageNumber?: boolean;
  /** Page number position: 'left' | 'center' | 'right' */
  pageNumberPosition?: "left" | "center" | "right";
  /** First page different (don't show header on first page) */
  differentFirstPage?: boolean;
}

export interface DocumentMeta {
  id: string;
  title: string;
  description?: string;
  author?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Resource/Reference attached to a chapter
 */
export interface ChapterResource {
  id: string;
  /** Resource title */
  title: string;
  /** Resource type */
  type: "link" | "file" | "video" | "audio" | "document" | "image";
  /** URL or file path */
  url: string;
  /** Optional description */
  description?: string;
  /** File size in bytes (for uploaded files) */
  fileSize?: number;
  /** MIME type (for files) */
  mimeType?: string;
  /** Order in the resources list */
  order: number;
  /** When the resource was added */
  createdAt: Date;
}

export interface Page {
  id: string;
  /** Order within the chapter (0-indexed) */
  order: number;
  /** HTML content of this page */
  content: string;
  /** Word count for this page */
  wordCount: number;
}

export interface Chapter {
  id: string;
  title: string;
  /** Order in the document (0-indexed) */
  order: number;
  /** Pages within this chapter */
  pages: Page[];
  /** Word count (sum of all pages) */
  wordCount: number;
  /** Resources/references for this chapter */
  resources?: ChapterResource[];
  /** Chapter-specific header (overrides book header if set) */
  header?: PageHeaderFooter;
  createdAt: Date;
  updatedAt: Date;
}

// Legacy Chapter interface for backwards compatibility
export interface LegacyChapter {
  id: string;
  title: string;
  order: number;
  content: string;
  ydocState?: string;
  pageCount: number;
  wordCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface DocumentStructure {
  meta: DocumentMeta;
  chapters: Chapter[];
  /** Total pages across all chapters */
  totalPages: number;
  /** Total words across all chapters */
  totalWords: number;
  /** Book-level header (appears on all pages) */
  header?: PageHeaderFooter;
  /** Book-level footer (appears on all pages) */
  footer?: PageHeaderFooter;
}

// Re-export helper functions and sample document
export {
  createPage,
  createEmptyDocument,
  createChapter,
  estimatePageCount,
  calculateWordCount,
  updateDocumentTotals,
  updateChapterWordCount,
  sampleDocument,
} from './types-helpers';
