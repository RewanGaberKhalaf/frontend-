"use client";

import { Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { PageHeaderFooter } from "./types";

export interface PageSetupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  header?: PageHeaderFooter;
  footer?: PageHeaderFooter;
  onUpdateHeader: (updates: Partial<PageHeaderFooter>) => void;
  onUpdateFooter: (updates: Partial<PageHeaderFooter>) => void;
}

export function PageSetupDialog({
  open,
  onOpenChange,
  header,
  footer,
  onUpdateHeader,
  onUpdateFooter,
}: PageSetupDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Settings className="h-4 w-4 mr-1" />
          Page Setup
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Page Setup</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="header">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="header">Header</TabsTrigger>
            <TabsTrigger value="footer">Footer</TabsTrigger>
          </TabsList>
          <TabsContent value="header" className="space-y-4 pt-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="header-enabled">Enable Header</Label>
              <Switch
                id="header-enabled"
                checked={header?.enabled ?? false}
                onCheckedChange={(checked) => onUpdateHeader({ enabled: checked })}
              />
            </div>
            {header?.enabled && (
              <>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="header-left">Left</Label>
                    <Input
                      id="header-left"
                      placeholder="e.g., Book Title"
                      value={header?.leftContent || ""}
                      onChange={(e) => onUpdateHeader({ leftContent: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="header-center">Center</Label>
                    <Input
                      id="header-center"
                      placeholder="e.g., Chapter Title"
                      value={header?.centerContent || ""}
                      onChange={(e) => onUpdateHeader({ centerContent: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="header-right">Right</Label>
                    <Input
                      id="header-right"
                      placeholder="e.g., Author"
                      value={header?.rightContent || ""}
                      onChange={(e) => onUpdateHeader({ rightContent: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="header-first-page">Different first page (no header)</Label>
                  <Switch
                    id="header-first-page"
                    checked={header?.differentFirstPage ?? false}
                    onCheckedChange={(checked) => onUpdateHeader({ differentFirstPage: checked })}
                  />
                </div>
              </>
            )}
          </TabsContent>
          <TabsContent value="footer" className="space-y-4 pt-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="footer-enabled">Enable Footer</Label>
              <Switch
                id="footer-enabled"
                checked={footer?.enabled ?? false}
                onCheckedChange={(checked) => onUpdateFooter({ enabled: checked })}
              />
            </div>
            {footer?.enabled && (
              <>
                <div className="flex items-center justify-between">
                  <Label htmlFor="footer-page-numbers">Show Page Numbers</Label>
                  <Switch
                    id="footer-page-numbers"
                    checked={footer?.showPageNumber ?? true}
                    onCheckedChange={(checked) => onUpdateFooter({ showPageNumber: checked })}
                  />
                </div>
                {footer?.showPageNumber && (
                  <div className="space-y-2">
                    <Label>Page Number Position</Label>
                    <Select
                      value={footer?.pageNumberPosition || "center"}
                      onValueChange={(value) => onUpdateFooter({ pageNumberPosition: value as "left" | "center" | "right" })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="left">Left</SelectItem>
                        <SelectItem value="center">Center</SelectItem>
                        <SelectItem value="right">Right</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="footer-left">Left</Label>
                    <Input
                      id="footer-left"
                      placeholder="e.g., Copyright"
                      value={footer?.leftContent || ""}
                      onChange={(e) => onUpdateFooter({ leftContent: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="footer-center">Center</Label>
                    <Input
                      id="footer-center"
                      value={footer?.centerContent || ""}
                      onChange={(e) => onUpdateFooter({ centerContent: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="footer-right">Right</Label>
                    <Input
                      id="footer-right"
                      value={footer?.rightContent || ""}
                      onChange={(e) => onUpdateFooter({ rightContent: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="footer-first-page">Different first page (no footer)</Label>
                  <Switch
                    id="footer-first-page"
                    checked={footer?.differentFirstPage ?? false}
                    onCheckedChange={(checked) => onUpdateFooter({ differentFirstPage: checked })}
                  />
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
