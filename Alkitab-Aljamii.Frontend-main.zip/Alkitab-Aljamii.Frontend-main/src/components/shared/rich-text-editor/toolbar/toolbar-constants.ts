/**
 * Constants for the rich text editor toolbar
 */

export interface ParagraphStyle {
  name: string;
  value: "paragraph" | "heading";
  level?: 1 | 2 | 3 | 4;
  fontSize: string | null;
  fontWeight: string | null;
}

export interface FontOption {
  name: string;
  value: string;
}

export interface FontSizeOption {
  name: string;
  value: string;
}

export interface ColorOption {
  name: string;
  value: string;
  isThemed?: boolean;
}

// Paragraph styles (like Google Docs)
export const PARAGRAPH_STYLES: ParagraphStyle[] = [
  { name: "Normal text", value: "paragraph", fontSize: null, fontWeight: null },
  { name: "Title", value: "heading", level: 1, fontSize: "26pt", fontWeight: "700" },
  { name: "Heading 1", value: "heading", level: 1, fontSize: "20pt", fontWeight: "600" },
  { name: "Heading 2", value: "heading", level: 2, fontSize: "16pt", fontWeight: "600" },
  { name: "Heading 3", value: "heading", level: 3, fontSize: "14pt", fontWeight: "600" },
  { name: "Heading 4", value: "heading", level: 4, fontSize: "12pt", fontWeight: "600" },
];

// Common book/document fonts
export const FONTS: FontOption[] = [
  { name: "Default", value: "" },
  { name: "Calibri", value: "Calibri, sans-serif" },
  { name: "Arial", value: "Arial, sans-serif" },
  { name: "Times New Roman", value: "Times New Roman, serif" },
  { name: "Georgia", value: "Georgia, serif" },
  { name: "Garamond", value: "Garamond, serif" },
  { name: "Palatino", value: "Palatino Linotype, serif" },
  { name: "Book Antiqua", value: "Book Antiqua, serif" },
  { name: "Cambria", value: "Cambria, serif" },
  { name: "Verdana", value: "Verdana, sans-serif" },
  { name: "Trebuchet MS", value: "Trebuchet MS, sans-serif" },
  { name: "Tahoma", value: "Tahoma, sans-serif" },
  { name: "Courier New", value: "Courier New, monospace" },
  { name: "Consolas", value: "Consolas, monospace" },
];

// Font sizes (matching Word)
export const FONT_SIZES: FontSizeOption[] = [
  { name: "8", value: "8pt" },
  { name: "9", value: "9pt" },
  { name: "10", value: "10pt" },
  { name: "11", value: "11pt" },
  { name: "12", value: "12pt" },
  { name: "14", value: "14pt" },
  { name: "16", value: "16pt" },
  { name: "18", value: "18pt" },
  { name: "20", value: "20pt" },
  { name: "22", value: "22pt" },
  { name: "24", value: "24pt" },
  { name: "26", value: "26pt" },
  { name: "28", value: "28pt" },
  { name: "36", value: "36pt" },
  { name: "48", value: "48pt" },
  { name: "72", value: "72pt" },
];

// Text colors - "Default" uses theme's foreground color, others are explicit
export const TEXT_COLORS: ColorOption[] = [
  { name: "Default", value: "", isThemed: true },
  { name: "White", value: "#ffffff" },
  { name: "Black", value: "#000000" },
  { name: "Dark Gray", value: "#4a4a4a" },
  { name: "Gray", value: "#9a9a9a" },
  { name: "Light Gray", value: "#d4d4d4" },
  { name: "Red", value: "#dc2626" },
  { name: "Orange", value: "#ea580c" },
  { name: "Yellow", value: "#ca8a04" },
  { name: "Green", value: "#16a34a" },
  { name: "Blue", value: "#2563eb" },
  { name: "Purple", value: "#9333ea" },
  { name: "Pink", value: "#db2777" },
];

// Highlight colors
export const HIGHLIGHT_COLORS: ColorOption[] = [
  { name: "None", value: "" },
  { name: "Yellow", value: "#fef08a" },
  { name: "Green", value: "#bbf7d0" },
  { name: "Blue", value: "#bfdbfe" },
  { name: "Pink", value: "#fbcfe8" },
  { name: "Purple", value: "#e9d5ff" },
  { name: "Orange", value: "#fed7aa" },
  { name: "Red", value: "#fecaca" },
  { name: "Cyan", value: "#a5f3fc" },
];

// Cell background colors (for tables) - "Default" uses theme background, others are explicit
export const CELL_COLORS: ColorOption[] = [
  { name: "Default", value: "", isThemed: true },
  { name: "White", value: "#ffffff" },
  { name: "Black", value: "#1f2937" },
  { name: "Light Gray", value: "#f3f4f6" },
  { name: "Gray", value: "#e5e7eb" },
  { name: "Dark Gray", value: "#d1d5db" },
  { name: "Light Yellow", value: "#fef9c3" },
  { name: "Light Green", value: "#dcfce7" },
  { name: "Light Blue", value: "#dbeafe" },
  { name: "Light Pink", value: "#fce7f3" },
  { name: "Light Purple", value: "#f3e8ff" },
  { name: "Light Orange", value: "#ffedd5" },
  { name: "Light Red", value: "#fee2e2" },
  { name: "Light Cyan", value: "#cffafe" },
];
