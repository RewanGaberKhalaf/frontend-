"use client";

import { ChevronDown, Type } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import type { Editor } from "@tiptap/react";
import { PARAGRAPH_STYLES, FONTS, FONT_SIZES, type ParagraphStyle } from "./toolbar-constants";

interface ParagraphStylePickerProps {
  getCurrentParagraphStyle: () => string;
  applyParagraphStyle: (style: ParagraphStyle) => void;
}

export function ParagraphStylePicker({
  getCurrentParagraphStyle,
  applyParagraphStyle,
}: ParagraphStylePickerProps) {
  return (
    <DropdownMenu>
      <Tooltip>
        <TooltipTrigger asChild>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 min-w-[120px] justify-between gap-1 px-2 font-normal"
            >
              <span className="truncate text-xs">{getCurrentParagraphStyle()}</span>
              <ChevronDown className="h-3 w-3 shrink-0 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
        </TooltipTrigger>
        <TooltipContent>Paragraph Style</TooltipContent>
      </Tooltip>
      <DropdownMenuContent align="start" className="w-[180px]">
        <DropdownMenuLabel className="text-xs">Styles</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {PARAGRAPH_STYLES.map((style) => (
          <DropdownMenuItem
            key={style.name}
            onClick={() => applyParagraphStyle(style)}
            className={cn(
              "cursor-pointer",
              getCurrentParagraphStyle() === style.name && "bg-accent"
            )}
          >
            <span
              style={{
                fontSize: style.fontSize || "11pt",
                fontWeight: style.fontWeight || "normal",
              }}
            >
              {style.name}
            </span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface FontFamilyPickerProps {
  editor: Editor;
  getCurrentFont: () => string;
}

export function FontFamilyPicker({ editor, getCurrentFont }: FontFamilyPickerProps) {
  return (
    <DropdownMenu>
      <Tooltip>
        <TooltipTrigger asChild>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 min-w-[100px] justify-between gap-1 px-2 font-normal"
            >
              <Type className="h-3.5 w-3.5 shrink-0 opacity-50" />
              <span className="truncate text-xs">{getCurrentFont()}</span>
              <ChevronDown className="h-3 w-3 shrink-0 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
        </TooltipTrigger>
        <TooltipContent>Font Family</TooltipContent>
      </Tooltip>
      <DropdownMenuContent align="start" className="max-h-[300px] overflow-y-auto">
        <DropdownMenuLabel className="text-xs">Font Family</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {FONTS.map((font) => (
          <DropdownMenuItem
            key={font.name}
            onClick={() => {
              if (font.value) {
                editor.chain().focus().setFontFamily(font.value).run();
              } else {
                editor.chain().focus().unsetFontFamily().run();
              }
            }}
            className={cn("cursor-pointer", getCurrentFont() === font.name && "bg-accent")}
            style={font.value ? { fontFamily: font.value } : undefined}
          >
            {font.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface FontSizePickerProps {
  editor: Editor;
  getCurrentFontSize: () => string;
}

export function FontSizePicker({ editor, getCurrentFontSize }: FontSizePickerProps) {
  return (
    <DropdownMenu>
      <Tooltip>
        <TooltipTrigger asChild>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-14 justify-between gap-1 px-2">
              <span className="text-xs">{getCurrentFontSize()}</span>
              <ChevronDown className="h-3 w-3 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
        </TooltipTrigger>
        <TooltipContent>Font Size</TooltipContent>
      </Tooltip>
      <DropdownMenuContent align="start" className="max-h-[300px] overflow-y-auto">
        <DropdownMenuLabel className="text-xs">Font Size</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {FONT_SIZES.map((size) => (
          <DropdownMenuItem
            key={size.name}
            onClick={() => {
              editor.chain().focus().setFontSize(size.value).run();
            }}
            className={cn("cursor-pointer", getCurrentFontSize() === size.name && "bg-accent")}
          >
            {size.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
