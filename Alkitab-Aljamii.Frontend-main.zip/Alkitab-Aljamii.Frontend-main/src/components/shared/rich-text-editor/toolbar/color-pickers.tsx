"use client";

import { Palette, Highlighter } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import type { Editor } from "@tiptap/react";
import { ColorButton } from "./color-button";
import { TEXT_COLORS, HIGHLIGHT_COLORS } from "./toolbar-constants";

interface TextColorPickerProps {
  editor: Editor;
  getCurrentColor: () => string;
}

export function TextColorPicker({ editor, getCurrentColor }: TextColorPickerProps) {
  return (
    <Popover>
      <Tooltip>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <div className="flex flex-col items-center">
                <Palette className="h-4 w-4" />
                <div
                  className="h-0.5 w-4 rounded-full"
                  style={{ backgroundColor: getCurrentColor() || "currentColor" }}
                />
              </div>
            </Button>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent>Text Color</TooltipContent>
      </Tooltip>
      <PopoverContent className="w-auto p-3">
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Text Color</p>
          <div className="grid grid-cols-7 gap-1.5">
            {TEXT_COLORS.map((color) => (
              <ColorButton
                key={color.name}
                color={color.value}
                isSelected={getCurrentColor() === color.value}
                onClick={() => {
                  if (color.value) {
                    editor.chain().focus().setColor(color.value).run();
                  } else {
                    editor.chain().focus().unsetColor().run();
                  }
                }}
                title={color.name}
                isThemed={"isThemed" in color && color.isThemed}
              />
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

interface HighlightColorPickerProps {
  editor: Editor;
  getCurrentHighlight: () => string;
}

export function HighlightColorPicker({ editor, getCurrentHighlight }: HighlightColorPickerProps) {
  return (
    <Popover>
      <Tooltip>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <div className="flex flex-col items-center">
                <Highlighter className="h-4 w-4" />
                <div
                  className="h-0.5 w-4 rounded-full"
                  style={{ backgroundColor: getCurrentHighlight() || "#fef08a" }}
                />
              </div>
            </Button>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent>Highlight Color</TooltipContent>
      </Tooltip>
      <PopoverContent className="w-auto p-3">
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Highlight Color</p>
          <div className="grid grid-cols-5 gap-1.5">
            {HIGHLIGHT_COLORS.map((color) => (
              <ColorButton
                key={color.name}
                color={color.value}
                isSelected={getCurrentHighlight() === color.value}
                onClick={() => {
                  if (color.value) {
                    editor.chain().focus().toggleHighlight({ color: color.value }).run();
                  } else {
                    editor.chain().focus().unsetHighlight().run();
                  }
                }}
                title={color.name}
              />
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
