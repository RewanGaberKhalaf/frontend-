"use client";

import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Code,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  Quote,
  Minus,
  Code2,
  ImageIcon,
  ClipboardList,
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import type { Editor } from "@tiptap/react";
import { ToolbarButton } from "./toolbar-button";
import { TableGridPicker } from "./table-grid-picker";

interface TextFormattingButtonsProps {
  editor: Editor;
}

export function TextFormattingButtons({ editor }: TextFormattingButtonsProps) {
  return (
    <>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleBold().run()}
        isActive={editor.isActive("bold")}
        tooltip="Bold (Ctrl+B)"
      >
        <Bold className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleItalic().run()}
        isActive={editor.isActive("italic")}
        tooltip="Italic (Ctrl+I)"
      >
        <Italic className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleUnderline().run()}
        isActive={editor.isActive("underline")}
        tooltip="Underline (Ctrl+U)"
      >
        <Underline className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleStrike().run()}
        isActive={editor.isActive("strike")}
        tooltip="Strikethrough"
      >
        <Strikethrough className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleCode().run()}
        isActive={editor.isActive("code")}
        tooltip="Inline Code"
      >
        <Code className="h-4 w-4" />
      </ToolbarButton>
    </>
  );
}

interface AlignmentButtonsProps {
  editor: Editor;
}

export function AlignmentButtons({ editor }: AlignmentButtonsProps) {
  return (
    <>
      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign("left").run()}
        isActive={editor.isActive({ textAlign: "left" })}
        tooltip="Align Left"
      >
        <AlignLeft className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign("center").run()}
        isActive={editor.isActive({ textAlign: "center" })}
        tooltip="Align Center"
      >
        <AlignCenter className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign("right").run()}
        isActive={editor.isActive({ textAlign: "right" })}
        tooltip="Align Right"
      >
        <AlignRight className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign("justify").run()}
        isActive={editor.isActive({ textAlign: "justify" })}
        tooltip="Justify"
      >
        <AlignJustify className="h-4 w-4" />
      </ToolbarButton>
    </>
  );
}

interface ListButtonsProps {
  editor: Editor;
  enableCodeBlock: boolean;
}

export function ListButtons({ editor, enableCodeBlock }: ListButtonsProps) {
  return (
    <>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        isActive={editor.isActive("bulletList")}
        tooltip="Bullet List"
      >
        <List className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        isActive={editor.isActive("orderedList")}
        tooltip="Ordered List"
      >
        <ListOrdered className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleBlockquote().run()}
        isActive={editor.isActive("blockquote")}
        tooltip="Blockquote"
      >
        <Quote className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().setHorizontalRule().run()}
        tooltip="Horizontal Rule"
      >
        <Minus className="h-4 w-4" />
      </ToolbarButton>

      {enableCodeBlock && (
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleCodeBlock().run()}
          isActive={editor.isActive("codeBlock")}
          tooltip="Code Block"
        >
          <Code2 className="h-4 w-4" />
        </ToolbarButton>
      )}
    </>
  );
}

interface InsertButtonsProps {
  editor: Editor;
  enableTable: boolean;
  enableMedia: boolean;
  enableQuiz: boolean;
  insertTable: (rows: number, cols: number) => void;
  onOpenMediaLibrary?: (filterType?: "image" | "video" | "audio" | "all") => void;
  onOpenQuizSelector?: () => void;
}

export function InsertButtons({
  enableTable,
  enableMedia,
  enableQuiz,
  insertTable,
  onOpenMediaLibrary,
  onOpenQuizSelector,
}: InsertButtonsProps) {
  return (
    <>
      {enableTable && <TableGridPicker onInsert={insertTable} />}

      {enableMedia && onOpenMediaLibrary && (
        <ToolbarButton
          onClick={() => onOpenMediaLibrary("all")}
          tooltip="Insert Media (Images, Videos, Audio)"
        >
          <ImageIcon className="h-4 w-4" />
        </ToolbarButton>
      )}

      {enableQuiz && onOpenQuizSelector && (
        <>
          <Separator orientation="vertical" className="mx-1 h-6" />
          <ToolbarButton onClick={onOpenQuizSelector} tooltip="Insert Quiz">
            <ClipboardList className="h-4 w-4" />
          </ToolbarButton>
        </>
      )}
    </>
  );
}
