"use client";

import { useState } from "react";
import { Table } from "lucide-react";
import { Toggle } from "@/components/ui/toggle";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";

export interface TableGridPickerProps {
  onInsert: (rows: number, cols: number) => void;
}

/**
 * Table Grid Picker - allows selecting rows x columns up to 10x10
 */
export function TableGridPicker({ onInsert }: TableGridPickerProps) {
  const [hoveredRow, setHoveredRow] = useState(0);
  const [hoveredCol, setHoveredCol] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const maxRows = 10;
  const maxCols = 10;

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <Tooltip>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <Toggle size="sm" className="h-8 w-8 p-0">
              <Table className="h-4 w-4" />
            </Toggle>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent>Insert Table</TooltipContent>
      </Tooltip>
      <PopoverContent className="w-auto p-3" align="start">
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">
            {hoveredRow > 0 && hoveredCol > 0
              ? `${hoveredRow} × ${hoveredCol} table`
              : "Select table size"}
          </p>
          <div
            className="grid gap-0.5"
            style={{ gridTemplateColumns: `repeat(${maxCols}, 1fr)` }}
            onMouseLeave={() => {
              setHoveredRow(0);
              setHoveredCol(0);
            }}
          >
            {Array.from({ length: maxRows * maxCols }).map((_, index) => {
              const row = Math.floor(index / maxCols) + 1;
              const col = (index % maxCols) + 1;
              const isHighlighted = row <= hoveredRow && col <= hoveredCol;

              return (
                <button
                  key={index}
                  type="button"
                  className={cn(
                    "h-4 w-4 border rounded-sm transition-colors",
                    isHighlighted
                      ? "bg-primary border-primary"
                      : "bg-muted/50 border-border hover:border-primary/50"
                  )}
                  onMouseEnter={() => {
                    setHoveredRow(row);
                    setHoveredCol(col);
                  }}
                  onClick={() => {
                    onInsert(row, col);
                    setIsOpen(false);
                    setHoveredRow(0);
                    setHoveredCol(0);
                  }}
                />
              );
            })}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
