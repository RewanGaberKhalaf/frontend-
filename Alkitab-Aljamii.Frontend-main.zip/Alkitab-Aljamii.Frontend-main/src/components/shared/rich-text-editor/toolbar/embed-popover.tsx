"use client";

import { Code2 } from "lucide-react";
import { Toggle } from "@/components/ui/toggle";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface EmbedPopoverProps {
  embedUrl: string;
  setEmbedUrl: (url: string) => void;
  embedPopoverOpen: boolean;
  setEmbedPopoverOpen: (open: boolean) => void;
  insertEmbed: () => void;
}

export function EmbedPopover({
  embedUrl,
  setEmbedUrl,
  embedPopoverOpen,
  setEmbedPopoverOpen,
  insertEmbed,
}: EmbedPopoverProps) {
  return (
    <Popover open={embedPopoverOpen} onOpenChange={setEmbedPopoverOpen}>
      <Tooltip>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <Toggle size="sm" className="h-8 w-8 p-0">
              <Code2 className="h-4 w-4" />
            </Toggle>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent>Embed (YouTube, Vimeo, Spotify, etc.)</TooltipContent>
      </Tooltip>
      <PopoverContent className="w-80">
        <div className="grid gap-4">
          <div className="space-y-2">
            <h4 className="font-medium leading-none">Embed Content</h4>
            <p className="text-xs text-muted-foreground">
              Paste a URL from YouTube, Vimeo, Loom, Spotify, or SoundCloud
            </p>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="embed-url">URL</Label>
            <Input
              id="embed-url"
              placeholder="https://youtube.com/watch?v=..."
              value={embedUrl}
              onChange={(e) => setEmbedUrl(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  insertEmbed();
                }
              }}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setEmbedPopoverOpen(false);
                setEmbedUrl("");
              }}
            >
              Cancel
            </Button>
            <Button size="sm" onClick={insertEmbed} disabled={!embedUrl}>
              Embed
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
