"use client";

import { type Editor } from "@tiptap/react";
import { Undo, Redo } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { ToolbarButton } from "./toolbar-button";
import { useToolbarState } from "./use-toolbar-state";
import { ParagraphStylePicker, FontFamilyPicker, FontSizePicker } from "./font-pickers";
import { TextColorPicker, HighlightColorPicker } from "./color-pickers";
import {
  TextFormattingButtons,
  AlignmentButtons,
  ListButtons,
  InsertButtons,
} from "./formatting-buttons";
import { LinkPopover } from "./link-popover";
import { EmbedPopover } from "./embed-popover";
import { MathPopover } from "./math-popover";

export interface EditorToolbarProps {
  editor: Editor | null;
  className?: string;
  enableTable?: boolean;
  enableCodeBlock?: boolean;
  enableMedia?: boolean;
  enableQuiz?: boolean;
  enableMath?: boolean;
  /** Callback to open media library with optional filter */
  onOpenMediaLibrary?: (filterType?: "image" | "video" | "audio" | "all") => void;
  /** Callback to open quiz selector dialog */
  onOpenQuizSelector?: () => void;
}

export function EditorToolbar({
  editor,
  className,
  enableTable = true,
  enableCodeBlock = true,
  enableMedia = true,
  enableQuiz = true,
  enableMath = true,
  onOpenMediaLibrary,
  onOpenQuizSelector,
}: EditorToolbarProps) {
  const {
    linkUrl,
    setLinkUrl,
    linkPopoverOpen,
    setLinkPopoverOpen,
    setLink,
    embedUrl,
    setEmbedUrl,
    embedPopoverOpen,
    setEmbedPopoverOpen,
    insertEmbed,
    insertTable,
    getCurrentFont,
    getCurrentFontSize,
    getCurrentColor,
    getCurrentHighlight,
    getCurrentParagraphStyle,
    applyParagraphStyle,
  } = useToolbarState(editor);

  if (!editor) {
    return null;
  }

  return (
    <div
      className={cn(
        "flex flex-wrap items-center gap-0.5 rounded-t-md border-b bg-muted/50 px-2 py-1.5",
        className
      )}
    >
      {/* Undo/Redo */}
      <ToolbarButton
        onClick={() => editor.chain().focus().undo().run()}
        disabled={!editor.can().undo()}
        tooltip="Undo (Ctrl+Z)"
      >
        <Undo className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().redo().run()}
        disabled={!editor.can().redo()}
        tooltip="Redo (Ctrl+Y)"
      >
        <Redo className="h-4 w-4" />
      </ToolbarButton>

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Paragraph Style Picker */}
      <ParagraphStylePicker
        getCurrentParagraphStyle={getCurrentParagraphStyle}
        applyParagraphStyle={applyParagraphStyle}
      />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Font Family Picker */}
      <FontFamilyPicker editor={editor} getCurrentFont={getCurrentFont} />

      {/* Font Size Picker */}
      <FontSizePicker editor={editor} getCurrentFontSize={getCurrentFontSize} />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Text Formatting */}
      <TextFormattingButtons editor={editor} />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Color Pickers */}
      <TextColorPicker editor={editor} getCurrentColor={getCurrentColor} />
      <HighlightColorPicker editor={editor} getCurrentHighlight={getCurrentHighlight} />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Text Alignment */}
      <AlignmentButtons editor={editor} />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Lists and Blocks */}
      <ListButtons editor={editor} enableCodeBlock={enableCodeBlock} />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Link */}
      <LinkPopover
        editor={editor}
        linkUrl={linkUrl}
        setLinkUrl={setLinkUrl}
        linkPopoverOpen={linkPopoverOpen}
        setLinkPopoverOpen={setLinkPopoverOpen}
        setLink={setLink}
      />

      {/* Insert Options */}
      <InsertButtons
        editor={editor}
        enableTable={enableTable}
        enableMedia={enableMedia}
        enableQuiz={enableQuiz}
        insertTable={insertTable}
        onOpenMediaLibrary={onOpenMediaLibrary}
        onOpenQuizSelector={onOpenQuizSelector}
      />

      {/* Embed */}
      <EmbedPopover
        embedUrl={embedUrl}
        setEmbedUrl={setEmbedUrl}
        embedPopoverOpen={embedPopoverOpen}
        setEmbedPopoverOpen={setEmbedPopoverOpen}
        insertEmbed={insertEmbed}
      />

      {/* Math */}
      {enableMath && (
        <>
          <Separator orientation="vertical" className="mx-1 h-6" />
          <MathPopover editor={editor} />
        </>
      )}
    </div>
  );
}
