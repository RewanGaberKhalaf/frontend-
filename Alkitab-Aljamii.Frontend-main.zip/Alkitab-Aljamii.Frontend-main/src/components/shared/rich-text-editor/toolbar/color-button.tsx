"use client";

import { cn } from "@/lib/utils";

export interface ColorButtonProps {
  color: string;
  isSelected: boolean;
  onClick: () => void;
  title: string;
  isThemed?: boolean;
}

export function ColorButton({
  color,
  isSelected,
  onClick,
  title,
  isThemed,
}: ColorButtonProps) {
  // For themed "Default" option, show half white / half dark to indicate it adapts
  const getBackgroundStyle = (): React.CSSProperties => {
    if (isThemed) {
      // Half white, half dark to show it adapts to theme
      return {
        backgroundImage: 'linear-gradient(135deg, #ffffff 50%, #1f2937 50%)',
      };
    }
    if (!color) {
      // No color = "None" - show red diagonal line through white
      return {
        backgroundColor: '#ffffff',
        backgroundImage: 'linear-gradient(135deg, #fff 45%, #ef4444 45%, #ef4444 55%, #fff 55%)',
      };
    }
    return { backgroundColor: color };
  };

  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={cn(
        "h-6 w-6 rounded border transition-all hover:scale-110",
        isSelected ? "border-gray-800 ring-2 ring-gray-400" : "border-gray-300 hover:border-gray-500"
      )}
      style={getBackgroundStyle()}
    />
  );
}
