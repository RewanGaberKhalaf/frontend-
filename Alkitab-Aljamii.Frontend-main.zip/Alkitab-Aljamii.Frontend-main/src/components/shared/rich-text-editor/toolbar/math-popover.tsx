"use client";

import { useEffect, useRef, useState } from "react";
import { Sigma } from "lucide-react";
import { Toggle } from "@/components/ui/toggle";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import katex from "katex";
import "katex/dist/katex.min.css";
import type { Editor } from "@tiptap/react";

interface MathPopoverProps {
  editor: Editor;
}

// Common math symbols for quick insertion
const MATH_SYMBOLS = [
  { symbol: "\\frac{a}{b}", display: "a/b", label: "Fraction" },
  { symbol: "\\sqrt{x}", display: "√x", label: "Square root" },
  { symbol: "\\sum_{i=1}^{n}", display: "Σ", label: "Sum" },
  { symbol: "\\int_{a}^{b}", display: "∫", label: "Integral" },
  { symbol: "\\prod_{i=1}^{n}", display: "∏", label: "Product" },
  { symbol: "\\lim_{x \\to \\infty}", display: "lim", label: "Limit" },
  { symbol: "\\alpha", display: "α", label: "Alpha" },
  { symbol: "\\beta", display: "β", label: "Beta" },
  { symbol: "\\gamma", display: "γ", label: "Gamma" },
  { symbol: "\\delta", display: "δ", label: "Delta" },
  { symbol: "\\theta", display: "θ", label: "Theta" },
  { symbol: "\\pi", display: "π", label: "Pi" },
  { symbol: "\\infty", display: "∞", label: "Infinity" },
  { symbol: "\\pm", display: "±", label: "Plus-minus" },
  { symbol: "\\times", display: "×", label: "Times" },
  { symbol: "\\div", display: "÷", label: "Divide" },
  { symbol: "\\leq", display: "≤", label: "Less or equal" },
  { symbol: "\\geq", display: "≥", label: "Greater or equal" },
  { symbol: "\\neq", display: "≠", label: "Not equal" },
  { symbol: "\\approx", display: "≈", label: "Approximately" },
];

export function MathPopover({ editor }: MathPopoverProps) {
  const [open, setOpen] = useState(false);
  const [latex, setLatex] = useState("");
  const [mathType, setMathType] = useState<"inline" | "block">("inline");
  const previewRef = useRef<HTMLDivElement>(null);

  // Render preview with small delay for DOM stability
  useEffect(() => {
    if (!previewRef.current) return;

    if (!latex) {
      previewRef.current.innerHTML = '<span class="text-muted-foreground">Preview will appear here</span>';
      return;
    }

    // Small delay to ensure DOM is ready
    const timeoutId = setTimeout(() => {
      if (!previewRef.current) return;

      try {
        katex.render(latex, previewRef.current, {
          displayMode: mathType === "block",
          throwOnError: false,
          errorColor: "#ef4444",
          trust: true,
          strict: false,
        });
      } catch (error) {
        if (previewRef.current) {
          previewRef.current.innerHTML = `<span class="text-destructive text-sm">${error instanceof Error ? error.message : "Invalid LaTeX"}</span>`;
        }
      }
    }, 0);

    return () => clearTimeout(timeoutId);
  }, [latex, mathType]);

  const insertSymbol = (symbol: string) => {
    setLatex((prev) => prev + symbol);
  };

  const insertMath = () => {
    if (!latex.trim()) return;

    if (mathType === "inline") {
      editor.chain().focus().insertMathInline(latex).run();
    } else {
      editor.chain().focus().insertMathBlock(latex).run();
    }

    setLatex("");
    setOpen(false);
  };

  const handleClose = () => {
    setLatex("");
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <Tooltip>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <Toggle size="sm" className="h-8 w-8 p-0">
              <Sigma className="h-4 w-4" />
            </Toggle>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent>Insert Math Formula (LaTeX)</TooltipContent>
      </Tooltip>
      <PopoverContent className="w-96 max-h-[80vh] overflow-y-auto" align="start" side="bottom" sideOffset={5}>
        <div className="grid gap-4">
          <div className="space-y-2">
            <h4 className="font-medium leading-none">Insert Math Formula</h4>
            <p className="text-xs text-muted-foreground">
              Enter LaTeX code or use symbols below. Use $...$ in text for inline math.
            </p>
          </div>

          <Tabs value={mathType} onValueChange={(v) => setMathType(v as "inline" | "block")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="inline">Inline</TabsTrigger>
              <TabsTrigger value="block">Block</TabsTrigger>
            </TabsList>
            <TabsContent value="inline" className="text-xs text-muted-foreground mt-1">
              Formula appears within the text line
            </TabsContent>
            <TabsContent value="block" className="text-xs text-muted-foreground mt-1">
              Formula appears on its own line, centered
            </TabsContent>
          </Tabs>

          <div className="grid gap-2">
            <Label htmlFor="latex-input">LaTeX Code</Label>
            <Textarea
              id="latex-input"
              placeholder="e.g., \frac{a}{b} or x^2 + y^2 = z^2"
              value={latex}
              onChange={(e) => setLatex(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
                  e.preventDefault();
                  insertMath();
                }
              }}
              className="font-mono min-h-[60px]"
              dir="ltr"
            />
          </div>

          <div className="space-y-2">
            <Label>Quick Symbols</Label>
            <div className="flex flex-wrap gap-1">
              {MATH_SYMBOLS.map((item) => (
                <Tooltip key={item.symbol}>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 px-2 text-xs font-mono"
                      onClick={() => insertSymbol(item.symbol)}
                    >
                      {item.display}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">{item.label}</TooltipContent>
                </Tooltip>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Preview</Label>
            <div
              className={cn(
                "min-h-[48px] max-h-[120px] p-3 bg-muted rounded-md overflow-auto",
                mathType === "block" ? "text-xl" : ""
              )}
            >
              <div
                ref={previewRef}
                className={cn(
                  "flex items-center min-h-[24px]",
                  mathType === "block" ? "justify-center" : "justify-start"
                )}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={handleClose}>
              Cancel
            </Button>
            <Button size="sm" onClick={insertMath} disabled={!latex.trim()}>
              Insert
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
