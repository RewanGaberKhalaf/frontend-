"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import type { Editor } from "@tiptap/react";
import { getEmbedSrc } from "./embed-utils";
import { FONTS, FONT_SIZES, type ParagraphStyle } from "./toolbar-constants";

export function useToolbarState(editor: Editor | null) {
  const [linkUrl, setLinkUrl] = useState("");
  const [linkPopoverOpen, setLinkPopoverOpen] = useState(false);
  const [embedUrl, setEmbedUrl] = useState("");
  const [embedPopoverOpen, setEmbedPopoverOpen] = useState(false);

  // Force re-render when editor selection changes (debounced for performance)
  const [, setForceUpdate] = useState(0);
  const updateTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!editor) return;

    const handleUpdate = () => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
      updateTimeoutRef.current = setTimeout(() => {
        setForceUpdate((prev) => prev + 1);
      }, 100);
    };

    editor.on("selectionUpdate", handleUpdate);

    return () => {
      editor.off("selectionUpdate", handleUpdate);
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, [editor]);

  const setLink = useCallback(() => {
    if (!editor) return;

    if (linkUrl === "") {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
    } else {
      editor.chain().focus().extendMarkRange("link").setLink({ href: linkUrl }).run();
    }
    setLinkUrl("");
    setLinkPopoverOpen(false);
  }, [editor, linkUrl]);

  const insertEmbed = useCallback(() => {
    if (!editor || !embedUrl) return;

    const embedSrc = getEmbedSrc(embedUrl);
    editor
      .chain()
      .focus()
      .setResizableMedia({
        src: embedSrc,
        mediaType: "iframe",
        width: "80%",
        alignment: "center",
        float: "none",
      })
      .run();

    setEmbedUrl("");
    setEmbedPopoverOpen(false);
  }, [editor, embedUrl]);

  const insertTable = useCallback(
    (rows: number, cols: number) => {
      if (!editor) return;
      editor.chain().focus().insertTable({ rows, cols, withHeaderRow: true }).run();
    },
    [editor]
  );

  const getCurrentFont = useCallback(() => {
    if (!editor) return "Default";
    const fontFamily = editor.getAttributes("textStyle")["fontFamily"] as string | undefined;
    const font = FONTS.find((f) => f.value === fontFamily);
    return font?.name || "Default";
  }, [editor]);

  const getCurrentFontSize = useCallback(() => {
    if (!editor) return "11";

    const fontSize = editor.getAttributes("textStyle")["fontSize"] as string | undefined;
    if (fontSize) {
      const size = FONT_SIZES.find((s) => s.value === fontSize);
      return size?.name || fontSize.replace("pt", "");
    }

    if (editor.isActive("heading", { level: 1 })) return "20";
    if (editor.isActive("heading", { level: 2 })) return "16";
    if (editor.isActive("heading", { level: 3 })) return "14";
    if (editor.isActive("heading", { level: 4 })) return "12";

    return "11";
  }, [editor]);

  const getCurrentColor = useCallback(() => {
    if (!editor) return "";
    return (editor.getAttributes("textStyle")["color"] as string) || "";
  }, [editor]);

  const getCurrentHighlight = useCallback(() => {
    if (!editor) return "";
    return (editor.getAttributes("highlight")["color"] as string) || "";
  }, [editor]);

  const getCurrentParagraphStyle = useCallback(() => {
    if (!editor) return "Normal text";
    if (editor.isActive("heading", { level: 1 })) {
      const fontSize = editor.getAttributes("textStyle")["fontSize"] as string | undefined;
      if (fontSize === "26pt") return "Title";
      return "Heading 1";
    }
    if (editor.isActive("heading", { level: 2 })) return "Heading 2";
    if (editor.isActive("heading", { level: 3 })) return "Heading 3";
    if (editor.isActive("heading", { level: 4 })) return "Heading 4";
    return "Normal text";
  }, [editor]);

  const applyParagraphStyle = useCallback(
    (style: ParagraphStyle) => {
      if (!editor) return;

      const chain = editor.chain().focus();

      if (style.value === "paragraph") {
        chain.setParagraph().unsetFontSize().run();
      } else if (style.value === "heading" && style.level) {
        chain.toggleHeading({ level: style.level }).run();
        if (style.fontSize) {
          editor.chain().focus().setFontSize(style.fontSize).run();
        }
      }
    },
    [editor]
  );

  return {
    // Link state
    linkUrl,
    setLinkUrl,
    linkPopoverOpen,
    setLinkPopoverOpen,
    setLink,
    // Embed state
    embedUrl,
    setEmbedUrl,
    embedPopoverOpen,
    setEmbedPopoverOpen,
    insertEmbed,
    // Table
    insertTable,
    // Getters
    getCurrentFont,
    getCurrentFontSize,
    getCurrentColor,
    getCurrentHighlight,
    getCurrentParagraphStyle,
    applyParagraphStyle,
  };
}
