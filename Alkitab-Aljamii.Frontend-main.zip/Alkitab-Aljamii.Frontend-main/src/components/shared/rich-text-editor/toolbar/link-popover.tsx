"use client";

import { Link, Unlink } from "lucide-react";
import { Toggle } from "@/components/ui/toggle";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Editor } from "@tiptap/react";
import { ToolbarButton } from "./toolbar-button";

interface LinkPopoverProps {
  editor: Editor;
  linkUrl: string;
  setLinkUrl: (url: string) => void;
  linkPopoverOpen: boolean;
  setLinkPopoverOpen: (open: boolean) => void;
  setLink: () => void;
}

export function LinkPopover({
  editor,
  linkUrl,
  setLinkUrl,
  linkPopoverOpen,
  setLinkPopoverOpen,
  setLink,
}: LinkPopoverProps) {
  return (
    <>
      <Popover open={linkPopoverOpen} onOpenChange={setLinkPopoverOpen}>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <Toggle size="sm" pressed={editor.isActive("link")} className="h-8 w-8 p-0">
                <Link className="h-4 w-4" />
              </Toggle>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent>Add Link</TooltipContent>
        </Tooltip>
        <PopoverContent className="w-80">
          <div className="grid gap-4">
            <div className="space-y-2">
              <h4 className="font-medium leading-none">Insert Link</h4>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="link-url">URL</Label>
              <Input
                id="link-url"
                placeholder="https://example.com"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    setLink();
                  }
                }}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setLinkPopoverOpen(false);
                  setLinkUrl("");
                }}
              >
                Cancel
              </Button>
              <Button size="sm" onClick={setLink}>
                Insert
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {editor.isActive("link") && (
        <ToolbarButton
          onClick={() => editor.chain().focus().unsetLink().run()}
          tooltip="Remove Link"
        >
          <Unlink className="h-4 w-4" />
        </ToolbarButton>
      )}
    </>
  );
}
