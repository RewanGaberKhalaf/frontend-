import { Node, mergeAttributes } from "@tiptap/core";

export interface IframeOptions {
  allowFullscreen: boolean;
  HTMLAttributes: Record<string, unknown>;
}

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    iframe: {
      /**
       * Add an iframe
       */
      setIframe: (options: { src: string }) => ReturnType;
    };
  }
}

// Helper to determine embed type from URL
function getEmbedType(src: string | null): string {
  if (!src) return "embed";
  if (src.includes("youtube.com") || src.includes("youtu.be")) return "youtube";
  if (src.includes("vimeo.com")) return "vimeo";
  if (src.includes("loom.com")) return "loom";
  if (src.includes("spotify.com")) return "spotify";
  if (src.includes("soundcloud.com")) return "soundcloud";
  return "embed";
}

export const Iframe = Node.create<IframeOptions>({
  name: "iframe",

  group: "block",

  atom: true,

  addOptions() {
    return {
      allowFullscreen: true,
      HTMLAttributes: {},
    };
  },

  addAttributes() {
    return {
      src: {
        default: null,
      },
      frameborder: {
        default: "0",
      },
      allowfullscreen: {
        default: this.options.allowFullscreen,
        parseHTML: () => this.options.allowFullscreen,
      },
      allow: {
        default: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: "iframe",
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    const embedType = getEmbedType(HTMLAttributes["src"] as string);
    return [
      "div",
      {
        class: "media-container embed-container",
        "data-type": embedType,
      },
      [
        "iframe",
        mergeAttributes(this.options.HTMLAttributes, HTMLAttributes),
      ],
    ];
  },

  addCommands() {
    return {
      setIframe:
        (options: { src: string }) =>
        ({ tr, dispatch }) => {
          const { selection } = tr;
          const node = this.type.create(options);

          if (dispatch) {
            tr.replaceRangeWith(selection.from, selection.to, node);
          }

          return true;
        },
    };
  },
});
