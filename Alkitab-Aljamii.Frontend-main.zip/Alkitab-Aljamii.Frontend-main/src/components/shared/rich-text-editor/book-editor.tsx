"use client";

import { useState, useCallback, useRef } from "react";
import { EditorToolbar } from "./editor-toolbar";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { DocumentSidebar } from "./document-sidebar";
import { ResourcesPanel } from "./resources-panel";
import { MediaLibraryConnected } from "./media-library-connected";
import { type MediaItem, resolveMediaUrl } from "@/lib/api";
import type { Editor } from "@tiptap/react";
import type { RichTextEditorRef } from "./rich-text-editor";

import {
  BookPage,
  BookPagePreview,
  BookEditorToolbarActions,
  useDocumentState,
  useOverflowDetection,
  type BookEditorProps,
} from "./book-editor-parts";

// Re-export for backward compatibility
export type { BookEditorProps } from "./book-editor-parts";

export function BookEditor({
  document: initialDocument,
  onDocumentChange,
  className,
}: BookEditorProps) {
  const [mediaLibraryOpen, setMediaLibraryOpen] = useState(false);
  const [mediaLibraryFilter, setMediaLibraryFilter] = useState<
    "image" | "video" | "audio" | "all"
  >("all");
  const [activeEditor, setActiveEditor] = useState<Editor | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [resourcesExpanded, setResourcesExpanded] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const pageContentRef = useRef<HTMLDivElement>(null);

  // Document state hook
  const {
    document,
    setDocument,
    activeLocation,
    activeChapter,
    activePage,
    globalPageNumber,
    expandedChapters,
    canNavigatePrevious,
    canNavigateNext,
    getEffectiveHeader,
    getEffectiveFooter,
    updateBookHeader,
    updateBookFooter,
    toggleChapter,
    navigateToPage,
    navigatePrevious,
    navigateNext,
    handlePageUpdate,
    addChapter,
    deleteChapter,
    addPage,
    deletePage,
    renameChapter,
  } = useDocumentState({
    initialDocument,
    onDocumentChange,
  });

  // Overflow detection hook
  const { isOverflowing } = useOverflowDetection({
    activeEditor,
    activeLocation,
    document,
    setDocument,
    navigateToPage,
    pageContentRef: pageContentRef as React.RefObject<HTMLDivElement>,
  });

  // Track active editor
  const handleEditorRef = useCallback((ref: RichTextEditorRef | null) => {
    if (ref?.editor) {
      setActiveEditor(ref.editor);
    }
  }, []);

  // Handle navigate to next page (or create one)
  const handleNavigateToNextPage = useCallback(() => {
    const chapter = document.chapters.find(
      (ch) => ch.id === activeLocation.chapterId
    );
    if (!chapter) return;

    const currentPageIndex = chapter.pages.findIndex(
      (p) => p.id === activeLocation.pageId
    );
    const nextPage = chapter.pages[currentPageIndex + 1];

    if (nextPage) {
      navigateToPage(activeLocation.chapterId, nextPage.id);
    } else {
      addPage(activeLocation.chapterId);
    }
  }, [document.chapters, activeLocation, navigateToPage, addPage]);

  return (
    <div className={cn("flex h-full", className)}>
      {/* Sidebar with chapters and pages */}
      <DocumentSidebar
        document={document}
        activeChapterId={activeLocation.chapterId}
        activePageId={activeLocation.pageId}
        expandedChapters={expandedChapters}
        onToggleChapter={toggleChapter}
        onNavigateToPage={navigateToPage}
        onAddChapter={addChapter}
        onDeleteChapter={deleteChapter}
        onRenameChapter={renameChapter}
        onAddPage={addPage}
        onDeletePage={deletePage}
      />

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-muted/50">
        {/* Toolbar */}
        <div className="bg-background border-b shadow-sm flex items-center">
          <EditorToolbar
            editor={activeEditor}
            enableTable={true}
            enableCodeBlock={true}
            enableMedia={true}
            onOpenMediaLibrary={(filterType) => {
              setMediaLibraryFilter(filterType || "all");
              setMediaLibraryOpen(true);
            }}
          />
          <BookEditorToolbarActions
            showPreview={showPreview}
            onTogglePreview={() => setShowPreview(!showPreview)}
            resourcesExpanded={resourcesExpanded}
            onToggleResources={() => setResourcesExpanded(!resourcesExpanded)}
            activeChapter={activeChapter}
            settingsOpen={settingsOpen}
            onSettingsOpenChange={setSettingsOpen}
            header={document.header}
            footer={document.footer}
            onUpdateHeader={updateBookHeader}
            onUpdateFooter={updateBookFooter}
          />
        </div>

        {/* Page Editor and Preview */}
        <div className={cn("flex-1 flex", showPreview ? "gap-4" : "")}>
          {/* Editor Panel */}
          <div className={cn("flex-1 overflow-auto", showPreview && "max-w-[50%]")}>
            <div className="flex flex-col items-center py-8 px-4 min-h-full">
              {/* Page Info */}
              <div className="w-full max-w-[794px] mb-4 flex items-center justify-between text-sm text-muted-foreground">
                <span>
                  {activeChapter?.title} — Page{" "}
                  {activePage
                    ? activeChapter!.pages.indexOf(activePage) + 1
                    : 1}{" "}
                  of {activeChapter?.pages.length}
                </span>
                <span>
                  Page {globalPageNumber} of {document.totalPages}
                </span>
              </div>

              {/* A4 Page */}
              {activeChapter && activePage && (
                <BookPage
                  chapter={activeChapter}
                  page={activePage}
                  globalPageNumber={globalPageNumber}
                  isOverflowing={isOverflowing}
                  pageContentRef={pageContentRef as React.RefObject<HTMLDivElement>}
                  getEffectiveHeader={getEffectiveHeader}
                  getEffectiveFooter={getEffectiveFooter}
                  onEditorRef={handleEditorRef}
                  onPageUpdate={handlePageUpdate}
                  onNavigateToNextPage={handleNavigateToNextPage}
                />
              )}

              {/* Navigation */}
              <div className="mt-4 flex items-center gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={navigatePrevious}
                  disabled={!canNavigatePrevious}
                  className="gap-1"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <span className="text-sm text-muted-foreground">
                  {globalPageNumber} / {document.totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={navigateNext}
                  disabled={!canNavigateNext}
                  className="gap-1"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Preview Panel */}
          {showPreview && activeChapter && activePage && (
            <div className="flex-1 overflow-auto border-l bg-muted/30 max-w-[50%]">
              <div className="flex flex-col items-center py-8 px-4 min-h-full">
                <div className="w-full max-w-[794px] mb-4 flex items-center justify-between text-sm text-muted-foreground">
                  <span className="font-medium">Preview</span>
                  <span>
                    Page {globalPageNumber} of {document.totalPages}
                  </span>
                </div>

                <BookPagePreview
                  chapter={activeChapter}
                  page={activePage}
                  globalPageNumber={globalPageNumber}
                  getEffectiveHeader={getEffectiveHeader}
                  getEffectiveFooter={getEffectiveFooter}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Resources Panel */}
      {resourcesExpanded && activeChapter && (
        <ResourcesPanel
          chapter={activeChapter}
          onAddResource={(resource) => {
            setDocument((prev) => ({
              ...prev,
              chapters: prev.chapters.map((ch) =>
                ch.id === activeChapter.id
                  ? {
                      ...ch,
                      resources: [
                        ...(ch.resources || []),
                        {
                          ...resource,
                          id: crypto.randomUUID(),
                          order: ch.resources?.length || 0,
                        },
                      ],
                    }
                  : ch
              ),
            }));
          }}
          onDeleteResource={(resourceId) => {
            setDocument((prev) => ({
              ...prev,
              chapters: prev.chapters.map((ch) =>
                ch.id === activeChapter.id
                  ? {
                      ...ch,
                      resources: ch.resources?.filter((r) => r.id !== resourceId),
                    }
                  : ch
              ),
            }));
          }}
          onClose={() => setResourcesExpanded(false)}
        />
      )}

      {/* Media Library Dialog */}
      <MediaLibraryConnected
        open={mediaLibraryOpen}
        onOpenChange={setMediaLibraryOpen}
        filterType={mediaLibraryFilter}
        onSelect={(item: MediaItem) => {
          if (!activeEditor) return;

          activeEditor
            .chain()
            .focus()
            .setResizableMedia({
              src: resolveMediaUrl(item.url),
              mediaId: item.id,
              mediaType: item.type as "image" | "video" | "audio",
              alt: item.name,
              width: "80%",
              alignment: "center",
              float: "none",
            })
            .run();
        }}
      />
    </div>
  );
}
