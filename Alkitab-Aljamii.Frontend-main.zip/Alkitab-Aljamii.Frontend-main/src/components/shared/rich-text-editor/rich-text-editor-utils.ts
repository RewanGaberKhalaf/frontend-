import * as Y from "yjs";
import { useMemo } from "react";
import type { useEditor } from "@tiptap/react";
import type { YjsNode, EditorOutput } from "./rich-text-editor";

/**
 * Convert Yjs XML element to readable structure
 */
export function xmlElementToNode(element: Y.XmlElement | Y.XmlText): YjsNode {
  if (element instanceof Y.XmlText) {
    const text = element.toString();
    const attrs = element.getAttributes();
    return {
      type: "text",
      text,
      attributes: Object.keys(attrs).length > 0 ? attrs : undefined,
    };
  }

  const children: YjsNode[] = [];
  element.toArray().forEach((child) => {
    if (child instanceof Y.XmlElement || child instanceof Y.XmlText) {
      children.push(xmlElementToNode(child));
    }
  });

  const attrs = element.getAttributes();
  return {
    type: element.nodeName,
    attributes: Object.keys(attrs).length > 0 ? attrs : undefined,
    children: children.length > 0 ? children : undefined,
  };
}

/**
 * Get Yjs structure from fragment
 */
export function getYjsStructure(fragment: Y.XmlFragment): YjsNode[] {
  const nodes: YjsNode[] = [];
  fragment.toArray().forEach((child) => {
    if (child instanceof Y.XmlElement || child instanceof Y.XmlText) {
      nodes.push(xmlElementToNode(child));
    }
  });
  return nodes;
}

/**
 * Strip page wrapper divs from HTML output
 */
export function stripPageWrappers(html: string): string {
  // Check if there are page wrappers
  if (!html.includes('data-page="true"')) {
    return html;
  }

  // Simple approach: parse with DOM
  if (typeof window !== "undefined") {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const pages = doc.querySelectorAll('[data-page="true"]');

    if (pages.length > 0) {
      let result = "";
      pages.forEach((page) => {
        result += page.innerHTML;
      });
      return result;
    }
  }

  return html;
}

/**
 * Utility function to get all editor outputs
 */
export function getEditorOutput(
  editor: ReturnType<typeof useEditor>,
  ydoc: Y.Doc,
  fragmentName: string,
  stripPages = false
): EditorOutput {
  if (!editor) {
    return {
      html: "",
      json: {},
      text: "",
      ydocState: "",
      yjsStructure: [],
      characterCount: 0,
      wordCount: 0,
    };
  }

  let html = editor.getHTML();
  const json = editor.getJSON();
  const text = editor.getText();

  // Strip page wrappers if requested
  if (stripPages) {
    html = stripPageWrappers(html);
  }

  // Get Yjs state as base64
  const ydocState = Y.encodeStateAsUpdate(ydoc);
  const ydocStateBase64 = btoa(
    String.fromCharCode.apply(null, Array.from(ydocState))
  );

  // Get human-readable Yjs structure
  const fragment = ydoc.getXmlFragment(fragmentName);
  const yjsStructure = getYjsStructure(fragment);

  // Calculate word count
  const wordCount = text
    .split(/\s+/)
    .filter((word) => word.length > 0).length;

  return {
    html,
    json: json as Record<string, unknown>,
    text,
    ydocState: ydocStateBase64,
    yjsStructure,
    characterCount: text.length,
    wordCount,
  };
}

/**
 * Hook for external access to editor output
 */
export function useEditorOutput(
  editor: ReturnType<typeof useEditor>,
  ydoc?: Y.Doc,
  fragmentName = "prosemirror"
): EditorOutput | null {
  const internalYdoc = useMemo(() => ydoc || new Y.Doc(), [ydoc]);

  if (!editor) return null;

  return getEditorOutput(editor, internalYdoc, fragmentName);
}
