import { Node, mergeAttributes } from "@tiptap/core";
import { ReactNodeViewRenderer } from "@tiptap/react";
import { QuizNodeComponent } from "./quiz-node-component";

export interface QuizBlockOptions {
  HTMLAttributes: Record<string, unknown>;
}

export interface QuizBlockAttributes {
  quizId: string;
  quizTitle: string;
  quizTitleAr?: string | null;
  questionCount: number;
  passingScore: number;
  timeLimit?: number | null;
  // For chapter-specific quiz
  isChapterQuiz?: boolean;
  chapterId?: string | null;
}

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    quizBlock: {
      /**
       * Insert a quiz block into the editor
       */
      setQuizBlock: (options: QuizBlockAttributes) => ReturnType;
      /**
       * Update quiz block attributes
       */
      updateQuizBlock: (options: Partial<QuizBlockAttributes>) => ReturnType;
    };
  }
}

export const QuizBlock = Node.create<QuizBlockOptions>({
  name: "quizBlock",

  group: "block",

  atom: true,

  draggable: true,

  addOptions() {
    return {
      HTMLAttributes: {},
    };
  },

  addAttributes() {
    return {
      quizId: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-quiz-id"),
        renderHTML: (attributes) => ({ "data-quiz-id": attributes["quizId"] }),
      },
      quizTitle: {
        default: "",
        parseHTML: (element) => element.getAttribute("data-quiz-title"),
        renderHTML: (attributes) => ({ "data-quiz-title": attributes["quizTitle"] }),
      },
      quizTitleAr: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-quiz-title-ar"),
        renderHTML: (attributes) => {
          if (!attributes["quizTitleAr"]) return {};
          return { "data-quiz-title-ar": attributes["quizTitleAr"] };
        },
      },
      questionCount: {
        default: 0,
        parseHTML: (element) => parseInt(element.getAttribute("data-question-count") || "0", 10),
        renderHTML: (attributes) => ({ "data-question-count": attributes["questionCount"] }),
      },
      passingScore: {
        default: 70,
        parseHTML: (element) => parseInt(element.getAttribute("data-passing-score") || "70", 10),
        renderHTML: (attributes) => ({ "data-passing-score": attributes["passingScore"] }),
      },
      timeLimit: {
        default: null,
        parseHTML: (element) => {
          const val = element.getAttribute("data-time-limit");
          return val ? parseInt(val, 10) : null;
        },
        renderHTML: (attributes) => {
          if (!attributes["timeLimit"]) return {};
          return { "data-time-limit": attributes["timeLimit"] };
        },
      },
      isChapterQuiz: {
        default: false,
        parseHTML: (element) => element.getAttribute("data-is-chapter-quiz") === "true",
        renderHTML: (attributes) => ({ "data-is-chapter-quiz": attributes["isChapterQuiz"] ? "true" : "false" }),
      },
      chapterId: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-chapter-id"),
        renderHTML: (attributes) => {
          if (!attributes["chapterId"]) return {};
          return { "data-chapter-id": attributes["chapterId"] };
        },
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'div[data-quiz-block="true"]',
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    const {
      quizId,
      quizTitle,
      quizTitleAr,
      questionCount,
      passingScore,
      timeLimit,
      isChapterQuiz,
      chapterId,
    } = HTMLAttributes as QuizBlockAttributes;

    return [
      "div",
      mergeAttributes(this.options.HTMLAttributes, {
        "data-quiz-block": "true",
        "data-quiz-id": quizId,
        "data-quiz-title": quizTitle,
        "data-quiz-title-ar": quizTitleAr || "",
        "data-question-count": questionCount,
        "data-passing-score": passingScore,
        "data-time-limit": timeLimit || "",
        "data-is-chapter-quiz": isChapterQuiz ? "true" : "false",
        "data-chapter-id": chapterId || "",
        class: "quiz-block-container",
      }),
      [
        "div",
        { class: "quiz-block-preview" },
        [
          "div",
          { class: "quiz-block-icon" },
          "📝",
        ],
        [
          "div",
          { class: "quiz-block-info" },
          [
            "span",
            { class: "quiz-block-title" },
            quizTitle || "Quiz",
          ],
          [
            "span",
            { class: "quiz-block-meta" },
            `${questionCount} questions • ${passingScore}% to pass${timeLimit ? ` • ${timeLimit} min` : ""}`,
          ],
        ],
      ],
    ];
  },

  addNodeView() {
    return ReactNodeViewRenderer(QuizNodeComponent);
  },

  addCommands() {
    return {
      setQuizBlock:
        (options) =>
        ({ commands }) => {
          return commands.insertContent({
            type: this.name,
            attrs: options,
          });
        },
      updateQuizBlock:
        (options) =>
        ({ commands }) => {
          return commands.updateAttributes(this.name, options);
        },
    };
  },
});
