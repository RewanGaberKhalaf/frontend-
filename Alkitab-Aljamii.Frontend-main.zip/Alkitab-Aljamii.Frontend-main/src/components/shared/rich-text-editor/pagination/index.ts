export { PageNode } from "./page-node";
export type { PageNodeOptions } from "./page-node";
export { PaginationExtension } from "./pagination-extension";
export type { PaginationExtensionOptions } from "./pagination-extension";
export { createPaginationPlugin, paginationPluginKey } from "./pagination-plugin";
export type { PaginationPluginOptions } from "./pagination-plugin";

// Constants
export const PAGE_DIMENSIONS = {
  A4: {
    width: 794,
    height: 1123,
    padding: 72,
    contentHeight: 979, // height - padding * 2
    contentWidth: 650, // width - padding * 2
  },
  LETTER: {
    width: 816,
    height: 1056,
    padding: 72,
    contentHeight: 912,
    contentWidth: 672,
  },
} as const;
