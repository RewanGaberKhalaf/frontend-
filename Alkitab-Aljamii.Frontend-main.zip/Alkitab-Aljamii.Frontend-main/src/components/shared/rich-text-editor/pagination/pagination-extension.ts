import { Extension } from "@tiptap/core";
import { createPaginationPlugin } from "./pagination-plugin";

export interface PaginationExtensionOptions {
  /**
   * Maximum content height per page in pixels
   * Default: 979px (A4 with 72px padding on each side)
   */
  pageContentHeight?: number;

  /**
   * Callback when page count changes
   */
  onPageCountChange?: (count: number) => void;
}

/**
 * Pagination Extension
 *
 * Automatically distributes document content across pages.
 * Requires PageNode to be registered in the schema.
 *
 * Usage:
 * ```ts
 * import { PaginationExtension, PageNode } from "./pagination";
 *
 * const editor = new Editor({
 *   extensions: [
 *     StarterKit,
 *     PageNode,
 *     PaginationExtension.configure({
 *       pageContentHeight: 979,
 *       onPageCountChange: (count) => console.log(`${count} pages`),
 *     }),
 *   ],
 * });
 * ```
 */
export const PaginationExtension = Extension.create<PaginationExtensionOptions>({
  name: "pagination",

  addOptions() {
    return {
      pageContentHeight: 979, // A4 height (1123) - padding (72*2)
      onPageCountChange: undefined,
    };
  },

  addProseMirrorPlugins() {
    return [
      createPaginationPlugin(this.editor.schema, {
        pageContentHeight: this.options.pageContentHeight,
        onPageCountChange: this.options.onPageCountChange,
      }),
    ];
  },
});

export default PaginationExtension;
