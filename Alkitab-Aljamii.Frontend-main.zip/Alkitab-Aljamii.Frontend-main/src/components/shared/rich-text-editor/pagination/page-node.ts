import { Node, mergeAttributes } from "@tiptap/core";
import { Plugin, PluginKey, TextSelection } from "@tiptap/pm/state";
import type { Node as ProseMirrorNode, ResolvedPos } from "@tiptap/pm/model";

export interface PageNodeOptions {
  /**
   * CSS class name for the page element
   * @default "pagination-page"
   */
  className: string;
}

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    pageNode: {
      /**
       * No commands yet - page nodes are managed by the pagination plugin
       */
    };
  }
}

/**
 * PageNode Extension
 *
 * Creates a block-level container that represents a single page in the document.
 * Content flows into these containers automatically via the pagination plugin.
 *
 * Key behaviors:
 * - Non-selectable: Users can't select the page node itself
 * - Non-copyable: Copy/paste only copies content, not page wrappers
 * - Seamless navigation: Cursor moves smoothly between pages
 *
 * Options:
 * - className: CSS class for the page div (default: "pagination-page", alt: "editor-page")
 */
export const PageNode = Node.create<PageNodeOptions>({
  name: "page",

  // Pages are top-level blocks in the document
  group: "block",

  // Pages contain block content (paragraphs, headings, lists, etc.)
  content: "block+",

  // DON'T isolate - this allows cursor to flow between pages naturally
  defining: false,
  isolating: false,

  // Prevent the page node from being selectable as a node
  selectable: false,

  // Don't allow dragging pages
  draggable: false,

  addOptions() {
    return {
      className: "pagination-page",
    };
  },

  addAttributes() {
    return {
      pageNumber: {
        default: 1,
        parseHTML: (element) => parseInt(element.getAttribute("data-page-number") || "1", 10),
        renderHTML: (attributes) => ({
          "data-page-number": attributes["pageNumber"],
        }),
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'div[data-page="true"]',
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      "div",
      mergeAttributes(HTMLAttributes, {
        "data-page": "true",
        class: this.options.className,
      }),
      0, // Content placeholder
    ];
  },

  // Add keyboard shortcuts to handle page boundaries
  addKeyboardShortcuts() {
    return {
      // Prevent backspace from merging pages - ONLY at the very start of page
      Backspace: ({ editor }) => {
        const { state } = editor;
        const { selection } = state;
        const { $from } = selection;

        // Only intercept if:
        // 1. Selection is empty (no text selected)
        // 2. We're at the absolute start of the first block on the page
        // 3. Not on the first page
        if (
          selection.empty &&
          isAtAbsoluteStartOfPage($from) &&
          !isFirstPage($from)
        ) {
          // Move cursor to end of previous page instead of merging
          const prevPageEnd = findPrevPageEnd(state.doc, $from);
          if (prevPageEnd !== null) {
            editor.commands.setTextSelection(prevPageEnd);
            return true; // Prevent default backspace
          }
        }

        return false; // Allow default behavior (normal deletion)
      },

      // Prevent delete from merging pages - ONLY at the very end of page
      Delete: ({ editor }) => {
        const { state } = editor;
        const { selection } = state;
        const { $from } = selection;

        // Only intercept at the absolute end of the last block on the page
        if (
          selection.empty &&
          isAtAbsoluteEndOfPage($from) &&
          !isLastPage($from, state.doc)
        ) {
          // Move cursor to start of next page instead of merging
          const nextPageStart = findNextPageStart(state.doc, $from);
          if (nextPageStart !== null) {
            editor.commands.setTextSelection(nextPageStart);
            return true; // Prevent default delete
          }
        }

        return false; // Allow default behavior (normal deletion)
      },
    };
  },

  // Add plugin to handle copy/paste - strip page wrappers from clipboard
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey("pageNodeClipboard"),
        props: {
          // Transform clipboard content to strip page wrappers
          transformCopied: (slice) => {
            // Extract content from page nodes when copying
            const content: ProseMirrorNode[] = [];

            slice.content.forEach((node) => {
              if (node.type.name === "page") {
                // Unwrap page content
                node.forEach((child) => content.push(child));
              } else {
                content.push(node);
              }
            });

            if (content.length === 0) {
              return slice;
            }

            // Return new slice with unwrapped content
            const { Fragment } = require("@tiptap/pm/model");
            return new (slice.constructor as any)(
              Fragment.from(content),
              slice.openStart,
              slice.openEnd
            );
          },

          // Also handle pasted content - ensure we don't paste page nodes
          transformPasted: (slice) => {
            const content: ProseMirrorNode[] = [];

            slice.content.forEach((node) => {
              if (node.type.name === "page") {
                // Unwrap page content when pasting
                node.forEach((child) => content.push(child));
              } else {
                content.push(node);
              }
            });

            if (content.length === 0) {
              return slice;
            }

            const { Fragment } = require("@tiptap/pm/model");
            return new (slice.constructor as any)(
              Fragment.from(content),
              slice.openStart,
              slice.openEnd
            );
          },
        },
      }),
    ];
  },
});

// Helper functions for page boundary detection

/**
 * Check if cursor is at the ABSOLUTE start of a page
 * This means: at position 0 of the first text position in the page
 * NOT just at the start of any paragraph
 */
function isAtAbsoluteStartOfPage($pos: ResolvedPos): boolean {
  // Find the page node
  for (let depth = $pos.depth; depth > 0; depth--) {
    const node = $pos.node(depth);
    if (node.type.name === "page") {
      const pageStart = $pos.start(depth);

      // We need to check if we're at the very first text position in this page
      // That means: page start + 1 (enter first block) + offset 0 in that block

      // Check if we're in the first child of the page
      const indexInPage = $pos.index(depth);
      if (indexInPage !== 0) return false;

      // Check if we're at offset 0 in that first child
      // $pos.parentOffset gives us the offset within the immediate parent
      if ($pos.parentOffset !== 0) return false;

      // Also make sure we're at the deepest text position start
      // (not somewhere in the middle of nested content)
      const firstChildDepth = depth + 1;
      if ($pos.depth > firstChildDepth) {
        // We're nested deeper - check if at start of that nesting too
        for (let d = firstChildDepth; d <= $pos.depth; d++) {
          if ($pos.index(d) !== 0) return false;
        }
      }

      return true;
    }
  }
  return false;
}

/**
 * Check if cursor is at the ABSOLUTE end of a page
 * This means: at the very last text position in the page
 */
function isAtAbsoluteEndOfPage($pos: ResolvedPos): boolean {
  for (let depth = $pos.depth; depth > 0; depth--) {
    const node = $pos.node(depth);
    if (node.type.name === "page") {
      // Check if we're in the last child of the page
      const indexInPage = $pos.index(depth);
      const pageChildCount = node.childCount;
      if (indexInPage !== pageChildCount - 1) return false;

      // Check if we're at the end of that last child
      const parent = $pos.parent;
      if ($pos.parentOffset !== parent.content.size) return false;

      return true;
    }
  }
  return false;
}

function isFirstPage($pos: ResolvedPos): boolean {
  // Find the page node and check if it's the first one
  for (let depth = $pos.depth; depth > 0; depth--) {
    const node = $pos.node(depth);
    if (node.type.name === "page") {
      const indexInParent = $pos.index(depth - 1);
      return indexInParent === 0;
    }
  }
  return true;
}

function isLastPage($pos: ResolvedPos, doc: ProseMirrorNode): boolean {
  // Find the page node and check if it's the last one
  for (let depth = $pos.depth; depth > 0; depth--) {
    const node = $pos.node(depth);
    if (node.type.name === "page") {
      const parent = $pos.node(depth - 1);
      const indexInParent = $pos.index(depth - 1);
      return indexInParent === parent.childCount - 1;
    }
  }
  return true;
}

function findPrevPageEnd(doc: ProseMirrorNode, $pos: ResolvedPos): number | null {
  // Find the end position of the previous page
  for (let depth = $pos.depth; depth > 0; depth--) {
    const node = $pos.node(depth);
    if (node.type.name === "page") {
      const indexInParent = $pos.index(depth - 1);
      if (indexInParent > 0) {
        // Get the previous page
        const pageStart = $pos.start(depth);
        const parent = $pos.node(depth - 1);
        let prevPageEnd = pageStart - 2; // Position before this page

        // Find exact end position of previous page's content
        let pos = 0;
        for (let i = 0; i < indexInParent; i++) {
          const child = parent.child(i);
          pos += child.nodeSize;
        }
        // pos is now at the start of current page, go back to end of prev page content
        return pos - 1;
      }
    }
  }
  return null;
}

function findNextPageStart(doc: ProseMirrorNode, $pos: ResolvedPos): number | null {
  // Find the start position of the next page
  for (let depth = $pos.depth; depth > 0; depth--) {
    const node = $pos.node(depth);
    if (node.type.name === "page") {
      const parent = $pos.node(depth - 1);
      const indexInParent = $pos.index(depth - 1);
      if (indexInParent < parent.childCount - 1) {
        // Get position after this page
        const pageEnd = $pos.end(depth);
        return pageEnd + 2; // Skip past page closing and next page opening
      }
    }
  }
  return null;
}

export default PageNode;
