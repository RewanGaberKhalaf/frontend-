import { Plugin, TextSelection } from "@tiptap/pm/state";
import { Node as ProseMirrorNode, Fragment, Schema } from "@tiptap/pm/model";
import type { EditorView } from "@tiptap/pm/view";
import {
  PAGE_CONTENT_HEIGHT,
  paginationPluginKey,
  type PaginationPluginOptions,
} from "./pagination-constants";
import {
  measureNodeHeights,
  measureNodeHeightsFromDOM,
} from "./pagination-height-utils";
import { getTextOffset, findPositionAtTextOffset } from "./pagination-position-utils";

// Re-export for backwards compatibility
export { paginationPluginKey } from "./pagination-constants";
export type { PaginationPluginOptions } from "./pagination-constants";

/**
 * Creates a pagination plugin that automatically distributes content across pages.
 *
 * How it works:
 * 1. On document changes, collect all content nodes
 * 2. Measure each node's height using DOM
 * 3. Distribute nodes across pages based on available height
 * 4. Rebuild document with PageNode wrappers
 * 5. Map cursor position to new document structure
 */
export function createPaginationPlugin(
  schema: Schema,
  options: PaginationPluginOptions = {}
) {
  const { pageContentHeight = PAGE_CONTENT_HEIGHT, onPageCountChange } = options;

  // Flag to prevent recursive pagination
  let isPaginating = false;

  return new Plugin({
    key: paginationPluginKey,

    view(editorView: EditorView) {
      // Initial pagination after editor mounts
      let initialTimeout: NodeJS.Timeout | null = null;

      const runInitialPagination = () => {
        // Wait for DOM to be ready
        initialTimeout = setTimeout(() => {
          paginateDocument(editorView, schema, pageContentHeight, onPageCountChange);
        }, 100);
      };

      runInitialPagination();

      return {
        update(view, prevState) {
          // Skip if we're already paginating or document hasn't changed
          if (isPaginating) return;
          if (view.state.doc.eq(prevState.doc)) return;

          // Check if the change was from pagination itself
          const meta = view.state.tr.getMeta(paginationPluginKey);
          if (meta?.fromPagination) return;

          // Debounce pagination to avoid too frequent updates
          if (initialTimeout) clearTimeout(initialTimeout);
          initialTimeout = setTimeout(() => {
            paginateDocument(view, schema, pageContentHeight, onPageCountChange);
          }, 150);
        },

        destroy() {
          if (initialTimeout) clearTimeout(initialTimeout);
        },
      };
    },
  });

  function paginateDocument(
    view: EditorView,
    schema: Schema,
    maxHeight: number,
    onPageCountChange?: (count: number) => void
  ) {
    if (isPaginating) return;
    isPaginating = true;

    try {
      const { state } = view;
      const { doc, selection } = state;
      const pageType = schema.nodes["page"];

      if (!pageType) {
        console.warn("PageNode not found in schema");
        isPaginating = false;
        return;
      }

      // Check if document already has pages
      const hasPages = doc.firstChild?.type.name === "page";

      let pages: ProseMirrorNode[];

      if (hasPages) {
        // Incremental pagination - respect existing page boundaries
        pages = paginateIncremental(doc, maxHeight, pageType, schema, view);
      } else {
        // Initial pagination - distribute all content
        const contentNodes: ProseMirrorNode[] = [];
        doc.forEach((node) => contentNodes.push(node));

        if (contentNodes.length === 0) {
          const emptyPara = schema.nodes["paragraph"]?.create();
          if (emptyPara) contentNodes.push(emptyPara);
        }

        const nodeHeights = measureNodeHeights(view, contentNodes);
        pages = distributeContent(contentNodes, nodeHeights, maxHeight, pageType, schema);
      }

      // Build new document
      const newDoc = schema.topNodeType.create(null, pages);

      // Check if document actually changed
      if (doc.eq(newDoc)) {
        isPaginating = false;
        return;
      }

      // Calculate text offset (ignoring page structure)
      const textOffsetBefore = getTextOffset(doc, selection.from);

      // Create transaction
      const tr = state.tr.replaceWith(0, doc.content.size, newDoc.content);
      tr.setMeta(paginationPluginKey, { fromPagination: true });

      // Find position in new doc that corresponds to same text offset
      const newPos = findPositionAtTextOffset(tr.doc, textOffsetBefore);

      try {
        tr.setSelection(TextSelection.near(tr.doc.resolve(newPos)));
      } catch {
        tr.setSelection(TextSelection.create(tr.doc, 1));
      }

      view.dispatch(tr);

      if (onPageCountChange) {
        onPageCountChange(pages.length);
      }
    } catch (error) {
      console.error("Pagination error:", error);
    } finally {
      isPaginating = false;
    }
  }

  /**
   * Incremental pagination - only moves content when pages overflow
   * Does NOT pull content back from next page just because there's room
   * Moves entire blocks to next page when they overflow (no mid-paragraph splitting)
   */
  function paginateIncremental(
    doc: ProseMirrorNode,
    maxHeight: number,
    pageType: any,
    schema: Schema,
    view: EditorView
  ): ProseMirrorNode[] {
    const pages: ProseMirrorNode[] = [];
    const pageContents: ProseMirrorNode[][] = [];

    // Extract content from each existing page
    doc.forEach((node) => {
      if (node.type.name === "page") {
        const content: ProseMirrorNode[] = [];
        node.forEach((child) => content.push(child));
        pageContents.push(content);
      } else {
        // Content not in a page - add to last page or create new
        if (pageContents.length === 0) {
          pageContents.push([node]);
        } else {
          const lastPage = pageContents[pageContents.length - 1];
          if (lastPage) {
            lastPage.push(node);
          }
        }
      }
    });

    // Ensure at least one page
    if (pageContents.length === 0) {
      const emptyPara = schema.nodes["paragraph"]?.create();
      if (emptyPara) {
        pageContents.push([emptyPara]);
      }
    }

    // Process each page - only push overflow to next page
    for (let i = 0; i < pageContents.length; i++) {
      const content = pageContents[i];
      if (!content || content.length === 0) continue;

      const heights = measureNodeHeightsFromDOM(view, content);
      let currentHeight = 0;
      const keepOnPage: ProseMirrorNode[] = [];
      const overflow: ProseMirrorNode[] = [];

      for (let j = 0; j < content.length; j++) {
        const node = content[j];
        if (!node) continue;
        const nodeHeight = heights[j] || 24;

        if (currentHeight + nodeHeight > maxHeight && keepOnPage.length > 0) {
          // This entire node and all following go to overflow
          overflow.push(node);
          for (let k = j + 1; k < content.length; k++) {
            const n = content[k];
            if (n) overflow.push(n);
          }
          break;
        } else {
          keepOnPage.push(node);
          currentHeight += nodeHeight;
        }
      }

      // Create page with kept content
      if (keepOnPage.length > 0) {
        pages.push(
          pageType.create({ pageNumber: pages.length + 1 }, Fragment.from(keepOnPage))
        );
      }

      // Push overflow to next page's content
      if (overflow.length > 0) {
        if (i + 1 < pageContents.length) {
          // Prepend overflow to next page
          pageContents[i + 1] = [...overflow, ...(pageContents[i + 1] || [])];
        } else {
          // Create new page for overflow
          pageContents.push(overflow);
        }
      }
    }

    // Handle empty pages - remove them but keep at least one
    if (pages.length === 0) {
      const emptyPara = schema.nodes["paragraph"]?.create();
      if (emptyPara) {
        pages.push(pageType.create({ pageNumber: 1 }, Fragment.from([emptyPara])));
      }
    }

    // Update page numbers
    return pages.map((page, index) => {
      if (page.attrs["pageNumber"] !== index + 1) {
        return pageType.create({ pageNumber: index + 1 }, page.content);
      }
      return page;
    });
  }
}

/**
 * Distribute content nodes across pages based on available height
 * Moves entire blocks to next page when they overflow (no mid-paragraph splitting)
 */
function distributeContent(
  nodes: ProseMirrorNode[],
  heights: number[],
  maxHeight: number,
  pageType: any,
  schema: Schema
): ProseMirrorNode[] {
  const pages: ProseMirrorNode[] = [];
  let currentPageContent: ProseMirrorNode[] = [];
  let currentHeight = 0;
  let pageNumber = 1;

  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    if (!node) continue;

    const nodeHeight = heights[i] || 24;

    // Check if adding this node would overflow the page
    if (currentHeight + nodeHeight > maxHeight && currentPageContent.length > 0) {
      // Create page with current content
      pages.push(pageType.create({ pageNumber }, Fragment.from(currentPageContent)));

      // Start new page
      pageNumber++;
      currentPageContent = [node];
      currentHeight = nodeHeight;
    } else {
      // Add to current page
      currentPageContent.push(node);
      currentHeight += nodeHeight;
    }
  }

  // Create final page with remaining content
  if (currentPageContent.length > 0) {
    pages.push(pageType.create({ pageNumber }, Fragment.from(currentPageContent)));
  }

  // Ensure at least one page exists
  if (pages.length === 0) {
    const emptyPara = schema.nodes["paragraph"]?.create();
    if (emptyPara) {
      pages.push(pageType.create({ pageNumber: 1 }, Fragment.from([emptyPara])));
    }
  }

  return pages;
}
