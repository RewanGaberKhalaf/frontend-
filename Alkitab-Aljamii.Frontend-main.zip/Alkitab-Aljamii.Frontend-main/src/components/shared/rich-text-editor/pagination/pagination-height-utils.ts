import { Node as ProseMirrorNode } from "@tiptap/pm/model";
import type { EditorView } from "@tiptap/pm/view";

/**
 * Estimate height for a node (fallback when DOM measurement fails)
 */
export function estimateNodeHeight(node: ProseMirrorNode): number {
  const lineHeight = 24;

  if (node.isTextblock) {
    const text = node.textContent;
    const lineCount = Math.max(1, Math.ceil(text.length / 80));
    const baseHeight = lineCount * lineHeight;

    if (node.type.name === "heading") {
      const level = (node.attrs["level"] as number) || 1;
      return baseHeight * (1.5 - level * 0.1) + 16;
    }
    return baseHeight + 8;
  } else if (node.type.name === "table") {
    let rowCount = 0;
    node.forEach((child) => {
      if (child.type.name === "tableRow") rowCount++;
    });
    return Math.max(50, rowCount * 40 + 20);
  } else if (node.type.name === "codeBlock") {
    const lines = node.textContent.split("\n").length;
    return lines * 20 + 32;
  } else if (node.type.name === "blockquote") {
    return estimateBlockquoteHeight(node, lineHeight);
  } else if (node.type.name === "bulletList" || node.type.name === "orderedList") {
    return estimateListHeight(node, lineHeight);
  } else if (node.type.name === "horizontalRule") {
    return 32;
  } else if (node.type.name === "resizableMedia") {
    return 300;
  }

  return lineHeight + 8;
}

export function estimateBlockquoteHeight(node: ProseMirrorNode, lineHeight: number): number {
  let height = 16; // Padding
  node.forEach((child) => {
    if (child.isTextblock) {
      const lines = Math.max(1, Math.ceil(child.textContent.length / 70));
      height += lines * lineHeight;
    }
  });
  return height;
}

export function estimateListHeight(node: ProseMirrorNode, lineHeight: number): number {
  let height = 8; // Margin
  node.forEach((item) => {
    height += lineHeight + 4; // Each list item
    // Check for nested content
    item.forEach((child) => {
      if (child.isTextblock && child.textContent.length > 60) {
        height += Math.ceil(child.textContent.length / 60) * lineHeight;
      }
    });
  });
  return height;
}

/**
 * Measure actual DOM heights by finding the rendered elements
 * This provides accurate heights for overflow detection
 */
export function measureNodeHeightsFromDOM(view: EditorView, nodes: ProseMirrorNode[]): number[] {
  const heights: number[] = [];

  // Try to find each node in the DOM and measure it
  for (const node of nodes) {
    let measured = false;

    // Walk through the view's DOM to find matching elements
    const pageElements = view.dom.querySelectorAll(".pagination-page");
    for (const pageEl of pageElements) {
      const children = pageEl.children;
      for (const child of children) {
        // Check if this DOM element corresponds to our node
        // by comparing text content (imperfect but works for most cases)
        if (child instanceof HTMLElement) {
          const domText = child.textContent || "";
          const nodeText = node.textContent || "";

          // If texts match closely, use this element's height
          if (nodeText && domText.includes(nodeText.substring(0, 50))) {
            const rect = child.getBoundingClientRect();
            const style = window.getComputedStyle(child);
            const marginTop = parseFloat(style.marginTop) || 0;
            const marginBottom = parseFloat(style.marginBottom) || 0;
            heights.push(rect.height + marginTop + marginBottom);
            measured = true;
            break;
          }
        }
      }
      if (measured) break;
    }

    // Fallback to estimation if DOM measurement failed
    if (!measured) {
      heights.push(estimateNodeHeight(node));
    }
  }

  return heights;
}

/**
 * Measure actual DOM heights for content nodes (estimation-based fallback)
 */
export function measureNodeHeights(view: EditorView, nodes: ProseMirrorNode[]): number[] {
  const heights: number[] = [];
  const defaultLineHeight = 24;

  for (const node of nodes) {
    if (node.isTextblock) {
      const text = node.textContent;
      const lineCount = Math.max(1, Math.ceil(text.length / 80));
      const baseHeight = lineCount * defaultLineHeight;

      if (node.type.name === "heading") {
        const level = (node.attrs["level"] as number) || 1;
        heights.push(baseHeight * (1.5 - level * 0.1) + 16);
      } else {
        heights.push(baseHeight + 8);
      }
    } else if (node.type.name === "table") {
      let rowCount = 0;
      node.forEach((child) => {
        if (child.type.name === "tableRow") rowCount++;
      });
      heights.push(Math.max(50, rowCount * 40 + 20));
    } else if (node.type.name === "codeBlock") {
      const lines = node.textContent.split("\n").length;
      heights.push(lines * 20 + 32);
    } else if (node.type.name === "blockquote") {
      heights.push(estimateBlockquoteHeight(node, defaultLineHeight));
    } else if (node.type.name === "bulletList" || node.type.name === "orderedList") {
      heights.push(estimateListHeight(node, defaultLineHeight));
    } else if (node.type.name === "horizontalRule") {
      heights.push(32);
    } else if (node.type.name === "resizableMedia") {
      heights.push(300);
    } else {
      heights.push(defaultLineHeight + 8);
    }
  }

  return heights;
}
