import { PluginKey } from "@tiptap/pm/state";

// A4 dimensions at 96 DPI
// A4 = 210mm × 297mm = 794px × 1123px
export const PAGE_WIDTH_PX = 794;
export const PAGE_HEIGHT_PX = 1123;
export const PAGE_PADDING_PX = 72; // ~0.75 inch margins
export const PAGE_CONTENT_HEIGHT = PAGE_HEIGHT_PX - PAGE_PADDING_PX * 2; // ~979px usable

export interface PaginationPluginOptions {
  pageContentHeight?: number;
  onPageCountChange?: (count: number) => void;
}

export const paginationPluginKey = new PluginKey("pagination");
