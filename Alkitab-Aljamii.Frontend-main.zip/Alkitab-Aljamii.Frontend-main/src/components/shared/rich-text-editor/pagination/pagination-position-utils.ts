import { Node as ProseMirrorNode } from "@tiptap/pm/model";

/**
 * Get text offset at a position, ignoring page node structure.
 * Counts: text characters + 1 per block boundary (paragraph, heading, etc)
 */
export function getTextOffset(doc: ProseMirrorNode, pos: number): number {
  let offset = 0;

  doc.nodesBetween(0, pos, (node, nodePos) => {
    if (node.type.name === "page") {
      // Skip page nodes themselves, just process their content
      return true;
    }

    if (node.isText) {
      // For text, count characters up to the position
      const start = nodePos;
      const end = Math.min(nodePos + node.nodeSize, pos);
      offset += end - start;
    } else if (node.isBlock && nodePos < pos) {
      // For blocks, add 1 for the "entry" into the block
      offset += 1;
    }

    return true;
  });

  return offset;
}

/**
 * Find position in document that corresponds to a text offset
 */
export function findPositionAtTextOffset(doc: ProseMirrorNode, targetOffset: number): number {
  let currentOffset = 0;
  let resultPos = 1;

  doc.descendants((node, pos) => {
    if (currentOffset >= targetOffset) {
      return false; // Stop
    }

    if (node.type.name === "page") {
      return true; // Skip page nodes, continue into content
    }

    if (node.isText) {
      const textLen = node.nodeSize;
      if (currentOffset + textLen >= targetOffset) {
        // Target is in this text node
        resultPos = pos + (targetOffset - currentOffset);
        return false;
      }
      currentOffset += textLen;
    } else if (node.isBlock) {
      currentOffset += 1;
      resultPos = pos + 1; // Default to start of this block
    }

    return true;
  });

  return Math.max(1, resultPos);
}
