'use client';

import { useCallback, memo } from 'react';
import { NodeViewContent, NodeViewWrapper, ReactNodeViewRenderer, type NodeViewProps } from '@tiptap/react';
import CodeBlockLowlight from '@tiptap/extension-code-block-lowlight';
import { common, createLowlight } from 'lowlight';

// Create lowlight instance for syntax highlighting
const lowlight = createLowlight(common);

// Popular languages for the dropdown
export const CODE_LANGUAGES = [
  { value: 'text', label: 'Plain Text' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'c', label: 'C' },
  { value: 'cpp', label: 'C++' },
  { value: 'csharp', label: 'C#' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
  { value: 'ruby', label: 'Ruby' },
  { value: 'php', label: 'PHP' },
  { value: 'swift', label: 'Swift' },
  { value: 'kotlin', label: 'Kotlin' },
  { value: 'sql', label: 'SQL' },
  { value: 'bash', label: 'Bash' },
  { value: 'shellscript', label: 'Shell' },
  { value: 'html', label: 'HTML' },
  { value: 'css', label: 'CSS' },
  { value: 'scss', label: 'SCSS' },
  { value: 'json', label: 'JSON' },
  { value: 'xml', label: 'XML' },
  { value: 'yaml', label: 'YAML' },
  { value: 'markdown', label: 'Markdown' },
  { value: 'graphql', label: 'GraphQL' },
  { value: 'dockerfile', label: 'Dockerfile' },
];

// Simple code block component with language selector
// Uses lowlight for synchronous syntax highlighting (no lag)
const CodeBlockComponent = memo(function CodeBlockComponent({ node, updateAttributes, editor }: NodeViewProps) {
  const language = (node.attrs['language'] as string) || 'text';

  const handleLanguageChange = useCallback(
    (e: React.ChangeEvent<HTMLSelectElement>) => {
      updateAttributes({ language: e.target.value });
    },
    [updateAttributes]
  );

  const isEditable = editor?.isEditable ?? false;

  return (
    <NodeViewWrapper className="code-block-wrapper">
      <div className="code-block-header">
        {isEditable ? (
          <select
            value={language}
            onChange={handleLanguageChange}
            contentEditable={false}
            className="code-language-select"
          >
            {CODE_LANGUAGES.map((lang) => (
              <option key={lang.value} value={lang.value}>
                {lang.label}
              </option>
            ))}
          </select>
        ) : (
          <span className="code-language-label">
            {CODE_LANGUAGES.find((l) => l.value === language)?.label || language}
          </span>
        )}
      </div>
      <pre className="code-block-content">
        <code>
          <NodeViewContent />
        </code>
      </pre>
    </NodeViewWrapper>
  );
});

// Export the configured CodeBlockLowlight extension
// Lowlight handles syntax highlighting synchronously via CSS classes
export const CodeBlockWithLanguage = CodeBlockLowlight.extend({
  addNodeView() {
    return ReactNodeViewRenderer(CodeBlockComponent);
  },
  addKeyboardShortcuts() {
    return {
      // Tab: indent in code blocks (like VS Code)
      Tab: ({ editor }) => {
        if (!editor.isActive('codeBlock')) return false;

        const { state } = editor;
        const { from, to, empty } = state.selection;

        if (empty) {
          // No selection - just insert 2 spaces
          editor.commands.insertContent('  ');
          return true;
        }

        // Has selection - indent all lines in selection
        // Get the text content and find line boundaries
        const $from = state.doc.resolve(from);
        const $to = state.doc.resolve(to);

        // Find the code block node
        const codeBlockNode = $from.node($from.depth);
        if (!codeBlockNode) return false;

        // Get text content of the code block
        const codeBlockStart = $from.start($from.depth);
        const text = codeBlockNode.textContent;

        // Calculate positions relative to code block
        const relativeFrom = from - codeBlockStart;
        const relativeTo = to - codeBlockStart;

        // Find line starts within selection
        const lines = text.split('\n');
        let pos = 0;
        const lineStarts: number[] = [];

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          if (line === undefined) continue;
          const lineEnd = pos + line.length;
          // Check if this line overlaps with selection
          if (lineEnd >= relativeFrom && pos <= relativeTo) {
            lineStarts.push(codeBlockStart + pos);
          }
          pos = lineEnd + 1; // +1 for newline
        }

        // Insert spaces at the start of each line (in reverse to maintain positions)
        let tr = state.tr;
        for (let i = lineStarts.length - 1; i >= 0; i--) {
          tr = tr.insertText('  ', lineStarts[i]);
        }

        editor.view.dispatch(tr);
        return true;
      },

      // Shift+Tab: outdent in code blocks
      'Shift-Tab': ({ editor }) => {
        if (!editor.isActive('codeBlock')) return false;

        const { state } = editor;
        const { from, to, empty } = state.selection;

        if (empty) {
          // No selection - remove up to 2 spaces before cursor
          const textBefore = state.doc.textBetween(Math.max(0, from - 2), from);
          if (textBefore === '  ') {
            editor.commands.deleteRange({ from: from - 2, to: from });
          } else if (textBefore.endsWith(' ')) {
            editor.commands.deleteRange({ from: from - 1, to: from });
          }
          return true;
        }

        // Has selection - outdent all lines in selection
        const $from = state.doc.resolve(from);

        // Find the code block node
        const codeBlockNode = $from.node($from.depth);
        if (!codeBlockNode) return false;

        // Get text content of the code block
        const codeBlockStart = $from.start($from.depth);
        const text = codeBlockNode.textContent;

        // Calculate positions relative to code block
        const relativeFrom = from - codeBlockStart;
        const relativeTo = to - codeBlockStart;

        // Find lines within selection and their leading spaces
        const lines = text.split('\n');
        let pos = 0;
        const linesToOutdent: { start: number; spaces: number }[] = [];

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          if (line === undefined) continue;
          const lineEnd = pos + line.length;
          // Check if this line overlaps with selection
          if (lineEnd >= relativeFrom && pos <= relativeTo) {
            const leadingSpaces = line.match(/^( {1,2})/);
            if (leadingSpaces && leadingSpaces[1]) {
              linesToOutdent.push({
                start: codeBlockStart + pos,
                spaces: leadingSpaces[1].length,
              });
            }
          }
          pos = lineEnd + 1;
        }

        // Remove leading spaces (in reverse to maintain positions)
        let tr = state.tr;
        for (let i = linesToOutdent.length - 1; i >= 0; i--) {
          const item = linesToOutdent[i];
          if (!item) continue;
          tr = tr.delete(item.start, item.start + item.spaces);
        }

        editor.view.dispatch(tr);
        return true;
      },
    };
  },
}).configure({
  lowlight,
  defaultLanguage: 'text',
});
