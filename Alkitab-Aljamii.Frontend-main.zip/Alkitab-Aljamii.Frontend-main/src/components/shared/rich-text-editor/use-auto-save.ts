"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import * as Y from "yjs";
import {
  type AutoSaveOptions,
  type AutoSaveState,
  type AutoSaveReturn,
  type DraftInfo,
  type StoredDraft,
  DRAFT_PREFIX,
} from "./auto-save-utils";

// Re-export types and utilities for backwards compatibility
export type { AutoSaveOptions, AutoSaveState, AutoSaveReturn, DraftInfo };
export { getAllDrafts, clearAllDrafts } from "./auto-save-utils";

/**
 * Hook for auto-saving editor content to browser storage
 */
export function useAutoSave(
  content: string,
  options: AutoSaveOptions
): AutoSaveReturn {
  const {
    storageKey,
    debounceMs = 1000,
    storage = "localStorage",
    onSave,
    onLoad,
    onError,
  } = options;

  const [state, setState] = useState<AutoSaveState>({
    hasDraft: false,
    lastSaved: null,
    isSaving: false,
  });

  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const contentRef = useRef(content);
  const fullKey = `${DRAFT_PREFIX}${storageKey}`;

  // Update content ref
  useEffect(() => {
    contentRef.current = content;
  }, [content]);

  // Get storage object
  const getStorage = useCallback((): Storage | null => {
    if (typeof window === "undefined") return null;
    return storage === "sessionStorage"
      ? window.sessionStorage
      : window.localStorage;
  }, [storage]);

  // Check for existing draft on mount
  useEffect(() => {
    const storageObj = getStorage();
    if (!storageObj) return;

    try {
      const saved = storageObj.getItem(fullKey);
      if (saved) {
        const draft: StoredDraft = JSON.parse(saved);
        setState((prev) => ({
          ...prev,
          hasDraft: true,
          lastSaved: new Date(draft.savedAt),
        }));
      }
    } catch (error) {
      onError?.(error as Error);
    }
  }, [fullKey, getStorage, onError]);

  // Save function
  const saveDraft = useCallback(
    (contentToSave: string) => {
      const storageObj = getStorage();
      if (!storageObj) return;

      setState((prev) => ({ ...prev, isSaving: true }));

      try {
        const wordCount = contentToSave
          .replace(/<[^>]+>/g, "")
          .split(/\s+/)
          .filter((w) => w.length > 0).length;

        const draft: StoredDraft = {
          content: contentToSave,
          savedAt: new Date().toISOString(),
          wordCount,
        };

        storageObj.setItem(fullKey, JSON.stringify(draft));

        const savedAt = new Date();
        setState({
          hasDraft: true,
          lastSaved: savedAt,
          isSaving: false,
        });

        onSave?.(savedAt);
      } catch (error) {
        setState((prev) => ({ ...prev, isSaving: false }));
        onError?.(error as Error);
      }
    },
    [fullKey, getStorage, onSave, onError]
  );

  // Debounced auto-save on content change
  useEffect(() => {
    if (!content) return;

    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Set new timeout
    timeoutRef.current = setTimeout(() => {
      saveDraft(content);
    }, debounceMs);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [content, debounceMs, saveDraft]);

  // Manual save
  const saveNow = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    saveDraft(contentRef.current);
  }, [saveDraft]);

  // Clear draft
  const clearDraft = useCallback(() => {
    const storageObj = getStorage();
    if (!storageObj) return;

    try {
      storageObj.removeItem(fullKey);
      setState({
        hasDraft: false,
        lastSaved: null,
        isSaving: false,
      });
    } catch (error) {
      onError?.(error as Error);
    }
  }, [fullKey, getStorage, onError]);

  // Load draft
  const loadDraft = useCallback((): string | null => {
    const storageObj = getStorage();
    if (!storageObj) return null;

    try {
      const saved = storageObj.getItem(fullKey);
      if (saved) {
        const draft: StoredDraft = JSON.parse(saved);
        onLoad?.();
        return draft.content;
      }
    } catch (error) {
      onError?.(error as Error);
    }

    return null;
  }, [fullKey, getStorage, onLoad, onError]);

  // Get draft info
  const getDraftInfo = useCallback((): DraftInfo | null => {
    const storageObj = getStorage();
    if (!storageObj) return null;

    try {
      const saved = storageObj.getItem(fullKey);
      if (saved) {
        const draft: StoredDraft = JSON.parse(saved);
        return {
          storageKey,
          savedAt: new Date(draft.savedAt),
          contentLength: draft.content.length,
          wordCount: draft.wordCount,
        };
      }
    } catch (error) {
      onError?.(error as Error);
    }

    return null;
  }, [fullKey, storageKey, getStorage, onError]);

  return {
    ...state,
    saveNow,
    clearDraft,
    loadDraft,
    getDraftInfo,
  };
}

/**
 * Hook for auto-saving with Yjs document state
 * Provides complete document recovery including cursor positions
 */
export function useAutoSaveWithYjs(
  content: string,
  ydoc: Y.Doc | undefined,
  options: AutoSaveOptions
): AutoSaveReturn & {
  loadYdocState: () => Uint8Array | null;
} {
  const base = useAutoSave(content, options);
  const { storageKey, storage = "localStorage", onError } = options;

  const fullKey = `${DRAFT_PREFIX}${storageKey}`;

  // Get storage object
  const getStorage = useCallback((): Storage | null => {
    if (typeof window === "undefined") return null;
    return storage === "sessionStorage"
      ? window.sessionStorage
      : window.localStorage;
  }, [storage]);

  // Enhanced save that includes Yjs state
  const saveNowWithYjs = useCallback(() => {
    const storageObj = getStorage();
    if (!storageObj) return;

    try {
      const wordCount = content
        .replace(/<[^>]+>/g, "")
        .split(/\s+/)
        .filter((w) => w.length > 0).length;

      let ydocState: string | undefined;
      if (ydoc) {
        const state = Y.encodeStateAsUpdate(ydoc);
        ydocState = btoa(String.fromCharCode.apply(null, Array.from(state)));
      }

      const draft: StoredDraft = {
        content,
        savedAt: new Date().toISOString(),
        wordCount,
        ydocState,
      };

      storageObj.setItem(fullKey, JSON.stringify(draft));
    } catch (error) {
      onError?.(error as Error);
    }

    base.saveNow();
  }, [content, ydoc, fullKey, getStorage, onError, base]);

  // Load Yjs state
  const loadYdocState = useCallback((): Uint8Array | null => {
    const storageObj = getStorage();
    if (!storageObj) return null;

    try {
      const saved = storageObj.getItem(fullKey);
      if (saved) {
        const draft: StoredDraft = JSON.parse(saved);
        if (draft.ydocState) {
          const binary = atob(draft.ydocState);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          return bytes;
        }
      }
    } catch (error) {
      onError?.(error as Error);
    }

    return null;
  }, [fullKey, getStorage, onError]);

  return {
    ...base,
    saveNow: saveNowWithYjs,
    loadYdocState,
  };
}
