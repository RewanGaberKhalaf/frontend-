"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Video, Music, Trash2, Check, FileText } from "lucide-react";
import { type MediaItem as ApiMediaItem, resolveMediaUrl } from "@/lib/api";

export interface MediaItemProps {
  item: ApiMediaItem;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
}

export function MediaGridItemConnected({
  item,
  isSelected,
  onSelect,
  onDelete,
}: MediaItemProps) {
  return (
    <div
      className={cn(
        "group relative aspect-square rounded-lg border overflow-hidden cursor-pointer transition-all",
        isSelected
          ? "border-primary ring-2 ring-primary/20"
          : "border-border hover:border-primary/50"
      )}
      onClick={onSelect}
    >
      {item.type === "image" ? (
        <img
          src={resolveMediaUrl(item.url)}
          alt={item.name}
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="h-full w-full bg-muted flex flex-col items-center justify-center p-2">
          {item.type === "video" ? (
            <Video className="h-6 w-6 text-muted-foreground mb-1" />
          ) : item.type === "document" ? (
            <FileText className="h-6 w-6 text-muted-foreground mb-1" />
          ) : (
            <Music className="h-6 w-6 text-muted-foreground mb-1" />
          )}
          <span className="text-[10px] text-muted-foreground text-center line-clamp-2">
            {item.name}
          </span>
        </div>
      )}

      {/* Selection indicator */}
      {isSelected && (
        <div className="absolute top-1.5 left-1.5 h-5 w-5 rounded-full bg-primary flex items-center justify-center">
          <Check className="h-3 w-3 text-primary-foreground" />
        </div>
      )}

      {/* Delete button */}
      <Button
        variant="destructive"
        size="icon"
        className="absolute top-1.5 right-1.5 h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
      >
        <Trash2 className="h-3 w-3" />
      </Button>
    </div>
  );
}

export function MediaListItemConnected({
  item,
  isSelected,
  onSelect,
  onDelete,
}: MediaItemProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all",
        isSelected
          ? "border-primary bg-primary/5"
          : "border-transparent hover:bg-muted/50"
      )}
      onClick={onSelect}
    >
      <div className="h-12 w-12 rounded bg-muted flex items-center justify-center overflow-hidden shrink-0">
        {item.type === "image" ? (
          <img
            src={resolveMediaUrl(item.url)}
            alt={item.name}
            className="h-full w-full object-cover"
          />
        ) : item.type === "video" ? (
          <Video className="h-6 w-6 text-muted-foreground" />
        ) : item.type === "document" ? (
          <FileText className="h-6 w-6 text-muted-foreground" />
        ) : (
          <Music className="h-6 w-6 text-muted-foreground" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{item.name}</p>
        <p className="text-xs text-muted-foreground">
          {item.type} • {formatFileSize(item.size)}
        </p>
      </div>

      {isSelected && (
        <Check className="h-5 w-5 text-primary shrink-0" />
      )}

      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
