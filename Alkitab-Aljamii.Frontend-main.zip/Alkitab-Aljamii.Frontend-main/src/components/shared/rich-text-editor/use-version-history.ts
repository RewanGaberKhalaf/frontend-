"use client";

import { useCallback, useState, useRef, useEffect } from "react";

export interface DocumentVersion {
  id: string;
  content: string;
  timestamp: Date;
  wordCount: number;
  label?: string; // Optional label like "Auto-save" or "Manual save"
}

export interface VersionHistoryOptions {
  /** Unique key for this document */
  storageKey: string;
  /** Maximum number of versions to keep (default: 10) */
  maxVersions?: number;
  /** Minimum time between auto-saves in ms (default: 30000 = 30s) */
  minIntervalMs?: number;
}

export interface VersionHistoryReturn {
  /** All saved versions (newest first) */
  versions: DocumentVersion[];
  /** Save a new version */
  saveVersion: (content: string, label?: string) => void;
  /** Restore to a specific version */
  restoreVersion: (versionId: string) => string | null;
  /** Get the original content (first version) */
  getOriginalContent: () => string | null;
  /** Clear all version history */
  clearHistory: () => void;
  /** Whether there are unsaved changes compared to last version */
  hasUnsavedChanges: boolean;
  /** Mark content as "clean" (matches saved version) */
  markClean: () => void;
  /** Mark content as "dirty" (has changes) */
  markDirty: () => void;
}

const VERSION_PREFIX = "editor_versions_";

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function countWords(content: string): number {
  return content
    .replace(/<[^>]+>/g, "")
    .split(/\s+/)
    .filter((w) => w.length > 0).length;
}

export function useVersionHistory(
  options: VersionHistoryOptions
): VersionHistoryReturn {
  const {
    storageKey,
    maxVersions = 10,
    minIntervalMs = 30000,
  } = options;

  const [versions, setVersions] = useState<DocumentVersion[]>([]);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const lastSaveTimeRef = useRef<number>(0);
  const fullKey = `${VERSION_PREFIX}${storageKey}`;

  // Load versions from storage on mount
  useEffect(() => {
    if (typeof window === "undefined") return;

    try {
      const saved = localStorage.getItem(fullKey);
      if (saved) {
        const parsed = JSON.parse(saved) as Array<{
          id: string;
          content: string;
          timestamp: string;
          wordCount: number;
          label?: string;
        }>;
        setVersions(
          parsed.map((v) => ({
            ...v,
            timestamp: new Date(v.timestamp),
          }))
        );
      }
    } catch {
      // Ignore parse errors
    }
  }, [fullKey]);

  // Save versions to storage
  const persistVersions = useCallback(
    (newVersions: DocumentVersion[]) => {
      if (typeof window === "undefined") return;

      try {
        const toStore = newVersions.map((v) => ({
          ...v,
          timestamp: v.timestamp.toISOString(),
        }));
        localStorage.setItem(fullKey, JSON.stringify(toStore));
      } catch {
        // Storage full or other error - ignore
      }
    },
    [fullKey]
  );

  // Save a new version
  const saveVersion = useCallback(
    (content: string, label?: string) => {
      const now = Date.now();

      // Check minimum interval (unless it's a manual/labeled save)
      if (!label && now - lastSaveTimeRef.current < minIntervalMs) {
        return;
      }

      lastSaveTimeRef.current = now;

      const newVersion: DocumentVersion = {
        id: generateId(),
        content,
        timestamp: new Date(now),
        wordCount: countWords(content),
        label,
      };

      setVersions((prev) => {
        // Add new version at the beginning
        const updated = [newVersion, ...prev];
        // Trim to max versions
        const trimmed = updated.slice(0, maxVersions);
        persistVersions(trimmed);
        return trimmed;
      });

      setHasUnsavedChanges(false);
    },
    [maxVersions, minIntervalMs, persistVersions]
  );

  // Restore to a specific version
  const restoreVersion = useCallback(
    (versionId: string): string | null => {
      const version = versions.find((v) => v.id === versionId);
      if (version) {
        setHasUnsavedChanges(false);
        return version.content;
      }
      return null;
    },
    [versions]
  );

  // Get original content (oldest version)
  const getOriginalContent = useCallback((): string | null => {
    if (versions.length === 0) return null;
    return versions[versions.length - 1]?.content ?? null;
  }, [versions]);

  // Clear all history
  const clearHistory = useCallback(() => {
    if (typeof window === "undefined") return;

    try {
      localStorage.removeItem(fullKey);
      setVersions([]);
      setHasUnsavedChanges(false);
    } catch {
      // Ignore errors
    }
  }, [fullKey]);

  // Mark as clean/dirty
  const markClean = useCallback(() => setHasUnsavedChanges(false), []);
  const markDirty = useCallback(() => setHasUnsavedChanges(true), []);

  return {
    versions,
    saveVersion,
    restoreVersion,
    getOriginalContent,
    clearHistory,
    hasUnsavedChanges,
    markClean,
    markDirty,
  };
}

/**
 * Get all documents with version history
 */
export function getAllDocumentsWithHistory(): string[] {
  if (typeof window === "undefined") return [];

  const keys: string[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key?.startsWith(VERSION_PREFIX)) {
      keys.push(key.replace(VERSION_PREFIX, ""));
    }
  }
  return keys;
}
