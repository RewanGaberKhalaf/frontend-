"use client";

import {
  Plus,
  Trash2,
  X,
  File,
  Link as LinkIcon,
  Video,
  Music,
  FileDown,
  ImageIcon,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ResourceForm } from "./resource-form";
import type { Chapter, ChapterResource } from "./types";

export interface ResourcesPanelProps {
  chapter: Chapter;
  onAddResource: (resource: Omit<ChapterResource, "id" | "order">) => void;
  onDeleteResource: (resourceId: string) => void;
  onClose: () => void;
}

export function ResourcesPanel({
  chapter,
  onAddResource,
  onDeleteResource,
  onClose,
}: ResourcesPanelProps) {
  return (
    <div className="w-80 border-l bg-background flex flex-col shrink-0">
      <div className="p-4 border-b flex items-center justify-between">
        <h3 className="font-semibold text-sm">Chapter Resources</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {/* Add Resource Button */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="w-full gap-1">
                <Plus className="h-4 w-4" />
                Add Resource
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Resource</DialogTitle>
              </DialogHeader>
              <ResourceForm onAdd={onAddResource} />
            </DialogContent>
          </Dialog>

          {/* Resources List */}
          <div className="space-y-2">
            {(!chapter.resources || chapter.resources.length === 0) && (
              <p className="text-sm text-muted-foreground text-center py-8">
                No resources yet. Add links, files, videos, or other materials
                for this chapter.
              </p>
            )}
            {chapter.resources?.map((resource) => (
              <div
                key={resource.id}
                className="flex items-start gap-3 p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className="shrink-0 mt-0.5">
                  {resource.type === "link" && (
                    <LinkIcon className="h-4 w-4 text-blue-500" />
                  )}
                  {resource.type === "video" && (
                    <Video className="h-4 w-4 text-red-500" />
                  )}
                  {resource.type === "audio" && (
                    <Music className="h-4 w-4 text-purple-500" />
                  )}
                  {resource.type === "document" && (
                    <FileDown className="h-4 w-4 text-orange-500" />
                  )}
                  {resource.type === "image" && (
                    <ImageIcon className="h-4 w-4 text-green-500" />
                  )}
                  {resource.type === "file" && (
                    <File className="h-4 w-4 text-gray-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">
                      {resource.title}
                    </span>
                    <a
                      href={resource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                  {resource.description && (
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {resource.description}
                    </p>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="shrink-0 h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                  onClick={() => onDeleteResource(resource.id)}
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
