"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { NodeViewWrapper, type NodeViewProps } from "@tiptap/react";
import { cn } from "@/lib/utils";
import type { MediaAlignment, MediaFloat } from "./resizable-media-extension";
import {
  MediaContent,
  MediaControlBar,
  MediaResizeHandles,
  useMediaResize,
  useMediaUrlRefresh,
  MAX_MEDIA_HEIGHT_PX,
} from "./media";

export function ResizableMediaComponent({
  node,
  updateAttributes,
  deleteNode,
  selected,
}: NodeViewProps) {
  const {
    src,
    mediaId,
    mediaType,
    alt,
    title,
    width,
    height,
    alignment,
    float,
  } = node.attrs as {
    src: string;
    mediaId?: string;
    mediaType: "image" | "video" | "audio" | "iframe";
    alt?: string;
    title?: string;
    width: string;
    height: string;
    alignment: MediaAlignment;
    float: MediaFloat;
  };

  const containerRef = useRef<HTMLDivElement>(null);
  const [showControls, setShowControls] = useState(false);
  const [sizePopoverOpen, setSizePopoverOpen] = useState(false);
  const hideTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // URL refresh hook
  const { isLoadError, isRefreshing, refreshSignedUrl, handleMediaError } =
    useMediaUrlRefresh({
      mediaId,
      src,
      updateAttributes,
    });

  // Resize hook
  const {
    isResizing,
    currentWidth,
    currentHeight,
    setCurrentWidth,
    setCurrentHeight,
    handleResizeStart,
    applySize,
  } = useMediaResize({
    width,
    height,
    alignment,
    containerRef: containerRef as React.RefObject<HTMLDivElement>,
    updateAttributes,
  });

  // Handle showing controls with delay on hide
  const handleMouseEnter = useCallback(() => {
    if (hideTimeoutRef.current) {
      clearTimeout(hideTimeoutRef.current);
      hideTimeoutRef.current = null;
    }
    setShowControls(true);
  }, []);

  const handleMouseLeave = useCallback(() => {
    if (isResizing || sizePopoverOpen) return;
    // Delay hiding to allow moving to the control bar
    hideTimeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 300);
  }, [isResizing, sizePopoverOpen]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
    };
  }, []);

  // Handlers for control bar
  const handleAlignmentChange = useCallback(
    (newAlignment: MediaAlignment, newFloat: MediaFloat) => {
      updateAttributes({ alignment: newAlignment, float: newFloat });
    },
    [updateAttributes]
  );

  const handleFloatChange = useCallback(
    (newFloat: MediaFloat, newAlignment?: MediaAlignment) => {
      if (newAlignment) {
        updateAttributes({ float: newFloat, alignment: newAlignment });
      } else {
        updateAttributes({ float: newFloat });
      }
    },
    [updateAttributes]
  );

  // Wrapper styles - controls width and positioning
  const wrapperStyle: React.CSSProperties = {
    width: currentWidth,
    height: currentHeight,
    maxWidth: "100%",
    maxHeight: MAX_MEDIA_HEIGHT_PX,
    display: "block",
    boxSizing: "border-box" as const,
    ...(float !== "none"
      ? {
          float: float as "left" | "right",
          marginRight: float === "left" ? "1rem" : undefined,
          marginLeft: float === "right" ? "1rem" : undefined,
          marginBottom: "0.5rem",
          clear: "none" as const,
        }
      : {
          clear: "both" as const,
          marginLeft:
            alignment === "center" || alignment === "right" ? "auto" : undefined,
          marginRight:
            alignment === "center" || alignment === "left" ? "auto" : undefined,
        }),
  };

  const showControlsOrSelected = showControls || selected;

  return (
    <NodeViewWrapper
      style={wrapperStyle}
      className={cn(
        "resizable-media-wrapper relative",
        float === "left" && "media-float-left",
        float === "right" && "media-float-right",
        float === "none" && "media-no-float",
        selected && "ring-2 ring-primary ring-offset-2",
        isResizing && "select-none"
      )}
      data-drag-handle
      data-float={float}
      data-alignment={alignment}
    >
      <div
        ref={containerRef}
        className={cn(
          "relative group w-full",
          currentHeight !== "auto" && "h-full"
        )}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {/* Media Content */}
        <div
          className={cn(
            "relative overflow-hidden rounded-lg border bg-muted/30 w-full",
            currentHeight !== "auto" && "h-full"
          )}
        >
          <MediaContent
            src={src}
            mediaId={mediaId}
            mediaType={mediaType}
            alt={alt}
            title={title}
            currentHeight={currentHeight}
            isLoadError={isLoadError}
            isRefreshing={isRefreshing}
            onRefreshUrl={refreshSignedUrl}
            onMediaError={handleMediaError}
          />

          {/* Resize Handles */}
          <MediaResizeHandles
            visible={showControlsOrSelected || isResizing}
            isResizing={isResizing}
            onResizeStart={handleResizeStart}
          />
        </div>

        {/* Control Bar */}
        <MediaControlBar
          visible={showControlsOrSelected && !isResizing}
          alignment={alignment}
          float={float}
          currentWidth={currentWidth}
          currentHeight={currentHeight}
          sizePopoverOpen={sizePopoverOpen}
          onSizePopoverOpenChange={setSizePopoverOpen}
          onAlignmentChange={handleAlignmentChange}
          onFloatChange={handleFloatChange}
          onWidthChange={setCurrentWidth}
          onHeightChange={setCurrentHeight}
          onApplySize={applySize}
          onDelete={deleteNode}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        />

        {/* Size Tooltip during resize */}
        {isResizing && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/75 text-white px-2 py-1 rounded text-sm">
            {currentWidth} × {currentHeight}
          </div>
        )}
      </div>
    </NodeViewWrapper>
  );
}
