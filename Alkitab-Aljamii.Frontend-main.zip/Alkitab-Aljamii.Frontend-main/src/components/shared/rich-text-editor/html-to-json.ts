import { generateJSON } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableCell } from '@tiptap/extension-table-cell';
import { TableHeader } from '@tiptap/extension-table-header';
import { TextStyle } from '@tiptap/extension-text-style';
import { FontFamily } from '@tiptap/extension-font-family';
import { Color } from '@tiptap/extension-color';
import Highlight from '@tiptap/extension-highlight';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import { FontSize } from './font-size-extension';
import { ResizableMedia } from './resizable-media-extension';
import { CodeBlockWithLanguage } from './code-block-extension';
import type { ProseMirrorDoc } from '@/types';

// Extensions used for HTML to JSON conversion
// Must match the extensions used in the editor
const extensions = [
  StarterKit.configure({ codeBlock: false }),
  TextStyle,
  FontFamily,
  FontSize,
  Color,
  Highlight.configure({ multicolor: true }),
  Underline,
  TextAlign.configure({
    types: ['heading', 'paragraph'],
    alignments: ['left', 'center', 'right', 'justify'],
  }),
  Table.configure({ resizable: true }),
  TableRow,
  TableCell,
  TableHeader,
  ResizableMedia,
  CodeBlockWithLanguage,
];

/**
 * Converts HTML content to ProseMirror JSON format
 * Uses the same extensions as the book editor for consistent parsing
 */
export function htmlToJson(html: string): ProseMirrorDoc {
  if (!html || !html.trim()) {
    return {
      type: 'doc',
      content: [{ type: 'paragraph' }],
    };
  }

  try {
    const json = generateJSON(html, extensions);
    return json as ProseMirrorDoc;
  } catch (error) {
    console.error('Failed to convert HTML to JSON:', error);
    // Return a doc with the HTML as a paragraph (fallback)
    return {
      type: 'doc',
      content: [{ type: 'paragraph' }],
    };
  }
}
