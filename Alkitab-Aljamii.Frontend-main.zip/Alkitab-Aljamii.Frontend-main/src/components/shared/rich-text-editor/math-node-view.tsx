"use client";

import { useCallback, useEffect, useRef, useState, memo } from "react";
import { NodeViewWrapper, type NodeViewProps } from "@tiptap/react";
import katex from "katex";
import "katex/dist/katex.min.css";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, X } from "lucide-react";

// Stable preview component - must be defined outside to prevent re-creation
const MathPreview = memo(function MathPreview({
  value,
  displayMode,
}: {
  value: string;
  displayMode: boolean;
}) {
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!previewRef.current) return;

    // Small delay to ensure DOM is ready
    const timeoutId = setTimeout(() => {
      if (!previewRef.current) return;
      try {
        katex.render(value || "\\text{Preview}", previewRef.current, {
          displayMode,
          throwOnError: false,
          errorColor: "#ef4444",
          trust: true,
          strict: false,
        });
      } catch {
        if (previewRef.current) {
          previewRef.current.textContent = value || "Preview";
        }
      }
    }, 0);

    return () => clearTimeout(timeoutId);
  }, [value, displayMode]);

  return (
    <div
      className={cn(
        "min-h-[48px] max-h-[150px] p-4 bg-muted rounded-md overflow-auto",
        displayMode ? "text-xl" : "text-base"
      )}
    >
      <div
        ref={previewRef}
        className={cn(
          "flex items-center min-h-[24px]",
          displayMode ? "justify-center" : "justify-start"
        )}
      />
    </div>
  );
});

// Common math symbols for quick insertion
const MATH_SYMBOLS = [
  { symbol: "\\frac{a}{b}", display: "a/b", label: "Fraction" },
  { symbol: "\\sqrt{x}", display: "√x", label: "Square root" },
  { symbol: "\\sum_{i=1}^{n}", display: "Σ", label: "Sum" },
  { symbol: "\\int_{a}^{b}", display: "∫", label: "Integral" },
  { symbol: "\\prod_{i=1}^{n}", display: "∏", label: "Product" },
  { symbol: "\\lim_{x \\to \\infty}", display: "lim", label: "Limit" },
  { symbol: "\\alpha", display: "α", label: "Alpha" },
  { symbol: "\\beta", display: "β", label: "Beta" },
  { symbol: "\\gamma", display: "γ", label: "Gamma" },
  { symbol: "\\delta", display: "δ", label: "Delta" },
  { symbol: "\\theta", display: "θ", label: "Theta" },
  { symbol: "\\pi", display: "π", label: "Pi" },
  { symbol: "\\infty", display: "∞", label: "Infinity" },
  { symbol: "\\pm", display: "±", label: "Plus-minus" },
  { symbol: "\\times", display: "×", label: "Times" },
  { symbol: "\\div", display: "÷", label: "Divide" },
  { symbol: "\\leq", display: "≤", label: "Less or equal" },
  { symbol: "\\geq", display: "≥", label: "Greater or equal" },
  { symbol: "\\neq", display: "≠", label: "Not equal" },
  { symbol: "\\approx", display: "≈", label: "Approximately" },
];

export function MathNodeView({
  node,
  updateAttributes,
  deleteNode,
  selected,
  editor,
}: NodeViewProps) {
  const isBlock = node.type.name === "mathBlock";
  const latex = (node.attrs["latex"] as string) || "";
  const containerRef = useRef<HTMLDivElement>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(latex);
  const [renderError, setRenderError] = useState<string | null>(null);

  // Render the math using KaTeX
  useEffect(() => {
    if (!containerRef.current) return;

    try {
      katex.render(latex || "\\text{Empty formula}", containerRef.current, {
        displayMode: isBlock,
        throwOnError: false,
        errorColor: "#ef4444",
        trust: true,
        strict: false,
      });
      setRenderError(null);
    } catch (error) {
      setRenderError(error instanceof Error ? error.message : "Invalid LaTeX");
    }
  }, [latex, isBlock]);

  const handleSave = useCallback(() => {
    updateAttributes({ latex: editValue });
    setIsEditing(false);
  }, [editValue, updateAttributes]);

  const handleCancel = useCallback(() => {
    setEditValue(latex);
    setIsEditing(false);
  }, [latex]);

  const handleDoubleClick = useCallback(() => {
    if (editor.isEditable) {
      setEditValue(latex);
      setIsEditing(true);
    }
  }, [editor.isEditable, latex]);

  const handleDelete = useCallback(() => {
    deleteNode();
  }, [deleteNode]);

  const insertSymbol = useCallback((symbol: string) => {
    setEditValue((prev) => prev + symbol);
  }, []);

  // Quick symbols component
  const QuickSymbols = () => (
    <div className="space-y-2">
      <Label>Quick Symbols</Label>
      <div className="flex flex-wrap gap-1">
        {MATH_SYMBOLS.map((item) => (
          <Tooltip key={item.symbol}>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 px-2 text-xs font-mono"
                onClick={() => insertSymbol(item.symbol)}
              >
                {item.display}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">{item.label}</TooltipContent>
          </Tooltip>
        ))}
      </div>
    </div>
  );

  if (isBlock) {
    return (
      <>
        <NodeViewWrapper
          className={cn(
            "math-block-wrapper my-4 p-4 rounded-md border",
            "flex items-center justify-center",
            selected && "ring-2 ring-primary ring-offset-2",
            editor.isEditable && "cursor-pointer hover:bg-muted/50",
            renderError && "border-destructive"
          )}
          onDoubleClick={handleDoubleClick}
          data-type="math-block"
        >
          <div className="relative w-full">
            {editor.isEditable && selected && (
              <div className="absolute -top-2 -right-2 flex gap-1 z-10">
                <Button
                  size="icon"
                  variant="secondary"
                  className="h-6 w-6"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditValue(latex);
                    setIsEditing(true);
                  }}
                >
                  <Pencil className="h-3 w-3" />
                </Button>
                <Button
                  size="icon"
                  variant="destructive"
                  className="h-6 w-6"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete();
                  }}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            )}
            <div
              ref={containerRef}
              className={cn(
                "text-xl",
                renderError && "text-destructive text-sm"
              )}
            />
          </div>
        </NodeViewWrapper>

        <Dialog open={isEditing} onOpenChange={setIsEditing}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Block Formula</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>LaTeX Code</Label>
                <Textarea
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  placeholder="Enter LaTeX formula, e.g., \frac{a}{b}"
                  className="font-mono min-h-[100px]"
                  dir="ltr"
                />
              </div>
              <QuickSymbols />
              <div className="space-y-2">
                <Label>Preview</Label>
                <MathPreview value={editValue} displayMode={true} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCancel}>
                Cancel
              </Button>
              <Button onClick={handleSave}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  // Inline math
  return (
    <>
      <NodeViewWrapper
        as="span"
        className={cn(
          "math-inline-wrapper inline px-0.5 rounded",
          selected && "ring-2 ring-primary ring-offset-1",
          editor.isEditable && "cursor-pointer hover:bg-muted/50",
          renderError && "text-destructive"
        )}
        onDoubleClick={handleDoubleClick}
        data-type="math-inline"
      >
        <span ref={containerRef} className="inline align-middle" />
      </NodeViewWrapper>

      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Inline Formula</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>LaTeX Code</Label>
              <Textarea
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                placeholder="Enter LaTeX formula, e.g., x^2 + y^2 = z^2"
                className="font-mono min-h-[80px]"
                dir="ltr"
              />
            </div>
            <QuickSymbols />
            <div className="space-y-2">
              <Label>Preview</Label>
              <MathPreview value={editValue} displayMode={false} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
