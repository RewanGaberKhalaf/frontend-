import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from '@tiptap/pm/state';
import { marked } from 'marked';

// Configure marked for safe HTML output
marked.setOptions({
  gfm: true, // GitHub Flavored Markdown
  breaks: false, // Don't convert single \n to <br>, use double for paragraphs
});

/**
 * Detects if text looks like Markdown and returns a confidence score
 */
function getMarkdownScore(text: string): number {
  let score = 0;

  // Strong indicators (high confidence)
  if (/^#{1,6}\s+.+$/m.test(text)) score += 3; // Headers: # Header
  if (/```[\s\S]*?```/.test(text)) score += 3; // Code blocks
  if (/^---+$/m.test(text)) score += 2; // Horizontal rules
  if (/^\s*>\s+.+$/m.test(text)) score += 2; // Blockquotes

  // Medium indicators
  if (/\*\*[^*]+\*\*/.test(text)) score += 2; // Bold: **text**
  if (/\*[^*\s][^*]*\*/.test(text)) score += 1; // Italic: *text* (excluding lone *)
  if (/^\s*[-*+]\s+.+$/m.test(text)) score += 2; // Unordered lists
  if (/^\s*\d+\.\s+.+$/m.test(text)) score += 2; // Ordered lists
  if (/`[^`]+`/.test(text)) score += 1; // Inline code

  // Links and images
  if (/\[([^\]]+)\]\(([^)]+)\)/.test(text)) score += 2; // Links
  if (/!\[([^\]]*)\]\(([^)]+)\)/.test(text)) score += 2; // Images

  // Other indicators
  if (/__[^_]+__/.test(text)) score += 1; // Bold: __text__
  if (/~~[^~]+~~/.test(text)) score += 1; // Strikethrough

  return score;
}

/**
 * Converts Markdown to HTML and cleans up the output
 */
function markdownToHtml(markdown: string): string {
  try {
    let html = marked.parse(markdown, { async: false }) as string;

    // Clean up: If marked wraps everything in a single <pre><code>, unwrap it
    // This can happen with certain markdown patterns
    const trimmed = html.trim();
    if (trimmed.startsWith('<pre><code') && trimmed.endsWith('</code></pre>')) {
      // Check if this is the ONLY content (entire paste was treated as code)
      const preCodeMatch = trimmed.match(/^<pre><code[^>]*>([\s\S]*)<\/code><\/pre>$/);
      if (preCodeMatch && preCodeMatch[1]) {
        // The entire content was wrapped in pre/code - this is likely a bug
        // Re-parse the inner content or return as paragraphs
        const innerContent = preCodeMatch[1]
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&amp;/g, '&')
          .replace(/&quot;/g, '"');
        // Try to re-parse if it looks like markdown was double-escaped
        if (getMarkdownScore(innerContent) > 0) {
          html = marked.parse(innerContent, { async: false }) as string;
        }
      }
    }

    return html;
  } catch {
    return markdown;
  }
}

/**
 * TipTap extension that handles pasting Markdown content
 * and converts it to rich text.
 *
 * Priority is set high to ensure this runs before other paste handlers.
 */
export const MarkdownPaste = Extension.create({
  name: 'markdownPaste',
  priority: 1000, // High priority to run before other extensions

  addProseMirrorPlugins() {
    const editor = this.editor;

    return [
      new Plugin({
        key: new PluginKey('markdownPaste'),
        props: {
          // Set high priority for the paste handler
          handlePaste(view, event) {
            const clipboardData = event.clipboardData;
            if (!clipboardData) return false;

            // Get plain text first
            const text = clipboardData.getData('text/plain');
            if (!text || !text.trim()) return false;

            // Calculate Markdown confidence score
            const markdownScore = getMarkdownScore(text);

            // Lower threshold: be more aggressive in detecting markdown
            // Score >= 1 means we found at least one markdown indicator
            if (markdownScore < 1) {
              return false;
            }

            // Check if there's HTML content
            const htmlContent = clipboardData.getData('text/html');

            // If HTML exists but Markdown score is moderate, prefer Markdown parsing
            // Score >= 3 means we're confident it's Markdown source
            if (htmlContent && htmlContent.trim() && markdownScore < 3) {
              // Has HTML and low Markdown confidence, let TipTap handle it
              return false;
            }

            // Convert Markdown to HTML
            const html = markdownToHtml(text);

            // Don't insert if it's just empty paragraphs
            if (!html || html.trim() === '' || html.trim() === '<p></p>') {
              return false;
            }

            // Insert the HTML content with explicit handling to avoid code block creation
            editor.commands.insertContent(html, {
              parseOptions: {
                preserveWhitespace: false,
              },
            });

            // Prevent default paste behavior
            event.preventDefault();
            return true;
          },
        },
      }),
    ];
  },
});
