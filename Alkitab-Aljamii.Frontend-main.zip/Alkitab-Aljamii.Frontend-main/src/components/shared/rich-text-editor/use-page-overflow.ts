"use client";

import { useCallback, useEffect, useRef } from "react";
import type { Editor } from "@tiptap/core";

// A4 content area height (page height minus margins)
const CONTENT_HEIGHT = 931; // 1123 - 96 - 96

export interface UsePageOverflowOptions {
  /** The TipTap editor instance */
  editor: Editor | null;
  /** Container element that has the page height constraint */
  containerRef: React.RefObject<HTMLDivElement>;
  /** Whether overflow detection is enabled */
  enabled?: boolean;
  /** Callback when content overflows - receives the HTML content that should move to next page */
  onOverflow?: (overflowHtml: string, remainingHtml: string) => void;
  /** Debounce delay in ms */
  debounceMs?: number;
}

/**
 * Hook that detects when content overflows the page height
 * and splits content appropriately
 */
export function usePageOverflow({
  editor,
  containerRef,
  enabled = true,
  onOverflow,
  debounceMs = 100,
}: UsePageOverflowOptions) {
  const checkTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastHeightRef = useRef(0);
  const isProcessingRef = useRef(false);

  const checkOverflow = useCallback(() => {
    if (!editor || !containerRef.current || !enabled || isProcessingRef.current) {
      return;
    }

    const editorElement = containerRef.current.querySelector(".ProseMirror") as HTMLElement;
    if (!editorElement) return;

    const contentHeight = editorElement.scrollHeight;

    // Only process if content exceeds page height
    if (contentHeight <= CONTENT_HEIGHT) {
      lastHeightRef.current = contentHeight;
      return;
    }

    // Prevent re-entrancy
    isProcessingRef.current = true;

    try {
      // Find the block node that causes overflow
      const overflowData = findOverflowBlock(editorElement, CONTENT_HEIGHT, editor);

      if (overflowData && onOverflow) {
        onOverflow(overflowData.overflowHtml, overflowData.remainingHtml);
      }
    } finally {
      isProcessingRef.current = false;
    }
  }, [editor, containerRef, enabled, onOverflow]);

  // Debounced check
  const scheduleCheck = useCallback(() => {
    if (checkTimeoutRef.current) {
      clearTimeout(checkTimeoutRef.current);
    }
    checkTimeoutRef.current = setTimeout(checkOverflow, debounceMs);
  }, [checkOverflow, debounceMs]);

  // Listen to editor updates
  useEffect(() => {
    if (!editor || !enabled) return;

    const handleUpdate = () => {
      scheduleCheck();
    };

    editor.on("update", handleUpdate);

    // Initial check
    scheduleCheck();

    return () => {
      editor.off("update", handleUpdate);
      if (checkTimeoutRef.current) {
        clearTimeout(checkTimeoutRef.current);
      }
    };
  }, [editor, enabled, scheduleCheck]);

  // Also observe resize
  useEffect(() => {
    if (!containerRef.current || !enabled) return;

    const resizeObserver = new ResizeObserver(() => {
      scheduleCheck();
    });

    const editorElement = containerRef.current.querySelector(".ProseMirror");
    if (editorElement) {
      resizeObserver.observe(editorElement);
    }

    return () => {
      resizeObserver.disconnect();
    };
  }, [containerRef, enabled, scheduleCheck]);

  return {
    checkOverflow,
    scheduleCheck,
  };
}

/**
 * Find the block element that causes overflow and split content
 */
function findOverflowBlock(
  editorElement: HTMLElement,
  maxHeight: number,
  editor: Editor
): { overflowHtml: string; remainingHtml: string } | null {
  const children = editorElement.children;
  let accumulatedHeight = 0;
  let overflowStartIndex = -1;

  // Find which block causes overflow
  for (let i = 0; i < children.length; i++) {
    const child = children[i] as HTMLElement;
    const childHeight = child.offsetHeight;
    const marginTop = parseInt(getComputedStyle(child).marginTop) || 0;
    const marginBottom = parseInt(getComputedStyle(child).marginBottom) || 0;
    const totalHeight = childHeight + marginTop + marginBottom;

    if (accumulatedHeight + totalHeight > maxHeight) {
      overflowStartIndex = i;
      break;
    }

    accumulatedHeight += totalHeight;
  }

  if (overflowStartIndex === -1 || overflowStartIndex === 0) {
    // No overflow found or first element overflows (can't split)
    return null;
  }

  // Get the HTML for content that fits and content that overflows
  const json = editor.getJSON();
  if (!json.content || json.content.length === 0) return null;

  // Split the content at the overflow point
  // This is simplified - in reality we'd need to map DOM indices to ProseMirror positions
  const remainingContent = json.content.slice(0, overflowStartIndex);
  const overflowContent = json.content.slice(overflowStartIndex);

  if (overflowContent.length === 0) return null;

  // Convert back to HTML
  const tempEditor = editor;

  // Create HTML strings from JSON fragments
  const remainingHtml = generateHtmlFromNodes(remainingContent);
  const overflowHtml = generateHtmlFromNodes(overflowContent);

  return {
    overflowHtml,
    remainingHtml,
  };
}

/**
 * Generate HTML from ProseMirror JSON nodes
 * This is a simplified version - for production, use editor.getHTML() with filtered content
 */
function generateHtmlFromNodes(nodes: unknown[]): string {
  // This is a placeholder - in practice, we'd need to properly serialize
  // For now, return JSON stringified which will be converted back
  return JSON.stringify(nodes);
}

/**
 * Utility to split editor content at a specific position
 */
export function splitContentAtPosition(
  editor: Editor,
  position: number
): { before: string; after: string } | null {
  const { doc } = editor.state;

  if (position < 0 || position > doc.content.size) {
    return null;
  }

  // Create a slice from start to position
  const beforeSlice = doc.slice(0, position);
  const afterSlice = doc.slice(position);

  // This would need proper HTML serialization
  return {
    before: beforeSlice.content.toString(),
    after: afterSlice.content.toString(),
  };
}
