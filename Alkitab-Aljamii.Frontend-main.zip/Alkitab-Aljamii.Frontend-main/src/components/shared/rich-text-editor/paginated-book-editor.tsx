"use client";

import { useState, useCallback, useRef } from "react";
import { RichTextEditor, type RichTextEditorRef } from "./rich-text-editor";
import { EditorToolbar } from "./editor-toolbar";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { BookOpen, Settings } from "lucide-react";
import { MediaLibraryConnected } from "./media-library-connected";
import { PageSetupDialog } from "./page-setup-dialog";
import { type MediaItem, resolveMediaUrl } from "@/lib/api";
import type { Editor } from "@tiptap/react";

import {
  ChapterSidebar,
  PaginatedResourcesPanel,
  usePaginatedDocument,
  A4_WIDTH_PX,
  type PaginatedBookEditorProps,
} from "./paginated-book-editor-parts";

// Re-export for backward compatibility
export type { PaginatedBookEditorProps } from "./paginated-book-editor-parts";

export function PaginatedBookEditor({
  document: initialDocument,
  onDocumentChange,
  className,
}: PaginatedBookEditorProps) {
  const [mediaLibraryOpen, setMediaLibraryOpen] = useState(false);
  const [mediaLibraryFilter, setMediaLibraryFilter] = useState<
    "image" | "video" | "audio" | "all"
  >("all");
  const [activeEditor, setActiveEditor] = useState<Editor | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [resourcesExpanded, setResourcesExpanded] = useState(false);
  const [pageCount, setPageCount] = useState(1);

  const editorRef = useRef<RichTextEditorRef>(null);

  // Document state hook
  const {
    document,
    currentChapter,
    chapterContent,
    expandedChapters,
    editingChapterId,
    editingTitle,
    setEditingTitle,
    activeChapter,
    updateBookHeader,
    updateBookFooter,
    toggleChapter,
    navigateToChapter,
    handleChapterUpdate,
    addChapter,
    deleteChapter,
    startEditingTitle,
    saveChapterTitle,
    cancelEditingTitle,
    addResource,
    deleteResource,
  } = usePaginatedDocument({
    initialDocument,
    onDocumentChange,
  });

  // Handle page count changes from the PageBreakExtension
  const handlePageCountChange = useCallback((count: number) => {
    setPageCount(count);
  }, []);

  // Track active editor
  const handleEditorRef = useCallback((ref: RichTextEditorRef | null) => {
    if (ref?.editor) {
      setActiveEditor(ref.editor);
    }
  }, []);

  return (
    <div className={cn("flex h-full", className)}>
      {/* Sidebar with chapters */}
      <ChapterSidebar
        document={document}
        activeChapterId={activeChapter.chapterId}
        expandedChapters={expandedChapters}
        editingChapterId={editingChapterId}
        editingTitle={editingTitle}
        onEditingTitleChange={setEditingTitle}
        onToggleChapter={toggleChapter}
        onNavigateToChapter={navigateToChapter}
        onAddChapter={addChapter}
        onDeleteChapter={deleteChapter}
        onStartEditingTitle={startEditingTitle}
        onSaveChapterTitle={saveChapterTitle}
        onCancelEditingTitle={cancelEditingTitle}
      />

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-muted/50">
        {/* Toolbar */}
        <div className="bg-background border-b shadow-sm flex items-center">
          <EditorToolbar
            editor={activeEditor}
            enableTable={true}
            enableCodeBlock={true}
            enableMedia={true}
            onOpenMediaLibrary={(filterType) => {
              setMediaLibraryFilter(filterType || "all");
              setMediaLibraryOpen(true);
            }}
          />
          {/* Toolbar Actions */}
          <div className="ml-auto flex items-center gap-1 mr-2">
            {/* Page count indicator */}
            <span className="text-sm text-muted-foreground mr-2">
              {pageCount} {pageCount === 1 ? "page" : "pages"}
            </span>

            {/* Resources Toggle */}
            <Button
              variant={resourcesExpanded ? "default" : "ghost"}
              size="sm"
              onClick={() => setResourcesExpanded(!resourcesExpanded)}
            >
              <BookOpen className="h-4 w-4 mr-1" />
              Resources
              {currentChapter?.resources?.length ? (
                <span className="ml-1 text-xs bg-primary-foreground/20 px-1.5 rounded">
                  {currentChapter.resources.length}
                </span>
              ) : null}
            </Button>

            {/* Page Setup */}
            <PageSetupDialog
              open={settingsOpen}
              onOpenChange={setSettingsOpen}
              header={document.header}
              footer={document.footer}
              onUpdateHeader={updateBookHeader}
              onUpdateFooter={updateBookFooter}
            />
          </div>
        </div>

        {/* Paginated Editor Area */}
        <div className="flex-1 overflow-auto paginated-canvas">
          <div className="flex flex-col items-center py-8 px-4 min-h-full">
            {/* Chapter Info */}
            <div className="w-full max-w-[794px] mb-4 flex items-center justify-between text-sm text-muted-foreground">
              <span>{currentChapter?.title}</span>
              <span>{currentChapter?.wordCount.toLocaleString()} words</span>
            </div>

            {/* Single A4 Page Container with Visual Page Breaks */}
            <div
              className="page-paper paginated-document"
              style={{
                width: A4_WIDTH_PX,
              }}
            >
              {currentChapter && (
                <RichTextEditor
                  key={currentChapter.id}
                  ref={handleEditorRef}
                  content={chapterContent}
                  onUpdate={handleChapterUpdate}
                  showToolbar={false}
                  className="border-0 rounded-none"
                  enablePageBreaks={true}
                  onPageCountChange={handlePageCountChange}
                />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Resources Panel */}
      {resourcesExpanded && currentChapter && (
        <PaginatedResourcesPanel
          chapter={currentChapter}
          onAddResource={(resource) => addResource(currentChapter.id, resource)}
          onDeleteResource={(resourceId) =>
            deleteResource(currentChapter.id, resourceId)
          }
          onClose={() => setResourcesExpanded(false)}
        />
      )}

      {/* Media Library Dialog */}
      <MediaLibraryConnected
        open={mediaLibraryOpen}
        onOpenChange={setMediaLibraryOpen}
        filterType={mediaLibraryFilter}
        onSelect={(item: MediaItem) => {
          if (!activeEditor) return;

          activeEditor
            .chain()
            .focus()
            .setResizableMedia({
              src: resolveMediaUrl(item.url),
              mediaId: item.id,
              mediaType: item.type as "image" | "video" | "audio",
              alt: item.name,
              width: "80%",
              alignment: "center",
              float: "none",
            })
            .run();
        }}
      />
    </div>
  );
}

export default PaginatedBookEditor;
