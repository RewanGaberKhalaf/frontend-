"use client";

import { useRef } from "react";
import { cn } from "@/lib/utils";
import type { RichTextEditorRef } from "./rich-text-editor";
import {
  type ChapterEditorProps,
  useChapterEditorState,
  DraftRecoveryBanner,
  ChapterEditorSidebar,
  ChapterEditorCanvas,
  DiscardChangesDialog,
} from "./chapter-editor-parts";

// Re-export types for backward compatibility
export type { ChapterEditorProps } from "./chapter-editor-parts";

export function ChapterEditor({
  document: initialDocument,
  onDocumentChange,
  className,
  showPageBreaks = true,
  enableAutoSave = true,
  onAutoSave,
  onDiscardChanges,
  enableVersionHistory = true,
}: ChapterEditorProps) {
  const editorRefsMap = useRef<Map<string, RichTextEditorRef>>(new Map());

  const {
    document,
    activeChapterId,
    activeChapter,
    activeEditor,
    setActiveEditor,
    sidebarCollapsed,
    setSidebarCollapsed,
    editingChapterId,
    setEditingChapterId,
    editingTitle,
    setEditingTitle,
    showDraftRecovery,
    showDiscardDialog,
    setShowDiscardDialog,
    chapterPageStarts,
    hasChangesFromOriginal,
    // Auto-save state
    isSaving,
    autoSaveTime,
    // Version history
    versions,
    // Actions
    switchToChapter,
    addChapter,
    deleteChapter,
    startEditingTitle,
    saveChapterTitle,
    recoverDraft,
    dismissDraftRecovery,
    handleRestoreVersion,
    handleDiscardChanges,
    handleChapterUpdate,
  } = useChapterEditorState({
    initialDocument,
    onDocumentChange,
    enableAutoSave,
    onAutoSave,
    onDiscardChanges,
    enableVersionHistory,
  });

  return (
    <div className={cn("flex h-full flex-col", className)}>
      {/* Draft Recovery Banner */}
      {showDraftRecovery && (
        <DraftRecoveryBanner onRecover={recoverDraft} onDiscard={dismissDraftRecovery} />
      )}

      <div className="flex flex-1 min-h-0">
        {/* Chapter Sidebar */}
        <ChapterEditorSidebar
          document={document}
          activeChapterId={activeChapterId}
          sidebarCollapsed={sidebarCollapsed}
          setSidebarCollapsed={setSidebarCollapsed}
          editingChapterId={editingChapterId}
          setEditingChapterId={setEditingChapterId}
          editingTitle={editingTitle}
          setEditingTitle={setEditingTitle}
          chapterPageStarts={chapterPageStarts}
          switchToChapter={switchToChapter}
          addChapter={addChapter}
          deleteChapter={deleteChapter}
          startEditingTitle={startEditingTitle}
          saveChapterTitle={saveChapterTitle}
          enableAutoSave={enableAutoSave}
          isSaving={isSaving}
          autoSaveTime={autoSaveTime}
          enableVersionHistory={enableVersionHistory}
          versions={versions}
          handleRestoreVersion={handleRestoreVersion}
          hasChangesFromOriginal={hasChangesFromOriginal}
          setShowDiscardDialog={setShowDiscardDialog}
        />

        {/* Editor Canvas */}
        <ChapterEditorCanvas
          document={document}
          activeChapterId={activeChapterId}
          activeEditor={activeEditor}
          setActiveEditor={setActiveEditor}
          showPageBreaks={showPageBreaks}
          chapterPageStarts={chapterPageStarts}
          editorRefsMap={editorRefsMap}
          handleChapterUpdate={handleChapterUpdate}
          switchToChapter={switchToChapter}
        />
      </div>

      {/* Discard Changes Confirmation Dialog */}
      <DiscardChangesDialog
        open={showDiscardDialog}
        onOpenChange={setShowDiscardDialog}
        onConfirm={handleDiscardChanges}
      />
    </div>
  );
}
