import type { Page, Chapter, DocumentStructure, DocumentMeta } from './types';

/**
 * Generate a unique ID
 */
function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

/**
 * Helper to create a new page
 */
export function createPage(order: number): Page {
  return { id: generateId(), order, content: '<p></p>', wordCount: 0 };
}

/**
 * Helper to create a new empty document
 */
export function createEmptyDocument(title: string = 'Untitled Document'): DocumentStructure {
  const now = new Date();
  return {
    meta: { id: generateId(), title, createdAt: now, updatedAt: now },
    chapters: [{ id: generateId(), title: 'Chapter 1', order: 0, pages: [createPage(0)], wordCount: 0, createdAt: now, updatedAt: now }],
    totalPages: 1,
    totalWords: 0,
  };
}

/**
 * Helper to create a new chapter
 */
export function createChapter(order: number, title?: string): Chapter {
  const now = new Date();
  return { id: generateId(), title: title || `Chapter ${order + 1}`, order, pages: [createPage(0)], wordCount: 0, createdAt: now, updatedAt: now };
}

/**
 * Calculate page count from HTML content
 */
export function estimatePageCount(html: string): number {
  const text = html.replace(/<[^>]+>/g, '');
  const CHARS_PER_PAGE = 2500;
  return Math.max(1, Math.ceil(text.length / CHARS_PER_PAGE));
}

/**
 * Calculate word count from HTML content
 */
export function calculateWordCount(html: string): number {
  const text = html.replace(/<[^>]+>/g, '');
  return text.split(/\s+/).filter((word) => word.length > 0).length;
}

/**
 * Update document totals based on chapters
 */
export function updateDocumentTotals(doc: DocumentStructure): DocumentStructure {
  const totalPages = doc.chapters.reduce((sum, ch) => sum + ch.pages.length, 0);
  const totalWords = doc.chapters.reduce((sum, ch) => sum + ch.wordCount, 0);
  return { ...doc, totalPages, totalWords, meta: { ...doc.meta, updatedAt: new Date() } };
}

/**
 * Update chapter word count from its pages
 */
export function updateChapterWordCount(chapter: Chapter): Chapter {
  const wordCount = chapter.pages.reduce((sum, page) => sum + page.wordCount, 0);
  return { ...chapter, wordCount, updatedAt: new Date() };
}

/**
 * Sample document for testing
 */
export const sampleDocument: DocumentStructure = {
  meta: { id: 'sample-doc', title: 'Introduction to Programming', description: "A beginner's guide to programming concepts", author: 'Demo Author', createdAt: new Date(), updatedAt: new Date() },
  chapters: [
    {
      id: 'ch1', title: 'Getting Started', order: 0, wordCount: 130, createdAt: new Date(), updatedAt: new Date(),
      pages: [
        { id: 'ch1-p1', order: 0, wordCount: 80, content: `<h1>Getting Started with Programming</h1><p>Welcome to your programming journey! This chapter will introduce you to the fundamental concepts.</p><h2>What is Programming?</h2><p>Programming is the process of creating a set of instructions that tell a computer how to perform a task. These instructions are written in a <strong>programming language</strong>.</p><p>Programming languages come in many forms:</p><ul><li><strong>Python</strong> - Great for beginners, used in data science and AI</li><li><strong>JavaScript</strong> - Powers the web, runs in browsers</li><li><strong>TypeScript</strong> - JavaScript with types, better for large projects</li><li><strong>Rust</strong> - Systems programming, memory safe</li></ul>` },
        { id: 'ch1-p2', order: 1, wordCount: 50, content: `<h2>Your First Program</h2><p>The traditional first program in any language is "Hello, World!" - a simple program that displays a greeting.</p><pre><code class="language-typescript">function greet(name: string): string { return \`Hello, \${name}!\`; }\nconsole.log(greet("World"));</code></pre><blockquote><p>The best way to learn programming is by doing. Don't just read—write code!</p></blockquote>` },
      ],
    },
    {
      id: 'ch2', title: 'Variables and Data Types', order: 1, wordCount: 130, createdAt: new Date(), updatedAt: new Date(),
      pages: [
        { id: 'ch2-p1', order: 0, wordCount: 70, content: `<h1>Variables and Data Types</h1><p>In this chapter, we'll explore how computers store and manipulate data.</p><h2>What are Variables?</h2><p>A <em>variable</em> is a named container that holds a value. Think of it like a labeled box where you can store information.</p><pre><code class="language-typescript">// Declaring variables\nlet age = 25;           // A number\nlet name = "Alice";     // A string (text)\nlet isStudent = true;   // A boolean (true/false)</code></pre>` },
        { id: 'ch2-p2', order: 1, wordCount: 60, content: `<h2>Common Data Types</h2><table><thead><tr><th>Type</th><th>Description</th><th>Example</th></tr></thead><tbody><tr><td>Number</td><td>Numeric values</td><td>42, 3.14</td></tr><tr><td>String</td><td>Text</td><td>"Hello"</td></tr><tr><td>Boolean</td><td>True or false</td><td>true, false</td></tr></tbody></table><h2>Type Safety</h2><p>TypeScript adds <strong>type safety</strong> to JavaScript, helping catch errors before your code runs.</p>` },
      ],
    },
    {
      id: 'ch3', title: 'Control Flow', order: 2, wordCount: 120, createdAt: new Date(), updatedAt: new Date(),
      pages: [
        { id: 'ch3-p1', order: 0, wordCount: 60, content: `<h1>Control Flow</h1><p>Control flow determines the order in which code executes. This chapter covers conditionals and loops.</p><h2>Conditional Statements</h2><p>Use <code>if</code> statements to execute code only when certain conditions are met:</p><pre><code class="language-typescript">const temperature = 25;\nif (temperature > 30) {\n  console.log("It's hot!");\n} else if (temperature > 20) {\n  console.log("It's nice weather.");\n} else {\n  console.log("It's cold!");\n}</code></pre>` },
        { id: 'ch3-p2', order: 1, wordCount: 60, content: `<h2>Loops</h2><p>Loops let you repeat code multiple times:</p><pre><code class="language-typescript">// For loop\nfor (let i = 0; i < 5; i++) {\n  console.log(\`Count: \${i}\`);\n}\n\n// While loop\nlet count = 0;\nwhile (count < 5) {\n  console.log(\`Count: \${count}\`);\n  count++;\n}</code></pre><h2>Practice Exercise</h2><p>Try writing a loop that prints all even numbers from 1 to 20.</p>` },
      ],
    },
  ],
  totalPages: 6,
  totalWords: 380,
};
