"use client";

import React, { useEffect, useState, useRef, useCallback } from "react";
import { type Editor } from "@tiptap/react";
import { cn } from "@/lib/utils";
import {
  Plus,
  Minus,
  Trash2,
  Rows3,
  Columns3,
  PaintBucket,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

// Cell background colors - "Default" adapts to theme, others are explicit
const CELL_COLORS = [
  { name: "Default", value: "", isThemed: true },
  { name: "White", value: "#ffffff" },
  { name: "Black", value: "#1f2937" },
  { name: "Light Gray", value: "#f3f4f6" },
  { name: "Gray", value: "#e5e7eb" },
  { name: "Dark Gray", value: "#d1d5db" },
  { name: "Light Yellow", value: "#fef9c3" },
  { name: "Light Green", value: "#dcfce7" },
  { name: "Light Blue", value: "#dbeafe" },
  { name: "Light Pink", value: "#fce7f3" },
  { name: "Light Purple", value: "#f3e8ff" },
  { name: "Light Orange", value: "#ffedd5" },
  { name: "Light Red", value: "#fee2e2" },
  { name: "Light Cyan", value: "#cffafe" },
];

interface TableFloatingToolbarProps {
  editor: Editor;
}

export function TableFloatingToolbar({ editor }: TableFloatingToolbarProps) {
  const [colorPickerOpen, setColorPickerOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [isInHeaderRow, setIsInHeaderRow] = useState(false);
  const [hasHeaderRow, setHasHeaderRow] = useState(false);
  const toolbarRef = useRef<HTMLDivElement>(null);

  // Check if current selection is in a header row
  const checkHeaderRow = useCallback(() => {
    if (!editor.isActive("table")) {
      return { inHeader: false, hasHeader: false };
    }

    const { view } = editor;
    const { from } = view.state.selection;
    const domAtPos = view.domAtPos(from);

    // Walk up to find if we're in a th or thead
    let node = domAtPos.node as HTMLElement;
    let inHeader = false;
    let tableEl: HTMLTableElement | null = null;

    while (node && node !== view.dom) {
      if (node.tagName === "TH" || node.tagName === "THEAD") {
        inHeader = true;
      }
      if (node.tagName === "TABLE") {
        tableEl = node as HTMLTableElement;
        break;
      }
      node = node.parentElement as HTMLElement;
    }

    // Check if table has a header row (th elements)
    const hasHeader = tableEl ? tableEl.querySelector("th") !== null : false;

    return { inHeader, hasHeader };
  }, [editor]);

  // Update toolbar position based on selected table
  const updatePosition = useCallback(() => {
    if (!editor.isActive("table")) {
      setIsVisible(false);
      return;
    }

    // Check header status
    const { inHeader, hasHeader } = checkHeaderRow();
    setIsInHeaderRow(inHeader);
    setHasHeaderRow(hasHeader);

    // Find the table element
    const { view } = editor;
    const { from } = view.state.selection;
    const domAtPos = view.domAtPos(from);
    let tableEl: HTMLElement | null = null;

    // Walk up to find table element
    let node = domAtPos.node as HTMLElement;
    while (node && node !== view.dom) {
      if (node.tagName === "TABLE") {
        tableEl = node;
        break;
      }
      node = node.parentElement as HTMLElement;
    }

    if (!tableEl) {
      setIsVisible(false);
      return;
    }

    const tableRect = tableEl.getBoundingClientRect();
    const editorRect = view.dom.getBoundingClientRect();

    // Position toolbar above the table, centered
    const toolbarWidth = toolbarRef.current?.offsetWidth || 300;
    const left = tableRect.left - editorRect.left + tableRect.width / 2 - toolbarWidth / 2;
    const top = tableRect.top - editorRect.top - 48; // 48px above table

    setPosition({ top: Math.max(0, top), left: Math.max(0, left) });
    setIsVisible(true);
  }, [editor, checkHeaderRow]);

  // Listen for selection changes
  useEffect(() => {
    const handleUpdate = () => {
      // Small delay to let DOM update
      requestAnimationFrame(updatePosition);
    };

    editor.on("selectionUpdate", handleUpdate);
    editor.on("transaction", handleUpdate);

    return () => {
      editor.off("selectionUpdate", handleUpdate);
      editor.off("transaction", handleUpdate);
    };
  }, [editor, updatePosition]);

  if (!isVisible) return null;

  return (
    <div
      ref={toolbarRef}
      className="absolute z-50 flex items-center gap-0.5 rounded-lg border bg-background p-1 shadow-lg animate-in fade-in-0 zoom-in-95 duration-150"
      style={{
        top: position.top,
        left: position.left,
      }}
    >
      {/* Toggle Header Row */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().toggleHeaderRow().run()}
          >
            {hasHeaderRow ? (
              <ToggleRight className="h-4 w-4 text-primary" />
            ) : (
              <ToggleLeft className="h-4 w-4" />
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          {hasHeaderRow ? "Remove Header Row" : "Add Header Row"}
        </TooltipContent>
      </Tooltip>

      <div className="w-px h-5 bg-border mx-1" />

      {/* Row controls */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().addRowBefore().run()}
            disabled={isInHeaderRow}
          >
            <div className={cn("relative", isInHeaderRow && "opacity-40")}>
              <Rows3 className="h-4 w-4" />
              <Plus className="h-2 w-2 absolute -top-0.5 -right-0.5 text-primary" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          {isInHeaderRow ? "Cannot add row above header" : "Add Row Above"}
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().addRowAfter().run()}
          >
            <div className="relative">
              <Rows3 className="h-4 w-4" />
              <Plus className="h-2 w-2 absolute -bottom-0.5 -right-0.5 text-primary" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">Add Row Below</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().deleteRow().run()}
          >
            <div className="relative">
              <Rows3 className="h-4 w-4" />
              <Minus className="h-2 w-2 absolute -bottom-0.5 -right-0.5 text-destructive" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">Delete Row</TooltipContent>
      </Tooltip>

      <div className="w-px h-5 bg-border mx-1" />

      {/* Column controls */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().addColumnBefore().run()}
          >
            <div className="relative">
              <Columns3 className="h-4 w-4" />
              <Plus className="h-2 w-2 absolute -top-0.5 -left-0.5 text-primary" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">Add Column Left</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().addColumnAfter().run()}
          >
            <div className="relative">
              <Columns3 className="h-4 w-4" />
              <Plus className="h-2 w-2 absolute -top-0.5 -right-0.5 text-primary" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">Add Column Right</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0"
            onClick={() => editor.chain().focus().deleteColumn().run()}
          >
            <div className="relative">
              <Columns3 className="h-4 w-4" />
              <Minus className="h-2 w-2 absolute -bottom-0.5 -right-0.5 text-destructive" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">Delete Column</TooltipContent>
      </Tooltip>

      <div className="w-px h-5 bg-border mx-1" />

      {/* Cell background color */}
      <Popover open={colorPickerOpen} onOpenChange={setColorPickerOpen}>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <PaintBucket className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent side="bottom">Cell Background</TooltipContent>
        </Tooltip>
        <PopoverContent className="w-auto p-2" side="bottom" align="center">
          <p className="text-xs font-medium text-muted-foreground mb-2">Cell Background</p>
          <div className="grid grid-cols-5 gap-1">
            {CELL_COLORS.map((color) => {
              // Determine background style based on color type
              const getStyle = (): React.CSSProperties => {
                if ('isThemed' in color && color.isThemed) {
                  // Half white / half dark to show it adapts to theme
                  return { backgroundImage: 'linear-gradient(135deg, #ffffff 50%, #1f2937 50%)' };
                }
                return { backgroundColor: color.value };
              };

              return (
                <button
                  key={color.name}
                  type="button"
                  title={color.name}
                  className="h-6 w-6 rounded border border-gray-300 transition-all hover:scale-110 hover:border-gray-500"
                  style={getStyle()}
                  onClick={() => {
                    if (color.value) {
                      editor.chain().focus().setCellAttribute('backgroundColor', color.value).run();
                    } else {
                      editor.chain().focus().setCellAttribute('backgroundColor', null).run();
                    }
                    setColorPickerOpen(false);
                  }}
                />
              );
            })}
          </div>
        </PopoverContent>
      </Popover>

      <div className="w-px h-5 bg-border mx-1" />

      {/* Delete table */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={() => editor.chain().focus().deleteTable().run()}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">Delete Table</TooltipContent>
      </Tooltip>
    </div>
  );
}
