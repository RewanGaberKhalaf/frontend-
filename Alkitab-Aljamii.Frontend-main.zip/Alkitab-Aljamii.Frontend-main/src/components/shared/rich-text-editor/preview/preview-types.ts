export interface PreviewHeaderFooter {
  enabled: boolean;
  left?: string;
  center?: string;
  right?: string;
}

/** Page boundary information for server-side pagination */
export interface PageBoundary {
  pageNumber: number;
  startIndex: number;
  endIndex: number;
  estimatedHeight?: number;
}

export interface PaginatedPreviewProps {
  /** HTML content to paginate */
  html: string;
  /** CSS class for the container */
  className?: string;
  /** Zoom level (0.5 to 2) */
  zoom?: number;
  /** Show page numbers */
  showPageNumbers?: boolean;
  /** Called when content is paginated with page count */
  onPaginate?: (pageCount: number) => void;
  /** Called with computed page boundaries (for saving to server) */
  onBoundariesComputed?: (boundaries: PageBoundary[], pageCount: number) => void;
  /** Chapter/document title for header (used when chapterTitles not provided) */
  title?: string;
  /** Array of chapter titles for full book mode - each chapter starts at a page break */
  chapterTitles?: string[];
  /** Show settings panel */
  showSettings?: boolean;
  /** Show print button */
  showPrint?: boolean;
  /** Single page mode - show one page at a time with navigation */
  singlePageMode?: boolean;
}
