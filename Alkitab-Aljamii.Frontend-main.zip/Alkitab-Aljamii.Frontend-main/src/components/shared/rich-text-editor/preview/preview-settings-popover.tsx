"use client";

import { Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import type { PreviewHeaderFooter } from "./preview-types";

interface PreviewSettingsPopoverProps {
  header: PreviewHeaderFooter;
  footer: PreviewHeaderFooter;
  onHeaderChange: (header: PreviewHeaderFooter) => void;
  onFooterChange: (footer: PreviewHeaderFooter) => void;
}

export function PreviewSettingsPopover({
  header,
  footer,
  onHeaderChange,
  onFooterChange,
}: PreviewSettingsPopoverProps) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-1">
          <Settings2 className="h-4 w-4" />
          <span className="hidden sm:inline text-xs">Settings</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <div className="font-medium text-sm">Page Settings</div>

          {/* Header settings */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="header-enabled" className="text-sm">
                Header
              </Label>
              <Switch
                id="header-enabled"
                checked={header.enabled}
                onCheckedChange={(checked) =>
                  onHeaderChange({ ...header, enabled: checked })
                }
              />
            </div>
            {header.enabled && (
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Left</Label>
                  <Input
                    value={header.left || ""}
                    onChange={(e) =>
                      onHeaderChange({ ...header, left: e.target.value })
                    }
                    placeholder="Left"
                    className="h-7 text-xs"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Center</Label>
                  <Input
                    value={header.center || ""}
                    onChange={(e) =>
                      onHeaderChange({ ...header, center: e.target.value })
                    }
                    placeholder="Center"
                    className="h-7 text-xs"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Right</Label>
                  <Input
                    value={header.right || ""}
                    onChange={(e) =>
                      onHeaderChange({ ...header, right: e.target.value })
                    }
                    placeholder="Right"
                    className="h-7 text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Footer settings */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="footer-enabled" className="text-sm">
                Footer
              </Label>
              <Switch
                id="footer-enabled"
                checked={footer.enabled}
                onCheckedChange={(checked) =>
                  onFooterChange({ ...footer, enabled: checked })
                }
              />
            </div>
            {footer.enabled && (
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Left</Label>
                  <Input
                    value={footer.left || ""}
                    onChange={(e) =>
                      onFooterChange({ ...footer, left: e.target.value })
                    }
                    placeholder="Left"
                    className="h-7 text-xs"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Center</Label>
                  <Input
                    value={footer.center || ""}
                    onChange={(e) =>
                      onFooterChange({ ...footer, center: e.target.value })
                    }
                    placeholder="Center"
                    className="h-7 text-xs"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Right</Label>
                  <Input
                    value={footer.right || ""}
                    onChange={(e) =>
                      onFooterChange({ ...footer, right: e.target.value })
                    }
                    placeholder="Right"
                    className="h-7 text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Placeholders help */}
          <div className="text-xs text-muted-foreground bg-muted rounded p-2">
            <div className="font-medium mb-1">Available placeholders:</div>
            <div>
              <code className="text-primary">{"{{page}}"}</code> - Current page
            </div>
            <div>
              <code className="text-primary">{"{{total}}"}</code> - Total pages
            </div>
            <div>
              <code className="text-primary">{"{{title}}"}</code> - Chapter title
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
