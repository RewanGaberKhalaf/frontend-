"use client";

import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PreviewSettingsPopover } from "./preview-settings-popover";
import type { PreviewHeaderFooter } from "./preview-types";

interface PreviewControlsProps {
  zoom: number;
  onZoomChange: (delta: number) => void;
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  showPrint: boolean;
  onPrint: () => void;
  showSettings: boolean;
  header: PreviewHeaderFooter;
  footer: PreviewHeaderFooter;
  onHeaderChange: (header: PreviewHeaderFooter) => void;
  onFooterChange: (footer: PreviewHeaderFooter) => void;
}

export function PreviewControls({
  zoom,
  onZoomChange,
  currentPage,
  totalPages,
  onPageChange,
  showPrint,
  onPrint,
  showSettings,
  header,
  footer,
  onHeaderChange,
  onFooterChange,
}: PreviewControlsProps) {
  return (
    <div className="flex items-center gap-2 bg-muted/50 px-4 py-2 border-b shrink-0 flex-wrap">
      {/* Zoom controls */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onZoomChange(-0.1)}
          disabled={zoom <= 0.3}
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
        <span className="text-xs w-12 text-center">{Math.round(zoom * 100)}%</span>
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onZoomChange(0.1)}
          disabled={zoom >= 1.5}
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
      </div>

      <div className="w-px h-6 bg-border" />

      {/* Page navigation */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <span className="text-xs min-w-[70px] text-center">
          {currentPage} of {totalPages}
        </span>
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {showPrint && (
        <>
          <div className="w-px h-6 bg-border" />

          {/* Print button */}
          <Button variant="ghost" size="sm" onClick={onPrint} className="gap-1">
            <Printer className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">Print</span>
          </Button>
        </>
      )}

      {/* Settings */}
      {showSettings && (
        <PreviewSettingsPopover
          header={header}
          footer={footer}
          onHeaderChange={onHeaderChange}
          onFooterChange={onFooterChange}
        />
      )}
    </div>
  );
}
