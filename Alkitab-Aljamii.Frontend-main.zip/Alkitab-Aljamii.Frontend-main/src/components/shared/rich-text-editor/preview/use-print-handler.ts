"use client";

import { useCallback } from "react";
import katex from "katex";
import { PRINT_STYLES, extractDocumentStyles } from "@/lib/utils/print-styles";
import { replacePlaceholders } from "@/lib/utils/print-media-transform";
import type { PreviewHeaderFooter } from "./preview-types";

// KaTeX CSS URL for print
const KATEX_CSS_URL = "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css";

/**
 * Render all math nodes in a document using KaTeX
 */
function renderMathInDocument(doc: Document) {
  // Find all math nodes that haven't been rendered
  const inlineMathNodes = doc.querySelectorAll('[data-type="math-inline"]:not([data-math-rendered])');
  const blockMathNodes = doc.querySelectorAll('[data-type="math-block"]:not([data-math-rendered])');

  // Render inline math
  inlineMathNodes.forEach((node) => {
    const element = node as HTMLElement;
    const latex = element.getAttribute('data-latex');
    if (!latex) return;

    element.setAttribute('data-math-rendered', 'true');

    try {
      katex.render(latex, element, {
        displayMode: false,
        throwOnError: false,
        errorColor: '#ef4444',
        trust: true,
        strict: false,
      });
    } catch {
      element.textContent = latex;
    }
  });

  // Render block math
  blockMathNodes.forEach((node) => {
    const element = node as HTMLElement;
    const latex = element.getAttribute('data-latex');
    if (!latex) return;

    element.setAttribute('data-math-rendered', 'true');

    try {
      katex.render(latex, element, {
        displayMode: true,
        throwOnError: false,
        errorColor: '#ef4444',
        trust: true,
        strict: false,
      });
    } catch {
      element.textContent = latex;
    }
  });
}

interface UsePrintHandlerOptions {
  pages: string[];
  header: PreviewHeaderFooter;
  footer: PreviewHeaderFooter;
  getPageTitle: (pageIndex: number) => string;
}

export function usePrintHandler({
  pages,
  header,
  footer,
  getPageTitle,
}: UsePrintHandlerOptions) {
  const handlePrint = useCallback(() => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const totalPages = pages.length;
    const extractedStyles = extractDocumentStyles();

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Print Preview</title>
        <link rel="stylesheet" href="${KATEX_CSS_URL}" crossorigin="anonymous">
        <style>
          /* Extracted styles from application */
          ${extractedStyles}
          ${PRINT_STYLES}
          /* Math block styling for print */
          [data-type="math-block"] {
            display: block;
            text-align: center;
            margin: 1em 0;
            font-size: 1.2em;
          }
          [data-type="math-inline"] {
            display: inline;
          }
        </style>
      </head>
      <body>
        ${pages
          .map(
            (pageContent, index) => `
          <div class="print-page">
            ${
              header.enabled
                ? `
              <div class="print-header">
                <span>${replacePlaceholders(header.left || "", index + 1, totalPages, getPageTitle(index))}</span>
                <span>${replacePlaceholders(header.center || "", index + 1, totalPages, getPageTitle(index))}</span>
                <span>${replacePlaceholders(header.right || "", index + 1, totalPages, getPageTitle(index))}</span>
              </div>
            `
                : ""
            }
            <div class="print-content ProseMirror chapter-content prose prose-sm">${pageContent}</div>
            ${
              footer.enabled
                ? `
              <div class="print-footer">
                <span>${replacePlaceholders(footer.left || "", index + 1, totalPages, getPageTitle(index))}</span>
                <span>${replacePlaceholders(footer.center || "", index + 1, totalPages, getPageTitle(index))}</span>
                <span>${replacePlaceholders(footer.right || "", index + 1, totalPages, getPageTitle(index))}</span>
              </div>
            `
                : ""
            }
          </div>
        `
          )
          .join("")}
      </body>
      </html>
    `);

    printWindow.document.close();

    // Render math formulas in the print document
    renderMathInDocument(printWindow.document);

    printWindow.focus();

    // Wait for KaTeX CSS to load and math to render before printing
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 800);
  }, [pages, header, footer, getPageTitle]);

  return { handlePrint };
}
