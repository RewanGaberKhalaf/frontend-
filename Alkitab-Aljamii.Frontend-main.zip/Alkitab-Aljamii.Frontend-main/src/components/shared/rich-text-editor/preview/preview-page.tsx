"use client";

import { useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { replacePlaceholders } from "@/lib/utils/print-media-transform";
import { renderMathInContainer } from "@/hooks/use-math-renderer";
import "katex/dist/katex.min.css";
import {
  A4_WIDTH_PX,
  A4_HEIGHT_PX,
  PAGE_MARGIN,
  HEADER_HEIGHT,
  FOOTER_HEIGHT,
} from "@/lib/constants/page-dimensions";
import type { PreviewHeaderFooter } from "./preview-types";

interface PreviewPageProps {
  pageContent: string;
  pageIndex: number;
  totalPages: number;
  currentPage: number;
  singlePageMode: boolean;
  header: PreviewHeaderFooter;
  footer: PreviewHeaderFooter;
  contentHeight: number;
  getPageTitle: (pageIndex: number) => string;
  onPageClick: (page: number) => void;
}

export function PreviewPage({
  pageContent,
  pageIndex,
  totalPages,
  currentPage,
  singlePageMode,
  header,
  footer,
  contentHeight,
  getPageTitle,
  onPageClick,
}: PreviewPageProps) {
  const contentRef = useRef<HTMLDivElement>(null);

  // Render math formulas after content changes
  // Use a small delay to ensure DOM is fully updated after dangerouslySetInnerHTML
  useEffect(() => {
    if (!contentRef.current) return;

    const timeoutId = setTimeout(() => {
      if (contentRef.current) {
        renderMathInContainer(contentRef.current);
      }
    }, 10);

    return () => clearTimeout(timeoutId);
  }, [pageContent]);

  return (
    <div
      className={cn(
        "bg-white dark:bg-zinc-900 shadow-lg relative flex flex-col",
        "transition-all duration-200",
        singlePageMode
          ? "ring-2 ring-primary"
          : currentPage === pageIndex + 1
            ? "ring-2 ring-primary"
            : "opacity-90 hover:opacity-100"
      )}
      style={{
        width: A4_WIDTH_PX,
        height: A4_HEIGHT_PX,
        padding: PAGE_MARGIN,
        overflow: "hidden",
      }}
      onClick={() => !singlePageMode && onPageClick(pageIndex + 1)}
    >
      {/* Page header */}
      {header.enabled && (
        <div
          className="flex items-center justify-between text-xs text-muted-foreground border-b border-muted pb-2 mb-4 shrink-0"
          style={{ height: HEADER_HEIGHT - 16 }}
        >
          <span>
            {replacePlaceholders(
              header.left || "",
              pageIndex + 1,
              totalPages,
              getPageTitle(pageIndex)
            )}
          </span>
          <span className="font-medium">
            {replacePlaceholders(
              header.center || "",
              pageIndex + 1,
              totalPages,
              getPageTitle(pageIndex)
            )}
          </span>
          <span>
            {replacePlaceholders(
              header.right || "",
              pageIndex + 1,
              totalPages,
              getPageTitle(pageIndex)
            )}
          </span>
        </div>
      )}

      {/* Page content */}
      <div
        ref={contentRef}
        className="ProseMirror chapter-content prose prose-sm dark:prose-invert max-w-none flex-1 overflow-hidden"
        style={{ maxHeight: contentHeight, fontSize: "11pt", lineHeight: 1.6 }}
        dangerouslySetInnerHTML={{ __html: pageContent }}
      />

      {/* Page footer */}
      {footer.enabled && (
        <div
          className="flex items-center justify-between text-xs text-muted-foreground border-t border-muted pt-2 mt-auto shrink-0"
          style={{ height: FOOTER_HEIGHT - 16 }}
        >
          <span>
            {replacePlaceholders(
              footer.left || "",
              pageIndex + 1,
              totalPages,
              getPageTitle(pageIndex)
            )}
          </span>
          <span>
            {replacePlaceholders(
              footer.center || "",
              pageIndex + 1,
              totalPages,
              getPageTitle(pageIndex)
            )}
          </span>
          <span>
            {replacePlaceholders(
              footer.right || "",
              pageIndex + 1,
              totalPages,
              getPageTitle(pageIndex)
            )}
          </span>
        </div>
      )}
    </div>
  );
}
