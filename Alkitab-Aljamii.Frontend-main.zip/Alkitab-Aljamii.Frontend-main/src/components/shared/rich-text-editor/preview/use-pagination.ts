"use client";

import { useRef, useState, useCallback, useMemo, useLayoutEffect } from "react";
import { sanitizeHtml } from "@/lib/utils/html-sanitizer";
import { highlightCodeBlocks } from "@/lib/utils/code-highlighter";
import { transformMediaForPrint } from "@/lib/utils/print-media-transform";
import {
  CONTENT_WIDTH,
  BASE_CONTENT_HEIGHT,
  HEADER_HEIGHT,
  FOOTER_HEIGHT,
  PAGINATION_BUFFER,
} from "@/lib/constants/page-dimensions";
import type { PageBoundary, PreviewHeaderFooter } from "./preview-types";

interface UsePaginationOptions {
  html: string;
  header: PreviewHeaderFooter;
  footer: PreviewHeaderFooter;
  onPaginate?: (pageCount: number) => void;
  onBoundariesComputed?: (boundaries: PageBoundary[], pageCount: number) => void;
  currentPage: number;
  setCurrentPage: (page: number) => void;
}

export function usePagination({
  html,
  header,
  footer,
  onPaginate,
  onBoundariesComputed,
  currentPage,
  setCurrentPage,
}: UsePaginationOptions) {
  const [pages, setPages] = useState<string[]>([]);
  const [pageChapterIndices, setPageChapterIndices] = useState<number[]>([]);

  // Calculate available content height accounting for header/footer
  const getContentHeight = useCallback(() => {
    let height = BASE_CONTENT_HEIGHT;
    if (header.enabled) height -= HEADER_HEIGHT;
    if (footer.enabled) height -= FOOTER_HEIGHT;
    return height;
  }, [header.enabled, footer.enabled]);

  // Memoize the processed HTML to avoid re-processing on every render
  const processedHtml = useMemo(() => {
    const sanitized = sanitizeHtml(html);
    const highlighted = highlightCodeBlocks(sanitized);
    return transformMediaForPrint(highlighted);
  }, [html]);

  // Ref to hold the measurement container
  const measureContainerRef = useRef<HTMLDivElement | null>(null);
  const paginationVersionRef = useRef(0);

  // Split content into pages using DOM measurement
  useLayoutEffect(() => {
    if (!processedHtml) {
      setPages([]);
      return;
    }

    const maxPageHeight = getContentHeight() - PAGINATION_BUFFER;
    const version = ++paginationVersionRef.current;

    // Create or reuse measurement container
    let measureContainer = measureContainerRef.current;
    if (!measureContainer) {
      measureContainer = document.createElement("div");
      measureContainer.style.cssText = `
        position: absolute;
        left: -9999px;
        top: 0;
        width: ${CONTENT_WIDTH}px;
        visibility: hidden;
        font-size: 11pt;
        line-height: 1.6;
      `;
      document.body.appendChild(measureContainer);
      measureContainerRef.current = measureContainer;
    }

    measureContainer.className = "ProseMirror chapter-content prose prose-sm dark:prose-invert";
    measureContainer.innerHTML = processedHtml;

    requestAnimationFrame(() => {
      if (version !== paginationVersionRef.current || !measureContainerRef.current) return;

      const container = measureContainerRef.current;
      const paginatedPages: string[] = [];
      const chapterIndices: number[] = [];
      const pageBoundaries: PageBoundary[] = [];
      let currentChapterIndex = 0;
      let currentPageElements: HTMLElement[] = [];
      let currentHeight = 0;
      let currentStartIndex = 0;

      const measureElement = (el: HTMLElement): number => {
        const height = el.offsetHeight || el.getBoundingClientRect().height;
        const style = window.getComputedStyle(el);
        const marginTop = parseFloat(style.marginTop) || 0;
        const marginBottom = parseFloat(style.marginBottom) || 0;
        return height + marginTop + marginBottom;
      };

      const flushPage = () => {
        if (currentPageElements.length > 0) {
          const pageHtml = currentPageElements.map((el) => el.outerHTML).join("");
          paginatedPages.push(pageHtml);
          chapterIndices.push(currentChapterIndex);

          const endIndex = currentStartIndex + pageHtml.length;
          pageBoundaries.push({
            pageNumber: paginatedPages.length,
            startIndex: currentStartIndex,
            endIndex,
            estimatedHeight: Math.round(currentHeight),
          });
          currentStartIndex = endIndex;

          currentPageElements = [];
          currentHeight = 0;
        }
      };

      const createTableChunk = (
        table: HTMLTableElement,
        rows: HTMLElement[],
        thead: HTMLElement | null
      ): HTMLElement => {
        const newTable = document.createElement("table");
        Array.from(table.attributes).forEach((attr) => {
          newTable.setAttribute(attr.name, attr.value);
        });
        if (thead) {
          newTable.appendChild(thead.cloneNode(true));
        }
        const tbody = document.createElement("tbody");
        rows.forEach((row) => tbody.appendChild(row.cloneNode(true)));
        newTable.appendChild(tbody);
        return newTable;
      };

      const findTable = (el: HTMLElement): HTMLTableElement | null => {
        if (el.tagName === "TABLE") return el as HTMLTableElement;
        const wrapped = el.querySelector("table");
        return wrapped as HTMLTableElement | null;
      };

      const hasPageBreakBefore = (el: HTMLElement): boolean => {
        const style = window.getComputedStyle(el);
        const inlineStyle = el.style.pageBreakBefore || el.style.breakBefore;
        return (
          style.pageBreakBefore === "always" ||
          style.breakBefore === "page" ||
          inlineStyle === "always" ||
          inlineStyle === "page"
        );
      };

      const children = Array.from(container.children) as HTMLElement[];

      for (const child of children) {
        if (hasPageBreakBefore(child)) {
          flushPage();
          currentChapterIndex++;
          if (!child.textContent?.trim() && child.children.length === 0) {
            continue;
          }
        }

        const childHeight = measureElement(child);
        const table = findTable(child);

        if (table) {
          let rows = Array.from(table.querySelectorAll("tbody > tr")) as HTMLElement[];
          if (rows.length === 0) {
            rows = Array.from(table.querySelectorAll("tr")) as HTMLElement[];
          }

          const thead = table.querySelector("thead") as HTMLElement | null;
          const headerRow = table.querySelector("tr:first-child") as HTMLElement | null;
          const theadHeight = thead
            ? measureElement(thead)
            : headerRow
              ? measureElement(headerRow)
              : 0;

          if (
            childHeight > maxPageHeight ||
            (currentHeight > 0 && currentHeight + childHeight > maxPageHeight)
          ) {
            let chunkRows: HTMLElement[] = [];
            let chunkHeight = theadHeight;
            let isFirstChunk = true;

            for (let i = 0; i < rows.length; i++) {
              const row = rows[i];
              if (!row) continue;
              if (thead && row.parentElement === thead) continue;

              const rowHeight = measureElement(row);
              const fitsInChunk = isFirstChunk
                ? currentHeight + chunkHeight + rowHeight <= maxPageHeight
                : chunkHeight + rowHeight <= maxPageHeight;

              if (!fitsInChunk && chunkRows.length > 0) {
                const chunkTable = createTableChunk(table, chunkRows, thead);
                if (isFirstChunk) {
                  currentPageElements.push(chunkTable);
                  flushPage();
                  isFirstChunk = false;
                } else {
                  paginatedPages.push(chunkTable.outerHTML);
                  chapterIndices.push(currentChapterIndex);
                }
                chunkRows = [];
                chunkHeight = theadHeight;
              }

              chunkRows.push(row);
              chunkHeight += rowHeight;
            }

            if (chunkRows.length > 0) {
              const chunkTable = createTableChunk(table, chunkRows, thead);
              if (isFirstChunk) {
                currentPageElements.push(chunkTable);
                currentHeight += chunkHeight;
              } else {
                currentPageElements.push(chunkTable);
                currentHeight = chunkHeight;
              }
            }

            continue;
          }
        }

        if (
          (child.hasAttribute("data-resizable-media") ||
            child.tagName === "IMG" ||
            child.tagName === "VIDEO") &&
          childHeight > maxPageHeight
        ) {
          flushPage();

          const clone = child.cloneNode(true) as HTMLElement;
          const mediaEl = (clone.querySelector("img, video") as HTMLElement) || clone;
          if (mediaEl) {
            mediaEl.style.maxHeight = `${maxPageHeight - 20}px`;
            mediaEl.style.width = "auto";
            mediaEl.style.height = "auto";
            mediaEl.style.objectFit = "contain";
          }
          paginatedPages.push(clone.outerHTML);
          chapterIndices.push(currentChapterIndex);
          continue;
        }

        if (currentHeight + childHeight > maxPageHeight && currentPageElements.length > 0) {
          flushPage();
        }

        const clone = child.cloneNode(true) as HTMLElement;
        currentPageElements.push(clone);
        currentHeight += childHeight;
      }

      flushPage();

      const finalPages = paginatedPages.length > 0 ? paginatedPages : ["<p></p>"];
      const finalChapterIndices = chapterIndices.length > 0 ? chapterIndices : [0];
      const finalBoundaries =
        pageBoundaries.length > 0
          ? pageBoundaries
          : [
              {
                pageNumber: 1,
                startIndex: 0,
                endIndex: finalPages[0]?.length || 0,
                estimatedHeight: 0,
              },
            ];

      setPages(finalPages);
      setPageChapterIndices(finalChapterIndices);
      onPaginate?.(finalPages.length);
      onBoundariesComputed?.(finalBoundaries, finalPages.length);

      if (currentPage > finalPages.length) {
        setCurrentPage(1);
      }
    });

    return () => {
      if (measureContainerRef.current && document.body.contains(measureContainerRef.current)) {
        document.body.removeChild(measureContainerRef.current);
        measureContainerRef.current = null;
      }
    };
  }, [processedHtml, header.enabled, footer.enabled, getContentHeight, onPaginate, currentPage, onBoundariesComputed, setCurrentPage]);

  return {
    pages,
    pageChapterIndices,
    getContentHeight,
  };
}
