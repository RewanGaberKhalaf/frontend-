"use client";

import { useEffect, useState, useCallback, useRef } from "react";

// A4 dimensions at 96 DPI
const PAGE_HEIGHT = 1123;
const PAGE_PADDING_Y = 60;
const CONTENT_HEIGHT_PER_PAGE = PAGE_HEIGHT - PAGE_PADDING_Y * 2; // 1003px

export interface PageBreakPosition {
  top: number;
  pageNumber: number;
}

export interface UsePageBreaksOptions {
  enabled?: boolean;
  pageContentHeight?: number;
  debounceMs?: number;
}

/**
 * Hook that calculates where page breaks should appear in an editor
 * Returns positions (in px from top of content) where breaks should render
 */
export function usePageBreaks(
  editorRef: React.RefObject<HTMLElement | null>,
  options: UsePageBreaksOptions = {}
) {
  const {
    enabled = true,
    pageContentHeight = CONTENT_HEIGHT_PER_PAGE,
    debounceMs = 150,
  } = options;

  const [pageBreaks, setPageBreaks] = useState<PageBreakPosition[]>([]);
  const [pageCount, setPageCount] = useState(1);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const calculatePageBreaks = useCallback(() => {
    if (!enabled || !editorRef.current) {
      setPageBreaks([]);
      setPageCount(1);
      return;
    }

    const editorEl = editorRef.current;
    const proseMirror = editorEl.querySelector(".ProseMirror");

    if (!proseMirror) {
      setPageBreaks([]);
      setPageCount(1);
      return;
    }

    const contentHeight = proseMirror.scrollHeight;
    const breaks: PageBreakPosition[] = [];

    // Calculate how many pages we need
    const numPages = Math.ceil(contentHeight / pageContentHeight);

    // Create break positions
    for (let i = 1; i < numPages; i++) {
      breaks.push({
        top: i * pageContentHeight,
        pageNumber: i + 1,
      });
    }

    setPageBreaks(breaks);
    setPageCount(Math.max(1, numPages));
  }, [enabled, editorRef, pageContentHeight]);

  // Debounced recalculation
  const scheduleRecalculation = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = setTimeout(calculatePageBreaks, debounceMs);
  }, [calculatePageBreaks, debounceMs]);

  // Observe content changes
  useEffect(() => {
    if (!enabled || !editorRef.current) return;

    const editorEl = editorRef.current;

    // Initial calculation
    calculatePageBreaks();

    // Set up mutation observer to watch for content changes
    const observer = new MutationObserver(() => {
      scheduleRecalculation();
    });

    observer.observe(editorEl, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
    });

    // Also watch for resize
    const resizeObserver = new ResizeObserver(() => {
      scheduleRecalculation();
    });
    resizeObserver.observe(editorEl);

    return () => {
      observer.disconnect();
      resizeObserver.disconnect();
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [enabled, editorRef, calculatePageBreaks, scheduleRecalculation]);

  return {
    pageBreaks,
    pageCount,
    recalculate: calculatePageBreaks,
  };
}
