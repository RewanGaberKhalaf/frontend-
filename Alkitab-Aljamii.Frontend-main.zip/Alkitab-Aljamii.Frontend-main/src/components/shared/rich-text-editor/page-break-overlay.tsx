"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";

// A4 dimensions
const PAGE_HEIGHT = 1123;
const PAGE_PADDING_Y = 60;
const PAGE_GAP = 40;
const CONTENT_HEIGHT_PER_PAGE = PAGE_HEIGHT - PAGE_PADDING_Y * 2;

export interface PageBreakOverlayProps {
  /** Reference to the editor container element */
  editorRef: React.RefObject<HTMLElement | null>;
  /** Whether page breaks are enabled */
  enabled?: boolean;
  /** Starting page number for this chapter */
  startPage?: number;
  /** Callback when page count changes */
  onPageCountChange?: (count: number) => void;
  /** Custom class name */
  className?: string;
}

/**
 * Renders visual page break overlays on top of editor content
 * This creates the Google Docs-like page gap effect
 */
export function PageBreakOverlay({
  editorRef,
  enabled = true,
  startPage = 1,
  onPageCountChange,
  className,
}: PageBreakOverlayProps) {
  const [pageBreaks, setPageBreaks] = useState<number[]>([]);
  const [contentHeight, setContentHeight] = useState(0);
  const overlayRef = useRef<HTMLDivElement>(null);

  const calculateBreaks = useCallback(() => {
    if (!enabled || !editorRef.current) {
      setPageBreaks([]);
      setContentHeight(0);
      return;
    }

    const proseMirror = editorRef.current.querySelector(".ProseMirror") as HTMLElement;
    if (!proseMirror) {
      setPageBreaks([]);
      setContentHeight(0);
      return;
    }

    const height = proseMirror.scrollHeight;
    setContentHeight(height);

    // Calculate page breaks
    const numPages = Math.ceil(height / CONTENT_HEIGHT_PER_PAGE);
    const breaks: number[] = [];

    for (let i = 1; i < numPages; i++) {
      breaks.push(i * CONTENT_HEIGHT_PER_PAGE + PAGE_PADDING_Y);
    }

    setPageBreaks(breaks);
    onPageCountChange?.(Math.max(1, numPages));
  }, [enabled, editorRef, onPageCountChange]);

  // Observe changes
  useEffect(() => {
    if (!enabled || !editorRef.current) return;

    // Initial calculation
    const timer = setTimeout(calculateBreaks, 50);

    // Watch for changes
    const observer = new MutationObserver(() => {
      requestAnimationFrame(calculateBreaks);
    });

    observer.observe(editorRef.current, {
      childList: true,
      subtree: true,
      characterData: true,
    });

    const resizeObserver = new ResizeObserver(() => {
      requestAnimationFrame(calculateBreaks);
    });
    resizeObserver.observe(editorRef.current);

    return () => {
      clearTimeout(timer);
      observer.disconnect();
      resizeObserver.disconnect();
    };
  }, [enabled, editorRef, calculateBreaks]);

  if (!enabled || pageBreaks.length === 0) {
    return null;
  }

  return (
    <div
      ref={overlayRef}
      className={cn("absolute inset-0 pointer-events-none overflow-hidden", className)}
      style={{ height: contentHeight + PAGE_PADDING_Y * 2 }}
    >
      {pageBreaks.map((topPosition, index) => (
        <div
          key={index}
          className="absolute left-0 right-0 flex flex-col items-center"
          style={{
            top: topPosition,
            height: PAGE_GAP,
            background: "var(--page-break-bg, rgb(243 244 246))",
            zIndex: 5,
          }}
        >
          {/* Top shadow line */}
          <div
            className="absolute top-0 left-0 right-0 h-[2px]"
            style={{
              background: "linear-gradient(to bottom, rgba(0,0,0,0.08), transparent)",
            }}
          />

          {/* Page number */}
          <span className="absolute bottom-2 text-[11px] text-muted-foreground/60">
            {startPage + index + 1}
          </span>

          {/* Bottom shadow line */}
          <div
            className="absolute bottom-0 left-0 right-0 h-[2px]"
            style={{
              background: "linear-gradient(to top, rgba(0,0,0,0.04), transparent)",
            }}
          />
        </div>
      ))}
    </div>
  );
}

// CSS variable for dark mode
// Add to your globals.css:
// .dark { --page-break-bg: rgb(24 24 27); }
