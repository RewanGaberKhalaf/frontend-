"use client";

import { useMemo, useCallback, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { renderMathInContainer } from "@/hooks/use-math-renderer";
import "katex/dist/katex.min.css";
import { type DocumentStructure, type Chapter, type PageHeaderFooter } from "./types";

// A4 dimensions at 96 DPI
const A4_WIDTH_PX = 794;
const A4_HEIGHT_PX = 1123;

export interface BookPreviewProps {
  /** Document to preview */
  document: DocumentStructure;
  /** CSS class for the container */
  className?: string;
  /** Scale factor for display (0.5 = half size, 1 = full size) */
  scale?: number;
  /** Show page numbers */
  showPageNumbers?: boolean;
  /** Show chapter titles as headers */
  showChapterTitles?: boolean;
}

export function BookPreview({
  document,
  className,
  scale = 1,
  showPageNumbers = true,
  showChapterTitles = true,
}: BookPreviewProps) {
  // Get effective header (chapter-specific or book-level)
  const getEffectiveHeader = useCallback((chapter: Chapter, isFirstPage: boolean): PageHeaderFooter | undefined => {
    const header = chapter.header?.enabled ? chapter.header : document.header;
    if (!header?.enabled) return undefined;
    if (header.differentFirstPage && isFirstPage) return undefined;
    return header;
  }, [document.header]);

  // Get effective footer
  const getEffectiveFooter = useCallback((isFirstPage: boolean): PageHeaderFooter | undefined => {
    const footer = document.footer;
    if (!footer?.enabled) return undefined;
    if (footer.differentFirstPage && isFirstPage) return undefined;
    return footer;
  }, [document.footer]);

  // Flatten all pages with their global page numbers and chapter info
  const allPages = useMemo(() => {
    const pages: Array<{
      chapterId: string;
      chapterTitle: string;
      chapter: Chapter;
      chapterIndex: number;
      pageId: string;
      pageIndex: number;
      globalPageNumber: number;
      content: string;
      isFirstPageOfChapter: boolean;
    }> = [];

    let globalPageNum = 1;

    document.chapters.forEach((chapter, chapterIndex) => {
      chapter.pages.forEach((page, pageIndex) => {
        pages.push({
          chapterId: chapter.id,
          chapterTitle: chapter.title,
          chapter,
          chapterIndex,
          pageId: page.id,
          pageIndex,
          globalPageNumber: globalPageNum,
          content: page.content,
          isFirstPageOfChapter: pageIndex === 0,
        });
        globalPageNum++;
      });
    });

    return pages;
  }, [document.chapters]);

  const scaledWidth = A4_WIDTH_PX * scale;
  const scaledHeight = A4_HEIGHT_PX * scale;
  const containerRef = useRef<HTMLDivElement>(null);

  // Render math formulas after content changes
  // Use a small delay to ensure DOM is fully updated
  useEffect(() => {
    if (!containerRef.current) return;

    const timeoutId = setTimeout(() => {
      if (containerRef.current) {
        renderMathInContainer(containerRef.current);
      }
    }, 10);

    return () => clearTimeout(timeoutId);
  }, [allPages]);

  return (
    <div className={cn("flex flex-col h-full bg-muted/50", className)}>
      {/* Header */}
      <div className="border-b bg-background px-6 py-3 shrink-0">
        <h2 className="text-lg font-semibold">{document.meta.title}</h2>
        <p className="text-sm text-muted-foreground">
          {document.chapters.length} chapters &bull; {document.totalPages} pages &bull;{" "}
          {document.totalWords.toLocaleString()} words
        </p>
      </div>

      {/* Scrollable preview area */}
      <ScrollArea className="flex-1">
        <div ref={containerRef} className="flex flex-col items-center gap-8 py-8 px-4">
          {allPages.map((page) => {
            const header = getEffectiveHeader(page.chapter, page.isFirstPageOfChapter);
            const footer = getEffectiveFooter(page.isFirstPageOfChapter);

            return (
              <div key={`${page.chapterId}-${page.pageId}`} className="flex flex-col items-center">
                {/* Chapter title (shown before first page of each chapter) */}
                {showChapterTitles && page.isFirstPageOfChapter && (
                  <div className="w-full mb-3 flex items-center gap-3" style={{ maxWidth: scaledWidth }}>
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                      {page.chapterTitle}
                    </span>
                    <div className="flex-1 h-px bg-border/60" />
                  </div>
                )}

                {/* Page container */}
                <div
                  className="relative bg-background shadow-lg overflow-hidden"
                  style={{
                    width: scaledWidth,
                    height: scaledHeight,
                  }}
                >
                  {/* Page content - scaled */}
                  <div
                    className="absolute top-0 left-0 origin-top-left flex flex-col"
                    style={{
                      width: A4_WIDTH_PX,
                      height: A4_HEIGHT_PX,
                      transform: `scale(${scale})`,
                    }}
                  >
                    {/* Page Header */}
                    {header && (
                      <div className="px-16 pt-8 pb-4 border-b border-muted-foreground/20 text-xs text-muted-foreground flex items-center justify-between shrink-0">
                        <span>{header.leftContent || ""}</span>
                        <span>{header.centerContent || page.chapterTitle}</span>
                        <span>{header.rightContent || ""}</span>
                      </div>
                    )}

                    {/* Main Content */}
                    <div
                      className="prose prose-sm dark:prose-invert max-w-none px-16 py-8 flex-1 overflow-hidden"
                      dangerouslySetInnerHTML={{ __html: page.content }}
                    />

                    {/* Page Footer */}
                    {footer && (
                      <div className="px-16 pb-8 pt-4 border-t border-muted-foreground/20 text-xs text-muted-foreground flex items-center justify-between shrink-0">
                        <span>
                          {footer.leftContent || ""}
                          {footer.showPageNumber && footer.pageNumberPosition === "left" && ` Page ${page.globalPageNumber}`}
                        </span>
                        <span>
                          {footer.centerContent || ""}
                          {footer.showPageNumber && footer.pageNumberPosition === "center" && `Page ${page.globalPageNumber}`}
                        </span>
                        <span>
                          {footer.showPageNumber && footer.pageNumberPosition === "right" && `Page ${page.globalPageNumber} `}
                          {footer.rightContent || ""}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Page number overlay (fallback when no footer) */}
                  {showPageNumbers && !footer && (
                    <div className="absolute bottom-3 left-0 right-0 flex justify-center">
                      <span className="text-xs text-muted-foreground bg-background/80 px-2 py-0.5 rounded">
                        {page.globalPageNumber}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}
