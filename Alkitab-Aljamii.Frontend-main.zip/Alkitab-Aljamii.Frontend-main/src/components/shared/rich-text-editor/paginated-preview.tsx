"use client";

import { useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { A4_HEIGHT_PX } from "@/lib/constants/page-dimensions";
import {
  PreviewControls,
  PreviewPage,
  usePagination,
  usePrintHandler,
  type PreviewHeaderFooter,
  type PaginatedPreviewProps,
} from "./preview";

// Re-export types for backward compatibility
export type { PreviewHeaderFooter, PageBoundary, PaginatedPreviewProps } from "./preview";

export function PaginatedPreview({
  html,
  className,
  zoom: initialZoom = 0.7,
  showPageNumbers = true,
  onPaginate,
  onBoundariesComputed,
  title,
  chapterTitles,
  showSettings = true,
  showPrint = true,
  singlePageMode = false,
}: PaginatedPreviewProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [zoom, setZoom] = useState(initialZoom);
  const printRef = useRef<HTMLDivElement>(null);

  // Header/Footer settings
  const [header, setHeader] = useState<PreviewHeaderFooter>({
    enabled: true,
    left: "",
    center: "{{title}}",
    right: "Page {{page}}",
  });
  const [footer, setFooter] = useState<PreviewHeaderFooter>({
    enabled: true,
    left: "",
    center: "{{page}} of {{total}}",
    right: "",
  });

  // Pagination hook
  const { pages, pageChapterIndices, getContentHeight } = usePagination({
    html,
    header,
    footer,
    onPaginate,
    onBoundariesComputed,
    currentPage,
    setCurrentPage,
  });

  // Get the title for a specific page (supports multi-chapter mode)
  const getPageTitle = useCallback(
    (pageIndex: number): string => {
      if (chapterTitles && chapterTitles.length > 0) {
        const chapterIndex = pageChapterIndices[pageIndex] ?? 0;
        return chapterTitles[chapterIndex] ?? title ?? "";
      }
      return title ?? "";
    },
    [chapterTitles, pageChapterIndices, title]
  );

  // Print handler hook
  const { handlePrint } = usePrintHandler({
    pages,
    header,
    footer,
    getPageTitle,
  });

  const goToPage = (page: number) => {
    if (page >= 1 && page <= pages.length) {
      setCurrentPage(page);
    }
  };

  const adjustZoom = (delta: number) => {
    setZoom((prev) => Math.max(0.3, Math.min(1.5, prev + delta)));
  };

  const totalPages = pages.length;

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Controls */}
      <PreviewControls
        zoom={zoom}
        onZoomChange={adjustZoom}
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={goToPage}
        showPrint={showPrint}
        onPrint={handlePrint}
        showSettings={showSettings}
        header={header}
        footer={footer}
        onHeaderChange={setHeader}
        onFooterChange={setFooter}
      />

      {/* Pages display */}
      <div ref={printRef} className="flex-1 overflow-auto bg-muted/30 p-4">
        {/* Wrapper that accounts for scaled height to prevent extra space */}
        <div
          style={{
            height: `${((singlePageMode ? 1 : pages.length) * (A4_HEIGHT_PX + 24)) * zoom}px`,
            minHeight: "100%",
          }}
        >
          <div
            className="flex flex-col gap-6 items-center pb-4"
            style={{
              transform: `scale(${zoom})`,
              transformOrigin: "top center",
            }}
          >
            {(singlePageMode
              ? [pages[currentPage - 1]].filter((p): p is string => !!p)
              : pages
            ).map((pageContent, mapIndex) => {
              // In single page mode, the actual page index is currentPage - 1
              const index = singlePageMode ? currentPage - 1 : mapIndex;
              return (
                <PreviewPage
                  key={index}
                  pageContent={pageContent}
                  pageIndex={index}
                  totalPages={totalPages}
                  currentPage={currentPage}
                  singlePageMode={singlePageMode}
                  header={header}
                  footer={footer}
                  contentHeight={getContentHeight()}
                  getPageTitle={getPageTitle}
                  onPageClick={setCurrentPage}
                />
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
