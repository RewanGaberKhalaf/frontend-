/**
 * Auto-save types and utility functions
 */

export interface AutoSaveOptions {
  /** Unique key for this document in storage */
  storageKey: string;
  /** Debounce delay in ms (default: 1000) */
  debounceMs?: number;
  /** Storage type (default: localStorage) */
  storage?: "localStorage" | "sessionStorage";
  /** Called when draft is saved */
  onSave?: (timestamp: Date) => void;
  /** Called when draft is loaded */
  onLoad?: () => void;
  /** Called when error occurs */
  onError?: (error: Error) => void;
}

export interface AutoSaveState {
  /** Whether there's a saved draft */
  hasDraft: boolean;
  /** Last save timestamp */
  lastSaved: Date | null;
  /** Whether a save is pending */
  isSaving: boolean;
}

export interface AutoSaveReturn extends AutoSaveState {
  /** Manually trigger save */
  saveNow: () => void;
  /** Clear saved draft */
  clearDraft: () => void;
  /** Load draft into editor */
  loadDraft: () => string | null;
  /** Get draft metadata */
  getDraftInfo: () => DraftInfo | null;
}

export interface DraftInfo {
  storageKey: string;
  savedAt: Date;
  contentLength: number;
  wordCount: number;
}

export interface StoredDraft {
  content: string;
  savedAt: string;
  wordCount: number;
  /** Optional Yjs state for full document recovery */
  ydocState?: string;
}

export const DRAFT_PREFIX = "editor_draft_";

/**
 * Get all saved drafts from storage
 */
export function getAllDrafts(
  storage: "localStorage" | "sessionStorage" = "localStorage"
): DraftInfo[] {
  if (typeof window === "undefined") return [];

  const storageObj =
    storage === "sessionStorage"
      ? window.sessionStorage
      : window.localStorage;

  const drafts: DraftInfo[] = [];

  for (let i = 0; i < storageObj.length; i++) {
    const key = storageObj.key(i);
    if (key?.startsWith(DRAFT_PREFIX)) {
      try {
        const saved = storageObj.getItem(key);
        if (saved) {
          const draft: StoredDraft = JSON.parse(saved);
          drafts.push({
            storageKey: key.replace(DRAFT_PREFIX, ""),
            savedAt: new Date(draft.savedAt),
            contentLength: draft.content.length,
            wordCount: draft.wordCount,
          });
        }
      } catch {
        // Skip invalid entries
      }
    }
  }

  return drafts.sort(
    (a, b) => b.savedAt.getTime() - a.savedAt.getTime()
  );
}

/**
 * Clear all drafts from storage
 */
export function clearAllDrafts(
  storage: "localStorage" | "sessionStorage" = "localStorage"
): void {
  if (typeof window === "undefined") return;

  const storageObj =
    storage === "sessionStorage"
      ? window.sessionStorage
      : window.localStorage;

  const keysToRemove: string[] = [];

  for (let i = 0; i < storageObj.length; i++) {
    const key = storageObj.key(i);
    if (key?.startsWith(DRAFT_PREFIX)) {
      keysToRemove.push(key);
    }
  }

  keysToRemove.forEach((key) => storageObj.removeItem(key));
}
