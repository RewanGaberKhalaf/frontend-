import StarterKit from "@tiptap/starter-kit";
import Placeholder from "@tiptap/extension-placeholder";
import Highlight from "@tiptap/extension-highlight";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import Link from "@tiptap/extension-link";
import { Table } from "@tiptap/extension-table";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";

// Extended TableCell with background color support
const CustomTableCell = TableCell.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      backgroundColor: {
        default: null,
        parseHTML: element => element.style.backgroundColor || element.getAttribute('data-background-color'),
        renderHTML: attributes => {
          if (!attributes['backgroundColor']) {
            return {};
          }
          return {
            style: `background-color: ${attributes['backgroundColor']}`,
            'data-background-color': attributes['backgroundColor'],
          };
        },
      },
    };
  },
});

// Extended TableHeader with background color support
const CustomTableHeader = TableHeader.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      backgroundColor: {
        default: null,
        parseHTML: element => element.style.backgroundColor || element.getAttribute('data-background-color'),
        renderHTML: attributes => {
          if (!attributes['backgroundColor']) {
            return {};
          }
          return {
            style: `background-color: ${attributes['backgroundColor']}`,
            'data-background-color': attributes['backgroundColor'],
          };
        },
      },
    };
  },
});
import CodeBlockLowlight from "@tiptap/extension-code-block-lowlight";
import Collaboration from "@tiptap/extension-collaboration";
import { TextStyle } from "@tiptap/extension-text-style";
import { FontFamily } from "@tiptap/extension-font-family";
import { Color } from "@tiptap/extension-color";
import { common, createLowlight } from "lowlight";
import type { AnyExtension } from "@tiptap/core";
import type * as Y from "yjs";
import { FontSize } from "./font-size-extension";
import { PageBreakExtension } from "./page-break-extension";
import { PageNode } from "./pagination";
import { ResizableMedia } from "./resizable-media-extension";
import { QuizBlock } from "./quiz-extension";
import { MathInline, MathBlock } from "./math-extension";

const lowlight = createLowlight(common);

export interface EditorExtensionOptions {
  placeholder?: string;
  enableCodeBlock?: boolean;
  enableTable?: boolean;
  enableImage?: boolean;
  /** Enable math/LaTeX support with KaTeX */
  enableMath?: boolean;
  /** Yjs XML Fragment for collaboration/stable positions */
  yFragment?: Y.XmlFragment;
  /** Enable visual page breaks (Google Docs style) - legacy decoration approach */
  enablePageBreaks?: boolean;
  /** Enable page nodes (each page is a container div) - new approach */
  enablePageNodes?: boolean;
  /** Callback when page count changes */
  onPageCountChange?: (count: number) => void;
}

export function getEditorExtensions(options: EditorExtensionOptions = {}): AnyExtension[] {
  const {
    placeholder = "Start writing...",
    enableCodeBlock = true,
    enableTable = true,
    enableImage = true,
    enableMath = true,
    yFragment,
    enablePageBreaks = false,
    enablePageNodes = false,
    onPageCountChange,
  } = options;

  const extensions: AnyExtension[] = [
    StarterKit.configure({
      codeBlock: false, // We use CodeBlockLowlight instead
      heading: {
        levels: [1, 2, 3, 4],
      },
      // Disable undo/redo when using Yjs collaboration (it has its own history)
      undoRedo: yFragment ? false : undefined,
    }),
    Placeholder.configure({
      placeholder,
      emptyEditorClass: "is-editor-empty",
    }),
    // Text styling extensions (must be before FontFamily and Color)
    TextStyle,
    FontFamily,
    FontSize,
    Color,
    Highlight.configure({
      multicolor: true,
    }),
    TextAlign.configure({
      types: ["heading", "paragraph"],
      alignments: ["left", "center", "right", "justify"],
    }),
    Underline,
    Link.configure({
      openOnClick: false,
      HTMLAttributes: {
        class: "text-primary underline cursor-pointer",
      },
    }),
  ];

  if (enableCodeBlock) {
    extensions.push(
      CodeBlockLowlight.configure({
        lowlight,
        HTMLAttributes: {
          class: "rounded-md bg-muted p-4 font-mono text-sm",
        },
      })
    );
  }

  if (enableTable) {
    extensions.push(
      Table.configure({
        resizable: true,
        HTMLAttributes: {
          class: "border-collapse table-auto w-full",
        },
      }),
      TableRow,
      CustomTableCell.configure({
        HTMLAttributes: {
          class: "border border-border p-2",
        },
      }),
      CustomTableHeader.configure({
        HTMLAttributes: {
          class: "border border-border p-2 bg-muted font-semibold",
        },
      })
    );
  }

  // Always enable resizable media for images, videos, audio, and embeds
  extensions.push(ResizableMedia);

  // Always enable quiz blocks for embedding quizzes in chapters
  extensions.push(QuizBlock);

  // Add math extensions for LaTeX support
  if (enableMath) {
    extensions.push(MathInline, MathBlock);
  }

  // Add Yjs Collaboration extension if fragment is provided
  // This syncs editor content to the Yjs document for stable character positions
  if (yFragment) {
    extensions.push(
      Collaboration.configure({
        fragment: yFragment,
      })
    );
  }

  // Add page break extension for Google Docs-style pagination (legacy)
  if (enablePageBreaks && !enablePageNodes) {
    extensions.push(
      PageBreakExtension.configure({
        enabled: true,
        onPageCountChange,
      })
    );
  }

  // Add page node extension - each page is a container div
  if (enablePageNodes) {
    extensions.push(
      PageNode.configure({
        className: "editor-page",
      })
    );
  }

  return extensions;
}
