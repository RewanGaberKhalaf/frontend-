import { Node, mergeAttributes } from "@tiptap/core";
import { ReactNodeViewRenderer } from "@tiptap/react";
import { ResizableMediaComponent } from "./resizable-media-component";

export type MediaAlignment = "left" | "center" | "right";
export type MediaFloat = "none" | "left" | "right";

export interface ResizableMediaOptions {
  HTMLAttributes: Record<string, unknown>;
}

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    resizableMedia: {
      /**
       * Set a resizable media (image, video, audio, iframe)
       */
      setResizableMedia: (options: {
        src: string;
        mediaId?: string; // Store media ID for refreshing signed URLs
        mediaType: "image" | "video" | "audio" | "iframe";
        alt?: string;
        title?: string;
        width?: string;
        alignment?: MediaAlignment;
        float?: MediaFloat;
      }) => ReturnType;
      /**
       * Update media attributes
       */
      updateMedia: (options: {
        width?: string;
        alignment?: MediaAlignment;
        float?: MediaFloat;
      }) => ReturnType;
    };
  }
}

export const ResizableMedia = Node.create<ResizableMediaOptions>({
  name: "resizableMedia",

  group: "block",

  atom: true,

  draggable: true,

  addOptions() {
    return {
      HTMLAttributes: {},
    };
  },

  addAttributes() {
    return {
      src: {
        default: null,
      },
      mediaId: {
        default: null, // Store media ID for refreshing signed URLs
      },
      mediaType: {
        default: "image",
      },
      alt: {
        default: null,
      },
      title: {
        default: null,
      },
      width: {
        default: "100%",
      },
      height: {
        default: "auto",
      },
      alignment: {
        default: "center" as MediaAlignment,
      },
      float: {
        default: "none" as MediaFloat,
      },
      "data-type": {
        default: null,
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'div[data-resizable-media="true"]',
        getAttrs: (dom) => {
          const element = dom as HTMLElement;
          const mediaType = element.getAttribute("data-media-type") || "image";
          const alignment = element.getAttribute("data-alignment") || "center";
          const float = element.getAttribute("data-float") || "none";

          // Parse width and height from style attribute
          const style = element.getAttribute("style") || "";
          const widthMatch = style.match(/\bwidth:\s*([^;]+)/);
          const heightMatch = style.match(/\bheight:\s*([^;]+)/);
          const width = widthMatch?.[1]?.trim() || "100%";
          const height = heightMatch?.[1]?.trim() || "auto";

          // Primary: Get src/alt/title from data attributes (most reliable)
          let src = element.getAttribute("data-src") || "";
          let alt: string | null = element.getAttribute("data-alt") || null;
          let title: string | null = element.getAttribute("data-title") || null;

          // Fallback 1: querySelector on nested media elements
          if (!src) {
            const img = element.querySelector("img");
            const video = element.querySelector("video");
            const audio = element.querySelector("audio");
            const iframe = element.querySelector("iframe");

            if (img) {
              src = img.getAttribute("src") || "";
              alt = alt || img.getAttribute("alt");
              title = title || img.getAttribute("title");
            } else if (video) {
              src = video.getAttribute("src") || "";
            } else if (audio) {
              src = audio.getAttribute("src") || "";
            } else if (iframe) {
              src = iframe.getAttribute("src") || "";
            }
          }

          // Fallback 2: Parse innerHTML as last resort
          if (!src && element.innerHTML) {
            const srcMatch = element.innerHTML.match(/src=["']([^"']+)["']/);
            if (srcMatch?.[1]) {
              src = srcMatch[1];
            }
          }

          return {
            src,
            mediaId: element.getAttribute("data-media-id") || null,
            mediaType,
            alt,
            title,
            width,
            height,
            alignment,
            float,
            "data-type": element.getAttribute("data-embed-type"),
          };
        },
      },
      // Also parse regular images and convert them
      {
        tag: "img[src]",
        getAttrs: (dom) => {
          const element = dom as HTMLElement;
          return {
            src: element.getAttribute("src"),
            mediaType: "image",
            alt: element.getAttribute("alt"),
            title: element.getAttribute("title"),
            width: element.style.width || element.getAttribute("width") || "100%",
          };
        },
      },
      // Parse iframes
      {
        tag: "iframe[src]",
        getAttrs: (dom) => {
          const element = dom as HTMLElement;
          const src = element.getAttribute("src") || "";
          return {
            src,
            mediaType: "iframe",
            width: element.style.width || "100%",
            "data-type": getEmbedType(src),
          };
        },
      },
      // Parse videos
      {
        tag: "video[src]",
        getAttrs: (dom) => {
          const element = dom as HTMLElement;
          return {
            src: element.getAttribute("src"),
            mediaType: "video",
            width: element.style.width || "100%",
          };
        },
      },
      // Parse audio
      {
        tag: "audio[src]",
        getAttrs: (dom) => {
          const element = dom as HTMLElement;
          return {
            src: element.getAttribute("src"),
            mediaType: "audio",
            width: element.style.width || "100%",
          };
        },
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    const { mediaType, mediaId, src, alt, title, width, height, alignment, float } = HTMLAttributes;

    const containerStyle = getContainerStyle(width as string, height as string, alignment as MediaAlignment, float as MediaFloat);

    // Store src and mediaId in data attributes for reliable parsing
    const containerAttrs = {
      "data-resizable-media": "true",
      "data-media-type": mediaType,
      "data-media-id": mediaId || "", // Store media ID for URL refresh
      "data-alignment": alignment,
      "data-float": float,
      "data-src": src || "", // Backup src storage
      "data-alt": alt || "",
      "data-title": title || "",
      style: containerStyle,
      class: `resizable-media-container resizable-media-${alignment} resizable-media-float-${float}`,
    };

    const mediaHeight = height && height !== "auto" ? height : "auto";
    const mediaStyle = `width: 100%; height: ${mediaHeight};${mediaHeight !== "auto" ? " object-fit: cover;" : ""}`;

    if (mediaType === "image") {
      return [
        "div",
        containerAttrs,
        ["img", mergeAttributes({ src, alt, title, style: mediaStyle })],
      ];
    }

    if (mediaType === "video") {
      return [
        "div",
        containerAttrs,
        ["video", mergeAttributes({ src, controls: true, style: mediaStyle })],
      ];
    }

    if (mediaType === "audio") {
      return [
        "div",
        containerAttrs,
        ["audio", mergeAttributes({ src, controls: true, style: "width: 100%;" })],
      ];
    }

    if (mediaType === "iframe") {
      const embedType = HTMLAttributes["data-type"] || getEmbedType(src as string);
      return [
        "div",
        mergeAttributes(containerAttrs, { "data-embed-type": embedType }),
        ["iframe", mergeAttributes({
          src,
          frameborder: "0",
          allowfullscreen: true,
          allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
          style: "width: 100%; aspect-ratio: 16/9;",
        })],
      ];
    }

    return ["div", containerAttrs];
  },

  addNodeView() {
    return ReactNodeViewRenderer(ResizableMediaComponent);
  },

  addCommands() {
    return {
      setResizableMedia:
        (options) =>
        ({ commands }) => {
          return commands.insertContent({
            type: this.name,
            attrs: options,
          });
        },
      updateMedia:
        (options) =>
        ({ commands }) => {
          return commands.updateAttributes(this.name, options);
        },
    };
  },
});

// Helper to determine embed type from URL
function getEmbedType(src: string | null): string {
  if (!src) return "embed";
  if (src.includes("youtube.com") || src.includes("youtu.be")) return "youtube";
  if (src.includes("vimeo.com")) return "vimeo";
  if (src.includes("loom.com")) return "loom";
  if (src.includes("spotify.com")) return "spotify";
  if (src.includes("soundcloud.com")) return "soundcloud";
  return "embed";
}

// Helper to generate container style
function getContainerStyle(width: string, height: string, alignment: MediaAlignment, float: MediaFloat): string {
  const styles: string[] = [`width: ${width}`];

  if (height && height !== "auto") {
    styles.push(`height: ${height}`);
  }

  if (float !== "none") {
    styles.push(`float: ${float}`);
    styles.push(float === "left" ? "margin-right: 1rem" : "margin-left: 1rem");
    styles.push("margin-bottom: 0.5rem");
  } else {
    if (alignment === "center") {
      styles.push("margin-left: auto", "margin-right: auto");
    } else if (alignment === "right") {
      styles.push("margin-left: auto");
    }
  }

  return styles.join("; ");
}
