'use client';

import { cn } from '@/lib/utils';

interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{
    name?: string;
    value?: number;
    dataKey?: string;
    payload?: Record<string, unknown>;
  }>;
  label?: string;
  valueLabel?: string;
}

export function ChartTooltip({ active, payload, valueLabel }: ChartTooltipProps) {
  if (!active || !payload || !payload.length) return null;

  const item = payload[0];
  if (!item) return null;
  const itemPayload = item.payload ?? {};
  const color = (itemPayload['color'] as string) || (itemPayload['fill'] as string) || '#3b82f6';
  const name = (itemPayload['name'] as string) || (itemPayload['facultyName'] as string) || (itemPayload['subjectName'] as string) || item.name || '';
  const value = item.value ?? 0;

  return (
    <div className="bg-popover border rounded-lg shadow-lg p-3 min-w-[120px] z-50">
      <div className="flex items-center gap-2 mb-1">
        <div
          className="w-3 h-3 rounded-full shrink-0"
          style={{ backgroundColor: color }}
        />
        <span className="font-medium text-sm text-foreground truncate">{name}</span>
      </div>
      <div className="text-lg font-bold text-foreground">
        {value.toLocaleString()}
        {valueLabel && <span className="text-sm font-normal text-muted-foreground ms-1">{valueLabel}</span>}
      </div>
    </div>
  );
}

interface ChartLegendProps {
  items: Array<{
    name: string;
    color: string;
    value?: number;
  }>;
  className?: string;
}

export function ChartLegend({ items, className }: ChartLegendProps) {
  return (
    <div className={cn("flex flex-wrap justify-center gap-x-4 gap-y-1", className)}>
      {items.map((item) => (
        <div key={item.name} className="flex items-center gap-1.5 text-xs">
          <div
            className="w-2.5 h-2.5 rounded-full shrink-0"
            style={{ backgroundColor: item.color }}
          />
          <span className="text-muted-foreground">{item.name}</span>
          {item.value !== undefined && (
            <span className="font-medium text-foreground">({item.value})</span>
          )}
        </div>
      ))}
    </div>
  );
}
