'use client';

import { useCallback } from 'react';
import { Upload, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DropzoneProps {
  onFileSelect: (file: File) => void;
  accept?: string | undefined;
  maxSize?: number | undefined;
  disabled?: boolean | undefined;
  className?: string | undefined;
}

export function Dropzone({
  onFileSelect,
  accept = '.pdf,.doc,.docx',
  maxSize = 50 * 1024 * 1024,
  disabled = false,
  className,
}: DropzoneProps) {
  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      if (disabled) return;

      const file = e.dataTransfer.files[0];
      if (file && file.size <= maxSize) {
        onFileSelect(file);
      }
    },
    [disabled, maxSize, onFileSelect]
  );

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file && file.size <= maxSize) {
        onFileSelect(file);
      }
    },
    [maxSize, onFileSelect]
  );

  return (
    <div
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
      className={cn(
        'relative flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-6',
        'transition-colors hover:border-primary/50 hover:bg-muted/50',
        disabled && 'cursor-not-allowed opacity-50',
        className
      )}
    >
      <input
        type="file"
        accept={accept}
        onChange={handleChange}
        disabled={disabled}
        className="absolute inset-0 cursor-pointer opacity-0"
      />
      <Upload className="mb-2 h-10 w-10 text-muted-foreground" />
      <p className="text-sm text-muted-foreground">
        Drag and drop or click to upload
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        PDF, DOC, DOCX (max 50MB)
      </p>
    </div>
  );
}

interface FilePreviewProps {
  file: File;
  onRemove: () => void;
}

export function FilePreview({ file, onRemove }: FilePreviewProps) {
  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="flex items-center gap-3 rounded-lg border p-3">
      <FileText className="h-8 w-8 text-primary" />
      <div className="flex-1 overflow-hidden">
        <p className="truncate text-sm font-medium">{file.name}</p>
        <p className="text-xs text-muted-foreground">{formatSize(file.size)}</p>
      </div>
      <button
        onClick={onRemove}
        className="text-sm text-muted-foreground hover:text-destructive"
      >
        Remove
      </button>
    </div>
  );
}
