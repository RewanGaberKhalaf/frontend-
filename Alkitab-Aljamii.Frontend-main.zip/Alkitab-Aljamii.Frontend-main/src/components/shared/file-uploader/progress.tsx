'use client';

import { CheckCircle, XCircle, Loader2 } from 'lucide-react';

export type UploadStatus = 'idle' | 'uploading' | 'success' | 'error';

interface UploadProgressProps {
  status: UploadStatus;
  progress: number;
  error?: string;
}

export function UploadProgress({ status, progress, error }: UploadProgressProps) {
  if (status === 'idle') return null;

  return (
    <div className="mt-4 space-y-2">
      <div className="flex items-center gap-2">
        {status === 'uploading' && (
          <Loader2 className="h-4 w-4 animate-spin text-primary" />
        )}
        {status === 'success' && (
          <CheckCircle className="h-4 w-4 text-green-500" />
        )}
        {status === 'error' && (
          <XCircle className="h-4 w-4 text-destructive" />
        )}
        <span className="text-sm">
          {status === 'uploading' && `Uploading... ${progress}%`}
          {status === 'success' && 'Upload complete!'}
          {status === 'error' && (error ?? 'Upload failed')}
        </span>
      </div>
      {status === 'uploading' && (
        <div className="h-2 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full bg-primary transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
}
