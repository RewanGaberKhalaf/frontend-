'use client';

import { useState } from 'react';
import { Dropzone, FilePreview } from './dropzone';
import { UploadProgress, type UploadStatus } from './progress';

interface FileUploaderProps {
  onUpload: (file: File) => Promise<void>;
  accept?: string;
  maxSize?: number;
  disabled?: boolean;
}

export function FileUploader({
  onUpload,
  accept,
  maxSize,
  disabled = false,
}: FileUploaderProps) {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<UploadStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string>();

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
    setStatus('idle');
    setProgress(0);
    setError(undefined);
  };

  const handleRemove = () => {
    setFile(null);
    setStatus('idle');
    setProgress(0);
    setError(undefined);
  };

  const handleUpload = async () => {
    if (!file) return;

    setStatus('uploading');
    setProgress(0);

    // Simulate progress
    const interval = setInterval(() => {
      setProgress((prev) => Math.min(prev + 10, 90));
    }, 200);

    try {
      await onUpload(file);
      clearInterval(interval);
      setProgress(100);
      setStatus('success');
    } catch (err) {
      clearInterval(interval);
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Upload failed');
    }
  };

  return (
    <div className="space-y-4">
      {!file ? (
        <Dropzone
          onFileSelect={handleFileSelect}
          accept={accept}
          maxSize={maxSize}
          disabled={disabled || status === 'uploading'}
        />
      ) : (
        <>
          <FilePreview file={file} onRemove={handleRemove} />
          {status !== 'success' && (
            <button
              onClick={handleUpload}
              disabled={disabled || status === 'uploading'}
              className="w-full rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {status === 'uploading' ? 'Uploading...' : 'Upload File'}
            </button>
          )}
        </>
      )}
      <UploadProgress status={status} progress={progress} error={error} />
    </div>
  );
}

export { Dropzone, FilePreview } from './dropzone';
export { UploadProgress, type UploadStatus } from './progress';
