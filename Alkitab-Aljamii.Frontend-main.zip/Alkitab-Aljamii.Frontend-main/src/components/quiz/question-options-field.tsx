"use client";

import { UseFormReturn, UseFieldArrayReturn } from "react-hook-form";
import { useTranslations } from "next-intl";
import { Plus, Trash2 } from "lucide-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { cn } from "@/lib/utils";
import { SortableOption } from "./sortable-option";
import type { QuestionFormData } from "./question-form-schema";

interface QuestionOptionsFieldProps {
  form: UseFormReturn<QuestionFormData>;
  fieldArray: UseFieldArrayReturn<QuestionFormData, "options", "id">;
  questionType: "multiple_choice" | "true_false";
}

export function QuestionOptionsField({
  form,
  fieldArray,
  questionType,
}: QuestionOptionsFieldProps) {
  const t = useTranslations();
  const { fields, append, remove, move } = fieldArray;

  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = fields.findIndex((field) => field.id === active.id);
      const newIndex = fields.findIndex((field) => field.id === over.id);
      move(oldIndex, newIndex);
      // Update order values
      fields.forEach((_, index) => {
        form.setValue(`options.${index}.order`, index);
      });
    }
  };

  const handleCorrectChange = (index: number, checked: boolean) => {
    // For true/false, only one can be correct
    if (questionType === "true_false") {
      fields.forEach((_, i) => {
        form.setValue(`options.${i}.isCorrect`, i === index);
      });
    } else {
      form.setValue(`options.${index}.isCorrect`, checked);
    }
  };

  const addOption = () => {
    append({
      text: "",
      textAr: "",
      isCorrect: false,
      order: fields.length,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <FormLabel>{t("questions.options")}</FormLabel>
        {questionType === "multiple_choice" && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addOption}
            disabled={fields.length >= 6}
          >
            <Plus className="me-1 h-4 w-4" />
            {t("questions.addOption")}
          </Button>
        )}
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={fields.map((f) => f.id)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-3">
            {fields.map((field, index) => (
              <SortableOption
                key={field.id}
                id={field.id}
                disabled={questionType === "true_false"}
              >
                <div
                  className={cn(
                    "flex-1 rounded-lg border p-2 sm:p-3",
                    form.watch(`options.${index}.isCorrect`) &&
                      "border-green-500 bg-green-50 dark:bg-green-950/20"
                  )}
                >
                  <div className="space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <FormField
                        control={form.control}
                        name={`options.${index}.text`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input
                                placeholder={t("questions.optionTextPlaceholder")}
                                {...field}
                                disabled={questionType === "true_false"}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`options.${index}.textAr`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input
                                placeholder={t("questions.optionTextArPlaceholder")}
                                dir="rtl"
                                {...field}
                                disabled={questionType === "true_false"}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <FormField
                        control={form.control}
                        name={`options.${index}.isCorrect`}
                        render={({ field }) => (
                          <FormItem className="flex items-center gap-2">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={(checked) =>
                                  handleCorrectChange(index, checked as boolean)
                                }
                              />
                            </FormControl>
                            <FormLabel className="text-sm font-normal">
                              {t("questions.correct")}
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      {questionType === "multiple_choice" && fields.length > 2 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => remove(index)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </SortableOption>
            ))}
          </div>
        </SortableContext>
      </DndContext>
      {form.formState.errors.options?.message && (
        <p className="text-sm font-medium text-destructive">
          {form.formState.errors.options.message}
        </p>
      )}
    </div>
  );
}
