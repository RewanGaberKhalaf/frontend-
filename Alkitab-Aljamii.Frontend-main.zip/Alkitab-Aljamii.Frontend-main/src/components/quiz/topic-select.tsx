'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { Check, ChevronsUpDown, Loader2, Plus, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { topicsApi, type Topic } from '@/lib/api/topics';
import { toast } from 'sonner';

interface CreateTopicDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  subjectId: string;
  onCreated: (topic: Topic) => void;
}

function CreateTopicDialog({
  open,
  onOpenChange,
  subjectId,
  onCreated,
}: CreateTopicDialogProps) {
  const t = useTranslations();
  const [name, setName] = useState('');
  const [nameAr, setNameAr] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error(t('topics.nameRequired'));
      return;
    }

    setIsCreating(true);
    try {
      const response = await topicsApi.createTopic(subjectId, {
        name: name.trim(),
        nameAr: nameAr.trim() || undefined,
      });
      toast.success(t('topics.created'));
      // API returns { data: Topic } wrapper
      const newTopic = 'data' in response ? response.data : response;
      onCreated(newTopic as Topic);
      onOpenChange(false);
      setName('');
      setNameAr('');
    } catch (error) {
      console.error('Failed to create topic:', error);
      toast.error(t('topics.createError'));
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t('topics.createNew')}</DialogTitle>
          <DialogDescription>{t('topics.createDescription')}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="topic-name">{t('topics.name')}</Label>
            <Input
              id="topic-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t('topics.namePlaceholder')}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleCreate();
                }
              }}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="topic-name-ar">{t('topics.nameAr')}</Label>
            <Input
              id="topic-name-ar"
              value={nameAr}
              onChange={(e) => setNameAr(e.target.value)}
              placeholder={t('topics.nameArPlaceholder')}
              dir="rtl"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleCreate();
                }
              }}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t('common.cancel')}
          </Button>
          <Button onClick={handleCreate} disabled={isCreating || !name.trim()}>
            {isCreating && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
            {t('common.create')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

interface TopicSelectProps {
  subjectId: string;
  value?: string;
  onChange: (topicId: string | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
}

/**
 * Single topic select component
 */
export function TopicSelect({
  subjectId,
  value,
  onChange,
  placeholder,
  disabled = false,
}: TopicSelectProps) {
  const t = useTranslations();
  const [open, setOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadTopics = useCallback(async () => {
    if (!subjectId) return;
    setIsLoading(true);
    try {
      const result = await topicsApi.getAllActiveTopics(subjectId);
      setTopics(result.data);
    } catch (error) {
      console.error('Failed to load topics:', error);
    } finally {
      setIsLoading(false);
    }
  }, [subjectId]);

  useEffect(() => {
    loadTopics();
  }, [loadTopics]);

  const selectedTopic = topics.find((t) => t.id === value);

  const handleTopicCreated = (newTopic: Topic) => {
    setTopics((prev) => [...prev, newTopic]);
    onChange(newTopic.id);
  };

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between"
            disabled={disabled || isLoading}
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : selectedTopic ? (
              selectedTopic.name
            ) : (
              <span className="text-muted-foreground">
                {placeholder || t('topics.selectTopic')}
              </span>
            )}
            <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0" align="start">
          <Command>
            <CommandInput placeholder={t('topics.searchTopics')} />
            <CommandList>
              <CommandEmpty>{t('topics.noTopicsFound')}</CommandEmpty>
              <CommandGroup>
                {/* Create new topic option */}
                <CommandItem
                  onSelect={() => {
                    setOpen(false);
                    setCreateDialogOpen(true);
                  }}
                  className="text-primary"
                >
                  <Plus className="me-2 h-4 w-4" />
                  {t('topics.createNew')}
                </CommandItem>
                <CommandSeparator className="my-1" />
                {/* Clear option */}
                <CommandItem
                  onSelect={() => {
                    onChange(undefined);
                    setOpen(false);
                  }}
                >
                  <span className="text-muted-foreground">{t('common.none')}</span>
                </CommandItem>
                {topics.map((topic) => (
                  <CommandItem
                    key={topic.id}
                    value={topic.name}
                    onSelect={() => {
                      onChange(topic.id);
                      setOpen(false);
                    }}
                  >
                    <Check
                      className={cn(
                        'me-2 h-4 w-4',
                        value === topic.id ? 'opacity-100' : 'opacity-0'
                      )}
                    />
                    {topic.name}
                    {topic.nameAr && (
                      <span className="text-muted-foreground me-2" dir="rtl">
                        ({topic.nameAr})
                      </span>
                    )}
                    <Badge variant="outline" className="ms-auto">
                      {topic.questionCount}
                    </Badge>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      <CreateTopicDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        subjectId={subjectId}
        onCreated={handleTopicCreated}
      />
    </>
  );
}

interface TopicMultiSelectProps {
  subjectId: string;
  value: string[];
  onChange: (topicIds: string[]) => void;
  placeholder?: string;
  disabled?: boolean;
}

/**
 * Multi-select topic component for quizzes
 */
export function TopicMultiSelect({
  subjectId,
  value = [],
  onChange,
  placeholder,
  disabled = false,
}: TopicMultiSelectProps) {
  const t = useTranslations();
  const [open, setOpen] = useState(false);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadTopics = useCallback(async () => {
    if (!subjectId) return;
    setIsLoading(true);
    try {
      const result = await topicsApi.getAllActiveTopics(subjectId);
      setTopics(result.data);
    } catch (error) {
      console.error('Failed to load topics:', error);
    } finally {
      setIsLoading(false);
    }
  }, [subjectId]);

  useEffect(() => {
    loadTopics();
  }, [loadTopics]);

  const selectedTopics = topics.filter((t) => value.includes(t.id));

  const toggleTopic = (topicId: string) => {
    if (value.includes(topicId)) {
      onChange(value.filter((id) => id !== topicId));
    } else {
      onChange([...value, topicId]);
    }
  };

  const removeTopic = (topicId: string) => {
    onChange(value.filter((id) => id !== topicId));
  };

  return (
    <div className="space-y-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between"
            disabled={disabled || isLoading}
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : selectedTopics.length > 0 ? (
              <span>
                {selectedTopics.length} {t('topics.selected')}
              </span>
            ) : (
              <span className="text-muted-foreground">
                {placeholder || t('topics.selectTopics')}
              </span>
            )}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0" align="start">
          <Command>
            <CommandInput placeholder={t('topics.searchTopics')} />
            <CommandList>
              <CommandEmpty>{t('topics.noTopicsFound')}</CommandEmpty>
              <CommandGroup>
                {topics.map((topic) => (
                  <CommandItem
                    key={topic.id}
                    value={topic.name}
                    onSelect={() => toggleTopic(topic.id)}
                  >
                    <Check
                      className={cn(
                        'mr-2 h-4 w-4',
                        value.includes(topic.id) ? 'opacity-100' : 'opacity-0'
                      )}
                    />
                    {topic.name}
                    {topic.nameAr && (
                      <span className="text-muted-foreground mr-2" dir="rtl">
                        ({topic.nameAr})
                      </span>
                    )}
                    <Badge variant="outline" className="ml-auto">
                      {topic.questionCount}
                    </Badge>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      {/* Selected topics badges */}
      {selectedTopics.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {selectedTopics.map((topic) => (
            <Badge key={topic.id} variant="secondary" className="gap-1">
              {topic.name}
              <button
                type="button"
                onClick={() => removeTopic(topic.id)}
                className="ml-1 ring-offset-background rounded-full outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
