# Question Forms - Implementation Guide

This directory contains multiple implementations of the question creation/editing form, each optimized for different use cases.

## Available Form Implementations

### 1. QuestionFormWizard (Recommended - Default)
**File:** `question-form-wizard.tsx`

**Best for:** Default question creation flow

**Features:**
- 4-step wizard interface (Basic Info → Question → Options → Details)
- Progressive disclosure - only shows relevant fields per step
- Visual progress indicator with step navigation
- Tabbed language switcher (English/Arabic) to reduce visual clutter
- Compact options field with tabbed language input
- Step validation before proceeding
- Smaller modal footprint (max-w-2xl vs max-w-3xl)
- Better mobile experience

**Modal Size:** `max-w-2xl` (672px)

**Usage:**
```tsx
import { QuestionFormWizard } from '@/components/quiz';

<Dialog open={isOpen} onOpenChange={setIsOpen}>
  <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
    <DialogHeader>
      <DialogTitle>Add Question</DialogTitle>
    </DialogHeader>
    <QuestionFormWizard
      subjectId={subjectId}
      onSubmit={handleSubmit}
      onCancel={handleCancel}
      isLoading={isLoading}
    />
  </DialogContent>
</Dialog>
```

### 2. QuestionFormCompact
**File:** `question-form-compact.tsx`

**Best for:** Users who prefer seeing all fields at once

**Features:**
- Single-page form with all fields visible
- Organized into logical sections with separators
- Tabbed language switcher (English/Arabic)
- Compact spacing and smaller inputs (h-9)
- Section headings for visual hierarchy
- Uses compact options field component
- Better than original but still scrollable

**Modal Size:** `max-w-2xl` (672px)

**Usage:**
```tsx
import { QuestionFormCompact } from '@/components/quiz';

<Dialog open={isOpen} onOpenChange={setIsOpen}>
  <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
    <DialogHeader>
      <DialogTitle>Add Question</DialogTitle>
    </DialogHeader>
    <QuestionFormCompact
      subjectId={subjectId}
      onSubmit={handleSubmit}
      onCancel={handleCancel}
      isLoading={isLoading}
    />
  </DialogContent>
</Dialog>
```

### 3. QuestionForm (Original)
**File:** `question-form.tsx`

**Best for:** Backward compatibility

**Features:**
- Original implementation
- All fields visible in single scrolling form
- Side-by-side English/Arabic fields
- Larger modal size needed
- Dense layout

**Modal Size:** `max-w-3xl` (768px)

**Note:** Consider migrating to QuestionFormWizard or QuestionFormCompact for better UX.

## Component Details

### QuestionOptionsFieldCompact
**File:** `question-options-field-compact.tsx`

Improved options field with:
- Tabbed language input (EN/AR) per option
- Drag handle for reordering
- Inline "Correct" checkbox with label
- Compact spacing
- Visual feedback for correct answers (green border/background)
- Delete button only shown when applicable

### QuestionOptionsField (Original)
**File:** `question-options-field.tsx`

Original implementation with side-by-side English/Arabic inputs.

## Migration Guide

### From QuestionForm to QuestionFormWizard

**Before:**
```tsx
import { QuestionForm } from '@/components/quiz';

<DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
  <QuestionForm {...props} />
</DialogContent>
```

**After:**
```tsx
import { QuestionFormWizard } from '@/components/quiz';

<DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
  <QuestionFormWizard {...props} />
</DialogContent>
```

## Design Decisions

### Why Multi-Step Wizard?

1. **Reduced Cognitive Load:** Users focus on one aspect at a time
2. **Smaller Modal:** Doesn't overwhelm the screen
3. **Progressive Disclosure:** Optional fields (explanation) shown at the end
4. **Better Mobile Experience:** Easier navigation on smaller screens
5. **Validation Feedback:** Immediate validation per step

### Why Tabbed Language Input?

1. **Space Efficiency:** Reduces vertical space by ~50%
2. **Focus:** Users work in one language at a time
3. **Optional Arabic:** Makes it clear that Arabic is optional
4. **Cleaner UI:** Less visual clutter

### Why Compact Options?

1. **Vertical Space:** Each option takes less space
2. **Tabbed Input:** EN/AR tabs per option
3. **Visual Hierarchy:** Clear indication of correct answers
4. **Touch-Friendly:** Larger touch targets for mobile

## Styling Notes

- All forms use consistent shadcn/ui components
- RTL support built-in for Arabic text
- Responsive grid layouts (grid-cols-1 sm:grid-cols-2)
- Proper spacing with Tailwind (space-y-3, space-y-4)
- Accessible form labels and error messages

## Future Improvements

- [ ] Add keyboard shortcuts for wizard navigation (Ctrl+→, Ctrl+←)
- [ ] Add "Save as Draft" functionality
- [ ] Add question preview before submission
- [ ] Add bulk edit mode for multiple questions
- [ ] Add AI-powered question suggestions
