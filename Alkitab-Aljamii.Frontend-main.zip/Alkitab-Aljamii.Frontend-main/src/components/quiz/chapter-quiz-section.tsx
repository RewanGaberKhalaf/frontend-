'use client';

import { useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import {
  ClipboardList,
  ArrowRight,
  CheckCircle2,
  Trophy,
  CircleDot,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';
import type { ChapterQuizStatus } from '@/lib/api/quiz';

interface ChapterQuizSectionProps {
  quizStatus: ChapterQuizStatus;
  className?: string;
}

export function ChapterQuizSection({ quizStatus, className }: ChapterQuizSectionProps) {
  const t = useTranslations();
  const router = useRouter();

  if (!quizStatus.hasQuiz || !quizStatus.quizId) {
    return null;
  }

  const {
    quizId,
    hasPassed,
    bestScore,
    attemptCount,
    maxAttempts,
    passingThreshold,
  } = quizStatus;

  const canAttempt = quizStatus.canAttempt && (maxAttempts == null || attemptCount < maxAttempts);

  const handleTakeQuiz = () => {
    router.push(ROUTES.STUDENT.QUIZ(quizId));
  };

  return (
    <div className={cn('rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 p-4 space-y-3', className)}>
      {/* Header with icon */}
      <div className="flex items-center gap-3">
        <div
          className={cn(
            'shrink-0 w-10 h-10 rounded-lg flex items-center justify-center',
            hasPassed
              ? 'bg-green-500/20 text-green-500'
              : 'bg-primary/20 text-primary'
          )}
        >
          {hasPassed ? (
            <Trophy className="h-5 w-5" />
          ) : (
            <ClipboardList className="h-5 w-5" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-semibold">{t('chapterQuiz.title')}</span>
            {hasPassed && (
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {hasPassed
              ? t('chapterQuiz.completedDescription')
              : t('chapterQuiz.description', { threshold: passingThreshold })
            }
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-3 text-sm">
        <div className="flex items-center gap-1.5">
          <CircleDot className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-muted-foreground">{passingThreshold}%</span>
        </div>
        {bestScore != null && (
          <div className="flex items-center gap-1.5">
            <Trophy className="h-3.5 w-3.5 text-muted-foreground" />
            <span className={cn(
              'font-medium',
              bestScore >= passingThreshold ? 'text-green-500' : 'text-amber-500'
            )}>
              {bestScore}%
            </span>
          </div>
        )}
        <div className="text-muted-foreground">
          {attemptCount}{maxAttempts != null ? ` / ${maxAttempts}` : ''} {t('chapterQuiz.attempts')}
        </div>
      </div>

      {/* Progress indicator */}
      {bestScore != null && !hasPassed && (
        <div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-primary transition-all"
              style={{ width: `${Math.min((bestScore / passingThreshold) * 100, 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Action Button */}
      <Button
        size="sm"
        className={cn(
          "w-full",
          hasPassed && "bg-green-600 hover:bg-green-700"
        )}
        onClick={handleTakeQuiz}
        disabled={!canAttempt && !hasPassed}
      >
        {canAttempt ? (
          <>
            {attemptCount > 0 ? t('chapterProgress.retakeQuiz') : t('chapterProgress.takeQuiz')}
            <ArrowRight className="ms-2 h-4 w-4" />
          </>
        ) : hasPassed ? (
          t('chapterQuiz.viewQuiz')
        ) : (
          t('quizTaking.maxAttemptsReached')
        )}
      </Button>
    </div>
  );
}
