"use client";

import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useTranslations } from "next-intl";
import { Loader2, ChevronLeft, ChevronRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import type { CreateQuestionData, UpdateQuestionData, QuestionType } from "@/lib/api/quiz";
import {
  questionSchema,
  getDefaultFormValues,
  type QuestionFormData,
  type QuestionFormProps,
} from "./question-form-schema";
import { QuestionOptionsFieldCompact } from "./question-options-field-compact";
import { TopicSelect } from "./topic-select";

const STEPS = [
  { id: 1, key: "basicInfo" },
  { id: 2, key: "question" },
  { id: 3, key: "options" },
  { id: 4, key: "details" },
] as const;

export function QuestionFormWizard({
  question,
  subjectId,
  onSubmit,
  onCancel,
  isLoading = false,
}: QuestionFormProps) {
  const t = useTranslations();
  const isEditing = !!question;
  const [currentStep, setCurrentStep] = useState(1);
  const [language, setLanguage] = useState<"en" | "ar">("en");

  const form = useForm<QuestionFormData>({
    resolver: zodResolver(questionSchema),
    defaultValues: getDefaultFormValues(question, isEditing),
    mode: "onChange",
  });

  const fieldArray = useFieldArray({
    control: form.control,
    name: "options",
  });

  const questionType = form.watch("questionType");

  const handleQuestionTypeChange = (value: QuestionType) => {
    form.setValue("questionType", value);
    if (value === "true_false") {
      form.setValue("options", [
        { text: "True", textAr: "صح", isCorrect: true, order: 0 },
        { text: "False", textAr: "خطأ", isCorrect: false, order: 1 },
      ]);
    } else if (fieldArray.fields.length === 2 && questionType === "true_false") {
      // If switching from true_false to multiple_choice, reset to default options
      form.setValue("options", [
        { text: "", textAr: "", isCorrect: true, order: 0 },
        { text: "", textAr: "", isCorrect: false, order: 1 },
        { text: "", textAr: "", isCorrect: false, order: 2 },
        { text: "", textAr: "", isCorrect: false, order: 3 },
      ]);
    }
  };

  const handleSubmit = async (data: QuestionFormData) => {
    const hasCorrect = data.options.some((opt) => opt.isCorrect);
    if (!hasCorrect) {
      form.setError("options", {
        type: "manual",
        message: t("questions.atLeastOneCorrect"),
      });
      setCurrentStep(3);
      return;
    }

    await onSubmit(data as CreateQuestionData | UpdateQuestionData);
  };

  const validateStep = async (step: number): Promise<boolean> => {
    let fieldsToValidate: Array<keyof QuestionFormData> = [];

    switch (step) {
      case 1:
        fieldsToValidate = ["questionType", "difficulty"];
        if (subjectId) {
          fieldsToValidate.push("topicId");
        } else {
          fieldsToValidate.push("topic");
        }
        break;
      case 2:
        fieldsToValidate = ["questionText"];
        break;
      case 3:
        fieldsToValidate = ["options"];
        break;
      case 4:
        fieldsToValidate = ["points"];
        break;
    }

    const result = await form.trigger(fieldsToValidate);
    return result;
  };

  const handleNext = async () => {
    const isValid = await validateStep(currentStep);
    if (isValid && currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canGoNext = () => {
    switch (currentStep) {
      case 1:
        return !!form.watch("questionType") && !!form.watch("difficulty");
      case 2:
        return !!form.watch("questionText");
      case 3:
        return fieldArray.fields.length >= 2;
      default:
        return true;
    }
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleSubmit)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && currentStep !== 4) {
            e.preventDefault();
          }
        }}
        className="space-y-6"
      >
        {/* Progress Steps */}
        <div className="flex items-center justify-between">
          {STEPS.map((step, index) => (
            <div key={step.id} className="flex items-center flex-1">
              <div className="flex flex-col items-center flex-1">
                <button
                  type="button"
                  onClick={() => setCurrentStep(step.id)}
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors",
                    currentStep === step.id
                      ? "bg-primary text-primary-foreground"
                      : currentStep > step.id
                      ? "bg-green-500 text-white"
                      : "bg-muted text-muted-foreground"
                  )}
                >
                  {currentStep > step.id ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    step.id
                  )}
                </button>
                <span
                  className={cn(
                    "text-xs mt-1 hidden sm:block",
                    currentStep === step.id
                      ? "text-foreground font-medium"
                      : "text-muted-foreground"
                  )}
                >
                  {t(`questions.wizard.${step.key}`)}
                </span>
              </div>
              {index < STEPS.length - 1 && (
                <div
                  className={cn(
                    "h-0.5 flex-1 mx-2",
                    currentStep > step.id ? "bg-green-500" : "bg-muted"
                  )}
                />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="min-h-[280px] max-h-[400px] overflow-y-auto">
          {/* Step 1: Basic Info */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="questionType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t("questions.type")}</FormLabel>
                      <Select
                        onValueChange={handleQuestionTypeChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t("questions.selectType")} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="multiple_choice">
                            {t("questions.multipleChoice")}
                          </SelectItem>
                          <SelectItem value="true_false">
                            {t("questions.trueFalse")}
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t("questions.difficulty")}</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t("questions.selectDifficulty")} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="easy">{t("questions.easy")}</SelectItem>
                          <SelectItem value="medium">{t("questions.medium")}</SelectItem>
                          <SelectItem value="hard">{t("questions.hard")}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Topic Field */}
              {subjectId ? (
                <FormField
                  control={form.control}
                  name="topicId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t("questions.topic")}</FormLabel>
                      <FormControl>
                        <TopicSelect
                          subjectId={subjectId}
                          value={field.value}
                          onChange={field.onChange}
                          placeholder={t("questions.selectTopic")}
                        />
                      </FormControl>
                      <FormDescription>{t("questions.topicDescription")}</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ) : (
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="topic"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("questions.topic")}</FormLabel>
                        <FormControl>
                          <Input placeholder={t("questions.topicPlaceholder")} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="topicAr"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("questions.topicAr")}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t("questions.topicArPlaceholder")}
                            dir="rtl"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              )}
            </div>
          )}

          {/* Step 2: Question Text */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <Tabs value={language} onValueChange={(v) => setLanguage(v as "en" | "ar")}>
                <TabsList className="grid w-full max-w-[300px] grid-cols-2">
                  <TabsTrigger value="en">{t("common.english")}</TabsTrigger>
                  <TabsTrigger value="ar">{t("common.arabic")}</TabsTrigger>
                </TabsList>

                <TabsContent value="en" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="questionText"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("questions.questionText")}</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={t("questions.questionTextPlaceholder")}
                            className="resize-none min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>

                <TabsContent value="ar" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="questionTextAr"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("questions.questionTextAr")}</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={t("questions.questionTextArPlaceholder")}
                            className="resize-none min-h-[150px]"
                            dir="rtl"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          {t("common.optional")}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Step 3: Options */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <QuestionOptionsFieldCompact
                form={form}
                fieldArray={fieldArray}
                questionType={questionType}
              />
            </div>
          )}

          {/* Step 4: Additional Details */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="points"
                render={({ field }) => (
                  <FormItem className="max-w-[200px]">
                    <FormLabel>{t("questions.points")}</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={1}
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Tabs value={language} onValueChange={(v) => setLanguage(v as "en" | "ar")}>
                <TabsList className="grid w-full max-w-[300px] grid-cols-2">
                  <TabsTrigger value="en">{t("common.english")}</TabsTrigger>
                  <TabsTrigger value="ar">{t("common.arabic")}</TabsTrigger>
                </TabsList>

                <TabsContent value="en" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="explanation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("questions.explanation")}</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={t("questions.explanationPlaceholder")}
                            className="resize-none"
                            rows={3}
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          {t("questions.explanationDescription")}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>

                <TabsContent value="ar" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="explanationAr"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("questions.explanationAr")}</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={t("questions.explanationArPlaceholder")}
                            className="resize-none"
                            dir="rtl"
                            rows={3}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
              </Tabs>

              {isEditing && (
                <FormField
                  control={form.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between gap-3 rounded-lg border p-4">
                      <div className="space-y-0.5 flex-1 min-w-0">
                        <FormLabel>{t("questions.active")}</FormLabel>
                        <FormDescription>
                          {t("questions.activeDescription")}
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} className="shrink-0" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}
            </div>
          )}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t">
          <Button
            type="button"
            variant="outline"
            onClick={currentStep === 1 ? onCancel : handlePrevious}
          >
            {currentStep === 1 ? (
              t("common.cancel")
            ) : (
              <>
                <ChevronLeft className="me-1 h-4 w-4" />
                {t("common.previous")}
              </>
            )}
          </Button>

          {currentStep < 4 ? (
            <Button type="button" onClick={handleNext} disabled={!canGoNext()}>
              {t("common.next")}
              <ChevronRight className="ms-1 h-4 w-4" />
            </Button>
          ) : (
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
              {isEditing ? t("common.save") : t("common.create")}
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}
