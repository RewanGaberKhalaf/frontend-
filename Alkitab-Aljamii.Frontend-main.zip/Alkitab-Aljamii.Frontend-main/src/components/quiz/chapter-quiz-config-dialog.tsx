"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useTranslations } from "next-intl";
import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { ConfirmDialog } from "@/components/shared";
import { chapterQuizConfigSchema, defaultFormValues, type ChapterQuizConfigFormData, type ChapterQuizConfigDialogProps } from "./chapter-quiz-config-schema";
import { useChapterQuizConfig } from "./use-chapter-quiz-config";
import { BankSelectField, BankInfo, QuestionDistributionFields, SettingsFields, SwitchFields } from "./chapter-quiz-config-fields";

export function ChapterQuizConfigDialog({ open, onOpenChange, chapterId, chapterTitle, subjectId, onConfigChange, readOnly = false }: ChapterQuizConfigDialogProps) {
  const t = useTranslations();

  const form = useForm<ChapterQuizConfigFormData>({
    resolver: zodResolver(chapterQuizConfigSchema),
    defaultValues: defaultFormValues,
  });

  const { banks, loadingBanks, existingConfig, loadingConfig, isSubmitting, showDeleteConfirm, setShowDeleteConfirm, isDeleting, selectedBank, totalQuestions, handleSubmit, handleDelete } = useChapterQuizConfig({ open, chapterId, subjectId, form, onConfigChange, onOpenChange });

  if (loadingConfig) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent><div className="flex items-center justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div></DialogContent>
      </Dialog>
    );
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t("chapterQuizConfig.title")}</DialogTitle>
            <DialogDescription>{t("chapterQuizConfig.description", { chapter: chapterTitle })}</DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <BankSelectField form={form} banks={banks} loadingBanks={loadingBanks} readOnly={readOnly} t={t} />
              <BankInfo selectedBank={selectedBank} t={t} />
              <QuestionDistributionFields form={form} selectedBank={selectedBank} readOnly={readOnly} t={t} />
              <div className="text-sm">{t("quizzes.totalQuestions")}: <span className="font-medium">{totalQuestions}</span></div>
              <Separator />
              <SettingsFields form={form} readOnly={readOnly} t={t} />
              <SwitchFields form={form} readOnly={readOnly} t={t} />

              <DialogFooter className="flex-col sm:flex-row gap-2">
                {!readOnly && existingConfig && (
                  <Button type="button" variant="destructive" onClick={() => setShowDeleteConfirm(true)} className="sm:me-auto">
                    <Trash2 className="h-4 w-4 me-2" />{t("chapterQuizConfig.remove")}
                  </Button>
                )}
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{readOnly ? t("common.close") : t("common.cancel")}</Button>
                {!readOnly && (
                  <Button type="submit" disabled={isSubmitting || totalQuestions === 0}>
                    {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                    {existingConfig ? t("common.save") : t("common.create")}
                  </Button>
                )}
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm} title={t("chapterQuizConfig.removeTitle")} description={t("chapterQuizConfig.removeDescription")} confirmLabel={t("common.delete")} onConfirm={handleDelete} loading={isDeleting} destructive />
    </>
  );
}
