'use client';

import { useTranslations } from 'next-intl';
import { UseFormReturn } from 'react-hook-form';
import { Info } from 'lucide-react';
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormDescription,
} from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import type { CreateQuizFormData, UpdateQuizFormData } from './quiz-form-schema';

interface QuizFormSettingsProps {
  form: UseFormReturn<CreateQuizFormData | UpdateQuizFormData>;
  isEditing: boolean;
}

export function QuizFormToggles({ form }: QuizFormSettingsProps) {
  const t = useTranslations();

  return (
    <div className="space-y-4">
      {/* Pool-based note */}
      <div className="flex items-start gap-3 text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <span>{t('quizzes.poolBasedNote')}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={form.control}
          name="shuffleQuestions"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 gap-3">
              <div className="space-y-0.5 flex-1 min-w-0">
                <FormLabel>{t('quizzes.shuffleQuestions')}</FormLabel>
                <FormDescription className="text-xs">
                  {t('quizzes.shuffleQuestionsDescription')}
                </FormDescription>
              </div>
              <FormControl>
                <Switch checked={field.value} onCheckedChange={field.onChange} className="shrink-0" />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="shuffleOptions"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 gap-3">
              <div className="space-y-0.5 flex-1 min-w-0">
                <FormLabel>{t('quizzes.shuffleOptions')}</FormLabel>
                <FormDescription className="text-xs">
                  {t('quizzes.shuffleOptionsDescription')}
                </FormDescription>
              </div>
              <FormControl>
                <Switch checked={field.value} onCheckedChange={field.onChange} className="shrink-0" />
              </FormControl>
            </FormItem>
          )}
        />
      </div>
    </div>
  );
}

export function QuizFormActiveToggle({ form }: Omit<QuizFormSettingsProps, 'isEditing'>) {
  const t = useTranslations();

  return (
    <FormField
      control={form.control}
      name="isActive"
      render={({ field }) => (
        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 gap-3">
          <div className="space-y-0.5 flex-1 min-w-0">
            <FormLabel>{t('questionBanks.active')}</FormLabel>
            <FormDescription className="text-xs">
              {t('questionBanks.activeDescription')}
            </FormDescription>
          </div>
          <FormControl>
            <Switch checked={field.value} onCheckedChange={field.onChange} className="shrink-0" />
          </FormControl>
        </FormItem>
      )}
    />
  );
}
