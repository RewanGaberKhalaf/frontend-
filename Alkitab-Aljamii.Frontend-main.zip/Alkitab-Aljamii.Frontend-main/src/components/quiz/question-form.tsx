"use client";

import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useTranslations } from "next-intl";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import type { CreateQuestionData, UpdateQuestionData, QuestionType } from "@/lib/api/quiz";
import {
  questionSchema,
  getDefaultFormValues,
  type QuestionFormData,
  type QuestionFormProps,
} from "./question-form-schema";
import { QuestionOptionsField } from "./question-options-field";
import { TopicSelect } from "./topic-select";

export function QuestionForm({
  question,
  subjectId,
  onSubmit,
  onCancel,
  isLoading = false,
}: QuestionFormProps) {
  const t = useTranslations();
  const isEditing = !!question;

  const form = useForm<QuestionFormData>({
    resolver: zodResolver(questionSchema),
    defaultValues: getDefaultFormValues(question, isEditing),
  });

  const fieldArray = useFieldArray({
    control: form.control,
    name: "options",
  });

  const questionType = form.watch("questionType");

  // When question type changes to true_false, reset options
  const handleQuestionTypeChange = (value: QuestionType) => {
    form.setValue("questionType", value);
    if (value === "true_false") {
      form.setValue("options", [
        { text: t("questions.trueOption"), textAr: t("questions.trueOption"), isCorrect: true, order: 0 },
        { text: t("questions.falseOption"), textAr: t("questions.falseOption"), isCorrect: false, order: 1 },
      ]);
    }
  };

  const handleSubmit = async (data: QuestionFormData) => {
    // Validate at least one correct answer
    const hasCorrect = data.options.some((opt) => opt.isCorrect);
    if (!hasCorrect) {
      form.setError("options", {
        type: "manual",
        message: t("questions.atLeastOneCorrect"),
      });
      return;
    }

    await onSubmit(data as CreateQuestionData | UpdateQuestionData);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 sm:space-y-6">
        {/* Type and Difficulty */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <FormField
            control={form.control}
            name="questionType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("questions.type")}</FormLabel>
                <Select onValueChange={handleQuestionTypeChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={t("questions.selectType")} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="multiple_choice">
                      {t("questions.multipleChoice")}
                    </SelectItem>
                    <SelectItem value="true_false">{t("questions.trueFalse")}</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="difficulty"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("questions.difficulty")}</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={t("questions.selectDifficulty")} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="easy">{t("questions.easy")}</SelectItem>
                    <SelectItem value="medium">{t("questions.medium")}</SelectItem>
                    <SelectItem value="hard">{t("questions.hard")}</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Topic Field */}
        {subjectId ? (
          <FormField
            control={form.control}
            name="topicId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("questions.topic")}</FormLabel>
                <FormControl>
                  <TopicSelect
                    subjectId={subjectId}
                    value={field.value}
                    onChange={field.onChange}
                    placeholder={t("questions.selectTopic")}
                  />
                </FormControl>
                <FormDescription>{t("questions.topicDescription")}</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <FormField
              control={form.control}
              name="topic"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("questions.topic")}</FormLabel>
                  <FormControl>
                    <Input placeholder={t("questions.topicPlaceholder")} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="topicAr"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("questions.topicAr")}</FormLabel>
                  <FormControl>
                    <Input placeholder={t("questions.topicArPlaceholder")} dir="rtl" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )}

        {/* Question Text Fields */}
        <FormField
          control={form.control}
          name="questionText"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t("questions.questionText")}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder={t("questions.questionTextPlaceholder")}
                  className="resize-none"
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="questionTextAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t("questions.questionTextAr")}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder={t("questions.questionTextArPlaceholder")}
                  className="resize-none"
                  dir="rtl"
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Options Field */}
        <QuestionOptionsField form={form} fieldArray={fieldArray} questionType={questionType} />

        {/* Explanation Fields */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <FormField
            control={form.control}
            name="explanation"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("questions.explanation")}</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder={t("questions.explanationPlaceholder")}
                    className="resize-none"
                    rows={2}
                    {...field}
                  />
                </FormControl>
                <FormDescription>{t("questions.explanationDescription")}</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="explanationAr"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("questions.explanationAr")}</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder={t("questions.explanationArPlaceholder")}
                    className="resize-none"
                    dir="rtl"
                    rows={2}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Points Field */}
        <FormField
          control={form.control}
          name="points"
          render={({ field }) => (
            <FormItem className="max-w-[200px]">
              <FormLabel>{t("questions.points")}</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min={1}
                  {...field}
                  onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Active Toggle (edit mode only) */}
        {isEditing && (
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between gap-3 rounded-lg border p-3">
                <div className="space-y-0.5 flex-1 min-w-0">
                  <FormLabel>{t("questions.active")}</FormLabel>
                  <FormDescription>{t("questions.activeDescription")}</FormDescription>
                </div>
                <FormControl>
                  <Switch checked={field.value} onCheckedChange={field.onChange} className="shrink-0" />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t("common.cancel")}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
            {isEditing ? t("common.save") : t("common.create")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
