'use client';

import { useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { Lock, ClipboardList, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ROUTES } from '@/lib/constants/routes';
import type { ChapterQuizStatus } from '@/lib/api/quiz';

interface ChapterLockedOverlayProps {
  chapterTitle: string;
  quizStatus?: ChapterQuizStatus | null;
  onGoToPrevious?: () => void;
  canGoToPrevious?: boolean;
}

export function ChapterLockedOverlay({
  chapterTitle,
  quizStatus,
  onGoToPrevious,
  canGoToPrevious = false,
}: ChapterLockedOverlayProps) {
  const t = useTranslations();
  const router = useRouter();

  const hasQuiz = quizStatus?.hasQuiz;
  const canAttempt = quizStatus?.canAttempt;
  const hasPassed = quizStatus?.hasPassed;
  const attemptCount = quizStatus?.attemptCount || 0;
  const passingThreshold = quizStatus?.passingThreshold || 70;

  // Determine the reason for lock
  // Note: max_attempts is no longer a lock reason - unlimited retries allowed
  let lockReason: 'quiz_required' | 'previous_incomplete' | 'default' = 'default';
  if (hasQuiz && !hasPassed) {
    if (canAttempt) {
      lockReason = 'quiz_required';
    } else {
      lockReason = 'previous_incomplete';
    }
  }

  return (
    <div className="h-full flex items-center justify-center">
      <div className="text-center max-w-md p-8">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
          <Lock className="h-8 w-8 text-muted-foreground" />
        </div>

        <h2 className="text-xl font-semibold mb-2">{t('books.chapterLocked')}</h2>

        {lockReason === 'quiz_required' && (
          <>
            <p className="text-muted-foreground mb-4">
              {t('chapterProgress.quizRequired', { threshold: passingThreshold })}
            </p>
            {attemptCount > 0 && (
              <p className="text-sm text-muted-foreground mb-4">
                {t('chapterProgress.previousAttempts', { count: attemptCount })}
                {quizStatus?.bestScore != null && (
                  <span className="ms-1">
                    ({t('chapterProgress.bestScore')}: {quizStatus?.bestScore}%)
                  </span>
                )}
              </p>
            )}
            <Button
              onClick={() => {
                if (quizStatus?.quizId) {
                  router.push(ROUTES.STUDENT.QUIZ(quizStatus.quizId));
                }
              }}
            >
              <ClipboardList className="h-4 w-4 me-2" />
              {attemptCount > 0 ? t('chapterProgress.retakeQuiz') : t('chapterProgress.takeQuiz')}
            </Button>
          </>
        )}

        {lockReason === 'previous_incomplete' && (
          <p className="text-muted-foreground mb-6">
            {t('chapterProgress.completePreviousChapter')}
          </p>
        )}

        {lockReason === 'default' && (
          <p className="text-muted-foreground mb-6">
            {t('books.chapterLockedDescription')}
          </p>
        )}

        {canGoToPrevious && onGoToPrevious && (
          <Button variant="outline" onClick={onGoToPrevious} className="mt-4">
            <ChevronLeft className="h-4 w-4 me-2" />
            {t('books.goToPreviousChapter')}
          </Button>
        )}
      </div>
    </div>
  );
}
