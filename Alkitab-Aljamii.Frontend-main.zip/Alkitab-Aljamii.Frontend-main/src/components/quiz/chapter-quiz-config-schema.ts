import { z } from "zod";
import type { ChapterQuizConfig } from "@/lib/api/quiz";

// Note: maxAttempts removed - unlimited retries allowed for educational focus
export const chapterQuizConfigSchema = z.object({
  bankId: z.string().min(1, "Question bank is required"),
  easyQuestions: z.number().min(0),
  mediumQuestions: z.number().min(0),
  hardQuestions: z.number().min(0),
  timeLimit: z.number().min(1).nullable().optional(),
  passingThreshold: z.number().min(0).max(100),
  cooldownMinutes: z.number().min(1).nullable().optional(),
  isRequired: z.boolean(),
  unlockNextChapter: z.boolean(),
  shuffleQuestions: z.boolean(),
  shuffleOptions: z.boolean(),
});

export type ChapterQuizConfigFormData = z.infer<typeof chapterQuizConfigSchema>;

export const defaultFormValues: ChapterQuizConfigFormData = {
  bankId: "",
  easyQuestions: 0,
  mediumQuestions: 0,
  hardQuestions: 0,
  timeLimit: null,
  passingThreshold: 70,
  cooldownMinutes: 30, // Default 30 min cooldown after failing
  isRequired: true,
  unlockNextChapter: true,
  shuffleQuestions: true,
  shuffleOptions: true,
};

export function configToFormData(config: ChapterQuizConfig): ChapterQuizConfigFormData {
  return {
    bankId: config.bankId,
    easyQuestions: config.easyQuestions,
    mediumQuestions: config.mediumQuestions,
    hardQuestions: config.hardQuestions,
    timeLimit: config.timeLimit,
    passingThreshold: config.passingThreshold,
    cooldownMinutes: config.cooldownMinutes,
    isRequired: config.isRequired,
    unlockNextChapter: config.unlockNextChapter,
    shuffleQuestions: config.shuffleQuestions,
    shuffleOptions: config.shuffleOptions,
  };
}

export interface ChapterQuizConfigDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  chapterId: string;
  chapterTitle: string;
  subjectId: string;
  onConfigChange?: () => void;
  readOnly?: boolean;
}
