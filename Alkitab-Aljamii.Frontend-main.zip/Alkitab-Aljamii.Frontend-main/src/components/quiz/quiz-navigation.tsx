'use client';

import { useTranslations } from 'next-intl';
import { cn } from '@/lib/utils';

interface QuizNavigationProps {
  totalQuestions: number;
  currentQuestion: number;
  answeredQuestions: Set<number>;
  onSelectQuestion: (index: number) => void;
  className?: string;
}

export function QuizNavigation({
  totalQuestions,
  currentQuestion,
  answeredQuestions,
  onSelectQuestion,
  className,
}: QuizNavigationProps) {
  const t = useTranslations();

  return (
    <div className={cn('space-y-4', className)}>
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-sm">{t('quizTaking.questions')}</h3>
        <span className="text-xs text-muted-foreground">
          {answeredQuestions.size}/{totalQuestions} {t('quizTaking.answered')}
        </span>
      </div>

      <div className="grid grid-cols-5 gap-2">
        {Array.from({ length: totalQuestions }).map((_, index) => {
          const isCurrent = currentQuestion === index;
          const isAnswered = answeredQuestions.has(index);

          return (
            <button
              key={index}
              type="button"
              onClick={() => onSelectQuestion(index)}
              className={cn(
                'w-full aspect-square rounded-lg text-sm font-medium transition-all',
                isCurrent && 'ring-2 ring-primary ring-offset-2',
                isAnswered && !isCurrent && 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400',
                !isAnswered && !isCurrent && 'bg-muted hover:bg-muted/80',
                isCurrent && isAnswered && 'bg-green-500 text-white',
                isCurrent && !isAnswered && 'bg-primary text-primary-foreground',
              )}
            >
              {index + 1}
            </button>
          );
        })}
      </div>

      <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-green-100 dark:bg-green-900/30" />
          <span>{t('quizTaking.answered')}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-muted" />
          <span>{t('quizTaking.notAnswered')}</span>
        </div>
      </div>
    </div>
  );
}
