"use client";

import { useState } from "react";
import { UseFormReturn, UseFieldArrayReturn } from "react-hook-form";
import { useTranslations } from "next-intl";
import { Plus, Trash2, GripVertical } from "lucide-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { cn } from "@/lib/utils";
import type { QuestionFormData } from "./question-form-schema";

interface QuestionOptionsFieldCompactProps {
  form: UseFormReturn<QuestionFormData>;
  fieldArray: UseFieldArrayReturn<QuestionFormData, "options", "id">;
  questionType: "multiple_choice" | "true_false";
}

interface SortableOptionItemProps {
  id: string;
  index: number;
  disabled: boolean;
  isCorrect: boolean;
  canDelete: boolean;
  form: UseFormReturn<QuestionFormData>;
  onRemove: () => void;
  onCorrectChange: (checked: boolean) => void;
}

function SortableOptionItem({
  id,
  index,
  disabled,
  isCorrect,
  canDelete,
  form,
  onRemove,
  onCorrectChange,
}: SortableOptionItemProps) {
  const t = useTranslations();
  const [language, setLanguage] = useState<"en" | "ar">("en");
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id, disabled });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes}>
      <div
        className={cn(
          "rounded-lg border p-3 space-y-2",
          isCorrect && "border-green-500 bg-green-50 dark:bg-green-950/20"
        )}
      >
        <div className="flex items-center gap-2">
          <div
            {...listeners}
            className={cn(
              "cursor-grab active:cursor-grabbing",
              disabled && "cursor-not-allowed opacity-50"
            )}
          >
            <GripVertical className="h-4 w-4 text-muted-foreground" />
          </div>

          <div className="flex-1 text-sm font-medium text-muted-foreground">
            {t("questions.optionNumber", { number: index + 1 })}
          </div>

          <FormField
            control={form.control}
            name={`options.${index}.isCorrect`}
            render={({ field }) => (
              <FormItem className="flex items-center gap-2">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={onCorrectChange}
                  />
                </FormControl>
                <FormLabel className="text-sm font-normal cursor-pointer">
                  {t("questions.correct")}
                </FormLabel>
              </FormItem>
            )}
          />

          {canDelete && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={onRemove}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          )}
        </div>

        <Tabs value={language} onValueChange={(v) => setLanguage(v as "en" | "ar")}>
          <TabsList className="grid w-full max-w-[250px] grid-cols-2 h-8">
            <TabsTrigger value="en" className="text-xs">{t("common.en")}</TabsTrigger>
            <TabsTrigger value="ar" className="text-xs">{t("common.ar")}</TabsTrigger>
          </TabsList>

          <TabsContent value="en" className="mt-2">
            <FormField
              control={form.control}
              name={`options.${index}.text`}
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input
                      placeholder={t("questions.optionTextPlaceholder")}
                      {...field}
                      disabled={disabled}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>

          <TabsContent value="ar" className="mt-2">
            <FormField
              control={form.control}
              name={`options.${index}.textAr`}
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input
                      placeholder={t("questions.optionTextArPlaceholder")}
                      dir="rtl"
                      {...field}
                      disabled={disabled}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export function QuestionOptionsFieldCompact({
  form,
  fieldArray,
  questionType,
}: QuestionOptionsFieldCompactProps) {
  const t = useTranslations();
  const { fields, append, remove, move } = fieldArray;

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = fields.findIndex((field) => field.id === active.id);
      const newIndex = fields.findIndex((field) => field.id === over.id);
      move(oldIndex, newIndex);
      fields.forEach((_, index) => {
        form.setValue(`options.${index}.order`, index);
      });
    }
  };

  const handleCorrectChange = (index: number, checked: boolean) => {
    if (questionType === "true_false") {
      fields.forEach((_, i) => {
        form.setValue(`options.${i}.isCorrect`, i === index);
      });
    } else {
      form.setValue(`options.${index}.isCorrect`, checked);
    }
  };

  const addOption = () => {
    append({
      text: "",
      textAr: "",
      isCorrect: false,
      order: fields.length,
    });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <FormLabel>{t("questions.options")}</FormLabel>
        {questionType === "multiple_choice" && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addOption}
            disabled={fields.length >= 6}
          >
            <Plus className="me-1 h-3 w-3" />
            {t("questions.addOption")}
          </Button>
        )}
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={fields.map((f) => f.id)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-2">
            {fields.map((field, index) => (
              <SortableOptionItem
                key={field.id}
                id={field.id}
                index={index}
                disabled={questionType === "true_false"}
                isCorrect={form.watch(`options.${index}.isCorrect`)}
                canDelete={questionType === "multiple_choice" && fields.length > 2}
                form={form}
                onRemove={() => remove(index)}
                onCorrectChange={(checked) => handleCorrectChange(index, checked)}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      {form.formState.errors.options?.message && (
        <p className="text-sm font-medium text-destructive">
          {form.formState.errors.options.message}
        </p>
      )}
    </div>
  );
}
