'use client';

import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslations } from 'next-intl';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { subjectsApi } from '@/lib/api/subjects';
import type { QuestionBank, CreateQuestionBankData, UpdateQuestionBankData } from '@/lib/api/quiz';

interface SubjectOption {
  id: string;
  name: string;
  nameAr?: string | null;
}

const createSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  nameAr: z.string().optional(),
  subjectId: z.string().min(1, 'Subject is required'),
  description: z.string().optional(),
  descriptionAr: z.string().optional(),
});

const updateSchema = z.object({
  name: z.string().min(1, 'Name is required').optional(),
  nameAr: z.string().optional(),
  description: z.string().optional(),
  descriptionAr: z.string().optional(),
  isActive: z.boolean().optional(),
});

type CreateFormData = z.infer<typeof createSchema>;
type UpdateFormData = z.infer<typeof updateSchema>;

interface QuestionBankFormProps {
  bank?: QuestionBank;
  onSubmit: (data: CreateQuestionBankData | UpdateQuestionBankData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export function QuestionBankForm({
  bank,
  onSubmit,
  onCancel,
  isLoading = false,
}: QuestionBankFormProps) {
  const t = useTranslations();
  const isEditing = !!bank;
  const [subjects, setSubjects] = useState<SubjectOption[]>([]);
  const [loadingSubjects, setLoadingSubjects] = useState(false);

  const form = useForm<CreateFormData | UpdateFormData>({
    resolver: zodResolver(isEditing ? updateSchema : createSchema),
    defaultValues: isEditing
      ? {
          name: bank.name,
          nameAr: bank.nameAr || '',
          description: bank.description || '',
          descriptionAr: bank.descriptionAr || '',
          isActive: bank.isActive,
        }
      : {
          name: '',
          nameAr: '',
          subjectId: '',
          description: '',
          descriptionAr: '',
        },
  });

  useEffect(() => {
    const fetchSubjects = async () => {
      setLoadingSubjects(true);
      try {
        const response = await subjectsApi.getAll({ limit: 100 });
        setSubjects(response.items);
      } catch (error) {
        console.error('Failed to fetch subjects:', error);
      } finally {
        setLoadingSubjects(false);
      }
    };
    fetchSubjects();
  }, []);

  const handleSubmit = async (data: CreateFormData | UpdateFormData) => {
    await onSubmit(data as CreateQuestionBankData | UpdateQuestionBankData);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('questionBanks.name')}</FormLabel>
              <FormControl>
                <Input placeholder={t('questionBanks.namePlaceholder')} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="nameAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('questionBanks.nameAr')}</FormLabel>
              <FormControl>
                <Input
                  placeholder={t('questionBanks.nameArPlaceholder')}
                  dir="rtl"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {!isEditing && (
          <FormField
            control={form.control}
            name="subjectId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('questionBanks.subject')}</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={t('questionBanks.selectSubject')} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {loadingSubjects ? (
                      <SelectItem value="loading" disabled>
                        {t('common.loading')}...
                      </SelectItem>
                    ) : (
                      subjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('questionBanks.description')}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder={t('questionBanks.descriptionPlaceholder')}
                  className="resize-none"
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="descriptionAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('questionBanks.descriptionAr')}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder={t('questionBanks.descriptionArPlaceholder')}
                  className="resize-none"
                  dir="rtl"
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {isEditing && (
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{t('questionBanks.active')}</FormLabel>
                  <p className="text-sm text-muted-foreground">
                    {t('questionBanks.activeDescription')}
                  </p>
                </div>
                <FormControl>
                  <Switch checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        <div className="flex justify-end gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEditing ? t('common.save') : t('common.create')}
          </Button>
        </div>
      </form>
    </Form>
  );
}
