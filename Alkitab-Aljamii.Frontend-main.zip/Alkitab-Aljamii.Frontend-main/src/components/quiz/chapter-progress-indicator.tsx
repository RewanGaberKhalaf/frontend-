'use client';

import { Lock, Unlock, CheckCircle2, ClipboardList } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import type { ChapterProgress } from '@/lib/api/quiz';

interface ChapterProgressIndicatorProps {
  progress?: ChapterProgress | null;
  isActive: boolean;
  onClick: () => void;
  index: number;
  title: string;
}

export function ChapterProgressIndicator({
  progress,
  isActive,
  onClick,
  index,
  title,
}: ChapterProgressIndicatorProps) {
  const isUnlocked = progress?.isUnlocked ?? true; // Default to unlocked if no progress
  const hasPassed = progress?.passedAt != null; // Uses != to check for both null and undefined
  const quizRequired = progress?.quizRequired ?? false;
  const bestScore = progress?.bestScore ?? null;

  return (
    <div
      className={cn(
        'flex items-center gap-2 rounded-md px-3 py-2 cursor-pointer transition-colors',
        isActive
          ? isUnlocked
            ? 'bg-primary/10 text-primary font-medium'
            : 'bg-destructive/10 text-destructive font-medium'
          : isUnlocked
            ? 'hover:bg-muted'
            : 'hover:bg-muted/50 text-muted-foreground'
      )}
      onClick={onClick}
    >
      {/* Status icon */}
      <div className="shrink-0">
        {hasPassed ? (
          <CheckCircle2 className="h-4 w-4 text-green-600" />
        ) : isUnlocked ? (
          <Unlock className="h-4 w-4 text-green-600" />
        ) : (
          <Lock className="h-4 w-4 text-muted-foreground" />
        )}
      </div>

      {/* Title */}
      <span className="text-sm truncate flex-1">
        {index + 1}. {title}
      </span>

      {/* Indicators */}
      <div className="flex items-center gap-1 shrink-0">
        {quizRequired && !hasPassed && isUnlocked && (
          <Badge variant="outline" className="h-5 px-1.5 text-[10px]">
            <ClipboardList className="h-3 w-3 me-0.5" />
            Quiz
          </Badge>
        )}
        {hasPassed && bestScore !== null && (
          <Badge variant="secondary" className="h-5 px-1.5 text-[10px]">
            {bestScore}%
          </Badge>
        )}
      </div>
    </div>
  );
}
