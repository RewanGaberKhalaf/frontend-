import { z } from "zod";
import type {
  Question,
  CreateQuestionData,
  UpdateQuestionData,
  QuestionType,
  Difficulty,
} from "@/lib/api/quiz";

export const optionSchema = z.object({
  text: z.string().min(1, "Option text is required"),
  textAr: z.string().optional(),
  isCorrect: z.boolean(),
  order: z.number(),
});

export const questionSchema = z.object({
  questionText: z.string().min(1, "Question text is required"),
  questionTextAr: z.string().optional(),
  questionType: z.enum(["multiple_choice", "true_false"]),
  difficulty: z.enum(["easy", "medium", "hard"]),
  topicId: z.string().optional(),
  topic: z.string().optional(),
  topicAr: z.string().optional(),
  options: z.array(optionSchema).min(2, "At least 2 options are required"),
  explanation: z.string().optional(),
  explanationAr: z.string().optional(),
  points: z.number().min(1),
  isActive: z.boolean().optional(),
});

export type QuestionFormData = z.infer<typeof questionSchema>;

export interface QuestionFormProps {
  question?: Question;
  subjectId?: string;
  onSubmit: (data: CreateQuestionData | UpdateQuestionData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export function getDefaultFormValues(
  question?: Question,
  isEditing: boolean = false
): QuestionFormData {
  if (isEditing && question) {
    return {
      questionText: question.questionText,
      questionTextAr: question.questionTextAr || "",
      questionType: question.questionType,
      difficulty: question.difficulty,
      topicId: question.topicId || undefined,
      topic: question.topic || "",
      topicAr: question.topicAr || "",
      options: question.options.map((opt) => ({
        text: opt.text,
        textAr: opt.textAr || "",
        isCorrect: opt.isCorrect,
        order: opt.order,
      })),
      explanation: question.explanation || "",
      explanationAr: question.explanationAr || "",
      points: question.points,
      isActive: question.isActive,
    };
  }

  return {
    questionText: "",
    questionTextAr: "",
    questionType: "multiple_choice" as QuestionType,
    difficulty: "medium" as Difficulty,
    topicId: undefined,
    topic: "",
    topicAr: "",
    options: [
      { text: "", textAr: "", isCorrect: true, order: 0 },
      { text: "", textAr: "", isCorrect: false, order: 1 },
      { text: "", textAr: "", isCorrect: false, order: 2 },
      { text: "", textAr: "", isCorrect: false, order: 3 },
    ],
    explanation: "",
    explanationAr: "",
    points: 1,
    isActive: true,
  };
}
