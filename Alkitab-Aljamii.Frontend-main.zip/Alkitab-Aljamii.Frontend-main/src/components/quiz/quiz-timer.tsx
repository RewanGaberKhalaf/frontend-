'use client';

import { useState, useEffect } from 'react';
import { Clock, AlertTriangle, Timer } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QuizTimerProps {
  /** Time limit in minutes (optional - if not provided, shows elapsed time) */
  timeLimit?: number | null;
  /** Start time ISO string */
  startTime: string;
  /** Called when time is up (only for timed quizzes) */
  onTimeUp?: () => void;
  className?: string;
}

export function QuizTimer({ timeLimit, startTime, onTimeUp, className }: QuizTimerProps) {
  const [seconds, setSeconds] = useState<number>(0);
  const [hasCalledTimeUp, setHasCalledTimeUp] = useState(false);

  const isTimed = timeLimit != null && timeLimit > 0;

  useEffect(() => {
    const calculateTime = () => {
      const start = new Date(startTime).getTime();
      const now = Date.now();
      const elapsed = Math.floor((now - start) / 1000);

      if (isTimed) {
        // Countdown mode
        const total = timeLimit * 60;
        return Math.max(0, total - elapsed);
      } else {
        // Count-up mode (elapsed time)
        return elapsed;
      }
    };

    // Initial calculation
    setSeconds(calculateTime());

    // Update every second
    const interval = setInterval(() => {
      const time = calculateTime();
      setSeconds(time);

      // Check for time up in timed mode
      if (isTimed && time <= 0 && !hasCalledTimeUp) {
        setHasCalledTimeUp(true);
        onTimeUp?.();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [timeLimit, startTime, onTimeUp, hasCalledTimeUp, isTimed]);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // For timed quizzes - warning states
  const isLow = isTimed && seconds <= 60;
  const isCritical = isTimed && seconds <= 30;

  return (
    <div
      className={cn(
        'flex items-center gap-2 px-3 py-2 rounded-lg font-mono text-lg',
        // Timed mode styling
        isTimed && !isLow && 'bg-muted',
        isLow && !isCritical && 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400',
        isCritical && 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 animate-pulse',
        // Untimed mode styling
        !isTimed && 'bg-muted/50 text-muted-foreground',
        className
      )}
    >
      {isCritical ? (
        <AlertTriangle className="h-5 w-5" />
      ) : isTimed ? (
        <Clock className="h-5 w-5" />
      ) : (
        <Timer className="h-5 w-5" />
      )}
      <span>{formatTime(seconds)}</span>
    </div>
  );
}
