'use client';

import { useState, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle, X, Loader2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { quizApi, type ImportQuestionsResult } from '@/lib/api/quiz';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface QuestionImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bankId: string;
  onSuccess: () => void;
}

export function QuestionImportDialog({
  open,
  onOpenChange,
  bankId,
  onSuccess,
}: QuestionImportDialogProps) {
  const t = useTranslations();
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState<ImportQuestionsResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const resetState = useCallback(() => {
    setFile(null);
    setResult(null);
    setError(null);
    setIsUploading(false);
  }, []);

  const handleClose = () => {
    if (!isUploading) {
      resetState();
      onOpenChange(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && isValidFile(droppedFile)) {
      setFile(droppedFile);
      setError(null);
    } else {
      setError(t('questions.import.invalidFileType'));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && isValidFile(selectedFile)) {
      setFile(selectedFile);
      setError(null);
    } else if (selectedFile) {
      setError(t('questions.import.invalidFileType'));
    }
    // Reset input so same file can be selected again
    e.target.value = '';
  };

  const isValidFile = (f: File) => {
    const validTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
    ];
    return validTypes.includes(f.type) || f.name.endsWith('.xlsx') || f.name.endsWith('.xls');
  };

  const handleUpload = async () => {
    if (!file) return;

    setIsUploading(true);
    setError(null);

    try {
      const importResult = await quizApi.importQuestions(bankId, file);
      setResult(importResult);
      if (importResult.successCount > 0) {
        onSuccess();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t('questions.import.uploadError'));
    } finally {
      setIsUploading(false);
    }
  };

  const handleDone = () => {
    resetState();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{t('questions.import.title')}</DialogTitle>
          <DialogDescription>{t('questions.import.description')}</DialogDescription>
        </DialogHeader>

        {!result ? (
          <>
            {/* Drop Zone */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={cn(
                'border-2 border-dashed rounded-lg p-8 text-center transition-colors',
                isDragging
                  ? 'border-primary bg-primary/5'
                  : 'border-muted-foreground/25 hover:border-muted-foreground/50',
                file && 'border-green-500 bg-green-500/5'
              )}
            >
              {file ? (
                <div className="flex items-center justify-center gap-3">
                  <FileSpreadsheet className="h-8 w-8 text-green-600" />
                  <div className="text-left">
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="ml-2"
                    onClick={() => setFile(null)}
                    disabled={isUploading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-2">
                    {t('questions.import.dropzone')}
                  </p>
                  <label>
                    <input
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={handleFileSelect}
                      className="hidden"
                      disabled={isUploading}
                    />
                    <Button variant="outline" asChild disabled={isUploading}>
                      <span className="cursor-pointer">{t('questions.import.selectFile')}</span>
                    </Button>
                  </label>
                  <p className="text-xs text-muted-foreground mt-3">
                    {t('questions.import.acceptedFormats')}
                  </p>
                </>
              )}
            </div>

            {/* Template Download */}
            <div className="flex items-center justify-between gap-3 rounded-lg border p-4">
              <div className="space-y-1">
                <p className="text-sm font-medium">{t('questions.import.downloadTemplate')}</p>
                <p className="text-xs text-muted-foreground">
                  {t('questions.import.templateDescription')}
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={async () => {
                  try {
                    await quizApi.downloadImportTemplate();
                    toast.success(t('questions.import.templateDownloaded'));
                  } catch (err) {
                    toast.error(t('questions.import.templateError'));
                  }
                }}
              >
                <Download className="me-2 h-4 w-4" />
                {t('common.download')}
              </Button>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={handleClose} disabled={isUploading}>
                {t('common.cancel')}
              </Button>
              <Button onClick={handleUpload} disabled={!file || isUploading}>
                {isUploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {t('questions.import.upload')}
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            {/* Results */}
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 rounded-lg bg-muted">
                {result.errorCount === 0 ? (
                  <CheckCircle className="h-8 w-8 text-green-600" />
                ) : result.successCount > 0 ? (
                  <AlertCircle className="h-8 w-8 text-yellow-600" />
                ) : (
                  <AlertCircle className="h-8 w-8 text-red-600" />
                )}
                <div>
                  <p className="font-medium">
                    {result.errorCount === 0
                      ? t('questions.import.success')
                      : result.successCount > 0
                        ? t('questions.import.partial')
                        : t('questions.import.failed')}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {t('questions.import.resultSummary', {
                      success: result.successCount,
                      total: result.totalProcessed,
                    })}
                  </p>
                </div>
              </div>

              {result.errors.length > 0 && (
                <div className="max-h-48 overflow-y-auto rounded-lg border p-3">
                  <p className="text-sm font-medium text-destructive mb-2">
                    {t('questions.import.errors')}:
                  </p>
                  <ul className="text-sm space-y-1">
                    {result.errors.map((err, idx) => (
                      <li key={idx} className="text-muted-foreground">
                        • {err}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button onClick={handleDone}>{t('common.done')}</Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
