import { z } from 'zod';
import type { Quiz, CreateQuizData, UpdateQuizData } from '@/lib/api/quiz';

// Note: maxAttempts removed - unlimited retries allowed for educational focus
export const createQuizSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  titleAr: z.string().optional(),
  bankId: z.string().min(1, 'Question bank is required'),
  topicIds: z.array(z.string()).optional(),
  description: z.string().optional(),
  descriptionAr: z.string().optional(),
  easyQuestions: z.number().min(0),
  mediumQuestions: z.number().min(0),
  hardQuestions: z.number().min(0),
  timeLimit: z.number().min(1).nullable().optional(),
  passingScore: z.number().min(0).max(100),
  cooldownMinutes: z.number().min(1).nullable().optional(),
  shuffleQuestions: z.boolean(),
  shuffleOptions: z.boolean(),
  isPoolBased: z.boolean(),
});

export const updateQuizSchema = z.object({
  title: z.string().min(1, 'Title is required').optional(),
  titleAr: z.string().optional(),
  topicIds: z.array(z.string()).optional(),
  description: z.string().optional(),
  descriptionAr: z.string().optional(),
  easyQuestions: z.number().min(0).optional(),
  mediumQuestions: z.number().min(0).optional(),
  hardQuestions: z.number().min(0).optional(),
  timeLimit: z.number().min(1).nullable().optional(),
  passingScore: z.number().min(0).max(100).optional(),
  cooldownMinutes: z.number().min(1).nullable().optional(),
  shuffleQuestions: z.boolean().optional(),
  shuffleOptions: z.boolean().optional(),
  isPoolBased: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

export type CreateQuizFormData = z.infer<typeof createQuizSchema>;
export type UpdateQuizFormData = z.infer<typeof updateQuizSchema>;

export interface QuizFormProps {
  quiz?: Quiz;
  onSubmit: (data: CreateQuizData | UpdateQuizData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export function getDefaultCreateValues(): CreateQuizFormData {
  return {
    title: '',
    titleAr: '',
    bankId: '',
    topicIds: [],
    description: '',
    descriptionAr: '',
    easyQuestions: 0,
    mediumQuestions: 0,
    hardQuestions: 0,
    timeLimit: null,
    passingScore: 60,
    cooldownMinutes: 30, // Default 30 min cooldown after failing
    shuffleQuestions: true,
    shuffleOptions: true,
    isPoolBased: true,
  };
}

export function getDefaultEditValues(quiz: Quiz): UpdateQuizFormData {
  return {
    title: quiz.title,
    titleAr: quiz.titleAr || '',
    topicIds: quiz.topicIds || [],
    description: quiz.description || '',
    descriptionAr: quiz.descriptionAr || '',
    easyQuestions: quiz.easyQuestions,
    mediumQuestions: quiz.mediumQuestions,
    hardQuestions: quiz.hardQuestions,
    timeLimit: quiz.timeLimit,
    passingScore: quiz.passingScore,
    cooldownMinutes: quiz.cooldownMinutes,
    shuffleQuestions: quiz.shuffleQuestions,
    shuffleOptions: quiz.shuffleOptions,
    isPoolBased: quiz.isPoolBased,
    isActive: quiz.isActive,
  };
}
