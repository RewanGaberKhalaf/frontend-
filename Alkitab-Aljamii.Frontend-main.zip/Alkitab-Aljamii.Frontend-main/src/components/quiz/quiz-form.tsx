'use client';

import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useTranslations } from 'next-intl';
import { Loader2, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { quizApi, type QuestionBank, type CreateQuizData, type UpdateQuizData } from '@/lib/api/quiz';
import {
  createQuizSchema,
  updateQuizSchema,
  type CreateQuizFormData,
  type UpdateQuizFormData,
  type QuizFormProps,
  getDefaultCreateValues,
  getDefaultEditValues,
} from './quiz-form-schema';
import { QuizFormToggles, QuizFormActiveToggle } from './quiz-form-settings';
import { TopicMultiSelect } from './topic-select';

export function QuizForm({
  quiz,
  onSubmit,
  onCancel,
  isLoading = false,
}: QuizFormProps) {
  const t = useTranslations();
  const isEditing = !!quiz;
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [loadingBanks, setLoadingBanks] = useState(false);
  const [selectedBank, setSelectedBank] = useState<QuestionBank | null>(null);
  const [filteredCounts, setFilteredCounts] = useState<{ easy: number; medium: number; hard: number } | null>(null);
  const [loadingCounts, setLoadingCounts] = useState(false);

  const form = useForm<CreateQuizFormData | UpdateQuizFormData>({
    resolver: zodResolver(isEditing ? updateQuizSchema : createQuizSchema),
    defaultValues: isEditing ? getDefaultEditValues(quiz) : getDefaultCreateValues(),
  });

  // Fetch question banks
  useEffect(() => {
    const fetchBanks = async () => {
      setLoadingBanks(true);
      try {
        const response = await quizApi.getQuestionBanks({ limit: 100, isActive: true });
        setBanks(response.items);
      } catch (error) {
        console.error('Failed to fetch question banks:', error);
      } finally {
        setLoadingBanks(false);
      }
    };
    fetchBanks();
  }, []);

  // Update selected bank when bankId changes (or for edit mode, from quiz.bankId)
  const bankId = form.watch('bankId');
  useEffect(() => {
    const effectiveBankId = bankId || (isEditing && quiz?.bankId);
    if (effectiveBankId) {
      const bank = banks.find((b) => b.id === effectiveBankId);
      setSelectedBank(bank || null);
    } else {
      setSelectedBank(null);
    }
  }, [bankId, banks, isEditing, quiz?.bankId]);

  // Fetch difficulty counts when topics change
  const topicIds = form.watch('topicIds');
  const effectiveBankId = bankId || (isEditing ? quiz?.bankId : undefined);
  useEffect(() => {
    const fetchCounts = async () => {
      if (!effectiveBankId) {
        setFilteredCounts(null);
        return;
      }
      // If no topics selected, use bank's counts
      if (!topicIds || topicIds.length === 0) {
        setFilteredCounts(null);
        return;
      }
      setLoadingCounts(true);
      try {
        const counts = await quizApi.getDifficultyCounts(effectiveBankId, topicIds);
        setFilteredCounts(counts);
      } catch (error) {
        console.error('Failed to fetch difficulty counts:', error);
        setFilteredCounts(null);
      } finally {
        setLoadingCounts(false);
      }
    };
    fetchCounts();
  }, [effectiveBankId, topicIds, isEditing, quiz?.bankId]);

  // Get available counts (filtered if topics selected, otherwise from bank)
  const availableCounts = filteredCounts || (selectedBank ? {
    easy: selectedBank.easyCount,
    medium: selectedBank.mediumCount,
    hard: selectedBank.hardCount,
  } : null);

  const handleSubmit = async (data: CreateQuizFormData | UpdateQuizFormData) => {
    // Transform null values for time limit and cooldown
    const submitData = {
      ...data,
      timeLimit: data.timeLimit || undefined,
      cooldownMinutes: data.cooldownMinutes || undefined,
    };
    await onSubmit(submitData as CreateQuizData | UpdateQuizData);
  };

  const easyQuestions = form.watch('easyQuestions') || 0;
  const mediumQuestions = form.watch('mediumQuestions') || 0;
  const hardQuestions = form.watch('hardQuestions') || 0;
  const totalQuestions = easyQuestions + mediumQuestions + hardQuestions;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        {/* Basic Info */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('quizzes.name')}</FormLabel>
                  <FormControl>
                    <Input placeholder={t('quizzes.namePlaceholder')} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="titleAr"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('quizzes.nameAr')}</FormLabel>
                  <FormControl>
                    <Input
                      placeholder={t('quizzes.nameArPlaceholder')}
                      dir="rtl"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {!isEditing && (
            <FormField
              control={form.control}
              name="bankId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('quizzes.questionBank')}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('quizzes.selectQuestionBank')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {loadingBanks ? (
                        <SelectItem value="loading" disabled>
                          {t('common.loading')}...
                        </SelectItem>
                      ) : (
                        banks.map((bank) => (
                          <SelectItem key={bank.id} value={bank.id}>
                            {bank.name} ({bank.totalQuestions} {t('questions.title').toLowerCase()})
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          {/* Topic Selection - shows when a bank is selected */}
          {selectedBank && (
            <FormField
              control={form.control}
              name="topicIds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('topics.title')}</FormLabel>
                  <FormControl>
                    <TopicMultiSelect
                      subjectId={selectedBank.subjectId}
                      value={field.value || []}
                      onChange={field.onChange}
                      placeholder={t('topics.selectTopics')}
                    />
                  </FormControl>
                  <FormDescription>
                    {t('topics.topicDescription')}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('questionBanks.description')}</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={t('questionBanks.descriptionPlaceholder')}
                      className="resize-none"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descriptionAr"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('questionBanks.descriptionAr')}</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={t('questionBanks.descriptionArPlaceholder')}
                      className="resize-none"
                      dir="rtl"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <Separator />

        {/* Question Distribution */}
        <div className="space-y-4">
          <h3 className="font-medium">{t('quizzes.questionDistribution')}</h3>

          {availableCounts && (
            <div className={`flex items-center gap-2 text-sm p-3 rounded-lg ${
              loadingCounts ? 'bg-muted/50 text-muted-foreground' :
              (easyQuestions > availableCounts.easy || mediumQuestions > availableCounts.medium || hardQuestions > availableCounts.hard)
                ? 'bg-destructive/10 text-destructive border border-destructive/20'
                : 'bg-muted/50 text-muted-foreground'
            }`}>
              <Info className="h-4 w-4 shrink-0" />
              <span>
                {loadingCounts ? t('common.loading') : (
                  <>
                    {t('questions.easy')}: {availableCounts.easy} | {t('questions.medium')}: {availableCounts.medium} | {t('questions.hard')}: {availableCounts.hard}
                    {filteredCounts && <span className="ms-2 text-xs">({t('quizzes.filteredByTopics')})</span>}
                  </>
                )}
              </span>
            </div>
          )}

          {availableCounts && (easyQuestions > availableCounts.easy || mediumQuestions > availableCounts.medium || hardQuestions > availableCounts.hard) && (
            <div className="text-sm text-destructive">
              {t('quizzes.insufficientQuestions')}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="easyQuestions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className={easyQuestions > (availableCounts?.easy || 999) ? 'text-destructive' : ''}>
                    {t('quizzes.easyQuestions')}
                    {availableCounts && <span className="text-xs text-muted-foreground ms-1">(max: {availableCounts.easy})</span>}
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={0}
                      max={availableCounts?.easy || 999}
                      className={easyQuestions > (availableCounts?.easy || 999) ? 'border-destructive' : ''}
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="mediumQuestions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className={mediumQuestions > (availableCounts?.medium || 999) ? 'text-destructive' : ''}>
                    {t('quizzes.mediumQuestions')}
                    {availableCounts && <span className="text-xs text-muted-foreground ms-1">(max: {availableCounts.medium})</span>}
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={0}
                      max={availableCounts?.medium || 999}
                      className={mediumQuestions > (availableCounts?.medium || 999) ? 'border-destructive' : ''}
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="hardQuestions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className={hardQuestions > (availableCounts?.hard || 999) ? 'text-destructive' : ''}>
                    {t('quizzes.hardQuestions')}
                    {availableCounts && <span className="text-xs text-muted-foreground ms-1">(max: {availableCounts.hard})</span>}
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={0}
                      max={availableCounts?.hard || 999}
                      className={hardQuestions > (availableCounts?.hard || 999) ? 'border-destructive' : ''}
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="text-sm">
            {t('quizzes.totalQuestions')}: <span className="font-medium">{totalQuestions}</span>
          </div>
        </div>

        <Separator />

        {/* Quiz Settings */}
        <div className="space-y-4">
          <h3 className="font-medium">{t('common.settings')}</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="timeLimit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('quizzes.timeLimit')}</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      placeholder={t('quizzes.timeLimitPlaceholder')}
                      {...field}
                      value={field.value ?? ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        field.onChange(val ? parseInt(val) : null);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="passingScore"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('quizzes.passingScore')}</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="cooldownMinutes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('quizzes.cooldownMinutes')}</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      placeholder={t('quizzes.cooldownPlaceholder')}
                      {...field}
                      value={field.value ?? ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        field.onChange(val ? parseInt(val) : null);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <QuizFormToggles form={form} isEditing={isEditing} />
        </div>

        {isEditing && (
          <>
            <Separator />
            <QuizFormActiveToggle form={form} />
          </>
        )}

        <div className="flex items-center justify-end gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button
            type="submit"
            disabled={isLoading || !!(availableCounts && (
              easyQuestions > availableCounts.easy ||
              mediumQuestions > availableCounts.medium ||
              hardQuestions > availableCounts.hard
            ))}
          >
            {isLoading && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
            {isEditing ? t('common.save') : t('common.create')}
          </Button>
        </div>
      </form>
    </Form>
  );
}
