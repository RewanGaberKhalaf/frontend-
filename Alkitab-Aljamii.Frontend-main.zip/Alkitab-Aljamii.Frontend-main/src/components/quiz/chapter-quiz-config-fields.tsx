"use client";

import { Info } from "lucide-react";
import { UseFormReturn } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import type { ChapterQuizConfigFormData } from "./chapter-quiz-config-schema";
import type { QuestionBank } from "@/lib/api/quiz";

interface BankSelectFieldProps {
  form: UseFormReturn<ChapterQuizConfigFormData>;
  banks: QuestionBank[];
  loadingBanks: boolean;
  readOnly: boolean;
  t: (key: string) => string;
}

export function BankSelectField({ form, banks, loadingBanks, readOnly, t }: BankSelectFieldProps) {
  return (
    <FormField control={form.control} name="bankId" render={({ field }) => (
      <FormItem>
        <FormLabel>{t("quizzes.questionBank")}</FormLabel>
        <Select onValueChange={field.onChange} value={field.value} disabled={readOnly}>
          <FormControl><SelectTrigger><SelectValue placeholder={t("quizzes.selectQuestionBank")} /></SelectTrigger></FormControl>
          <SelectContent>
            {loadingBanks ? <SelectItem value="loading" disabled>{t("common.loading")}...</SelectItem>
            : banks.length === 0 ? <SelectItem value="none" disabled>{t("chapterQuizConfig.noBanks")}</SelectItem>
            : banks.map((bank) => <SelectItem key={bank.id} value={bank.id}>{bank.name} ({bank.totalQuestions} {t("questions.title").toLowerCase()})</SelectItem>)}
          </SelectContent>
        </Select>
        <FormMessage />
      </FormItem>
    )} />
  );
}

interface BankInfoProps {
  selectedBank: QuestionBank | null;
  t: (key: string) => string;
}

export function BankInfo({ selectedBank, t }: BankInfoProps) {
  if (!selectedBank) return null;
  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
      <Info className="h-4 w-4" />
      <span>{t("questions.easy")}: {selectedBank.easyCount} | {t("questions.medium")}: {selectedBank.mediumCount} | {t("questions.hard")}: {selectedBank.hardCount}</span>
    </div>
  );
}

interface QuestionDistributionFieldsProps {
  form: UseFormReturn<ChapterQuizConfigFormData>;
  selectedBank: QuestionBank | null;
  readOnly: boolean;
  t: (key: string) => string;
}

export function QuestionDistributionFields({ form, selectedBank, readOnly, t }: QuestionDistributionFieldsProps) {
  return (
    <div className="grid grid-cols-3 gap-3">
      <FormField control={form.control} name="easyQuestions" render={({ field }) => (
        <FormItem>
          <FormLabel>{t("quizzes.easyQuestions")}</FormLabel>
          <FormControl><Input type="number" min={0} max={selectedBank?.easyCount || 999} disabled={readOnly} {...field} onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="mediumQuestions" render={({ field }) => (
        <FormItem>
          <FormLabel>{t("quizzes.mediumQuestions")}</FormLabel>
          <FormControl><Input type="number" min={0} max={selectedBank?.mediumCount || 999} disabled={readOnly} {...field} onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="hardQuestions" render={({ field }) => (
        <FormItem>
          <FormLabel>{t("quizzes.hardQuestions")}</FormLabel>
          <FormControl><Input type="number" min={0} max={selectedBank?.hardCount || 999} disabled={readOnly} {...field} onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
    </div>
  );
}

interface SettingsFieldsProps {
  form: UseFormReturn<ChapterQuizConfigFormData>;
  readOnly: boolean;
  t: (key: string) => string;
}

export function SettingsFields({ form, readOnly, t }: SettingsFieldsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
      <FormField control={form.control} name="timeLimit" render={({ field }) => (
        <FormItem>
          <FormLabel>{t("quizzes.timeLimit")}</FormLabel>
          <FormControl>
            <Input type="number" min={1} placeholder="-" disabled={readOnly} {...field} value={field.value ?? ""} onChange={(e) => { const val = e.target.value; field.onChange(val ? parseInt(val) : null); }} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="passingThreshold" render={({ field }) => (
        <FormItem>
          <FormLabel>{t("chapterQuizConfig.passingThreshold")}</FormLabel>
          <FormControl>
            <Input type="number" min={0} max={100} disabled={readOnly} {...field} onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="cooldownMinutes" render={({ field }) => (
        <FormItem>
          <FormLabel>{t("quizzes.cooldownMinutes")}</FormLabel>
          <FormControl>
            <Input type="number" min={1} placeholder="-" disabled={readOnly} {...field} value={field.value ?? ""} onChange={(e) => { const val = e.target.value; field.onChange(val ? parseInt(val) : null); }} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )} />
    </div>
  );
}

interface SwitchFieldsProps {
  form: UseFormReturn<ChapterQuizConfigFormData>;
  readOnly: boolean;
  t: (key: string) => string;
}

export function SwitchFields({ form, readOnly, t }: SwitchFieldsProps) {
  return (
    <div className="space-y-3">
      <FormField control={form.control} name="isRequired" render={({ field }) => (
        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 gap-3">
          <div className="space-y-0.5 flex-1 min-w-0">
            <FormLabel>{t("chapterQuizConfig.required")}</FormLabel>
            <FormDescription className="text-xs">{t("chapterQuizConfig.requiredDescription")}</FormDescription>
          </div>
          <FormControl>
            <Switch checked={field.value} onCheckedChange={field.onChange} disabled={readOnly} className="shrink-0" />
          </FormControl>
        </FormItem>
      )} />
      <FormField control={form.control} name="unlockNextChapter" render={({ field }) => (
        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 gap-3">
          <div className="space-y-0.5 flex-1 min-w-0">
            <FormLabel>{t("chapterQuizConfig.unlockNext")}</FormLabel>
            <FormDescription className="text-xs">{t("chapterQuizConfig.unlockNextDescription")}</FormDescription>
          </div>
          <FormControl>
            <Switch checked={field.value} onCheckedChange={field.onChange} disabled={readOnly} className="shrink-0" />
          </FormControl>
        </FormItem>
      )} />
      <FormField control={form.control} name="shuffleQuestions" render={({ field }) => (
        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 gap-3">
          <div className="space-y-0.5 flex-1 min-w-0">
            <FormLabel>{t("quizzes.shuffleQuestions")}</FormLabel>
          </div>
          <FormControl>
            <Switch checked={field.value} onCheckedChange={field.onChange} disabled={readOnly} className="shrink-0" />
          </FormControl>
        </FormItem>
      )} />
      <FormField control={form.control} name="shuffleOptions" render={({ field }) => (
        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 gap-3">
          <div className="space-y-0.5 flex-1 min-w-0">
            <FormLabel>{t("quizzes.shuffleOptions")}</FormLabel>
          </div>
          <FormControl>
            <Switch checked={field.value} onCheckedChange={field.onChange} disabled={readOnly} className="shrink-0" />
          </FormControl>
        </FormItem>
      )} />
    </div>
  );
}
