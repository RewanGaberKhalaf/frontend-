"use client";

import { useEffect, useState, useCallback } from "react";
import { UseFormReturn } from "react-hook-form";
import { useTranslations } from "next-intl";
import { toast } from "sonner";
import { quizApi, type QuestionBank, type ChapterQuizConfig } from "@/lib/api/quiz";
import type { ChapterQuizConfigFormData } from "./chapter-quiz-config-schema";
import { defaultFormValues, configToFormData } from "./chapter-quiz-config-schema";

interface UseChapterQuizConfigOptions {
  open: boolean;
  chapterId: string;
  subjectId: string;
  form: UseFormReturn<ChapterQuizConfigFormData>;
  onConfigChange?: () => void;
  onOpenChange: (open: boolean) => void;
}

interface UseChapterQuizConfigReturn {
  banks: QuestionBank[];
  loadingBanks: boolean;
  existingConfig: ChapterQuizConfig | null;
  loadingConfig: boolean;
  isSubmitting: boolean;
  showDeleteConfirm: boolean;
  setShowDeleteConfirm: (show: boolean) => void;
  isDeleting: boolean;
  selectedBank: QuestionBank | null;
  totalQuestions: number;
  handleSubmit: (data: ChapterQuizConfigFormData) => Promise<void>;
  handleDelete: () => Promise<void>;
}

export function useChapterQuizConfig({
  open,
  chapterId,
  subjectId,
  form,
  onConfigChange,
  onOpenChange,
}: UseChapterQuizConfigOptions): UseChapterQuizConfigReturn {
  const t = useTranslations();
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [loadingBanks, setLoadingBanks] = useState(false);
  const [existingConfig, setExistingConfig] = useState<ChapterQuizConfig | null>(null);
  const [loadingConfig, setLoadingConfig] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedBank, setSelectedBank] = useState<QuestionBank | null>(null);

  // Fetch question banks for this subject
  useEffect(() => {
    if (!open) return;

    const fetchBanks = async () => {
      setLoadingBanks(true);
      try {
        const response = await quizApi.getQuestionBanks({
          limit: 100,
          subjectId,
          isActive: true,
        });
        setBanks(response.items);
      } catch (error) {
        console.error("Failed to fetch question banks:", error);
      } finally {
        setLoadingBanks(false);
      }
    };

    fetchBanks();
  }, [open, subjectId]);

  // Fetch existing config for this chapter
  useEffect(() => {
    if (!open || !chapterId) return;

    const fetchConfig = async () => {
      setLoadingConfig(true);
      try {
        const config = await quizApi.getChapterQuizConfig(chapterId);
        setExistingConfig(config);
        if (config) {
          form.reset(configToFormData(config));
        } else {
          form.reset(defaultFormValues);
        }
      } catch (error) {
        console.error("Failed to fetch chapter quiz config:", error);
        setExistingConfig(null);
      } finally {
        setLoadingConfig(false);
      }
    };

    fetchConfig();
  }, [open, chapterId, form]);

  // Update selected bank when bankId changes
  const bankId = form.watch("bankId");
  useEffect(() => {
    if (bankId) {
      const bank = banks.find((b) => b.id === bankId);
      setSelectedBank(bank || null);
    } else {
      setSelectedBank(null);
    }
  }, [bankId, banks]);

  // Calculate total questions
  const easyQuestions = form.watch("easyQuestions") || 0;
  const mediumQuestions = form.watch("mediumQuestions") || 0;
  const hardQuestions = form.watch("hardQuestions") || 0;
  const totalQuestions = easyQuestions + mediumQuestions + hardQuestions;

  const handleSubmit = useCallback(
    async (data: ChapterQuizConfigFormData) => {
      setIsSubmitting(true);
      try {
        if (existingConfig) {
          // Update existing config
          await quizApi.updateChapterQuizConfig(existingConfig.id, {
            bankId: data.bankId,
            easyQuestions: data.easyQuestions,
            mediumQuestions: data.mediumQuestions,
            hardQuestions: data.hardQuestions,
            timeLimit: data.timeLimit || null,
            passingThreshold: data.passingThreshold,
            cooldownMinutes: data.cooldownMinutes || null,
            isRequired: data.isRequired,
            unlockNextChapter: data.unlockNextChapter,
            shuffleQuestions: data.shuffleQuestions,
            shuffleOptions: data.shuffleOptions,
          });
          toast.success(t("chapterQuizConfig.updateSuccess"));
        } else {
          // Create new config
          await quizApi.createChapterQuizConfig({
            chapterId,
            bankId: data.bankId,
            easyQuestions: data.easyQuestions,
            mediumQuestions: data.mediumQuestions,
            hardQuestions: data.hardQuestions,
            timeLimit: data.timeLimit || undefined,
            passingThreshold: data.passingThreshold,
            cooldownMinutes: data.cooldownMinutes || undefined,
            isRequired: data.isRequired,
            unlockNextChapter: data.unlockNextChapter,
            shuffleQuestions: data.shuffleQuestions,
            shuffleOptions: data.shuffleOptions,
          });
          toast.success(t("chapterQuizConfig.createSuccess"));
        }
        onConfigChange?.();
        onOpenChange(false);
      } catch {
        toast.error(
          existingConfig
            ? t("chapterQuizConfig.updateError")
            : t("chapterQuizConfig.createError")
        );
      } finally {
        setIsSubmitting(false);
      }
    },
    [existingConfig, chapterId, t, onConfigChange, onOpenChange]
  );

  const handleDelete = useCallback(async () => {
    if (!existingConfig) return;
    setIsDeleting(true);
    try {
      await quizApi.deleteChapterQuizConfig(existingConfig.id);
      toast.success(t("chapterQuizConfig.deleteSuccess"));
      setExistingConfig(null);
      form.reset();
      onConfigChange?.();
      setShowDeleteConfirm(false);
      onOpenChange(false);
    } catch {
      toast.error(t("chapterQuizConfig.deleteError"));
    } finally {
      setIsDeleting(false);
    }
  }, [existingConfig, t, form, onConfigChange, onOpenChange]);

  return {
    banks,
    loadingBanks,
    existingConfig,
    loadingConfig,
    isSubmitting,
    showDeleteConfirm,
    setShowDeleteConfirm,
    isDeleting,
    selectedBank,
    totalQuestions,
    handleSubmit,
    handleDelete,
  };
}
