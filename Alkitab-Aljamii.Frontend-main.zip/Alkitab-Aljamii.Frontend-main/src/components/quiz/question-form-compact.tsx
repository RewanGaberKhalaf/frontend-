"use client";

import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useTranslations } from "next-intl";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import type { CreateQuestionData, UpdateQuestionData, QuestionType } from "@/lib/api/quiz";
import {
  questionSchema,
  getDefaultFormValues,
  type QuestionFormData,
  type QuestionFormProps,
} from "./question-form-schema";
import { QuestionOptionsFieldCompact } from "./question-options-field-compact";
import { TopicSelect } from "./topic-select";
import { useState } from "react";

export function QuestionFormCompact({
  question,
  subjectId,
  onSubmit,
  onCancel,
  isLoading = false,
}: QuestionFormProps) {
  const t = useTranslations();
  const isEditing = !!question;
  const [language, setLanguage] = useState<"en" | "ar">("en");

  const form = useForm<QuestionFormData>({
    resolver: zodResolver(questionSchema),
    defaultValues: getDefaultFormValues(question, isEditing),
  });

  const fieldArray = useFieldArray({
    control: form.control,
    name: "options",
  });

  const questionType = form.watch("questionType");

  const handleQuestionTypeChange = (value: QuestionType) => {
    form.setValue("questionType", value);
    if (value === "true_false") {
      form.setValue("options", [
        { text: "True", textAr: "صح", isCorrect: true, order: 0 },
        { text: "False", textAr: "خطأ", isCorrect: false, order: 1 },
      ]);
    }
  };

  const handleSubmit = async (data: QuestionFormData) => {
    const hasCorrect = data.options.some((opt) => opt.isCorrect);
    if (!hasCorrect) {
      form.setError("options", {
        type: "manual",
        message: t("questions.atLeastOneCorrect"),
      });
      return;
    }

    await onSubmit(data as CreateQuestionData | UpdateQuestionData);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-5">
        {/* Basic Configuration */}
        <div className="space-y-4">
          <h3 className="text-sm font-medium">{t("questions.wizard.basicInfo")}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <FormField
              control={form.control}
              name="questionType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs">{t("questions.type")}</FormLabel>
                  <Select onValueChange={handleQuestionTypeChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder={t("questions.selectType")} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="multiple_choice">
                        {t("questions.multipleChoice")}
                      </SelectItem>
                      <SelectItem value="true_false">{t("questions.trueFalse")}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="difficulty"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs">{t("questions.difficulty")}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder={t("questions.selectDifficulty")} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="easy">{t("questions.easy")}</SelectItem>
                      <SelectItem value="medium">{t("questions.medium")}</SelectItem>
                      <SelectItem value="hard">{t("questions.hard")}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="points"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs">{t("questions.points")}</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      className="h-9"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Topic */}
          {subjectId ? (
            <FormField
              control={form.control}
              name="topicId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs">{t("questions.topic")}</FormLabel>
                  <FormControl>
                    <TopicSelect
                      subjectId={subjectId}
                      value={field.value}
                      onChange={field.onChange}
                      placeholder={t("questions.selectTopic")}
                    />
                  </FormControl>
                  <FormDescription className="text-xs">
                    {t("questions.topicDescription")}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="topic"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">{t("questions.topic")}</FormLabel>
                    <FormControl>
                      <Input
                        placeholder={t("questions.topicPlaceholder")}
                        className="h-9"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="topicAr"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">{t("questions.topicAr")}</FormLabel>
                    <FormControl>
                      <Input
                        placeholder={t("questions.topicArPlaceholder")}
                        dir="rtl"
                        className="h-9"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
        </div>

        <Separator />

        {/* Question Text */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium">{t("questions.wizard.question")}</h3>
          <Tabs value={language} onValueChange={(v) => setLanguage(v as "en" | "ar")}>
            <TabsList className="grid w-full max-w-[300px] grid-cols-2 h-9">
              <TabsTrigger value="en">{t("common.english")}</TabsTrigger>
              <TabsTrigger value="ar">{t("common.arabic")}</TabsTrigger>
            </TabsList>

            <TabsContent value="en" className="space-y-3 mt-3">
              <FormField
                control={form.control}
                name="questionText"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">{t("questions.questionText")}</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={t("questions.questionTextPlaceholder")}
                        className="resize-none"
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>

            <TabsContent value="ar" className="space-y-3 mt-3">
              <FormField
                control={form.control}
                name="questionTextAr"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">{t("questions.questionTextAr")}</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={t("questions.questionTextArPlaceholder")}
                        className="resize-none"
                        dir="rtl"
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription className="text-xs">{t("common.optional")}</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>
          </Tabs>
        </div>

        <Separator />

        {/* Options */}
        <QuestionOptionsFieldCompact form={form} fieldArray={fieldArray} questionType={questionType} />

        <Separator />

        {/* Explanation (Optional) */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium">{t("questions.explanation")} ({t("common.optional")})</h3>
          <Tabs value={language} onValueChange={(v) => setLanguage(v as "en" | "ar")}>
            <TabsList className="grid w-full max-w-[300px] grid-cols-2 h-9">
              <TabsTrigger value="en">{t("common.english")}</TabsTrigger>
              <TabsTrigger value="ar">{t("common.arabic")}</TabsTrigger>
            </TabsList>

            <TabsContent value="en" className="space-y-3 mt-3">
              <FormField
                control={form.control}
                name="explanation"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea
                        placeholder={t("questions.explanationPlaceholder")}
                        className="resize-none"
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription className="text-xs">
                      {t("questions.explanationDescription")}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>

            <TabsContent value="ar" className="space-y-3 mt-3">
              <FormField
                control={form.control}
                name="explanationAr"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea
                        placeholder={t("questions.explanationArPlaceholder")}
                        className="resize-none"
                        dir="rtl"
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>
          </Tabs>
        </div>

        {/* Active Toggle (edit mode only) */}
        {isEditing && (
          <>
            <Separator />
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <FormLabel className="text-sm">{t("questions.active")}</FormLabel>
                    <FormDescription className="text-xs">
                      {t("questions.activeDescription")}
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                </FormItem>
              )}
            />
          </>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t("common.cancel")}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
            {isEditing ? t("common.save") : t("common.create")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
