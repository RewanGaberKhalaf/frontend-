'use client';

import { useTranslations, useLocale } from 'next-intl';
import { CheckCircle2, XCircle, Circle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { MathRenderer } from '@/components/shared/math-renderer';
import type { AttemptQuestion, QuestionType } from '@/lib/api/quiz';

interface QuestionDisplayProps {
  question: AttemptQuestion;
  questionNumber: number;
  selectedOptionId: string | null;
  onSelectOption: (optionId: string) => void;
  disabled?: boolean;
  showResult?: boolean;
  correctOptionId?: string | null;
  explanation?: string | null;
  explanationAr?: string | null;
}

export function QuestionDisplay({
  question,
  questionNumber,
  selectedOptionId,
  onSelectOption,
  disabled = false,
  showResult = false,
  correctOptionId,
  explanation,
  explanationAr,
}: QuestionDisplayProps) {
  const t = useTranslations();
  const locale = useLocale();
  const isArabic = locale === 'ar';

  const questionText = isArabic && question.questionTextAr
    ? question.questionTextAr
    : question.questionText;

  const getOptionState = (optionId: string) => {
    if (!showResult) {
      return selectedOptionId === optionId ? 'selected' : 'default';
    }

    const isSelected = selectedOptionId === optionId;
    const isCorrect = optionId === correctOptionId;

    if (isCorrect) return 'correct';
    if (isSelected && !isCorrect) return 'incorrect';
    return 'default';
  };

  return (
    <div className="space-y-6">
      {/* Question Header */}
      <div className="space-y-3">
        <div className="flex items-start gap-4">
          <span className="shrink-0 flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 text-primary font-bold text-base border border-primary/20">
            {questionNumber}
          </span>
          <div className="flex-1 space-y-2">
            <p className="text-lg md:text-xl font-semibold leading-relaxed text-foreground" dir={isArabic ? 'rtl' : 'ltr'}>
              <MathRenderer>{questionText}</MathRenderer>
            </p>
            {question.questionType === 'true_false' && (
              <Badge variant="muted" className="text-xs font-medium">
                {t('questions.trueFalse')}
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Options */}
      <div className={cn("space-y-3", isArabic ? "pe-14" : "ps-14")}>
        {question.options.map((option) => {
          const optionKey = 'key' in option ? option.key : (option as { id: string }).id;
          const optionText = isArabic && option.textAr
            ? option.textAr
            : option.text;
          const state = getOptionState(optionKey);

          return (
            <button
              key={optionKey}
              type="button"
              disabled={disabled}
              onClick={() => onSelectOption(optionKey)}
              className={cn(
                'w-full flex items-center gap-4 p-4 md:p-5 rounded-xl border-2 text-start transition-all',
                !disabled && 'hover:border-primary/50 hover:bg-primary/5 hover:shadow-sm active:scale-[0.99]',
                state === 'default' && 'border-border bg-card',
                state === 'selected' && 'border-primary bg-primary/10 shadow-sm',
                state === 'correct' && 'border-green-500 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/20 shadow-md ring-2 ring-green-500/20',
                state === 'incorrect' && 'border-red-500 bg-gradient-to-r from-red-50 to-rose-50 dark:from-red-950/30 dark:to-rose-950/20 shadow-md ring-2 ring-red-500/20',
                disabled && 'cursor-default'
              )}
              dir={isArabic ? 'rtl' : 'ltr'}
            >
              <div className="shrink-0">
                {state === 'correct' ? (
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-500 dark:bg-green-600 shadow-sm">
                    <CheckCircle2 className="h-5 w-5 text-white" strokeWidth={2.5} />
                  </div>
                ) : state === 'incorrect' ? (
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-red-500 dark:bg-red-600 shadow-sm">
                    <XCircle className="h-5 w-5 text-white" strokeWidth={2.5} />
                  </div>
                ) : state === 'selected' ? (
                  <div className="h-6 w-6 rounded-full border-2 border-primary bg-primary flex items-center justify-center shadow-sm">
                    <div className="h-2.5 w-2.5 rounded-full bg-white" />
                  </div>
                ) : (
                  <div className="h-6 w-6 rounded-full border-2 border-muted-foreground/30 bg-background" />
                )}
              </div>
              <span className={cn(
                'flex-1 text-base leading-relaxed min-w-0',
                state === 'correct' && 'text-green-900 dark:text-green-200 font-semibold',
                state === 'incorrect' && 'text-red-900 dark:text-red-200 font-medium',
                state === 'default' && 'text-foreground',
                state === 'selected' && 'text-foreground font-medium'
              )}>
                <MathRenderer>{optionText}</MathRenderer>
              </span>
            </button>
          );
        })}
      </div>

      {/* Explanation (shown in result mode) */}
      {showResult && (explanation || explanationAr) && (
        <div className={cn(isArabic ? "pe-14" : "ps-14")}>
          <div className="p-5 md:p-6 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/20 border-2 border-blue-200 dark:border-blue-800 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="shrink-0 mt-0.5">
                <div className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-500 dark:bg-blue-600">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <div className="flex-1 min-w-0 space-y-2">
                <p className="text-sm font-bold text-blue-900 dark:text-blue-300 uppercase tracking-wide">
                  {t('questions.explanation')}
                </p>
                <p className="text-base leading-relaxed text-blue-800 dark:text-blue-200 break-words" dir={isArabic ? 'rtl' : 'ltr'}>
                  <MathRenderer>{(isArabic && explanationAr ? explanationAr : explanation) || ''}</MathRenderer>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
