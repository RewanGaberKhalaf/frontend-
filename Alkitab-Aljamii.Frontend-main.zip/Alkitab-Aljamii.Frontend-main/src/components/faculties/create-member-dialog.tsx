'use client';

import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, Plus, UserCheck, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { usersApi, type EmailCheckResult } from '@/lib/api/users';
import type { CreateMemberDto } from '@/types';

// Base schema - password validation is done manually when needed
const createMemberSchema = z.object({
  firstName: z.string(),
  lastName: z.string(),
  email: z.string().email('Invalid email'),
  password: z.string(),
});

type CreateMemberFormData = z.infer<typeof createMemberSchema>;

interface CreateMemberDialogProps {
  title: string;
  role: 'professor' | 'student';
  onCreate: (data: CreateMemberDto) => Promise<void>;
}


export function CreateMemberDialog({
  title,
  role,
  onCreate,
}: CreateMemberDialogProps) {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);
  const [existingUser, setExistingUser] = useState<EmailCheckResult['user'] | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);

  const form = useForm<CreateMemberFormData>({
    resolver: zodResolver(createMemberSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
    },
  });

  const checkEmail = useCallback(async (email: string) => {
    if (!email || !email.includes('@')) return;

    setIsCheckingEmail(true);
    setEmailError(null);
    setExistingUser(null);

    try {
      const result = await usersApi.checkEmail(email);
      if (result.exists && result.user) {
        // Super admins cannot be added as faculty members
        if (result.user.isSuperAdmin) {
          setEmailError(
            'This email belongs to a Super Admin. Super admins cannot be added as faculty members.'
          );
        } else {
          // User exists and can potentially be added
          // Faculty role compatibility will be checked by the backend when adding
          setExistingUser(result.user);
          // Pre-fill name fields
          form.setValue('firstName', result.user.firstName);
          form.setValue('lastName', result.user.lastName);
        }
      }
    } catch {
      // Silently fail - user doesn't exist or network error
    } finally {
      setIsCheckingEmail(false);
    }
  }, [form]);

  const handleSubmit = async (data: CreateMemberFormData) => {
    if (emailError) return;

    // Manual validation for new users
    if (!existingUser) {
      if (!data.firstName.trim()) {
        form.setError('firstName', { message: 'First name is required' });
        return;
      }
      if (!data.lastName.trim()) {
        form.setError('lastName', { message: 'Last name is required' });
        return;
      }
      if (!data.password || data.password.length < 8) {
        form.setError('password', { message: 'Password must be at least 8 characters' });
        return;
      }
    }

    setIsLoading(true);
    try {
      // If linking existing user, we still send the data but password will be ignored by backend
      await onCreate({
        email: data.email,
        firstName: existingUser ? existingUser.firstName : data.firstName,
        lastName: existingUser ? existingUser.lastName : data.lastName,
        password: data.password || 'ignored-for-existing-user',
      });
      resetForm();
      setOpen(false);
    } catch {
      // Error already handled by parent
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    form.reset();
    setExistingUser(null);
    setEmailError(null);
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      resetForm();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          {title}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">{title}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        type="email"
                        placeholder="Enter Valid Email..."
                        {...field}
                        onBlur={(e) => {
                          field.onBlur();
                          checkEmail(e.target.value);
                        }}
                        onChange={(e) => {
                          field.onChange(e);
                          // Reset existing user state when email changes
                          if (existingUser || emailError) {
                            setExistingUser(null);
                            setEmailError(null);
                          }
                        }}
                      />
                      {isCheckingEmail && (
                        <Loader2 className="absolute right-3 top-2.5 h-4 w-4 animate-spin text-muted-foreground" />
                      )}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {emailError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{emailError}</AlertDescription>
              </Alert>
            )}

            {existingUser && (
              <Alert>
                <UserCheck className="h-4 w-4" />
                <AlertDescription>
                  <strong>{existingUser.firstName} {existingUser.lastName}</strong> already exists.
                  They will be added to your faculty as a {role}.
                </AlertDescription>
              </Alert>
            )}

            {!existingUser && !emailError && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name</FormLabel>
                        <FormControl>
                          <Input  {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => handleOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading || isCheckingEmail || !!emailError}>
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {existingUser ? 'Add to Faculty' : 'Create'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
