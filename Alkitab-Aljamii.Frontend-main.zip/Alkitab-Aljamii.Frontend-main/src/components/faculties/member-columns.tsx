'use client';

import { Loader2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { FacultyMember } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';

interface MemberColumnsOptions {
  nameHeader: string;
  emailHeader: string;
  dateHeader: string;
  onRemove: (id: string) => void;
  removingId: string | null;
}

export function createMemberColumns({
  nameHeader,
  emailHeader,
  dateHeader,
  onRemove,
  removingId,
}: MemberColumnsOptions): ColumnDef<FacultyMember>[] {
  return [
    {
      id: 'name',
      header: nameHeader,
      cell: ({ row }) => `${row.original.firstName} ${row.original.lastName}`,
    },
    { accessorKey: 'email', header: emailHeader },
    {
      accessorKey: 'assignedAt',
      header: dateHeader,
      cell: ({ row }) => new Date(row.original.assignedAt).toLocaleDateString(),
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onRemove(row.original.id)}
          disabled={removingId === row.original.id}
        >
          {removingId === row.original.id ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Trash2 className="h-4 w-4 text-destructive" />
          )}
        </Button>
      ),
    },
  ];
}
