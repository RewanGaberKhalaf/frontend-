'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import type { Faculty, FacultyMember } from '@/types';

interface FacultyInfoCardProps {
  faculty: Faculty;
  admins: FacultyMember[];
  professorsCount: number;
  studentsCount: number;
  labels: {
    title: string;
    professors: string;
    students: string;
    createdAt: string;
    updatedAt: string;
    notAssigned: string;
  };
}

export function FacultyInfoCard({
  faculty,
  admins,
  professorsCount,
  studentsCount,
  labels,
}: FacultyInfoCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{labels.title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            Faculty Admin
          </p>
          {admins.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">{labels.notAssigned}</p>
          ) : (
            <div className="space-y-1">
              {admins.map((admin) => (
                <p key={admin.id} className="text-sm">
                  {admin.firstName} {admin.lastName}
                </p>
              ))}
            </div>
          )}
        </div>
        <Separator />
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            {labels.professors}
          </p>
          <p className="text-sm">{professorsCount}</p>
        </div>
        <Separator />
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            {labels.students}
          </p>
          <p className="text-sm">{studentsCount}</p>
        </div>
        <Separator />
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            {labels.createdAt}
          </p>
          <p className="text-sm">
            {new Date(faculty.createdAt).toLocaleDateString()}
          </p>
        </div>
        <Separator />
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            {labels.updatedAt}
          </p>
          <p className="text-sm">
            {new Date(faculty.updatedAt).toLocaleDateString()}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
