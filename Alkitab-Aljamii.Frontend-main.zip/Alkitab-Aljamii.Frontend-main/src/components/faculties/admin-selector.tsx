'use client';

import { useEffect, useState } from 'react';
import { Check, ChevronsUpDown, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { usersApi } from '@/lib/api/users';
import type { User } from '@/types';

interface AdminSelectorProps {
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
}

export function AdminSelector({ value, onChange, placeholder = 'Select admin...' }: AdminSelectorProps) {
  const [open, setOpen] = useState(false);
  const [admins, setAdmins] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loadAdmins = async () => {
      setIsLoading(true);
      try {
        const result = await usersApi.getAll({ role: 'faculty_admin', limit: 100 });
        setAdmins(result.items);
      } catch {
        setAdmins([]);
      } finally {
        setIsLoading(false);
      }
    };
    loadAdmins();
  }, []);

  const selectedAdmin = admins.find((a) => a.id === value);

  return (
    <div className="flex gap-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="flex-1 justify-between"
            disabled={isLoading}
          >
            {selectedAdmin
              ? `${selectedAdmin.firstName} ${selectedAdmin.lastName}`
              : placeholder}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[300px] p-0">
          <Command>
            <CommandInput placeholder="Search admins..." />
            <CommandList>
              <CommandEmpty>No admin found.</CommandEmpty>
              <CommandGroup>
                {admins.map((admin) => (
                  <CommandItem
                    key={admin.id}
                    value={`${admin.firstName} ${admin.lastName} ${admin.email}`}
                    onSelect={() => {
                      onChange(admin.id === value ? null : admin.id);
                      setOpen(false);
                    }}
                  >
                    <Check
                      className={cn('mr-2 h-4 w-4', value === admin.id ? 'opacity-100' : 'opacity-0')}
                    />
                    <div className="flex flex-col">
                      <span>{admin.firstName} {admin.lastName}</span>
                      <span className="text-xs text-muted-foreground">{admin.email}</span>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {value && (
        <Button variant="ghost" size="icon" onClick={() => onChange(null)}>
          <X className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}
