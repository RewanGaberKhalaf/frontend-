'use client';

import { useState, useMemo } from 'react';
import { Loader2, Plus, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { usersApi, type UserFilterParams } from '@/lib/api/users';
import type { User, FacultyRole } from '@/types';

interface BaseMember {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

interface AddMemberDialogProps {
  title: string;
  /** Faculty role to filter by (professor or student) */
  facultyRole?: FacultyRole;
  onAdd: (userId: string) => Promise<void>;
  existingMemberIds: string[];
  /** If provided, will filter from this list instead of searching API */
  availableMembers?: BaseMember[];
}

export function AddMemberDialog({
  title,
  facultyRole,
  onAdd,
  existingMemberIds,
  availableMembers,
}: AddMemberDialogProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [addingId, setAddingId] = useState<string | null>(null);

  // For availableMembers mode - filter locally with multi-term search support
  const filteredAvailable = useMemo(() => {
    if (!availableMembers) return [];
    const available = availableMembers.filter((m) => !existingMemberIds.includes(m.id));
    const trimmed = search.trim();
    if (!trimmed) return available;

    const terms = trimmed.toLowerCase().split(/\s+/).filter(Boolean);

    return available.filter((m) => {
      const firstName = m.firstName.toLowerCase();
      const lastName = m.lastName.toLowerCase();
      const email = m.email.toLowerCase();
      const fullName = `${firstName} ${lastName}`;

      if (terms.length === 1) {
        const term = terms[0]!;
        return (
          firstName.includes(term) ||
          lastName.includes(term) ||
          email.includes(term)
        );
      }

      // Multi-term: check if all terms match somewhere OR first+rest matches firstName+lastName
      const firstTerm = terms[0]!;
      const restTerms = terms.slice(1).join(' ');

      // Check firstName + lastName pattern
      if (firstName.includes(firstTerm) && lastName.includes(restTerms)) {
        return true;
      }
      // Check lastName + firstName pattern (reversed)
      if (lastName.includes(firstTerm) && firstName.includes(restTerms)) {
        return true;
      }
      // Check if full name contains the search
      if (fullName.includes(trimmed.toLowerCase())) {
        return true;
      }
      // Check if all terms exist somewhere in the member data
      return terms.every(
        (term) => firstName.includes(term) || lastName.includes(term) || email.includes(term)
      );
    });
  }, [availableMembers, existingMemberIds, search]);

  const handleSearch = async () => {
    if (availableMembers) return; // Use local filtering
    if (!search.trim()) return;
    setIsLoading(true);
    try {
      const params: UserFilterParams = {
        search,
        limit: 20,
        ...(facultyRole && { role: facultyRole }),
      };
      const result = await usersApi.getAll(params);
      setUsers(result.items.filter((u) => !existingMemberIds.includes(u.id)));
    } catch {
      setUsers([]);
    } finally {
      setIsLoading(false);
    }
  };

  const displayUsers = availableMembers ? filteredAvailable : users;

  const handleAdd = async (userId: string) => {
    setAddingId(userId);
    try {
      await onAdd(userId);
      setUsers((prev) => prev.filter((u) => u.id !== userId));
    } finally {
      setAddingId(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          {title}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        {!availableMembers && (
          <div className="flex gap-2">
            <Input
              placeholder="Search by name or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch} disabled={isLoading}>
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </div>
        )}
        {availableMembers && (
          <Input
            placeholder="Filter members..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        )}
        <ScrollArea className="h-64">
          {displayUsers.length === 0 ? (
            <p className="py-4 text-center text-sm text-muted-foreground">
              {availableMembers
                ? 'No available members to add'
                : (search ? 'No users found' : 'Search for users to add')}
            </p>
          ) : (
            <div className="space-y-2">
              {displayUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between rounded-md border p-2"
                >
                  <div>
                    <p className="font-medium">{user.firstName} {user.lastName}</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleAdd(user.id)}
                    disabled={addingId === user.id}
                  >
                    {addingId === user.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      'Add'
                    )}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
