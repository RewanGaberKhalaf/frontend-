'use client';

import { useState } from 'react';
import { AlertTriangle, Trash2, Loader2 } from 'lucide-react';
import { useTranslations, useLocale } from 'next-intl';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { facultiesApi, type FacultyAdminConflict } from '@/lib/api';

interface AdminConflictAlertProps {
  conflicts: FacultyAdminConflict[];
  onConflictResolved?: () => void;
  /** Show only conflicts for a specific faculty */
  facultyId?: string;
  /** Compact mode for showing in faculty detail page */
  compact?: boolean;
}

export function AdminConflictAlert({
  conflicts,
  onConflictResolved,
  facultyId,
  compact = false,
}: AdminConflictAlertProps) {
  const t = useTranslations();
  const locale = useLocale();
  const [removingAdmin, setRemovingAdmin] = useState<string | null>(null);

  // Filter conflicts if facultyId is provided
  const filteredConflicts = facultyId
    ? conflicts.filter((c) => c.faculty.id === facultyId)
    : conflicts;

  if (filteredConflicts.length === 0) return null;

  // Helper to get localized faculty name
  const getFacultyName = (faculty: FacultyAdminConflict['faculty']) => {
    return locale === 'ar' && faculty.nameAr ? faculty.nameAr : faculty.name;
  };

  const handleRemoveAdmin = async (conflictFacultyId: string, userId: string) => {
    setRemovingAdmin(userId);
    try {
      await facultiesApi.removeFacultyAdmin(conflictFacultyId, userId);
      toast.success(t('dashboard.superAdmin.adminRemoved'));
      onConflictResolved?.();
    } catch {
      toast.error(t('common.error'));
    } finally {
      setRemovingAdmin(null);
    }
  };

  return (
    <Alert className="border-red-500 bg-red-50 text-red-900 dark:border-red-500/50 dark:bg-red-950/30 dark:text-red-100">
      <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
      <AlertTitle className="text-base font-semibold text-red-900 dark:text-red-100">
        {t('dashboard.superAdmin.adminConflicts')}
      </AlertTitle>
      <AlertDescription className="mt-2 text-red-800 dark:text-red-200">
        {!compact && (
          <p className="mb-3">
            {t('dashboard.superAdmin.adminConflictsFound', { count: filteredConflicts.length })}
          </p>
        )}
        <div className="space-y-3">
          {filteredConflicts.map((conflict) => (
            <div
              key={conflict.faculty.id}
              className="rounded-lg border border-red-300 bg-white p-3 dark:border-red-700 dark:bg-red-950/40"
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  {!compact && (
                    <>
                      <span className="font-medium text-red-900 dark:text-red-100">
                        {getFacultyName(conflict.faculty)}
                      </span>
                      <span className="ms-2 text-sm text-red-700 dark:text-red-300">
                        ({conflict.faculty.code})
                      </span>
                    </>
                  )}
                  <Badge
                    variant="outline"
                    className={`${compact ? '' : 'ms-2'} border-red-600 bg-red-200 text-red-900 dark:border-red-500 dark:bg-red-800 dark:text-red-100`}
                  >
                    {conflict.adminCount} {t('dashboard.superAdmin.facultyAdminsCount')}
                  </Badge>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="destructive"
                      size="sm"
                    >
                      {t('dashboard.superAdmin.resolveConflicts')}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>
                        {t('dashboard.superAdmin.conflictResolution')}: {getFacultyName(conflict.faculty)}
                      </DialogTitle>
                      <DialogDescription>
                        {t('dashboard.superAdmin.conflictWarning')}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-3 py-4">
                      {conflict.admins.map((admin) => (
                        <div
                          key={admin.id}
                          className="flex items-center justify-between rounded-lg border p-3"
                        >
                          <div>
                            <p className="font-medium">
                              {admin.firstName} {admin.lastName}
                            </p>
                            <p className="text-sm text-muted-foreground">{admin.email}</p>
                            <p className="text-xs text-muted-foreground">
                              {t('common.createdAt')}:{' '}
                              {new Date(admin.assignedAt).toLocaleDateString()}
                            </p>
                          </div>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleRemoveAdmin(conflict.faculty.id, admin.id)}
                            disabled={removingAdmin !== null}
                          >
                            {removingAdmin === admin.id ? (
                              <Loader2 className="me-2 h-4 w-4 animate-spin" />
                            ) : (
                              <Trash2 className="me-2 h-4 w-4" />
                            )}
                            {t('dashboard.superAdmin.removeAdmin')}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          ))}
        </div>
      </AlertDescription>
    </Alert>
  );
}
