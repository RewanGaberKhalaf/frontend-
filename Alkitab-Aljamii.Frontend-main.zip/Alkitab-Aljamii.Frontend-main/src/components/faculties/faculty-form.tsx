'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import type { Faculty } from '@/types';

const createFacultySchema = z.object({
  name: z.string().min(1, 'Name is required').max(100, 'Name is too long'),
  nameAr: z.string().max(100, 'Name is too long').optional(),
  code: z.string().min(1, 'Code is required').max(20, 'Code is too long'),
  description: z.string().max(500, 'Description is too long').optional(),
  descriptionAr: z.string().max(500, 'Description is too long').optional(),
});

const updateFacultySchema = createFacultySchema.extend({
  isActive: z.boolean(),
});

export type CreateFacultyFormData = z.infer<typeof createFacultySchema>;
export type UpdateFacultyFormData = z.infer<typeof updateFacultySchema>;

interface BaseFacultyFormProps {
  onCancel: () => void;
  isLoading?: boolean;
}

interface CreateFacultyFormProps extends BaseFacultyFormProps {
  faculty?: undefined;
  onSubmit: (data: CreateFacultyFormData) => Promise<void>;
}

interface EditFacultyFormProps extends BaseFacultyFormProps {
  faculty: Faculty;
  onSubmit: (data: UpdateFacultyFormData) => Promise<void>;
}

type FacultyFormProps = CreateFacultyFormProps | EditFacultyFormProps;

export function FacultyForm(props: FacultyFormProps) {
  const { onCancel, isLoading } = props;
  const t = useTranslations();
  const isEditing = !!props.faculty;

  const form = useForm<CreateFacultyFormData | UpdateFacultyFormData>({
    resolver: zodResolver(isEditing ? updateFacultySchema : createFacultySchema),
    defaultValues: isEditing
      ? {
          name: props.faculty.name,
          nameAr: props.faculty.nameAr ?? '',
          code: props.faculty.code,
          description: props.faculty.description ?? '',
          descriptionAr: props.faculty.descriptionAr ?? '',
          isActive: props.faculty.isActive,
        }
      : {
          name: '',
          nameAr: '',
          code: '',
          description: '',
          descriptionAr: '',
        },
  });

  const handleSubmit = async (data: CreateFacultyFormData | UpdateFacultyFormData) => {
    if (isEditing) {
      await (props as EditFacultyFormProps).onSubmit(data as UpdateFacultyFormData);
    } else {
      await (props as CreateFacultyFormProps).onSubmit(data as CreateFacultyFormData);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('faculties.name')}</FormLabel>
              <FormControl>
                <Input placeholder="Faculty Name..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="nameAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('faculties.nameAr')}</FormLabel>
              <FormControl>
                <Input dir="rtl" {...field} />
              </FormControl>
              <FormDescription>{t('common.optional')}</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="code"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('faculties.code')}</FormLabel>
              <FormControl>
                <Input placeholder="Code For Faculty..." {...field} />
              </FormControl>
              <FormDescription>
                A unique short code for this faculty
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('faculties.description')}</FormLabel>
              <FormControl>
                <Textarea placeholder="Enter faculty description..." className="resize-none" rows={3} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="descriptionAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('faculties.descriptionAr')}</FormLabel>
              <FormControl>
                <Textarea placeholder="أدخل وصف الكلية..." className="resize-none" dir="rtl" rows={3} {...field} />
              </FormControl>
              <FormDescription>{t('common.optional')}</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        {isEditing && (
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{t('faculties.active')}</FormLabel>
                  <FormDescription>
                    Inactive faculties are hidden from users
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value as boolean}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
            {isEditing ? t('common.save') : t('faculties.create')}
          </Button>
        </div>
      </form>
    </Form>
  );
}
