"use client";

import { useRouter } from "next/navigation";
import { MoreHorizontal, Eye, Pencil, Trash2, RotateCcw } from "lucide-react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "@/components/shared/data-table";
import type { ColumnDef } from "@tanstack/react-table";
import type { Faculty } from "@/types";

interface UseFacultyColumnsProps {
  onDelete: (faculty: Faculty) => void;
  onRestore: (faculty: Faculty) => void;
}

export function useFacultyColumns({
  onDelete,
  onRestore,
}: UseFacultyColumnsProps): ColumnDef<Faculty>[] {
  const t = useTranslations("faculties");
  const tCommon = useTranslations("common");
  const tTooltips = useTranslations("tooltips");
  const router = useRouter();

  return [
    {
      accessorKey: "name",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("name")} />
      ),
    },
    {
      accessorKey: "code",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("code")} />
      ),
    },
    {
      accessorKey: "professorsCount",
      header: t("professors"),
      cell: ({ row }) =>
        row.original.professorsCount ?? row.original.professorCount ?? 0,
    },
    {
      accessorKey: "studentsCount",
      header: t("students"),
      cell: ({ row }) =>
        row.original.studentsCount ?? row.original.studentCount ?? 0,
    },
    {
      accessorKey: "isActive",
      header: t("status"),
      cell: ({ row }) => (
        <Badge variant={row.original.isActive ? "default" : "secondary"}>
          {row.original.isActive ? t("active") : t("inactive")}
        </Badge>
      ),
    },
    {
      accessorKey: "createdAt",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title={t("createdAt")} />
      ),
      cell: ({ row }) => new Date(row.original.createdAt).toLocaleDateString(),
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const faculty = row.original;
        return (
          <Tooltip>
            <DropdownMenu>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">{tCommon("actions")}</span>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() =>
                  router.push(`/super-admin/faculties/${faculty.id}`)
                }
              >
                <Eye className="me-2 h-4 w-4" />
                {tCommon("view")}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() =>
                  router.push(`/super-admin/faculties/${faculty.id}`)
                }
              >
                <Pencil className="me-2 h-4 w-4" />
                {tCommon("edit")}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {faculty.isActive ? (
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => onDelete(faculty)}
                >
                  <Trash2 className="me-2 h-4 w-4" />
                  {tCommon("delete")}
                </DropdownMenuItem>
              ) : (
                <DropdownMenuItem onClick={() => onRestore(faculty)}>
                  <RotateCcw className="me-2 h-4 w-4" />
                  {t("restore")}
                </DropdownMenuItem>
              )}
              </DropdownMenuContent>
            </DropdownMenu>
            <TooltipContent>{tTooltips("actions.moreActions")}</TooltipContent>
          </Tooltip>
        );
      },
    },
  ];
}
