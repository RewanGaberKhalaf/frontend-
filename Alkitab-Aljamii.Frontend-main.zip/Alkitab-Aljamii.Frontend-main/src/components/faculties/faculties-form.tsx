'use client'
import { useTranslations } from "next-intl";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { useForm } from "react-hook-form";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { FaArrowLeft } from "react-icons/fa";
import { useRouter } from "next/navigation";

import { Faculty } from "@/types";
import { Loader2 } from "lucide-react";
import z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const createFacultySchema = z.object({
  name: z.string().email('Invalid email address'),
  code: z.string().min(4, 'code is required'),
  description: z.string().min(10, 'description is required'),
  
});
const updateFacultySchema = z.object({
  name: z.string().email('Invalid email address'),
  code: z.string().min(4, 'code is required'),
  description: z.string().min(10, 'description is required'),
});
export type CreateFacultyFormData = z.infer<typeof createFacultySchema>;
export type UpdateFacultyFormData = z.infer<typeof updateFacultySchema>;
interface BaseUserFormProps {
    onCancel: () => void;
    isLoading?: boolean;
}
interface CreateFacultyFormProps extends BaseUserFormProps {
  faculty?: undefined;
  onSubmit: (data: CreateFacultyFormData) => Promise<void>;
}
interface UpdateFacultyFormDataProps extends BaseUserFormProps{
    faculty: Faculty,
    onSubmit: (data: UpdateFacultyFormData) => Promise<void>;
}

type FacultyFormProps=CreateFacultyFormProps|UpdateFacultyFormDataProps


export function FacultyForm(props:FacultyFormProps) {
    const t = useTranslations();
    const router = useRouter();
  const { onCancel, isLoading } = props;
  const isUpdating = !!props.faculty;
  const form = useForm<CreateFacultyFormData | UpdateFacultyFormData>({
      resolver:zodResolver(isUpdating?updateFacultySchema:createFacultySchema),
      defaultValues: isUpdating ? {
        name: props.faculty.name,
        code:props.faculty.code,
        description:props.faculty.description
      } : {
          name: "",
          code: "",
          description:""
        }
    })
  const handleSubmit = async (data: CreateFacultyFormData | UpdateFacultyFormData) => {
    if (isUpdating) {
         await (props as UpdateFacultyFormDataProps).onSubmit(data as UpdateFacultyFormData)
    }
    else {
      await (props as CreateFacultyFormProps).onSubmit(data as CreateFacultyFormData)
    }
      
    };
    
    return (
        <Form  {...form}>
            <div className="my-4">
                <Button variant={"link"} onClick={() => {
                    router.back()
                }}>
                        <FaArrowLeft/>
                </Button>
            </div>
            <form 
                onSubmit={form.handleSubmit(handleSubmit)}
            >
                  <div className="grid gap-4 my-3 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>faculty name</FormLabel>
                <FormControl>
                  <Input placeholder="faculty Name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="code"
            render={({ field }) => (
              <FormItem>
                <FormLabel>faculty code</FormLabel>
                <FormControl>
                  <Input placeholder="code" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
            name="description"
            
          render={({ field }) => (
            <FormItem>
              <FormLabel>description</FormLabel>
              <FormControl>
                <Input type="text" placeholder="desc..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

       
       

     

        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create
          </Button>
        </div>
                
            </form>
       </Form>
  );
}