'use client';

import { Loader2 } from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { DataTable } from '@/components/shared';
import { CreateMemberDialog } from './create-member-dialog';
import type { FacultyMember, CreateMemberDto } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';

interface MembersTabContentProps {
  title: string;
  description: string;
  addButtonTitle: string;
  role: 'professor' | 'student';
  members: FacultyMember[];
  columns: ColumnDef<FacultyMember>[];
  isLoading: boolean;
  emptyMessage: string;
  searchPlaceholder: string;
  onCreate: (data: CreateMemberDto) => Promise<void>;
}

export function MembersTabContent({
  title,
  description,
  addButtonTitle,
  role,
  members,
  columns,
  isLoading,
  emptyMessage,
  searchPlaceholder,
  onCreate,
}: MembersTabContentProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <CreateMemberDialog
          title={addButtonTitle}
          role={role}
          onCreate={onCreate}
        />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex h-32 items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : members.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            {emptyMessage}
          </p>
        ) : (
          <DataTable
            columns={columns}
            data={members}
            searchKey="email"
            searchPlaceholder={searchPlaceholder}
          />
        )}
      </CardContent>
    </Card>
  );
}
