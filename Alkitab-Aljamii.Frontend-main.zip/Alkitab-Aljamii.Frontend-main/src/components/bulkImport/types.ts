export type ImportType = 
  | 'students_only'
  | 'students_with_subjects'
  | 'professors_only'
  | 'professors_with_subjects'
  | 'student_enrollments'
  | 'professor_assignments'
  | 'student_unenrollments'
  | 'professor_unassignments';

export interface ColumnMapping {
  excelColumn: string;
  databaseColumn: string;
  isMatched: boolean;
}

export interface Template {
  id: string;
  name: string;
  importType: ImportType;
  columnMappings: {
    excelColumn: string;
    databaseColumn: string;
  }[];
  createdAt: Date;
  updatedAt: Date;
  facultyId: string;
}

export interface UploadModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUploadComplete?: () => void;
  allowedImportTypes?: ImportType[];  role?: 'super-admin' | 'faculty-admin';}

export type UploadStep = 'upload' | 'mapping' | 'template-name';

export enum BulkOperationType {
  STUDENTS_ONLY = 'STUDENTS_ONLY',
  PROFESSORS_ONLY = 'PROFESSORS_ONLY',
  USERS = 'USERS',
}