'use client';

import { useRef } from 'react';
import { useTranslations } from 'next-intl';
import { Upload, X, FileSpreadsheet, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import type { Faculty } from '@/types';
import { ImportType } from './types';
import { formatFileSize } from './utils';

interface FileUploadStepProps {
  selectedFile: File | null;
  selectedImportType: string;
  selectedFacultyId?: string;
  faculties?: Faculty[];
  isLoadingFaculties?: boolean;
  userRole?: 'super-admin' | 'faculty-admin';
  error: string | null;
  importTypes: ImportType[];
  isUploading: boolean;
  onFileSelect: (file: File | null) => void;
  onImportTypeChange: (type: string) => void;
  onFacultyChange?: (facultyId: string) => void;
  onRemoveFile: () => void;
}

export function FileUploadStep({
  selectedFile,
  selectedImportType,
  selectedFacultyId = '',
  faculties = [],
  isLoadingFaculties = false,
  userRole = 'faculty-admin',
  error,
  importTypes,
  isUploading,
  onFileSelect,
  onImportTypeChange,
  onFacultyChange,
  onRemoveFile,
}: FileUploadStepProps) {
  const t = useTranslations();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    onFileSelect(file || null);
  };

  return (
    <div className="space-y-4 py-4 lg:grid lg:grid-cols-2 lg:gap-6 lg:space-y-0">
      <div className="space-y-4">
        {/* File input area */}
        {!selectedFile ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-muted-foreground/25 p-8 text-center hover:border-muted-foreground/50 transition-colors cursor-pointer"
          >
            <Upload className="h-10 w-10 text-muted-foreground" />
            <div className="space-y-1">
              <p className="text-sm font-medium">{t('bulkImport.clickToUpload')}</p>
              <p className="text-xs text-muted-foreground">
                {t('bulkImport.supportedFormats')}: .xlsx, .xls (max 10MB)
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
        ) : (
          <div className="rounded-lg border bg-muted/50 p-4">
            <div className="flex items-start gap-3">
              <FileSpreadsheet className="h-10 w-10 text-green-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{selectedFile.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatFileSize(selectedFile.size)}
                </p>
              </div>
              {!isUploading && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onRemoveFile}
                  className="shrink-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Error message */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Instructions */}
        <div className="rounded-lg bg-blue-50 dark:bg-blue-950/20 p-4 space-y-2">
          <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
            Excel File Requirements
          </p>
          <ul className="text-xs text-blue-800 dark:text-blue-200 space-y-1 list-disc list-inside">
            <li>First row must contain column headers</li>
            <li>Data should start from the second row</li>
            <li>Remove all empty rows from the file before uploading</li>
            <li>Ensure all required fields are filled for each row</li>
          </ul>
        </div>
      </div>

      {/* Import Type Selection */}
      <div className="rounded-lg bg-transparent p-4 space-y-3 lg:h-fit">
        <p className="text-sm font-medium">{t('bulkImport.selectImportType')}</p>
        <div className="space-y-2 max-h-48 lg:max-h-96 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-muted-foreground/20 scrollbar-track-transparent">
          {importTypes.map((type) => (
            <div key={type} className="flex items-center space-x-2">
              <input
                type="radio"
                id={type}
                name="importType"
                value={type}
                checked={selectedImportType === type}
                onChange={() => onImportTypeChange(type)}
                disabled={isUploading}
                className="h-4 w-4 text-primary"
              />
              <label
                htmlFor={type}
                className="text-sm cursor-pointer hover:text-foreground transition-colors capitalize"
              >
                {t(`bulkImport.importType.${type}`)}
              </label>
            </div>
          ))}
        </div>

        {/* Faculty Selection for Super Admin */}
        {userRole === 'super-admin' && (
          <div className="space-y-2 pt-4 border-t">
            <Label htmlFor="faculty-select" className="text-sm font-medium">
              Select Faculty *
            </Label>
            <Select
              value={selectedFacultyId}
              onValueChange={onFacultyChange}
              disabled={isUploading || isLoadingFaculties}
            >
              <SelectTrigger id="faculty-select" className="w-full">
                <SelectValue placeholder={isLoadingFaculties ? 'Loading faculties...' : 'Select a faculty'} />
              </SelectTrigger>
              <SelectContent>
                {faculties.map((faculty) => (
                  <SelectItem key={faculty.id} value={faculty.id}>
                    {faculty.name} ({faculty.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Choose the faculty this template will be associated with
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
