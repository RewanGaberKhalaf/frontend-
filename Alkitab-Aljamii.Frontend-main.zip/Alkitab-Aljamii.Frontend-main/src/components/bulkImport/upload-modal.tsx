'use client';

import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { importsApi, facultiesApi } from '@/lib/api';
import type { Faculty } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { 
  ImportType, 
  UploadModalProps, 
  UploadStep, 
  ColumnMapping, 
  Template 
} from './types';
import { 
  readExcelColumns, 
  getDatabaseColumns, 
  createColumnMappings, 
  areAllColumnsMatched,
  isValidExcelFile,
  isValidFileSize
} from './utils';
import { FileUploadStep } from './file-upload-step';
import { ColumnMappingStep } from './column-mapping-step';
import { TemplateNameStep } from './template-name-step';

export function UploadModal({ open, onOpenChange, onUploadComplete, allowedImportTypes, role }: UploadModalProps) {
  const pathname = usePathname();
  const t = useTranslations();
  
  // Auto-detect role from pathname if not provided
  const userRole: 'super-admin' | 'faculty-admin' = 
    role || (pathname?.includes('/super-admin') ? 'super-admin' : 'faculty-admin');
  
  const [step, setStep] = useState<UploadStep>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedImportType, setSelectedImportType] = useState<ImportType | ''>('');
  const [selectedFacultyId, setSelectedFacultyId] = useState<string>('');
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [isLoadingFaculties, setIsLoadingFaculties] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [databaseColumns, setDatabaseColumns] = useState<string[]>([]);
  const [requiredColumns, setRequiredColumns] = useState<string[]>([]);
  const [templateName, setTemplateName] = useState<string>('');

  const allImportTypes: ImportType[] = [
    'students_only',
    'students_with_subjects',
    'professors_only',
    'professors_with_subjects',
    'student_enrollments',
    'professor_assignments',
    'student_unenrollments',
    'professor_unassignments',
  ];

  const importTypes = allowedImportTypes || allImportTypes;

  // Load faculties for super-admin
  useEffect(() => {
    if (open && userRole === 'super-admin') {
      loadFaculties();
    }
  }, [open, userRole]);

  const loadFaculties = async () => {
    setIsLoadingFaculties(true);
    try {
      const response = await facultiesApi.getAll({ page: 1, limit: 100, isActive: true });
      setFaculties(response.items);
    } catch (err) {
      console.error('Failed to load faculties:', err);
      setError('Failed to load faculties');
    } finally {
      setIsLoadingFaculties(false);
    }
  };

  const handleFileSelect = (file: File | null) => {
    if (!file) {
      setSelectedFile(null);
      setError(null);
      return;
    }

    // Validate file type
    if (!isValidExcelFile(file)) {
      setError(t('bulkImport.invalidFileType'));
      setSelectedFile(null);
      return;
    }

    // Validate file size
    if (!isValidFileSize(file)) {
      setError(t('bulkImport.fileTooLarge'));
      setSelectedFile(null);
      return;
    }

    setError(null);
    setSelectedFile(file);
  };

  const handleImportTypeChange = (type: string) => {
    setSelectedImportType(type as ImportType);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setError(null);
  };

  const handleNext = async () => {
    if (!selectedFile || !selectedImportType) return;
    if (userRole === 'super-admin' && !selectedFacultyId) {
      setError('Please select a faculty');
      return;
    }

    setIsUploading(true);
    setError(null);

    try {
      // Upload file to API
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('operation', selectedImportType);
      
      // Add facultyId for super-admin
      if (userRole === 'super-admin' && selectedFacultyId) {
        formData.append('facultyId', selectedFacultyId);
      }

      const result = await importsApi.uploadFile(formData, userRole);

      // Store template ID for later use
      setTemplateName(result.templateId);

      // Get Excel columns from API response
      const excelColumns = result.fileMetadata.headerColumns;
      
      // Get database columns from API response (required + optional)
      const dbCols = [
        ...result.requiredColumns.required,
        ...result.requiredColumns.optional,
      ];
      setDatabaseColumns(dbCols);
      setRequiredColumns(result.requiredColumns.required);

      // Create initial column mappings with empty selections
      const mappings: ColumnMapping[] = excelColumns.map((excelCol: string) => ({
        excelColumn: excelCol,
        databaseColumn: '', // Empty initially, user will select
        isMatched: false,
      }));
      setColumnMappings(mappings);

      // Always go to mapping step for manual selection
      setStep('mapping');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload file');
    } finally {
      setIsUploading(false);
    }
  };

  const handleFinish = async () => {
    if (!templateName || !columnMappings.length) return;

    setIsUploading(true);
    setUploadProgress(0);
    setError(null);

    try {
      // Create mappings object for API (Excel column name -> Database column name)
      const mappings: Record<string, string> = {};
      columnMappings.forEach(mapping => {
        if (mapping.databaseColumn) {
          mappings[mapping.excelColumn] = mapping.databaseColumn;
        }
      });

      // Send column mappings to API
      await importsApi.saveMappings(templateName, mappings);

      // Simulate progress
      for (let i = 0; i <= 100; i += 20) {
        setUploadProgress(i);
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      onUploadComplete?.();
      handleClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : t('bulkImport.uploadError'));
    } finally {
      setIsUploading(false);
    }
  };

  const handleMappingChange = (excelColumn: string, selectedDbColumn: string) => {
    setColumnMappings(prev => 
      prev.map(mapping => 
        mapping.excelColumn === excelColumn
          ? { ...mapping, databaseColumn: selectedDbColumn, isMatched: selectedDbColumn !== '' }
          : mapping
      )
    );
  };

  const handleMappingNext = () => {
    // Check if all required columns are mapped
    const mappedDbColumns = columnMappings
      .filter(m => m.databaseColumn !== '')
      .map(m => m.databaseColumn);
    
    const allRequiredMapped = requiredColumns.every(reqCol => 
      mappedDbColumns.includes(reqCol)
    );
    
    if (allRequiredMapped) {
      setStep('template-name');
    }
  };

  const handleBack = () => {
    if (step === 'template-name') {
      setStep('mapping');
    } else if (step === 'mapping') {
      setStep('upload');
      setColumnMappings([]);
      setDatabaseColumns([]);
    }
  };

  const handleClose = () => {
    if (!isUploading) {
      setStep('upload');
      setSelectedFile(null);
      setSelectedImportType('');
      setSelectedFacultyId('');
      setUploadProgress(0);
      setError(null);
      setColumnMappings([]);
      setDatabaseColumns([]);
      setTemplateName('');
      onOpenChange(false);
    }
  };

  const getDialogTitle = () => {
    switch (step) {
      case 'upload':
        return t('bulkImport.uploadExcel');
      case 'mapping':
        return 'Column Mapping';
      case 'template-name':
        return 'Name Your Template';
      default:
        return t('bulkImport.uploadExcel');
    }
  };

  const getDialogDescription = () => {
    switch (step) {
      case 'upload':
        return t('bulkImport.uploadDescription');
      case 'mapping':
        return 'Match your Excel columns with database columns';
      case 'template-name':
        return 'All columns matched! Provide a name to save this template.';
      default:
        return t('bulkImport.uploadDescription');
    }
  };

  const canProceed = () => {
    switch (step) {
      case 'upload':
        if (userRole === 'super-admin') {
          return selectedFile && selectedImportType && selectedFacultyId && !isUploading;
        }
        return selectedFile && selectedImportType && !isUploading;
      case 'mapping':
        return false; // Cannot proceed from mapping step if columns don't match
      case 'template-name':
        return templateName.trim() && !isUploading;
      default:
        return false;
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl md:max-w-3xl lg:max-w-4xl xl:max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{getDialogTitle()}</DialogTitle>
          <DialogDescription>{getDialogDescription()}</DialogDescription>
        </DialogHeader>

        {step === 'upload' && (
          <FileUploadStep
            selectedFile={selectedFile}
            selectedImportType={selectedImportType}
            selectedFacultyId={selectedFacultyId}
            faculties={faculties}
            isLoadingFaculties={isLoadingFaculties}
            userRole={userRole}
            error={error}
            importTypes={importTypes}
            isUploading={isUploading}
            onFileSelect={handleFileSelect}
            onImportTypeChange={handleImportTypeChange}
            onFacultyChange={setSelectedFacultyId}
            onRemoveFile={handleRemoveFile}
          />
        )}

        {step === 'mapping' && (
          <ColumnMappingStep
            columnMappings={columnMappings}
            databaseColumns={databaseColumns}
            requiredColumns={requiredColumns}
            onMappingChange={handleMappingChange}
          />
        )}

        {step === 'template-name' && (
          <TemplateNameStep
            templateName={templateName}
            onTemplateNameChange={setTemplateName}
          />
        )}

        {/* Upload Progress */}
        {isUploading && step === 'template-name' && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{t('bulkImport.uploading')}</span>
              <span>{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2" />
          </div>
        )}

        <DialogFooter>
          {step !== 'upload' && (
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={isUploading}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('common.back')}
            </Button>
          )}
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isUploading}
          >
            {t('common.cancel')}
          </Button>
          {step === 'upload' ? (
            <Button
              onClick={handleNext}
              disabled={!canProceed()}
            >
              {t('common.next')}
            </Button>
          ) : step === 'mapping' ? (
            <Button
              onClick={handleMappingNext}
              disabled={(() => {
                const mappedDbColumns = columnMappings
                  .filter(m => m.databaseColumn !== '')
                  .map(m => m.databaseColumn);
                return !requiredColumns.every(reqCol => mappedDbColumns.includes(reqCol));
              })()}
            >
              {t('common.next')}
            </Button>
          ) : step === 'template-name' ? (
            <Button
              onClick={handleFinish}
              disabled={!canProceed()}
            >
              {isUploading ? t('bulkImport.uploading') : 'Finish'}
            </Button>
          ) : null}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
