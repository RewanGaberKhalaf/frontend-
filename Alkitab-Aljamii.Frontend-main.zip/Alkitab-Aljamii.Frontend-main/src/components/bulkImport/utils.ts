import * as XLSX from 'xlsx';
import { ImportType, ColumnMapping } from './types';

/**
 * Read Excel file and extract column headers from the first row
 */
export const readExcelColumns = async (file: File): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) return resolve([]);

        const workbook = XLSX.read(data, { type: 'binary' });

        const sheetNames = workbook.SheetNames;
        if (!sheetNames || sheetNames.length === 0) return resolve([]);

        // تأكيد النوع
        const firstSheetName = sheetNames[0]!;
        const firstSheet = workbook.Sheets[firstSheetName];
        if (!firstSheet) return resolve([]);

        const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
        const headers = (jsonData[0] as string[]) || [];
        resolve(headers.filter(h => h && h.trim()));
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = reject;
    reader.readAsBinaryString(file);
  });
};

/**
 * Get database columns based on import type
 */
export const getDatabaseColumns = (importType: ImportType): string[] => {
  const columnMap: Record<ImportType, string[]> = {
    students_only: ['National ID', 'Student ID', 'Full Name', 'Email', 'Faculty'],
    students_with_subjects: ['National ID', 'Student ID', 'Full Name', 'Email', 'Faculty', 'Subject Codes'],
    professors_only: ['National ID', 'Employee ID', 'Full Name', 'Email', 'Faculty', 'Department'],
    professors_with_subjects: ['National ID', 'Employee ID', 'Full Name', 'Email', 'Faculty', 'Department', 'Subject Codes'],
    student_enrollments: ['Student ID', 'Subject Code', 'Enrollment Date'],
    professor_assignments: ['Employee ID', 'Subject Code', 'Assignment Date'],
    student_unenrollments: ['Student ID', 'Subject Code'],
    professor_unassignments: ['Employee ID', 'Subject Code'],
  };
  return columnMap[importType] || [];
};

/**
 * Check if a column name matches (case-insensitive, whitespace-normalized)
 */
export const isColumnMatched = (excelCol: string, databaseColumns: string[]): boolean => {
  return databaseColumns.some(dbCol =>
    dbCol.toLowerCase().replace(/\s+/g, '') === excelCol.toLowerCase().replace(/\s+/g, '')
  );
};

/**
 * Get the matched database column for an Excel column
 */
export const getMatchedColumn = (excelCol: string, databaseColumns: string[]): string => {
  const matched = databaseColumns.find(dbCol =>
    dbCol.toLowerCase().replace(/\s+/g, '') === excelCol.toLowerCase().replace(/\s+/g, '')
  );
  return matched ?? ''; 
};

/**
 * Create column mappings from Excel and database columns
 */
export const createColumnMappings = (
  excelColumns: string[],
  databaseColumns: string[]
): ColumnMapping[] => {
  return excelColumns.map(excelCol => {
    const matchedCol = getMatchedColumn(excelCol, databaseColumns);
    return {
      excelColumn: excelCol,
      databaseColumn: matchedCol,
      isMatched: matchedCol !== '',
    };
  });
};

/**
 * Check if all columns are matched
 */
export const areAllColumnsMatched = (mappings: ColumnMapping[]): boolean => {
  return mappings.every(mapping => mapping.isMatched);
};

/**
 * Format file size in human-readable format
 */
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${Math.round((bytes / Math.pow(k, i)) * 100) / 100} ${sizes[i]}`;
};

/**
 * Validate file type
 */
export const isValidExcelFile = (file: File): boolean => {
  const validTypes = [
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel',
  ];
  return validTypes.includes(file.type) || /\.(xlsx|xls)$/i.test(file.name);
};

/**
 * Validate file size (default max 10MB)
 */
export const isValidFileSize = (file: File, maxSizeMB: number = 10): boolean => {
  const maxSize = maxSizeMB * 1024 * 1024;
  return file.size <= maxSize;
};

