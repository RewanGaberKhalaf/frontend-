'use client';

import { useState, useRef, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { Upload, X, FileSpreadsheet, AlertCircle, CheckCircle2, Download, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { importsApi, facultiesApi, type ImportResult } from '@/lib/api';
import type { Faculty } from '@/types';
import { useFacultyContextStore } from '@/stores';
import { ImportType, Template } from './types';
import { formatFileSize, isValidExcelFile, isValidFileSize } from './utils';

interface QuickUploadModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUploadComplete?: () => void;
  allowedImportTypes?: ImportType[];
  facultyId?: string;
}

export function QuickUploadModal({
  open,
  onOpenChange,
  onUploadComplete,
  allowedImportTypes,
  facultyId,
}: QuickUploadModalProps) {
  const pathname = usePathname();
  const t = useTranslations();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { currentFacultyId } = useFacultyContextStore();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFacultyId, setSelectedFacultyId] = useState<string>('');
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [isLoadingFaculties, setIsLoadingFaculties] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [templates, setTemplates] = useState<Template[]>([]);
  const [isLoadingTemplates, setIsLoadingTemplates] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  const userRole: 'super-admin' | 'faculty-admin' =
    pathname?.includes('/super-admin') ? 'super-admin' : 'faculty-admin';

  // Load faculties on modal open (only for super-admin)
  useEffect(() => {
    if (open && userRole === 'super-admin') {
      loadFaculties();
    }
  }, [open, userRole]);

  // Load templates when faculty is selected or for faculty-admin on modal open
  useEffect(() => {
    if (!open) return;

    if (userRole === 'faculty-admin' && currentFacultyId) {
      setSelectedFacultyId(currentFacultyId);
      loadTemplates(currentFacultyId);
    } else if (userRole === 'super-admin' && selectedFacultyId) {
      loadTemplates(selectedFacultyId);
    } else if (userRole === 'super-admin' && !selectedFacultyId) {
      setTemplates([]);
      setSelectedTemplate('');
    }
  }, [open, selectedFacultyId, allowedImportTypes, userRole, currentFacultyId]);

  const loadFaculties = async () => {
    setIsLoadingFaculties(true);
    try {
      const response = await facultiesApi.getAll({ page: 1, limit: 100, isActive: true });
      setFaculties(response.items);
    } catch (err) {
      console.error('Failed to load faculties:', err);
      setError('Failed to load faculties');
    } finally {
      setIsLoadingFaculties(false);
    }
  };

  const loadTemplates = async (facultyId: string) => {
    setIsLoadingTemplates(true);
    try {
      const allTemplates = await importsApi.getTemplates(facultyId);

      const validImportTypes: ImportType[] = [
        'students_only',
        'students_with_subjects',
        'professors_only',
        'professors_with_subjects',
        'student_enrollments',
        'professor_assignments',
        'student_unenrollments',
        'professor_unassignments',
      ];

      // Filter templates by allowedImportTypes if provided
      const filtered = allowedImportTypes
        ? allTemplates.filter(t => allowedImportTypes.includes(t.importType))
        : allTemplates;

      // Map templates and ensure facultyId exists
      const mapped: Template[] = filtered.map((t: any) => ({
        ...t,
        importType: validImportTypes.includes(t.importType as ImportType)
          ? (t.importType as ImportType)
          : 'students_only',
        columnMappings: (t.columnMappings || []).map((c: any) => ({
          excelColumn: c.excelColumn,
          databaseColumn: c.databaseColumn,
          isMatched: false,
        })),
        facultyId: t.facultyId || facultyId || 'unknown',
      }));

      setTemplates(mapped);
    } catch (err) {
      console.error('Failed to load templates:', err);
      setError('Failed to load templates');
    } finally {
      setIsLoadingTemplates(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isValidExcelFile(file)) {
      setError(t('bulkImport.invalidFileType'));
      setSelectedFile(null);
      return;
    }

    if (!isValidFileSize(file)) {
      setError(t('bulkImport.fileTooLarge'));
      setSelectedFile(null);
      return;
    }

    setError(null);
    setSelectedFile(file);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const checkImportStatus = async (jobId: string) => {
    try {
      const result = await importsApi.getImportResult(jobId);
      setImportResult(result);

      if (result.status === 'processing') {
        setTimeout(() => checkImportStatus(jobId), 2000);
      } else {
        setIsProcessing(false);
        if (result.status === 'completed' && result.successCount > 0) {
          onUploadComplete?.();
        }
      }
    } catch (err) {
      console.error('Failed to check import status:', err);
      setError('Failed to check import status');
      setIsProcessing(false);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile || !selectedTemplate) return;

    setIsUploading(true);
    setUploadProgress(0);
    setError(null);
    setJobId(null);
    setImportResult(null);

    try {
      const template = templates.find(t => t.id === selectedTemplate);
      if (!template) {
        setError('Selected template not found');
        setIsUploading(false);
        return;
      }

      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('operation', template.importType);
      formData.append('templateId', selectedTemplate);

      if (userRole === 'super-admin' && selectedFacultyId) {
        formData.append('facultyId', selectedFacultyId);
      }

      const response = await importsApi.uploadWithTemplate(formData, userRole);

      setJobId(response.jobId);
      setIsUploading(false);
      setIsProcessing(true);

      await checkImportStatus(response.jobId);
    } catch (err: any) {
      console.error('Upload error:', err);
      setError(err?.response?.data?.message || err?.response?.data?.error || err?.message || 'Failed to upload file');
      setIsUploading(false);
      setIsProcessing(false);
    }
  };

  const handleDownloadErrorFile = () => {
    if (importResult?.errorFileUrl) window.open(importResult.errorFileUrl, '_blank');
  };

  const handleClose = () => {
    if (!isUploading && !isProcessing) {
      setSelectedFile(null);
      setSelectedFacultyId('');
      setSelectedTemplate('');
      setUploadProgress(0);
      setError(null);
      setJobId(null);
      setImportResult(null);
      onOpenChange(false);
    }
  };

  const getStatusIcon = () => {
    if (!importResult) return null;
    if (importResult.status === 'completed' && importResult.failureCount === 0)
      return <CheckCircle2 className="h-5 w-5 text-green-600" />;
    if (importResult.status === 'failed' || importResult.failureCount > 0)
      return <XCircle className="h-5 w-5 text-red-600" />;
    return null;
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{t('bulkImport.uploadExcel')}</DialogTitle>
          <DialogDescription>
            Upload an Excel file using a pre-configured template
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Faculty Selection for Super Admin */}
          {!importResult && userRole === 'super-admin' && (
            <div className="space-y-2">
              <Label htmlFor="faculty-select">Select Faculty *</Label>
              <Select
                value={selectedFacultyId}
                onValueChange={setSelectedFacultyId}
                disabled={isUploading || isProcessing || isLoadingFaculties}
              >
                <SelectTrigger id="faculty-select">
                  <SelectValue placeholder={isLoadingFaculties ? 'Loading faculties...' : 'Choose a faculty'} />
                </SelectTrigger>
                <SelectContent>
                  {faculties.map((faculty) => (
                    <SelectItem key={faculty.id} value={faculty.id}>
                      {faculty.name} ({faculty.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select the faculty to view its templates
              </p>
            </div>
          )}

          {/* File Upload Area */}
          {!importResult && (
            <div className="space-y-2">
              <Label>Select File</Label>
              {!selectedFile ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-muted-foreground/25 p-8 text-center hover:border-muted-foreground/50 transition-colors cursor-pointer"
                >
                  <Upload className="h-10 w-10 text-muted-foreground" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Click to upload or drag and drop</p>
                    <p className="text-xs text-muted-foreground">
                      Supported formats: .xlsx, .xls (max 10MB)
                    </p>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="rounded-lg border bg-muted/50 p-4">
                  <div className="flex items-start gap-3">
                    <FileSpreadsheet className="h-10 w-10 text-green-600 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
                    </div>
                    {!isUploading && !isProcessing && (
                      <Button variant="ghost" size="icon" onClick={handleRemoveFile} className="shrink-0">
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              )}

              {selectedFile && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    <strong>Important:</strong> Ensure your Excel file has no empty rows. Remove all blank rows before uploading to avoid validation errors.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {/* Template Selection */}
          {!importResult && (
            <div className="space-y-2">
              <Label>Select Template</Label>
              {userRole === 'super-admin' && !selectedFacultyId ? (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Please select a faculty first to view available templates.
                  </AlertDescription>
                </Alert>
              ) : isLoadingTemplates ? (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Loading templates...
                  </AlertDescription>
                </Alert>
              ) : templates.length > 0 ? (
                <Select
                  value={selectedTemplate}
                  onValueChange={setSelectedTemplate}
                  disabled={isUploading || isProcessing}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a template" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{template.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {t(`bulkImport.importType.${template.importType}`)} • {template.columnMappings.length} columns
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    No templates available for the selected faculty. Please create a template in the Template Management page first.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {/* Error */}
          {error && !importResult && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="text-sm whitespace-pre-wrap">{error}</AlertDescription>
            </Alert>
          )}

          {/* Processing Status */}
          {isProcessing && !importResult && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Processing your import... This may take a few moments.
              </AlertDescription>
            </Alert>
          )}

          {/* Import Results */}
          {importResult && (
            <div className="space-y-4">
              <div className="rounded-lg border p-4 space-y-3">
                <div className="flex items-center gap-2">{getStatusIcon()}<h3 className="font-semibold">Import Results</h3></div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Status</p>
                    <p className="font-medium capitalize">{importResult.status}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Total Rows</p>
                    <p className="font-medium">{importResult.totalRows}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Successful</p>
                    <p className="font-medium text-green-600">{importResult.successCount}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Failed</p>
                    <p className="font-medium text-red-600">{importResult.failureCount}</p>
                  </div>
                </div>

                {importResult.errorFileUrl && (
                  <Button variant="destructive" size="sm" onClick={handleDownloadErrorFile} className="w-full">
                    <Download className="mr-2 h-4 w-4" />
                    Download Error Report (Excel)
                  </Button>
                )}
              </div>

              {importResult.status === 'completed' && importResult.failureCount === 0 && (
                <Alert>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>
                    Import completed successfully! All rows were processed without errors.
                  </AlertDescription>
                </Alert>
              )}

              {importResult.failureCount > 0 && (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    {importResult.failureCount} rows failed to import. Please download the error report for details.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {/* Upload Progress */}
          {isUploading && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Uploading file...</span>
              </div>
              <Progress value={100} className="h-2" />
            </div>
          )}
        </div>

        <DialogFooter>
          {!importResult ? (
            <>
              <Button variant="outline" onClick={handleClose} disabled={isUploading || isProcessing}>
                {t('common.cancel')}
              </Button>
              <Button onClick={handleUpload} disabled={!selectedFile || !selectedTemplate || isUploading || isProcessing}>
                {isUploading || isProcessing ? 'Processing...' : 'Upload'}
              </Button>
            </>
          ) : (
            <Button onClick={handleClose}>Close</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

