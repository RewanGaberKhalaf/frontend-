import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import { importsApi } from '@/lib/api';
import { Template, BulkOperationType, ImportType } from './types';
import {
  editTemplateSchema,
  EditTemplateForm,
} from '@/lib/validations/edit-template.schema';

interface Props {
  open: boolean;
  template: Template | null;
  onClose: () => void;
  onSuccess: () => void;
}
const importTypeToBulkOperation: Record<ImportType, BulkOperationType> = {
  students_only: BulkOperationType.STUDENTS_ONLY,
  students_with_subjects: BulkOperationType.STUDENTS_ONLY,
  professors_only: BulkOperationType.PROFESSORS_ONLY,
  professors_with_subjects: BulkOperationType.PROFESSORS_ONLY,
  student_enrollments: BulkOperationType.USERS,
  professor_assignments: BulkOperationType.USERS,
  student_unenrollments: BulkOperationType.USERS,
  professor_unassignments: BulkOperationType.USERS,
};

export function EditTemplateModal({
  open,
  template,
  onClose,
  onSuccess,
}: Props) {
  const form = useForm<EditTemplateForm>({
    resolver: zodResolver(editTemplateSchema),
  });

  useEffect(() => {
    if (template) {
      const operationEnum =
        importTypeToBulkOperation[template.importType] ?? BulkOperationType.USERS;
      form.reset({
        name: template.name,
        operation: operationEnum,
      });
    }
  }, [template, form]);

  if (!template) return null;

  const onSubmit = async (values: EditTemplateForm) => {
    try {
      await importsApi.updateTemplate(template.id, values);
      toast.success('Template updated successfully');
      onSuccess();
      onClose();
    } catch {
      toast.error('Failed to update template');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Template</DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          {/* Name */}
          <Input placeholder="Template name" {...form.register('name')} />

          {/* Operation */}
          <Select
            value={form.watch('operation')}
            onValueChange={(val) =>
              form.setValue('operation', val as BulkOperationType)
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select operation type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={BulkOperationType.STUDENTS_ONLY}>
                Students Only
              </SelectItem>
              <SelectItem value={BulkOperationType.PROFESSORS_ONLY}>
                Professors Only
              </SelectItem>
              <SelectItem value={BulkOperationType.USERS}>All Users</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Save Changes</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
