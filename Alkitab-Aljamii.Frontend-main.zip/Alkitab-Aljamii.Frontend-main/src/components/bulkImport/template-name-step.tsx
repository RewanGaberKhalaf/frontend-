'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { CheckCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface TemplateNameStepProps {
  templateName: string;
  onTemplateNameChange: (name: string) => void;
}

export function TemplateNameStep({
  templateName,
  onTemplateNameChange,
}: TemplateNameStepProps) {
  const t = useTranslations();

  return (
    <div className="py-6 space-y-6">
      {/* Success message */}
      <div className="flex items-center gap-3 p-4 rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800">
        <CheckCircle className="h-6 w-6 text-green-600 shrink-0" />
        <div>
          <p className="text-sm font-medium text-green-900 dark:text-green-100">
            All columns matched successfully!
          </p>
          <p className="text-xs text-green-700 dark:text-green-300 mt-1">
            Your Excel file structure matches the template perfectly. Please provide a name for this template.
          </p>
        </div>
      </div>

      {/* Template name input */}
      <div className="space-y-2">
        <Label htmlFor="template-name" className="text-sm font-medium">
          Template ID
        </Label>
        <Input
          id="template-name"
          type="text"
          placeholder="e.g., Student Registration Template 2025"
          value={templateName}
          onChange={(e) => onTemplateNameChange(e.target.value)}
          className="w-full"
        />
        <p className="text-xs text-muted-foreground">
          Choose a descriptive name to easily identify this template later.
        </p>
      </div>

      {/* Template details summary */}
      <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
        <p className="text-sm font-medium">Template Details</p>
        <div className="text-xs text-muted-foreground space-y-1">
          <p>• This template will be saved for future use</p>
          <p>• You can edit or delete it anytime from the Template Management page</p>
          <p>• The column mappings will be preserved for quick uploads</p>
        </div>
      </div>
    </div>
  );
}
