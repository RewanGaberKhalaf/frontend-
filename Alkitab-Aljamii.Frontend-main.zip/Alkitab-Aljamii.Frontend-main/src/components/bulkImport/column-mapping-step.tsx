'use client';

import { useTranslations } from 'next-intl';
import { ArrowRight } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ColumnMapping } from './types';

interface ColumnMappingStepProps {
  columnMappings: ColumnMapping[];
  databaseColumns: string[];
  requiredColumns: string[];
  onMappingChange: (excelColumn: string, selectedDbColumn: string) => void;
}

export function ColumnMappingStep({
  columnMappings,
  databaseColumns,
  requiredColumns,
  onMappingChange,
}: ColumnMappingStepProps) {
  const t = useTranslations();

  return (
    <div className="py-4">
      <div className="max-w-3xl mx-auto">
        <h3 className="text-sm font-semibold mb-4 text-muted-foreground">
          Map Your Excel Columns
        </h3>
        <p className="text-sm text-muted-foreground mb-6">
          Select the corresponding database column for each column in your Excel file
        </p>
        <div className="space-y-3">
          {columnMappings.map((mapping, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="flex-1 p-3 rounded-lg border bg-muted/50 text-sm font-medium">
                {mapping.excelColumn}
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
              <Select
                value={mapping.databaseColumn}
                onValueChange={(value) => onMappingChange(mapping.excelColumn, value)}
              >
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select column to map" />
                </SelectTrigger>
                <SelectContent>
                  {databaseColumns.map((dbCol) => (
                    <SelectItem key={dbCol} value={dbCol}>
                      {dbCol}
                      {requiredColumns.includes(dbCol) && (
                        <span className="ml-1 text-xs text-red-500">*</span>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
