'use client';

import Image from 'next/image';
import { useTranslations } from 'next-intl';
import { cn } from '@/lib/utils';
import { useUIStore } from '@/stores';
import { SidebarNav } from './sidebar-nav';
import { SidebarFooter } from './sidebar-footer';

export function Sidebar() {
  const { sidebarCollapsed, toggleSidebarCollapse } = useUIStore();
  const t = useTranslations('app');

  return (
    <aside
      className={cn(
        'flex h-full flex-col border-r bg-background transition-all duration-300',
        sidebarCollapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Logo */}
      <div className={cn(
        "flex items-center justify-center border-b",
        sidebarCollapsed ? "h-14 px-2" : "h-20 px-4"
      )}>
        <Image
          src="/logo-large.png"
          alt={t('name')}
          width={sidebarCollapsed ? 40 : 200}
          height={sidebarCollapsed ? 40 : 50}
          className={cn(
            "object-contain transition-all duration-300",
            sidebarCollapsed ? "w-8 h-8" : "w-auto h-12 max-w-full"
          )}
          priority
        />
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto">
        <SidebarNav collapsed={sidebarCollapsed} />
      </div>

      {/* Footer */}
      <SidebarFooter
        collapsed={sidebarCollapsed}
        onToggleCollapse={toggleSidebarCollapse}
      />
    </aside>
  );
}

export { SidebarNav } from './sidebar-nav';
export { SidebarItem } from './sidebar-item';
export { SidebarFooter } from './sidebar-footer';
