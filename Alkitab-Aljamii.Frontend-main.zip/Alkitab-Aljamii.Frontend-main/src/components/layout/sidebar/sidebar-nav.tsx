'use client';

import { useTranslations } from 'next-intl';
import { useAuthStore, useViewContextStore } from '@/stores';
import { NAVIGATION } from '@/lib/constants';
import { SidebarItem } from './sidebar-item';
import type { ViewRole } from '@/lib/api/users';

interface SidebarNavProps {
  collapsed?: boolean;
}

export function SidebarNav({ collapsed = false }: SidebarNavProps) {
  const t = useTranslations();
  const { user } = useAuthStore();
  const { activeView, primaryRole } = useViewContextStore();

  if (!user) return null;

  // Use the active view if available, otherwise fall back to primary role or derive from isSuperAdmin
  const effectiveRole = (activeView ?? primaryRole ?? (user.isSuperAdmin ? 'super_admin' : null)) as ViewRole | null;
  const navItems = effectiveRole ? (NAVIGATION[effectiveRole] ?? []) : [];
  return (
    <nav className="flex flex-col gap-1 px-2 py-4">
      {navItems.map((item) => (
        <SidebarItem
          key={item.href}
          label={t(item.labelKey)}
          href={item.href}
          icon={item.icon}
          collapsed={collapsed}
          exact={item.exact}
        />
      ))}
    

    </nav>
  );
}
