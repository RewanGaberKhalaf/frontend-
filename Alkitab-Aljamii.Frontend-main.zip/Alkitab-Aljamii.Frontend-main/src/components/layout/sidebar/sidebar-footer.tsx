'use client';

import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuthStore, useViewContextStore } from '@/stores';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface SidebarFooterProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export function SidebarFooter({ collapsed, onToggleCollapse }: SidebarFooterProps) {
  const { user } = useAuthStore();
  const { activeView, primaryRole } = useViewContextStore();

  const fullName = user ? `${user.firstName} ${user.lastName}` : '';
  const initials = user
    ? `${user.firstName[0] ?? ''}${user.lastName[0] ?? ''}`.toUpperCase()
    : 'U';

  // Show active view role if different from primary
  const effectiveRole = activeView ?? primaryRole ?? (user?.isSuperAdmin ? 'super_admin' : null);
  const roleDisplay = effectiveRole?.replace('_', ' ') ?? '';

  return (
    <div className="border-t p-2">
      <div className="flex items-center gap-2">
        {!collapsed && (
          <div className="flex flex-1 items-center gap-2 overflow-hidden">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1 overflow-hidden">
              <p className="truncate text-sm font-medium">{fullName}</p>
              <p className="truncate text-xs text-muted-foreground">
                {roleDisplay}
              </p>
            </div>
          </div>
        )}
        {/* Hide collapse button on mobile */}
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 shrink-0 hidden md:flex"
          onClick={onToggleCollapse}
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronLeft className="h-4 w-4" />
          )}
        </Button>
      </div>
    </div>
  );
}
