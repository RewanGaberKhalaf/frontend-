'use client';

import { Menu, X } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { useUIStore, useAuthStore, useViewContextStore } from '@/stores';
import { UserMenu } from './user-menu';
import { FacultySwitcher } from './faculty-switcher';
import { ViewSwitcher } from './view-switcher';
import { LocaleSwitcher } from '@/components/shared/locale-switcher';
import { NotificationCenter } from '@/components/notifications';
import { NAVIGATION } from '@/lib/constants';
import { ToggleTheme } from '@/components/toggleTheme/toggleTheme';
import type { ViewRole } from '@/lib/api/users';

export function Header() {
  const t = useTranslations();
  const pathname = usePathname();
  const { toggleSidebar,sidebarOpen } = useUIStore();
  const user = useAuthStore((state) => state.user);
  const { activeView, primaryRole } = useViewContextStore();

  // Get current page title from navigation config
  const getCurrentPageTitle = () => {
    if (!user) return t('nav.dashboard');

    // Use effective role (active view) for navigation
    const effectiveRole = (activeView ?? primaryRole ?? (user.isSuperAdmin ? 'super_admin' : null)) as ViewRole | null;
    const navItems = effectiveRole ? (NAVIGATION[effectiveRole] ?? []) : [];

    // Find exact match first
    const exactMatch = navItems.find((item) => item.href === pathname);
    if (exactMatch) return t(exactMatch.labelKey);

    // Find prefix match (for nested routes like /users/123)
    const prefixMatch = navItems.find(
      (item) => !item.exact && pathname.startsWith(item.href)
    );
    if (prefixMatch) return t(prefixMatch.labelKey);

    return t('nav.dashboard');
  };

  return (
    <header className="sticky top-0 z-50 flex h-14 items-center justify-between border-b bg-background/80 backdrop-blur-md px-3 sm:px-4">
      <div className="flex items-center gap-2 sm:gap-4 min-w-0">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden shrink-0"
              onClick={toggleSidebar}
              aria-label={sidebarOpen ? t('common.closeMenu') : t('common.openMenu')}
              aria-expanded={sidebarOpen}
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            {sidebarOpen ? t('tooltips.header.closeMenu') : t('tooltips.header.openMenu')}
          </TooltipContent>
        </Tooltip>
        <h1 className="text-base sm:text-lg font-semibold truncate text-foreground">{getCurrentPageTitle()}</h1>
      </div>

      {/* Toolbar items - responsive gap */}
      <div className="flex items-center justify-end gap-1 sm:gap-2">
        <ViewSwitcher />
        <FacultySwitcher />
        <NotificationCenter />
        <ToggleTheme />
        <LocaleSwitcher />
        <UserMenu />
      </div>
    </header>
  );
}

export { UserMenu } from './user-menu';
