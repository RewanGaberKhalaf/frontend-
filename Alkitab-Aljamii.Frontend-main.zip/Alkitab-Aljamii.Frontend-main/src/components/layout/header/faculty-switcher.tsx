'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Building2, ChevronDown, Check, Shield, GraduationCap, BookUser } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useAuthStore, useFacultyContextStore, useViewContextStore } from '@/stores';
import { ROLE_HOME_ROUTES } from '@/lib/constants/routes';
import type { UserFaculty } from '@/lib/api/users';
import type { ViewRole } from '@/lib/api/users';

// Create a unique key for faculty + role combination
const getFacultyRoleKey = (faculty: UserFaculty) => `${faculty.id}-${faculty.role}`;

// Map faculty role to view role (now they match directly)
const facultyRoleToViewRole = (role: UserFaculty['role']): ViewRole => {
  return role;
};

const ROLE_ICONS = {
  faculty_admin: Shield,
  professor: GraduationCap,
  student: BookUser,
};

const ROLE_LABELS = {
  faculty_admin: 'Admin',
  professor: 'Professor',
  student: 'Student',
};

export function FacultySwitcher() {
  const router = useRouter();
  const user = useAuthStore((state) => state.user);
  const switchContext = useAuthStore((state) => state.switchContext);
  const { loadAvailableViews } = useViewContextStore();
  const { faculties, currentFacultyId, currentFacultyRole, loadFaculties, setCurrentFaculty, clearContext } =
    useFacultyContextStore();
  const prevUserIdRef = useRef<string | null>(null);
  const hasInitializedRef = useRef(false);

  // Check if a faculty+role combo is currently selected
  const isSelected = useCallback((faculty: UserFaculty) => {
    return faculty.id === currentFacultyId && faculty.role === currentFacultyRole;
  }, [currentFacultyId, currentFacultyRole]);

  // Handle faculty change - auto-set view based on user's role in that faculty
  const handleFacultyChange = useCallback(async (faculty: UserFaculty) => {
    if (isSelected(faculty)) return;

    // Determine the view based on user's role in this faculty
    const viewRole = facultyRoleToViewRole(faculty.role);
    console.log('[FacultySwitcher] Switching to:', viewRole, faculty.id);

    // Switch context on backend to get scoped token
    const result = await switchContext({
      activeView: viewRole,
      facultyId: faculty.id,
    });

    console.log('[FacultySwitcher] Switch result:', result);

    if (result.success) {
      setCurrentFaculty(faculty.id, faculty.role);
      console.log('[FacultySwitcher] Reloading available views...');
      // Force reload available views to sync with the new JWT token
      await loadAvailableViews(true);
      // Also reload faculties to sync with current state
      await loadFaculties();
      console.log('[FacultySwitcher] Views reloaded, navigating to:', ROLE_HOME_ROUTES[viewRole]);
      // Navigate to the appropriate dashboard for the new view
      router.push(ROLE_HOME_ROUTES[viewRole]);
    } else {
      // Switch failed - role may have been revoked, show error and refresh
      toast.error(result.message || 'This role is no longer available.');
      await loadAvailableViews(true);
      await loadFaculties();
    }
  }, [isSelected, switchContext, setCurrentFaculty, loadAvailableViews, loadFaculties, router]);

  // Load faculties on mount and user change
  useEffect(() => {
    // Clear and reload when user changes
    if (user?.id !== prevUserIdRef.current) {
      if (prevUserIdRef.current !== null) {
        clearContext();
        hasInitializedRef.current = false;
      }
      prevUserIdRef.current = user?.id ?? null;
    }
    // Load ALL faculties without view filter - we want to show all faculties user has access to
    // Don't load for super admins - they don't use faculty switcher
    if (user && !user.isSuperAdmin) {
      loadFaculties(); // No view filter - get all faculties with their roles
    }
  }, [user, loadFaculties, clearContext]);

  // Auto-initialize faculty context when faculties are loaded (only once per session)
  // This syncs the faculty-context-store with the view-context-store (which has the JWT context)
  useEffect(() => {
    if (faculties.length > 0 && !hasInitializedRef.current) {
      hasInitializedRef.current = true;

      // Get the current context from view store (set from JWT token)
      const viewContextState = useViewContextStore.getState();
      const activeView = viewContextState.activeView;
      const activeFacultyId = viewContextState.activeFacultyId;

      // Find matching faculty+role from the JWT context, or fall back to first by priority
      let matchingFaculty = activeFacultyId && activeView
        ? faculties.find((f) => f.id === activeFacultyId && f.role === activeView)
        : null;

      // If no match from JWT, use priority order: faculty_admin > professor > student
      if (!matchingFaculty) {
        const priorityOrder = ['faculty_admin', 'professor', 'student'] as const;
        const sortedFaculties = [...faculties].sort((a, b) => {
          const aIndex = priorityOrder.indexOf(a.role);
          const bIndex = priorityOrder.indexOf(b.role);
          return aIndex - bIndex;
        });
        matchingFaculty = sortedFaculties[0] ?? null;
      }

      if (matchingFaculty) {
        // Just set the faculty context store - no need to switch backend context
        // since the JWT already has the correct context from login
        setCurrentFaculty(matchingFaculty.id, matchingFaculty.role);
      }
    }
  }, [faculties, setCurrentFaculty]);

  // Don't show for super_admin or if no faculties
  if (!user || user.isSuperAdmin) return null;
  if (faculties.length === 0) return null;

  // If only one faculty, show it as static badge with role
  if (faculties.length === 1 && faculties[0]) {
    const faculty = faculties[0];
    const RoleIcon = ROLE_ICONS[faculty.role];
    return (
      <Badge variant="secondary" className="gap-1">
        <RoleIcon className="h-3 w-3" />
        <span className="hidden sm:inline">{faculty.code}</span>
      </Badge>
    );
  }

  const currentFaculty = faculties.find((f) => f.id === currentFacultyId && f.role === currentFacultyRole);
  const CurrentRoleIcon = currentFaculty ? ROLE_ICONS[currentFaculty.role] : Building2;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1 sm:gap-2">
          <CurrentRoleIcon className="h-4 w-4" />
          <span className="max-w-32 truncate hidden sm:inline">
            {currentFaculty ? `${currentFaculty.code} (${ROLE_LABELS[currentFaculty.role]})` : 'Select Faculty'}
          </span>
          <ChevronDown className="h-3 w-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel>Switch Faculty & Role</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {faculties.map((faculty) => {
          const RoleIcon = ROLE_ICONS[faculty.role];
          const selected = isSelected(faculty);
          return (
            <DropdownMenuItem
              key={getFacultyRoleKey(faculty)}
              onClick={() => handleFacultyChange(faculty)}
              className="justify-between cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <RoleIcon className="h-4 w-4 text-muted-foreground" />
                <div className="flex flex-col">
                  <span className="font-medium">{faculty.code}</span>
                  <span className="text-xs text-muted-foreground">
                    {faculty.name} • {ROLE_LABELS[faculty.role]}
                  </span>
                </div>
              </div>
              {selected && <Check className="h-4 w-4" />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
