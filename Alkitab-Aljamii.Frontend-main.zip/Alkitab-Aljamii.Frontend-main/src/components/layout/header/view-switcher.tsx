'use client';

import { useEffect, useRef } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { UserCog, ChevronDown, Check, Shield, GraduationCap, BookUser } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuthStore, useViewContextStore, useFacultyContextStore } from '@/stores';
import { ROLE_HOME_ROUTES } from '@/lib/constants/routes';
import type { ViewRole, AvailableView } from '@/lib/api/users';

const VIEW_LABELS: Record<ViewRole, string> = {
  super_admin: 'Super Admin',
  faculty_admin: 'Faculty Admin',
  professor: 'Professor',
  student: 'Student',
};

const VIEW_ICONS: Record<ViewRole, typeof Shield> = {
  super_admin: Shield,
  faculty_admin: UserCog,
  professor: GraduationCap,
  student: BookUser,
};

/**
 * ViewSwitcher shows available views with faculty context.
 * Each view entry shows the role and faculty name for clarity.
 */
export function ViewSwitcher() {
  const router = useRouter();
  const pathname = usePathname();
  const user = useAuthStore((state) => state.user);
  const {
    availableViews,
    activeView,
    activeFacultyId,
    loadAvailableViews,
    clearContext,
  } = useViewContextStore();
  const { faculties, clearContext: clearFacultyContext } = useFacultyContextStore();
  const prevUserIdRef = useRef<string | null>(null);

  useEffect(() => {
    // Clear and reload when user changes
    if (user?.id !== prevUserIdRef.current) {
      if (prevUserIdRef.current !== null) {
        clearContext();
      }
      prevUserIdRef.current = user?.id ?? null;
    }
    if (user) {
      loadAvailableViews();
    }
  }, [user, loadAvailableViews, clearContext]);

  // Don't show if no user or only one view available
  if (!user || availableViews.length <= 1) return null;

  // Don't show for users who have faculties - they use the FacultySwitcher instead
  // The FacultySwitcher handles both faculty and view switching for these users
  if (faculties.length > 0) return null;

  const handleViewChange = async (view: AvailableView) => {
    if (view.role === activeView && view.facultyId === activeFacultyId) return;

    // Switch context on the backend to get a new scoped token
    const { switchContext } = useAuthStore.getState();
    const result = await switchContext({
      activeView: view.role,
      facultyId: view.facultyId,
    });

    if (result.success) {
      // Clear faculty context since faculties will be different for new view
      clearFacultyContext();

      // Force reload available views to sync with the new JWT token
      // This will set activeView/activeFacultyId from the server's currentView/currentFacultyId
      await loadAvailableViews(true);

      // Navigate to the appropriate dashboard for the new view
      const targetRoute = ROLE_HOME_ROUTES[view.role];
      if (targetRoute && !pathname.startsWith(targetRoute.replace(/\/$/, ''))) {
        router.push(targetRoute);
      }
    } else {
      // Switch failed - role may have been revoked, show error and refresh
      toast.error(result.message || 'This role is no longer available.');
      await loadAvailableViews(true);
    }
  };

  const CurrentIcon = activeView ? VIEW_ICONS[activeView] : UserCog;
  const currentView = availableViews.find(
    (v) => v.role === activeView && v.facultyId === activeFacultyId
  );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <CurrentIcon className="h-4 w-4" />
          <span className="max-w-28 truncate hidden sm:inline">
            {currentView
              ? currentView.facultyName
                ? `${VIEW_LABELS[currentView.role]} - ${currentView.facultyName}`
                : VIEW_LABELS[currentView.role]
              : 'Select View'}
          </span>
          <ChevronDown className="h-3 w-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel>Switch View</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {availableViews.map((view) => {
          const Icon = VIEW_ICONS[view.role];
          const isActive = view.role === activeView && view.facultyId === activeFacultyId;
          const key = view.facultyId ? `${view.role}-${view.facultyId}` : view.role;
          return (
            <DropdownMenuItem
              key={key}
              onClick={() => handleViewChange(view)}
              className="justify-between cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                <div className="flex flex-col">
                  <span className="font-medium">{VIEW_LABELS[view.role]}</span>
                  {view.facultyName && (
                    <span className="text-xs text-muted-foreground">{view.facultyName}</span>
                  )}
                </div>
              </div>
              {isActive && <Check className="h-4 w-4" />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
