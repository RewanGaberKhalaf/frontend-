'use client';

import { useEffect, useState } from 'react';
import { Coffee, BookOpen } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface IdlePromptDialogProps {
  /** Whether the user is idle */
  isIdle: boolean;
  /** Formatted idle duration */
  idleDuration?: string;
  /** Called when user confirms they're still reading */
  onContinueReading: () => void;
  /** Delay before showing the dialog after idle starts (ms) */
  showDelay?: number;
}

export function IdlePromptDialog({
  isIdle,
  idleDuration,
  onContinueReading,
  showDelay = 0,
}: IdlePromptDialogProps) {
  const [showDialog, setShowDialog] = useState(false);

  useEffect(() => {
    if (isIdle) {
      // Show dialog after delay
      const timeout = setTimeout(() => {
        setShowDialog(true);
      }, showDelay);

      return () => clearTimeout(timeout);
    }

    setShowDialog(false);
    return undefined;
  }, [isIdle, showDelay]);

  const handleContinue = () => {
    setShowDialog(false);
    onContinueReading();
  };

  return (
    <AlertDialog open={showDialog} onOpenChange={setShowDialog}>
      <AlertDialogContent className="max-w-sm">
        <AlertDialogHeader>
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
            <Coffee className="h-8 w-8 text-muted-foreground" />
          </div>
          <AlertDialogTitle className="text-center">
            Still reading?
          </AlertDialogTitle>
          <AlertDialogDescription className="text-center">
            You&apos;ve been inactive for a while. Your reading time is paused.
            {idleDuration && (
              <span className="block mt-1 text-xs">
                Idle for {idleDuration}
              </span>
            )}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="sm:justify-center">
          <AlertDialogAction onClick={handleContinue} className="gap-2">
            <BookOpen className="h-4 w-4" />
            Yes, continue reading
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export default IdlePromptDialog;
