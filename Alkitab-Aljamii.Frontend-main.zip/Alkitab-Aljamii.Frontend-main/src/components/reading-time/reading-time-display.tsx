'use client';

import { Clock, Pause, Coffee, Timer } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useReadingTimeDisplayStore } from '@/stores/reading-time-store';

interface ReadingTimeDisplayProps {
  /** Display variant */
  variant?: 'compact' | 'full';
  /** Additional class names */
  className?: string;
}

/**
 * Reading time display component that subscribes directly to the reading time store.
 * This isolates re-renders to this component only when the time updates every second.
 */
export function ReadingTimeDisplay({
  variant = 'compact',
  className,
}: ReadingTimeDisplayProps) {
  // Subscribe directly to store - only this component re-renders when time updates
  const formattedTime = useReadingTimeDisplayStore((s) => s.formattedTime);
  const formattedTotalTime = useReadingTimeDisplayStore((s) => s.formattedTotalTime);
  const isIdle = useReadingTimeDisplayStore((s) => s.isIdle);
  const isPaused = useReadingTimeDisplayStore((s) => s.isPaused);

  const getStatusIcon = () => {
    if (isPaused) return <Pause className="h-3 w-3" />;
    if (isIdle) return <Coffee className="h-3 w-3" />;
    return <Clock className="h-3 w-3" />;
  };

  const getStatusText = () => {
    if (isPaused) return 'Paused';
    if (isIdle) return 'Idle';
    return 'Reading';
  };

  const getStatusColor = () => {
    if (isPaused) return 'text-muted-foreground';
    if (isIdle) return 'text-yellow-600 dark:text-yellow-500';
    return 'text-green-600 dark:text-green-500';
  };

  if (variant === 'compact') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div
              className={cn(
                'flex items-center gap-1.5 sm:gap-2 px-1.5 sm:px-2 py-1 rounded-md text-xs sm:text-sm font-mono',
                'bg-muted/50 border border-border/50',
                className
              )}
            >
              <div className={cn('flex items-center gap-1', getStatusColor())}>
                {getStatusIcon()}
                <span className="tabular-nums">{formattedTime}</span>
              </div>
              <div className="h-3 w-px bg-border/50" />
              <div className="flex items-center gap-1 text-muted-foreground">
                <Timer className="h-3 w-3" />
                <span className="tabular-nums">{formattedTotalTime}</span>
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <div className="text-xs space-y-1">
              <p>{getStatusText()} • Session: {formattedTime}</p>
              <p>Total chapter time: {formattedTotalTime}</p>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Full variant with label
  return (
    <div
      className={cn(
        'flex items-center gap-2 px-3 py-1.5 rounded-lg',
        'bg-muted/50 border border-border/50',
        className
      )}
    >
      <div className={cn('flex items-center gap-1.5', getStatusColor())}>
        {getStatusIcon()}
        <span className="text-xs font-medium">{getStatusText()}</span>
      </div>
      <div className="h-4 w-px bg-border" />
      <div className="flex items-center gap-1.5">
        <Clock className="h-3 w-3 text-muted-foreground" />
        <span className="text-sm font-mono tabular-nums">{formattedTime}</span>
      </div>
      <div className="h-4 w-px bg-border" />
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Timer className="h-3 w-3" />
        <span className="text-sm font-mono tabular-nums">{formattedTotalTime}</span>
      </div>
    </div>
  );
}

export default ReadingTimeDisplay;
