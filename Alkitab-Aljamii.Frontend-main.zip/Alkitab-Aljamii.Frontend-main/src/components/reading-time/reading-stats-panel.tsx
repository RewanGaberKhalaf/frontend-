'use client';

import { useState } from 'react';
import { Clock, BookOpen, FileText, Target, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

interface ReadingStatsPanelProps {
  /** Current session time formatted */
  sessionTime: string;
  /** Session time in ms */
  sessionTimeMs: number;
  /** Total time on this chapter formatted */
  chapterTotalTime?: string;
  /** Total chapter time in ms */
  chapterTotalTimeMs?: number;
  /** Current page number */
  currentPage: number;
  /** Total pages in chapter */
  totalPages?: number;
  /** Time on current page formatted */
  pageTime?: string;
  /** Weekly reading goal in ms */
  weeklyGoalMs?: number;
  /** Weekly progress in ms */
  weeklyProgressMs?: number;
  /** Is currently idle */
  isIdle?: boolean;
  /** Is paused */
  isPaused?: boolean;
  /** Additional class names */
  className?: string;
  /** Default collapsed state */
  defaultCollapsed?: boolean;
}

function formatTimeFromMs(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }
  return `${seconds}s`;
}

interface StatItemProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  subValue?: string;
  className?: string;
}

function StatItem({ icon, label, value, subValue, className }: StatItemProps) {
  return (
    <div className={cn('flex items-center gap-3', className)}>
      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-muted">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <div className="flex items-baseline gap-1">
          <p className="text-sm font-medium tabular-nums">{value}</p>
          {subValue && (
            <span className="text-xs text-muted-foreground">{subValue}</span>
          )}
        </div>
      </div>
    </div>
  );
}

export function ReadingStatsPanel({
  sessionTime,
  sessionTimeMs,
  chapterTotalTime,
  chapterTotalTimeMs,
  currentPage,
  totalPages,
  pageTime,
  weeklyGoalMs,
  weeklyProgressMs,
  isIdle = false,
  isPaused = false,
  className,
  defaultCollapsed = false,
}: ReadingStatsPanelProps) {
  const [isOpen, setIsOpen] = useState(!defaultCollapsed);

  const weeklyProgressPercent = weeklyGoalMs && weeklyProgressMs
    ? Math.min(100, Math.round((weeklyProgressMs / weeklyGoalMs) * 100))
    : null;

  const getStatusBadge = () => {
    if (isPaused) {
      return (
        <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
          Paused
        </span>
      );
    }
    if (isIdle) {
      return (
        <span className="text-xs px-1.5 py-0.5 rounded bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-500">
          Idle
        </span>
      );
    }
    return (
      <span className="text-xs px-1.5 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-500">
        Active
      </span>
    );
  };

  return (
    <Card className={cn('overflow-hidden', className)}>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CardHeader className="py-3 px-4">
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              className="w-full justify-between p-0 h-auto hover:bg-transparent"
            >
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Reading Time
                {getStatusBadge()}
              </CardTitle>
              {isOpen ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </Button>
          </CollapsibleTrigger>
        </CardHeader>

        <CollapsibleContent>
          <CardContent className="pt-0 pb-4 px-4 space-y-4">
            {/* Session Time */}
            <StatItem
              icon={<Clock className="h-4 w-4 text-primary" />}
              label="This session"
              value={sessionTime}
              subValue={sessionTimeMs > 0 ? `(${formatTimeFromMs(sessionTimeMs)})` : undefined}
            />

            {/* Chapter Total Time */}
            {chapterTotalTime && (
              <StatItem
                icon={<BookOpen className="h-4 w-4 text-blue-500" />}
                label="Chapter total"
                value={chapterTotalTime}
                subValue={chapterTotalTimeMs ? `(${formatTimeFromMs(chapterTotalTimeMs)})` : undefined}
              />
            )}

            {/* Current Page */}
            <StatItem
              icon={<FileText className="h-4 w-4 text-orange-500" />}
              label="Current page"
              value={`Page ${currentPage}`}
              subValue={totalPages ? `of ${totalPages}` : undefined}
            />

            {/* Page Time */}
            {pageTime && (
              <div className="ml-11 text-xs text-muted-foreground">
                Time on page: {pageTime}
              </div>
            )}

            {/* Weekly Goal Progress */}
            {weeklyProgressPercent !== null && weeklyGoalMs && weeklyProgressMs && (
              <div className="pt-2 border-t">
                <StatItem
                  icon={<Target className="h-4 w-4 text-purple-500" />}
                  label="Weekly goal"
                  value={`${weeklyProgressPercent}%`}
                  subValue={`${formatTimeFromMs(weeklyProgressMs)} / ${formatTimeFromMs(weeklyGoalMs)}`}
                />
                <Progress
                  value={weeklyProgressPercent}
                  className="h-1.5 mt-2 ml-11"
                />
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

export default ReadingStatsPanel;
