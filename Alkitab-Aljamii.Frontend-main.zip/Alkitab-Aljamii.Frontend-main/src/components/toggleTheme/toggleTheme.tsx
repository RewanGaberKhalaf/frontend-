"use client";

import useThemeStore from "@/stores/theme-store";
import { Button } from "../ui/button";
import { Tooltip, TooltipTrigger, TooltipContent } from "../ui/tooltip";
import { Moon, Sun } from "lucide-react";
import { useTranslations } from "next-intl";

export function ToggleTheme() {
  const { theme, setTheme } = useThemeStore();
  const t = useTranslations();

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          aria-label={t('common.toggleTheme')}
        >
          {theme === "dark" ? (
            <Sun className="h-5 w-5" />
          ) : (
            <Moon className="h-5 w-5" />
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        {theme === "dark" ? t('nav.LightMode') : t('nav.DarkMode')}
      </TooltipContent>
    </Tooltip>
  );
}
