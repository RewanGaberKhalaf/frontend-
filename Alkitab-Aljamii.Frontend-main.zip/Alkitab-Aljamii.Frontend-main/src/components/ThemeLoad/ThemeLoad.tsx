"use client";

import useThemeStore from "@/stores/theme-store";
import { useEffect } from "react";


export default function ThemeInitializer() {
  const loadTheme = useThemeStore((s) => s.loadTheme);

  useEffect(() => {
    loadTheme();
  }, [loadTheme]);

  return null;
}
