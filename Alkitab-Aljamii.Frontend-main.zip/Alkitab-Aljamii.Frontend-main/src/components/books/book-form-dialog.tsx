'use client';

import { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Loader2, FileUp, X, FileText } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { booksApi } from '@/lib/api/books';
import { ImportDocumentDialog, type ImportResult } from './import-document-dialog';
import { CoverImageUpload } from './cover-image-upload';
import { htmlToJson } from '@/components/shared/rich-text-editor/html-to-json';
import type { Book, Subject, CreateBookDto, UpdateBookDto } from '@/types';

const bookFormSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  titleAr: z.string().max(200).optional(),
  description: z.string().max(2000).optional(),
  descriptionAr: z.string().max(2000).optional(),
  subjectId: z.string().min(1, 'Subject is required'),
  coverImageUrl: z.string().url().optional().or(z.literal('')),
});

type BookFormValues = z.infer<typeof bookFormSchema>;

interface BookFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  subjects: Subject[];
  book?: Book; // For editing
  onSuccess: (book: Book) => void;
}

export function BookFormDialog({
  open,
  onOpenChange,
  subjects,
  book,
  onSuccess,
}: BookFormDialogProps) {
  const t = useTranslations();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [pendingChapters, setPendingChapters] = useState<ImportResult['chapters']>([]);
  const [hasCover, setHasCover] = useState(!!book?.coverImageUrl);
  const isEditing = !!book;

  // Handle cover change - update hasCover state
  const handleCoverChange = useCallback((newHasCover: boolean) => {
    setHasCover(newHasCover);
  }, []);

  const form = useForm<BookFormValues>({
    resolver: zodResolver(bookFormSchema),
    defaultValues: {
      title: book?.title ?? '',
      titleAr: book?.titleAr ?? '',
      description: book?.description ?? '',
      descriptionAr: book?.descriptionAr ?? '',
      subjectId: book?.subjectId ?? '',
      coverImageUrl: book?.coverImageUrl ?? '',
    },
  });

  const onSubmit = async (values: BookFormValues) => {
    setIsSubmitting(true);
    try {
      let result: Book;

      if (isEditing && book) {
        const updateData: UpdateBookDto = {
          title: values.title,
          titleAr: values.titleAr || undefined,
          description: values.description || undefined,
          descriptionAr: values.descriptionAr || undefined,
          coverImageUrl: values.coverImageUrl || undefined,
        };
        result = await booksApi.update(book.id, updateData);
        toast.success(t('books.updateSuccess'));
      } else {
        const createData: CreateBookDto = {
          title: values.title,
          titleAr: values.titleAr || undefined,
          description: values.description || undefined,
          descriptionAr: values.descriptionAr || undefined,
          subjectId: values.subjectId,
          coverImageUrl: values.coverImageUrl || undefined,
        };
        result = await booksApi.create(createData);

        // Create chapters from imported document if any
        if (pendingChapters.length > 0) {
          for (let i = 0; i < pendingChapters.length; i++) {
            const chapter = pendingChapters[i];
            if (!chapter) continue;
            // Create chapter first
            const newChapter = await booksApi.createChapter(result.id, {
              title: chapter.title,
              order: i,
            });
            // Then update with content as ProseMirror JSON
            if (chapter.content) {
              const contentJson = htmlToJson(chapter.content);
              await booksApi.updateChapter(result.id, newChapter.id, {
                contentJson,
              });
            }
          }
          toast.success(t('books.createSuccessWithChapters', { count: pendingChapters.length }));
        } else {
          toast.success(t('books.createSuccess'));
        }
      }

      form.reset();
      setPendingChapters([]);
      onSuccess(result);
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      form.reset();
      setPendingChapters([]);
    }
    onOpenChange(newOpen);
  };

  const handleImport = async (result: ImportResult) => {
    setPendingChapters(result.chapters);
    // If no title set yet, use the first chapter title or filename
    if (!form.getValues('title') && result.chapters.length > 0 && result.chapters[0]) {
      form.setValue('title', result.chapters[0].title);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? t('books.editBook') : t('books.createBook')}
          </DialogTitle>
          <DialogDescription>
            {isEditing ? t('books.editBookDescription') : t('books.createBookDescription')}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('books.bookTitle')} (English)</FormLabel>
                  <FormControl>
                    <Input placeholder={t('books.titlePlaceholder')} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="titleAr"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('books.bookTitle')} (Arabic)</FormLabel>
                  <FormControl>
                    <Input
                      dir="rtl"
                      placeholder={t('books.titleArPlaceholder')}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {!isEditing && (
              <FormField
                control={form.control}
                name="subjectId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('subjects.title')}</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t('books.selectSubject')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.id} value={subject.id}>
                            {subject.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('books.description')} (English)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={t('books.descriptionPlaceholder')}
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="descriptionAr"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('books.description')} (Arabic)</FormLabel>
                  <FormControl>
                    <Textarea
                      dir="rtl"
                      placeholder={t('books.descriptionArPlaceholder')}
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Cover Image Upload - only when editing (need book ID) */}
            {isEditing && book && (
              <CoverImageUpload
                bookId={book.id}
                hasCover={hasCover}
                onCoverChange={handleCoverChange}
              />
            )}

            {/* Import from Document - only when creating */}
            {!isEditing && (
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{t('books.importFromDocument')}</span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setImportDialogOpen(true)}
                  >
                    <FileUp className="h-4 w-4 me-2" />
                    {pendingChapters.length > 0 ? t('books.changeDocument') : t('books.selectDocument')}
                  </Button>
                </div>
                {pendingChapters.length > 0 && (
                  <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">
                          {pendingChapters.length} {pendingChapters.length === 1 ? 'chapter' : 'chapters'} ready
                        </span>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => setPendingChapters([])}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {pendingChapters.slice(0, 5).map((chapter, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {chapter.title.length > 20 ? chapter.title.slice(0, 20) + '...' : chapter.title}
                        </Badge>
                      ))}
                      {pendingChapters.length > 5 && (
                        <Badge variant="outline" className="text-xs">
                          +{pendingChapters.length - 5} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
                disabled={isSubmitting}
              >
                {t('common.cancel')}
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {isEditing ? t('common.save') : t('common.create')}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>

      {/* Import Document Dialog */}
      <ImportDocumentDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
        onImport={handleImport}
      />
    </Dialog>
  );
}
