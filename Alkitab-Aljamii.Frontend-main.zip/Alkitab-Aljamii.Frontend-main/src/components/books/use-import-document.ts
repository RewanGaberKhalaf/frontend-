"use client";

import { useState, useCallback, useRef } from "react";
import { toast } from "sonner";
import mammoth from "mammoth";
import { mediaApi } from "@/lib/api/media";
import type { DetectedChapter, ImportResult, SplitOption } from "./import-document-types";

interface UseImportDocumentOptions {
  onImport: (result: ImportResult) => Promise<void>;
  onOpenChange: (open: boolean) => void;
}

export function useImportDocument({ onImport, onOpenChange }: UseImportDocumentOptions) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState("");

  const [file, setFile] = useState<File | null>(null);
  const [htmlContent, setHtmlContent] = useState<string>("");
  const [detectedChapters, setDetectedChapters] = useState<DetectedChapter[]>([]);
  const [splitOption, setSplitOption] = useState<SplitOption>("h1");
  const [h1Count, setH1Count] = useState(0);
  const [h2Count, setH2Count] = useState(0);
  const [warnings, setWarnings] = useState<string[]>([]);

  const reset = useCallback(() => {
    setFile(null);
    setHtmlContent("");
    setDetectedChapters([]);
    setSplitOption("h1");
    setH1Count(0);
    setH2Count(0);
    setWarnings([]);
    setProgress(0);
    setProgressText("");
  }, []);

  const handleOpenChange = useCallback(
    (newOpen: boolean) => {
      if (!newOpen) {
        reset();
      }
      onOpenChange(newOpen);
    },
    [onOpenChange, reset]
  );

  const detectChapters = useCallback(
    (html: string, option: SplitOption): DetectedChapter[] => {
      if (option === "single") {
        return [
          {
            id: "single",
            title: file?.name.replace(/\.[^/.]+$/, "") || "Imported Content",
            content: html,
            selected: true,
          },
        ];
      }

      const parser = new DOMParser();
      const doc = parser.parseFromString(`<div>${html}</div>`, "text/html");
      const container = doc.body.firstElementChild;
      if (!container) return [];

      const selector = option === "h1" ? "h1" : "h1, h2";
      const headings = container.querySelectorAll(selector);

      if (headings.length === 0) {
        return [
          {
            id: "single",
            title: file?.name.replace(/\.[^/.]+$/, "") || "Imported Content",
            content: html,
            selected: true,
          },
        ];
      }

      const chapters: DetectedChapter[] = [];
      let currentChapter: { title: string; elements: Element[] } | null = null;
      let introElements: Element[] = [];
      let chapterIndex = 0;

      const children = Array.from(container.children);
      for (const child of children) {
        const isTargetHeading =
          option === "h1"
            ? child.tagName === "H1"
            : child.tagName === "H1" || child.tagName === "H2";

        if (isTargetHeading) {
          if (currentChapter) {
            const content = currentChapter.elements.map((el) => el.outerHTML).join("\n");
            chapters.push({
              id: `chapter-${chapterIndex++}`,
              title: currentChapter.title,
              content,
              selected: true,
            });
          } else if (introElements.length > 0) {
            const content = introElements.map((el) => el.outerHTML).join("\n");
            chapters.push({
              id: `chapter-${chapterIndex++}`,
              title: "Introduction",
              content,
              selected: true,
            });
          }

          currentChapter = {
            title: child.textContent?.trim() || `Chapter ${chapterIndex + 1}`,
            elements: [child],
          };
        } else {
          if (currentChapter) {
            currentChapter.elements.push(child);
          } else {
            introElements.push(child);
          }
        }
      }

      if (currentChapter) {
        const content = currentChapter.elements.map((el) => el.outerHTML).join("\n");
        chapters.push({
          id: `chapter-${chapterIndex}`,
          title: currentChapter.title,
          content,
          selected: true,
        });
      } else if (introElements.length > 0) {
        const content = introElements.map((el) => el.outerHTML).join("\n");
        chapters.push({
          id: `chapter-${chapterIndex}`,
          title: file?.name.replace(/\.[^/.]+$/, "") || "Imported Content",
          content,
          selected: true,
        });
      }

      return chapters;
    },
    [file]
  );

  const countHeadings = useCallback((html: string) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(`<div>${html}</div>`, "text/html");
    const container = doc.body.firstElementChild;
    if (!container) return { h1: 0, h2: 0 };

    const h1s = container.querySelectorAll("h1").length;
    const h2s = container.querySelectorAll("h2").length;
    return { h1: h1s, h2: h2s };
  }, []);

  const processFile = useCallback(
    async (selectedFile: File) => {
      if (!selectedFile.name.endsWith(".docx")) {
        toast.error("Please select a .docx file");
        return;
      }

      setFile(selectedFile);
      setIsProcessing(true);
      setProgress(0);
      setProgressText("Reading file...");
      setWarnings([]);

      try {
        const arrayBuffer = await selectedFile.arrayBuffer();
        setProgress(20);
        setProgressText("Converting document...");

        let imageCount = 0;
        const conversionWarnings: string[] = [];

        // Map Word paragraph styles to HTML elements
        const styleMap = [
          // Title styles
          "p[style-name='Title'] => h1:fresh",
          "p[style-name='Subtitle'] => h2:fresh",
          // Heading styles (Word default)
          "p[style-name='Heading 1'] => h1:fresh",
          "p[style-name='Heading 2'] => h2:fresh",
          "p[style-name='Heading 3'] => h3:fresh",
          "p[style-name='Heading 4'] => h4:fresh",
          "p[style-name='Heading 5'] => h5:fresh",
          "p[style-name='Heading 6'] => h6:fresh",
          // Arabic heading styles
          "p[style-name='عنوان'] => h1:fresh",
          "p[style-name='عنوان 1'] => h1:fresh",
          "p[style-name='عنوان 2'] => h2:fresh",
          "p[style-name='عنوان 3'] => h3:fresh",
          // Quote styles
          "p[style-name='Quote'] => blockquote:fresh",
          "p[style-name='Intense Quote'] => blockquote:fresh",
          // List styles handled automatically by mammoth
        ];

        const result = await mammoth.convertToHtml(
          { arrayBuffer },
          {
            styleMap,
            convertImage: mammoth.images.imgElement(async (image) => {
              imageCount++;
              setProgressText(`Uploading image ${imageCount}...`);

              try {
                const imageBuffer = await image.read();
                const extension = image.contentType.split("/")[1] || "png";
                const uint8Array = new Uint8Array(imageBuffer);
                const blob = new Blob([uint8Array], { type: image.contentType });
                const imageFile = new File(
                  [blob],
                  `imported-image-${imageCount}.${extension}`,
                  { type: image.contentType }
                );

                const uploadedMedia = await mediaApi.upload({ file: imageFile });
                return { src: uploadedMedia.url };
              } catch {
                conversionWarnings.push(`Failed to upload image ${imageCount}`);
                return { src: "" };
              }
            }),
          }
        );

        setProgress(80);
        setProgressText("Analyzing structure...");

        if (result.messages.length > 0) {
          result.messages.forEach((msg) => {
            if (msg.type === "warning") {
              conversionWarnings.push(msg.message);
            }
          });
        }

        setWarnings(conversionWarnings);
        setHtmlContent(result.value);

        const headingCounts = countHeadings(result.value);
        setH1Count(headingCounts.h1);
        setH2Count(headingCounts.h2);

        if (headingCounts.h1 > 1) {
          setSplitOption("h1");
        } else if (headingCounts.h2 > 1) {
          setSplitOption("h2");
        } else {
          setSplitOption("single");
        }

        const chapters = detectChapters(
          result.value,
          headingCounts.h1 > 1 ? "h1" : headingCounts.h2 > 1 ? "h2" : "single"
        );
        setDetectedChapters(chapters);

        setProgress(100);
        setProgressText("Done!");
      } catch (error) {
        console.error("Error processing file:", error);
        toast.error("Failed to process document");
        reset();
      } finally {
        setIsProcessing(false);
      }
    },
    [detectChapters, countHeadings, reset]
  );

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const selectedFile = e.target.files?.[0];
      if (selectedFile) {
        processFile(selectedFile);
      }
    },
    [processFile]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);

      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile) {
        processFile(droppedFile);
      }
    },
    [processFile]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleSplitOptionChange = useCallback(
    (value: SplitOption) => {
      setSplitOption(value);
      if (htmlContent) {
        const chapters = detectChapters(htmlContent, value);
        setDetectedChapters(chapters);
      }
    },
    [htmlContent, detectChapters]
  );

  const toggleChapter = useCallback((id: string) => {
    setDetectedChapters((prev) =>
      prev.map((ch) => (ch.id === id ? { ...ch, selected: !ch.selected } : ch))
    );
  }, []);

  const handleImport = useCallback(async () => {
    const selectedChapters = detectedChapters.filter((ch) => ch.selected);
    if (selectedChapters.length === 0) {
      toast.error("Please select at least one chapter to import");
      return;
    }

    setIsImporting(true);
    try {
      await onImport({
        chapters: selectedChapters.map((ch) => ({
          title: ch.title,
          content: ch.content,
        })),
      });
      toast.success(`Imported ${selectedChapters.length} chapter(s)`);
      handleOpenChange(false);
    } catch (error) {
      console.error("Import error:", error);
      toast.error("Failed to import chapters");
    } finally {
      setIsImporting(false);
    }
  }, [detectedChapters, onImport, handleOpenChange]);

  const selectedCount = detectedChapters.filter((ch) => ch.selected).length;

  return {
    fileInputRef,
    isDragging,
    isProcessing,
    isImporting,
    progress,
    progressText,
    file,
    htmlContent,
    detectedChapters,
    splitOption,
    h1Count,
    h2Count,
    warnings,
    selectedCount,
    reset,
    handleOpenChange,
    handleFileSelect,
    handleDrop,
    handleDragOver,
    handleDragLeave,
    handleSplitOptionChange,
    toggleChapter,
    handleImport,
  };
}
