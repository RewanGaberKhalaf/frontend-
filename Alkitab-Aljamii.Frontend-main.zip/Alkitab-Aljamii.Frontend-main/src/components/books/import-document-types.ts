export interface DetectedChapter {
  id: string;
  title: string;
  content: string;
  selected: boolean;
}

export interface ImportResult {
  chapters: Array<{
    title: string;
    content: string;
  }>;
}

export interface ImportDocumentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (result: ImportResult) => Promise<void>;
}

export type SplitOption = "single" | "h1" | "h2";
