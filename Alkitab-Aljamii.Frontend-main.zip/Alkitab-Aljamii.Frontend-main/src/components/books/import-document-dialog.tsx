"use client";

import { Loader2, Upload, FileText, AlertCircle, CheckCircle2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import type { ImportDocumentDialogProps, SplitOption } from "./import-document-types";
import { useImportDocument } from "./use-import-document";

// Re-export types for backwards compatibility
export type { DetectedChapter, ImportResult } from "./import-document-types";

export function ImportDocumentDialog({
  open,
  onOpenChange,
  onImport,
}: ImportDocumentDialogProps) {
  const {
    fileInputRef,
    isDragging,
    isProcessing,
    isImporting,
    progress,
    progressText,
    file,
    htmlContent,
    detectedChapters,
    splitOption,
    h1Count,
    h2Count,
    warnings,
    selectedCount,
    reset,
    handleOpenChange,
    handleFileSelect,
    handleDrop,
    handleDragOver,
    handleDragLeave,
    handleSplitOptionChange,
    toggleChapter,
    handleImport,
  } = useImportDocument({ onImport, onOpenChange });

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Import Document</DialogTitle>
          <DialogDescription>
            Import content from a Word document (.docx) and split it into chapters.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col gap-4">
          {/* File Drop Zone */}
          {!file && (
            <div
              className={cn(
                "border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer",
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-muted-foreground/25 hover:border-primary/50"
              )}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".docx"
                className="hidden"
                onChange={handleFileSelect}
              />
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-1">Drop your Word document here</p>
              <p className="text-sm text-muted-foreground">
                or click to browse (.docx files only)
              </p>
            </div>
          )}

          {/* Processing State */}
          {isProcessing && (
            <div className="space-y-4 p-4">
              <div className="flex items-center gap-3">
                <Loader2 className="h-5 w-5 animate-spin" />
                <span>{progressText}</span>
              </div>
              <Progress value={progress} />
            </div>
          )}

          {/* File Selected - Show Options */}
          {file && !isProcessing && htmlContent && (
            <>
              {/* File Info */}
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <FileText className="h-8 w-8 text-blue-500" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{file.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB
                  </p>
                </div>
                <Button variant="ghost" size="sm" onClick={reset}>
                  Change
                </Button>
              </div>

              {/* Warnings */}
              {warnings.length > 0 && (
                <Alert variant="default">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <p className="font-medium mb-1">Conversion warnings:</p>
                    <ul className="list-disc list-inside text-sm">
                      {warnings.slice(0, 3).map((w, i) => (
                        <li key={i}>{w}</li>
                      ))}
                      {warnings.length > 3 && <li>...and {warnings.length - 3} more</li>}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              {/* Split Options */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Chapter Detection</Label>
                <RadioGroup
                  value={splitOption}
                  onValueChange={(v) => handleSplitOptionChange(v as SplitOption)}
                  className="space-y-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="single" id="single" />
                    <Label htmlFor="single" className="cursor-pointer">
                      Import as single chapter
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="h1" id="h1" disabled={h1Count === 0} />
                    <Label
                      htmlFor="h1"
                      className={cn("cursor-pointer", h1Count === 0 && "text-muted-foreground")}
                    >
                      Split at H1 headings ({h1Count} found)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="h2" id="h2" disabled={h2Count === 0} />
                    <Label
                      htmlFor="h2"
                      className={cn("cursor-pointer", h2Count === 0 && "text-muted-foreground")}
                    >
                      Split at H2 headings ({h2Count} found)
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Detected Chapters */}
              <div className="flex-1 min-h-0">
                <Label className="text-sm font-medium mb-2 block">
                  Chapters to Import ({selectedCount} selected)
                </Label>
                <ScrollArea className="h-[200px] border rounded-lg">
                  <div className="p-2 space-y-1">
                    {detectedChapters.map((chapter, index) => (
                      <div
                        key={chapter.id}
                        className={cn(
                          "flex items-center gap-3 p-2 rounded-md transition-colors",
                          chapter.selected ? "bg-primary/10" : "hover:bg-muted/50"
                        )}
                      >
                        <Checkbox
                          id={chapter.id}
                          checked={chapter.selected}
                          onCheckedChange={() => toggleChapter(chapter.id)}
                        />
                        <label htmlFor={chapter.id} className="flex-1 cursor-pointer">
                          <span className="text-muted-foreground text-sm mr-2">
                            {index + 1}.
                          </span>
                          {chapter.title}
                        </label>
                        {chapter.selected && (
                          <CheckCircle2 className="h-4 w-4 text-primary" />
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={() => handleOpenChange(false)} disabled={isImporting}>
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            disabled={!file || isProcessing || isImporting || selectedCount === 0}
          >
            {isImporting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Import {selectedCount > 0 ? `${selectedCount} Chapter${selectedCount > 1 ? "s" : ""}` : ""}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
