'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Upload, X, Loader2, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { booksApi } from '@/lib/api/books';
import { cn } from '@/lib/utils';

interface CoverImageUploadProps {
  bookId: string;
  hasCover: boolean;
  onCoverChange?: (hasCover: boolean) => void;
  className?: string;
}

export function CoverImageUpload({
  bookId,
  hasCover,
  onCoverChange,
  className,
}: CoverImageUploadProps) {
  const t = useTranslations();
  const [isUploading, setIsUploading] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Fetch cover URL when component mounts or hasCover changes
  useEffect(() => {
    if (hasCover && bookId) {
      booksApi.getCoverUrl(bookId)
        .then(({ url }) => setCoverUrl(url))
        .catch(() => setCoverUrl(null));
    } else {
      setCoverUrl(null);
    }
  }, [bookId, hasCover]);

  const handleUpload = async (file: File) => {
    if (!file.type.match(/^image\/(jpeg|png|webp)$/)) {
      toast.error(t('books.coverInvalidType'));
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error(t('books.coverTooLarge'));
      return;
    }

    setIsUploading(true);
    try {
      await booksApi.uploadCover(bookId, file);
      // Refresh cover URL
      const { url } = await booksApi.getCoverUrl(bookId);
      setCoverUrl(url);
      toast.success(t('books.coverUploadSuccess'));
      onCoverChange?.(true);
    } catch {
      toast.error(t('books.coverUploadError'));
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemove = async () => {
    setIsRemoving(true);
    try {
      await booksApi.removeCover(bookId);
      setCoverUrl(null);
      toast.success(t('books.coverRemoveSuccess'));
      onCoverChange?.(false);
    } catch {
      toast.error(t('books.coverRemoveError'));
    } finally {
      setIsRemoving(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleUpload(file);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      handleUpload(file);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  return (
    <div className={cn('space-y-2', className)}>
      <label className="text-sm font-medium">{t('books.coverImage')}</label>

      <div
        className={cn(
          'relative rounded-lg border-2 border-dashed transition-colors',
          isDragging ? 'border-primary bg-primary/5' : 'border-muted-foreground/25',
          coverUrl ? 'aspect-[2/3] max-w-[200px]' : 'p-4'
        )}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        {coverUrl ? (
          <div className="relative w-full h-full">
            <img
              src={coverUrl}
              alt="Book cover"
              className="w-full h-full object-cover rounded-md"
            />
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute -top-2 -right-2 h-6 w-6"
              onClick={handleRemove}
              disabled={isRemoving}
            >
              {isRemoving ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <X className="h-3 w-3" />
              )}
            </Button>
          </div>
        ) : (
          <label className="flex flex-col items-center justify-center gap-2 cursor-pointer py-4">
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleFileChange}
              disabled={isUploading}
            />
            {isUploading ? (
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            ) : (
              <>
                <div className="rounded-full bg-muted p-3">
                  <ImageIcon className="h-6 w-6 text-muted-foreground" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium">{t('books.uploadCover')}</p>
                  <p className="text-xs text-muted-foreground">
                    {t('books.coverHint')}
                  </p>
                </div>
              </>
            )}
          </label>
        )}
      </div>
    </div>
  );
}
