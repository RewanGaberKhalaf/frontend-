'use client';

import { useState, useMemo } from 'react';
import { ThumbsUp, ThumbsDown, User, Bot, ChevronDown, ChevronUp, Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { ChatMessage as ChatMessageType, ChatSource } from '@/lib/api/chat';

// Configure marked for simple output
marked.setOptions({
  breaks: true, // Convert \n to <br>
  gfm: true, // GitHub Flavored Markdown
});

interface ChatMessageProps {
  message: ChatMessageType;
  onFeedback?: (messageId: string, helpful: boolean) => void;
  isLast?: boolean;
  isStreaming?: boolean;
}

export function ChatMessage({ message, onFeedback, isLast, isStreaming }: ChatMessageProps) {
  const t = useTranslations('chat');
  const [showSources, setShowSources] = useState(false);
  const isUser = message.role === 'user';
  const sources = message.contextChunks ?? [];
  const isEmpty = !message.content || message.content.trim().length === 0;

  // Render markdown for assistant messages only
  const renderedContent = useMemo(() => {
    if (isUser || isEmpty) return null;
    const rawHtml = marked.parse(message.content) as string;
    return DOMPurify.sanitize(rawHtml);
  }, [message.content, isUser, isEmpty]);

  return (
    <div
      className={cn(
        'flex gap-3 p-3 rounded-lg',
        isUser ? 'bg-primary/5' : 'bg-muted/50'
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          'flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center',
          isUser ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'
        )}
      >
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 space-y-2">
        {/* Role label */}
        <div className="text-xs font-medium text-muted-foreground">
          {isUser ? t('you') : t('assistant')}
        </div>

        {/* Message content */}
        {isUser ? (
          <div className="text-sm whitespace-pre-wrap break-words">
            {message.content}
          </div>
        ) : isEmpty && isStreaming ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin" />
            {t('thinking')}
          </div>
        ) : (
          <div
            className="text-sm break-words chat-markdown [&>p]:my-1 [&>ul]:my-1 [&>ol]:my-1 [&>ul]:ps-4 [&>ol]:ps-4 [&>ul]:list-disc [&>ol]:list-decimal [&>li]:my-0.5 [&>h1]:text-base [&>h1]:font-bold [&>h2]:text-sm [&>h2]:font-semibold [&>h3]:text-sm [&>h3]:font-medium [&>code]:bg-muted [&>code]:px-1 [&>code]:rounded [&>pre]:bg-muted [&>pre]:p-2 [&>pre]:rounded [&>pre]:overflow-x-auto [&>blockquote]:border-s-2 [&>blockquote]:ps-3 [&>blockquote]:italic [&>blockquote]:text-muted-foreground"
            dangerouslySetInnerHTML={{ __html: renderedContent || '' }}
          />
        )}

        {/* Sources (for assistant messages) */}
        {!isUser && sources.length > 0 && (
          <div className="pt-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
              onClick={() => setShowSources(!showSources)}
            >
              {showSources ? (
                <ChevronUp className="w-3 h-3 me-1" />
              ) : (
                <ChevronDown className="w-3 h-3 me-1" />
              )}
              {t('sources', { count: sources.length })}
            </Button>

            {showSources && (
              <div className="mt-2 space-y-2">
                {sources.map((source: ChatSource, index: number) => (
                  <div
                    key={source.chunkId || index}
                    className="p-2 text-xs bg-background rounded border"
                  >
                    {source.chapterTitle && (
                      <div className="font-medium text-primary mb-1">
                        {source.chapterTitle}
                      </div>
                    )}
                    <div className="text-muted-foreground line-clamp-3">
                      {source.content}
                    </div>
                    <div className="mt-1 text-[10px] text-muted-foreground/70">
                      {t('relevance')}: {Math.round(source.score * 100)}%
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Feedback (for assistant messages, only on last message) */}
        {!isUser && isLast && onFeedback && (
          <div className="flex items-center gap-1 pt-2">
            <span className="text-xs text-muted-foreground me-2">
              {t('wasHelpful')}
            </span>
            <Button
              variant={message.helpful === true ? 'secondary' : 'ghost'}
              size="icon"
              className="h-7 w-7"
              onClick={() => onFeedback(message.id, true)}
              disabled={message.helpful !== null}
            >
              <ThumbsUp className="w-3.5 h-3.5" />
            </Button>
            <Button
              variant={message.helpful === false ? 'secondary' : 'ghost'}
              size="icon"
              className="h-7 w-7"
              onClick={() => onFeedback(message.id, false)}
              disabled={message.helpful !== null}
            >
              <ThumbsDown className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
