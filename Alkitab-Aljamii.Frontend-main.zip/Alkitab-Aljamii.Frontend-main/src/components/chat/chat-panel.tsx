'use client';

import { useEffect, useRef } from 'react';
import { Bot, Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useChatStore } from '@/stores/chat-store';
import { ChatMessage } from './chat-message';
import { ChatInput } from './chat-input';

interface ChatPanelProps {
  conversationType?: 'book_qa' | 'tos_qa';
  bookId?: string;
  facultyId?: string;
}

export function ChatPanel({ conversationType = 'book_qa', bookId, facultyId }: ChatPanelProps) {
  const t = useTranslations('chat');
  const scrollRef = useRef<HTMLDivElement>(null);

  const {
    activeConversation,
    messagesLoading,
    sendingMessage,
    streamingMessage,
    isEnabled,
    isHealthy,
    createConversation,
    sendMessageStream,
    submitFeedback,
  } = useChatStore();

  const messages = activeConversation?.messages ?? [];

  // Auto-scroll to bottom on new messages and during streaming
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length, streamingMessage]);

  // Create conversation if needed
  const handleSendMessage = async (message: string) => {
    if (!activeConversation) {
      // Create new conversation first
      const conversationId = await createConversation(conversationType, bookId, facultyId);
      if (!conversationId) return;
    }
    // Use streaming for real-time response
    await sendMessageStream(message);
  };

  // Check if currently streaming
  const isStreaming = streamingMessage !== null;

  if (!isEnabled) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-4 text-center">
        <Bot className="w-12 h-12 text-muted-foreground mb-3" />
        <p className="text-sm font-medium">{t('disabled')}</p>
        <p className="text-xs text-muted-foreground mt-1">{t('disabledDescription')}</p>
      </div>
    );
  }

  if (!isHealthy) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-4 text-center">
        <Bot className="w-12 h-12 text-destructive/50 mb-3" />
        <p className="text-sm font-medium">{t('unavailable')}</p>
        <p className="text-xs text-muted-foreground mt-1">{t('unavailableDescription')}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <ScrollArea className="flex-1 p-3" ref={scrollRef}>
        {messagesLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full py-8 text-center">
            <Bot className="w-10 h-10 text-primary/50 mb-3" />
            <p className="text-sm font-medium">{t('welcome')}</p>
            <p className="text-xs text-muted-foreground mt-1 max-w-[250px]">
              {t('welcomeDescription')}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {messages.map((msg, index) => (
              <ChatMessage
                key={msg.id}
                message={msg}
                isLast={index === messages.length - 1 && !isStreaming}
                onFeedback={submitFeedback}
                isStreaming={isStreaming && index === messages.length - 1 && msg.role === 'assistant'}
              />
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <ChatInput
        onSend={handleSendMessage}
        isSending={sendingMessage}
        disabled={messagesLoading}
      />
    </div>
  );
}
