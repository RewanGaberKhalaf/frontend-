'use client';

import { useEffect, useCallback } from 'react';
import { MessageCircle, X, Minus, Maximize2, ArrowLeft } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useChatStore, useAuthStore } from '@/stores';
import { ChatPanel } from './chat-panel';
import { ChatConversationList } from './chat-conversation-list';

interface ChatWidgetProps {
  position?: 'bottom-right' | 'bottom-left';
  defaultType?: 'book_qa' | 'tos_qa';
  bookId?: string;
  facultyId?: string;
  className?: string;
}

export function ChatWidget({
  position = 'bottom-right',
  defaultType = 'book_qa',
  bookId,
  facultyId,
  className,
}: ChatWidgetProps) {
  const t = useTranslations('chat');
  const { isAuthenticated } = useAuthStore();

  const {
    isChatOpen,
    isMinimized,
    isEnabled,
    healthChecked,
    conversations,
    conversationsLoading,
    activeConversationId,
    checkHealth,
    loadConversations,
    setActiveConversation,
    createConversation,
    deleteConversation,
    openChat,
    closeChat,
    minimizeChat,
    maximizeChat,
    setContext,
  } = useChatStore();

  // Check health and load conversations on mount
  useEffect(() => {
    if (isAuthenticated && !healthChecked) {
      checkHealth();
    }
  }, [isAuthenticated, healthChecked, checkHealth]);

  useEffect(() => {
    if (isAuthenticated && isEnabled && isChatOpen) {
      loadConversations(defaultType);
    }
  }, [isAuthenticated, isEnabled, isChatOpen, loadConversations, defaultType]);

  // Set context when bookId/facultyId changes
  useEffect(() => {
    setContext({
      bookId,
      facultyId,
    });
  }, [bookId, facultyId, setContext]);

  const handleNewChat = useCallback(async () => {
    await createConversation(defaultType, bookId, facultyId);
  }, [createConversation, defaultType, bookId, facultyId]);

  const handleBackToList = useCallback(() => {
    setActiveConversation(null);
  }, [setActiveConversation]);

  // Don't render if not authenticated or not enabled
  if (!isAuthenticated || (healthChecked && !isEnabled)) {
    return null;
  }

  const positionClasses = position === 'bottom-right'
    ? 'end-4 bottom-4'
    : 'start-4 bottom-4';

  return (
    <div className={cn('fixed z-50', positionClasses, className)}>
      {/* Chat Panel */}
      {isChatOpen && (
        <div
          className={cn(
            'mb-4 bg-background border rounded-xl shadow-xl overflow-hidden',
            'transition-all duration-200',
            isMinimized
              ? 'w-72 h-12'
              : 'w-[360px] sm:w-[400px] h-[500px] sm:h-[550px]'
          )}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b bg-muted/30">
            <div className="flex items-center gap-2">
              {activeConversationId && !isMinimized && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={handleBackToList}
                >
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              )}
              <MessageCircle className="w-5 h-5 text-primary" />
              <span className="font-semibold text-sm">{t('title')}</span>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={isMinimized ? maximizeChat : minimizeChat}
              >
                {isMinimized ? (
                  <Maximize2 className="w-4 h-4" />
                ) : (
                  <Minus className="w-4 h-4" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={closeChat}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Content */}
          {!isMinimized && (
            <div className="h-[calc(100%-52px)]">
              {activeConversationId ? (
                <ChatPanel
                  conversationType={defaultType}
                  bookId={bookId}
                  facultyId={facultyId}
                />
              ) : (
                <ChatConversationList
                  conversations={conversations}
                  activeId={activeConversationId}
                  loading={conversationsLoading}
                  onSelect={setActiveConversation}
                  onDelete={deleteConversation}
                  onNewChat={handleNewChat}
                />
              )}
            </div>
          )}
        </div>
      )}

      {/* Floating Button */}
      <Button
        onClick={isChatOpen ? closeChat : openChat}
        size="icon"
        className={cn(
          'h-14 w-14 rounded-full shadow-lg',
          'hover:scale-105 transition-transform'
        )}
      >
        {isChatOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
      </Button>
    </div>
  );
}
