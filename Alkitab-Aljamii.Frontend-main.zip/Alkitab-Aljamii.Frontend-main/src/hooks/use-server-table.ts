'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { useDebounce } from 'use-debounce';
import type { PaginatedResponse, PaginationParams } from '@/types';

interface UseServerTableOptions<TData, TFilters extends Record<string, unknown> = Record<string, never>> {
  /** Function to fetch data from API */
  fetchFn: (params: PaginationParams & TFilters) => Promise<PaginatedResponse<TData>>;
  /** Initial page size */
  initialPageSize?: number;
  /** Initial filters */
  initialFilters?: TFilters;
  /** Debounce delay for search in ms */
  searchDebounce?: number;
  /** Whether to fetch on mount */
  fetchOnMount?: boolean;
  /** Dependencies that should trigger a refetch when changed */
  deps?: unknown[];
}

interface UseServerTableReturn<TData, TFilters extends Record<string, unknown>> {
  /** Current data items */
  data: TData[];
  /** Pagination metadata */
  meta: PaginatedResponse<TData>['meta'] | null;
  /** Loading state */
  isLoading: boolean;
  /** Error message */
  error: string | null;
  /** Current page (1-indexed) */
  page: number;
  /** Current page size */
  pageSize: number;
  /** Current search value (raw input) */
  searchValue: string;
  /** Current sort column */
  sortBy: string | undefined;
  /** Current sort direction */
  sortOrder: 'asc' | 'desc' | undefined;
  /** Current filters */
  filters: TFilters;
  /** Set page */
  setPage: (page: number) => void;
  /** Set page size (resets to page 1) */
  setPageSize: (size: number) => void;
  /** Set search value */
  setSearch: (search: string) => void;
  /** Set sort */
  setSort: (sortBy: string | undefined, sortOrder: 'asc' | 'desc' | undefined) => void;
  /** Set a single filter value (resets to page 1) */
  setFilter: <K extends keyof TFilters>(key: K, value: TFilters[K]) => void;
  /** Set multiple filters at once (resets to page 1) */
  setFilters: (filters: Partial<TFilters>) => void;
  /** Reset all filters to initial state */
  resetFilters: () => void;
  /** Manually refetch data */
  refetch: () => Promise<void>;
}

const defaultMeta = {
  total: 0,
  page: 1,
  limit: 10,
  totalPages: 0,
  hasNextPage: false,
  hasPreviousPage: false,
};

export function useServerTable<TData, TFilters extends Record<string, unknown> = Record<string, never>>({
  fetchFn,
  initialPageSize = 10,
  initialFilters = {} as TFilters,
  searchDebounce = 300,
  fetchOnMount = true,
  deps = [],
}: UseServerTableOptions<TData, TFilters>): UseServerTableReturn<TData, TFilters> {
  // State
  const [data, setData] = useState<TData[]>([]);
  const [meta, setMeta] = useState<PaginatedResponse<TData>['meta'] | null>(null);
  const [isLoading, setIsLoading] = useState(fetchOnMount);
  const [error, setError] = useState<string | null>(null);

  // Pagination state
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(initialPageSize);

  // Search state
  const [searchValue, setSearchValue] = useState('');
  const [debouncedSearch] = useDebounce(searchValue, searchDebounce);

  // Sort state
  const [sortBy, setSortBy] = useState<string | undefined>(undefined);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | undefined>(undefined);

  // Filter state
  const [filters, setFiltersState] = useState<TFilters>(initialFilters);

  // Use ref for fetchFn to avoid dependency issues
  const fetchFnRef = useRef(fetchFn);
  fetchFnRef.current = fetchFn;

  // Fetch function
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const params: PaginationParams & TFilters = {
        page,
        limit: pageSize,
        search: debouncedSearch || undefined,
        sortBy,
        sortOrder: sortOrder?.toUpperCase() as 'ASC' | 'DESC' | undefined,
        ...filters,
      };

      const response = await fetchFnRef.current(params);
      setData(response.items);
      setMeta(response.meta);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch data';
      setError(message);
      setData([]);
      setMeta(defaultMeta);
    } finally {
      setIsLoading(false);
    }
  }, [page, pageSize, debouncedSearch, sortBy, sortOrder, filters]);

  // Auto-fetch when dependencies change
  useEffect(() => {
    if (fetchOnMount) {
      fetchData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchData, fetchOnMount, ...deps]);

  // Handlers
  const handleSetPage = useCallback((newPage: number) => {
    setPage(newPage);
  }, []);

  const handleSetPageSize = useCallback((newSize: number) => {
    setPageSize(newSize);
    setPage(1); // Reset to first page
  }, []);

  const handleSetSearch = useCallback((search: string) => {
    setSearchValue(search);
    setPage(1); // Reset to first page
  }, []);

  const handleSetSort = useCallback((newSortBy: string | undefined, newSortOrder: 'asc' | 'desc' | undefined) => {
    setSortBy(newSortBy);
    setSortOrder(newSortOrder);
    setPage(1); // Reset to first page when sorting changes
  }, []);

  const handleSetFilter = useCallback(<K extends keyof TFilters>(key: K, value: TFilters[K]) => {
    setFiltersState((prev) => ({ ...prev, [key]: value }));
    setPage(1); // Reset to first page
  }, []);

  const handleSetFilters = useCallback((newFilters: Partial<TFilters>) => {
    setFiltersState((prev) => ({ ...prev, ...newFilters }));
    setPage(1); // Reset to first page
  }, []);

  const handleResetFilters = useCallback(() => {
    setFiltersState(initialFilters);
    setSearchValue('');
    setSortBy(undefined);
    setSortOrder(undefined);
    setPage(1);
  }, [initialFilters]);

  return {
    data,
    meta,
    isLoading,
    error,
    page,
    pageSize,
    searchValue,
    sortBy,
    sortOrder,
    filters,
    setPage: handleSetPage,
    setPageSize: handleSetPageSize,
    setSearch: handleSetSearch,
    setSort: handleSetSort,
    setFilter: handleSetFilter,
    setFilters: handleSetFilters,
    resetFilters: handleResetFilters,
    refetch: fetchData,
  };
}
