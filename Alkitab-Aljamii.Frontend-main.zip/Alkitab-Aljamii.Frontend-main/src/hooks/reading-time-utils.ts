import type { PersistedSession } from "./reading-time-types";

/**
 * Format milliseconds to human readable time
 */
export function formatTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

/**
 * Generate a unique session ID
 */
export function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

/**
 * Storage key for persisting session data
 */
export function getStorageKey(chapterId: string): string {
  return `reading_session_${chapterId}`;
}

/**
 * Save session to sessionStorage
 */
export function saveSession(chapterId: string, data: PersistedSession): void {
  try {
    sessionStorage.setItem(getStorageKey(chapterId), JSON.stringify(data));
  } catch {
    // Ignore storage errors
  }
}

/**
 * Load session from sessionStorage
 * Returns null if no valid session exists or if session is too old (> 30 min)
 */
export function loadSession(chapterId: string): PersistedSession | null {
  try {
    const stored = sessionStorage.getItem(getStorageKey(chapterId));
    if (!stored) return null;

    const data = JSON.parse(stored) as PersistedSession;

    // Check if session is still valid (within 30 minutes)
    const thirtyMinutes = 30 * 60 * 1000;
    if (Date.now() - data.lastUpdated > thirtyMinutes) {
      sessionStorage.removeItem(getStorageKey(chapterId));
      return null;
    }

    return data;
  } catch {
    return null;
  }
}

/**
 * Clear session from sessionStorage
 */
export function clearSession(chapterId: string): void {
  try {
    sessionStorage.removeItem(getStorageKey(chapterId));
  } catch {
    // Ignore storage errors
  }
}

/**
 * Activity events to track for idle detection
 */
export const ACTIVITY_EVENTS = [
  "mousedown",
  "mousemove",
  "keydown",
  "scroll",
  "touchstart",
  "touchmove", // Mobile scrolling
  "touchend", // Mobile tap
  "wheel", // Mouse wheel
  "pointerdown", // Unified pointer events
  "pointermove",
] as const;
