'use client';

import { useEffect, useCallback, useRef, type RefObject } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';

/**
 * Hook to render LaTeX math formulas in HTML content.
 * Finds all elements with data-type="math-inline" or data-type="math-block"
 * and renders them using KaTeX.
 *
 * @param containerRef - Ref to the container element with HTML content
 * @param dependencies - Array of dependencies that trigger re-render (e.g., content changes)
 */
export function useMathRenderer(
  containerRef: RefObject<HTMLElement | null>,
  dependencies: unknown[] = []
) {
  const renderMath = useCallback(() => {
    if (!containerRef.current) return;
    renderMathInContainer(containerRef.current);
  }, [containerRef]);

  useEffect(() => {
    // Small delay to ensure DOM is ready
    const timeoutId = setTimeout(renderMath, 50);
    return () => clearTimeout(timeoutId);
  }, [renderMath, ...dependencies]);

  return { renderMath };
}

/**
 * Utility function to render math in a container element (non-hook version)
 * Useful for one-time rendering or in non-React contexts
 */
export function renderMathInContainer(container: HTMLElement) {
  // Find all math nodes that haven't been rendered yet
  // Check for data-math-rendered attribute to avoid re-rendering
  const inlineMathNodes = container.querySelectorAll('[data-type="math-inline"]:not([data-math-rendered])');
  const blockMathNodes = container.querySelectorAll('[data-type="math-block"]:not([data-math-rendered])');

  // Render inline math
  inlineMathNodes.forEach((node) => {
    const element = node as HTMLElement;
    const latex = element.getAttribute('data-latex');
    if (!latex) return;

    // Mark as rendered to prevent re-rendering
    element.setAttribute('data-math-rendered', 'true');

    try {
      katex.render(latex, element, {
        displayMode: false,
        throwOnError: false,
        errorColor: '#ef4444',
        trust: true,
        strict: false,
      });
    } catch {
      element.textContent = latex;
    }
  });

  // Render block math
  blockMathNodes.forEach((node) => {
    const element = node as HTMLElement;
    const latex = element.getAttribute('data-latex');
    if (!latex) return;

    // Mark as rendered to prevent re-rendering
    element.setAttribute('data-math-rendered', 'true');

    try {
      katex.render(latex, element, {
        displayMode: true,
        throwOnError: false,
        errorColor: '#ef4444',
        trust: true,
        strict: false,
      });
    } catch {
      element.textContent = latex;
    }
  });
}
