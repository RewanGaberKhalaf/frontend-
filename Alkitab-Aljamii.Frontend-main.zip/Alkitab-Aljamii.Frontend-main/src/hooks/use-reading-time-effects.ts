"use client";

import { useEffect, useRef, useCallback } from "react";
import { saveSession, clearSession, ACTIVITY_EVENTS } from "./reading-time-utils";

interface IdleTimerOptions {
  idleTimeoutMs: number;
  onIdleStart?: () => void;
  onIdleEnd?: () => void;
}

interface IdleTimerRefs {
  isIdleRef: React.MutableRefObject<boolean>;
  isPausedRef: React.MutableRefObject<boolean>;
}

interface IdleTimerReturn {
  resetIdleTimer: () => void;
  idleTimeoutRef: React.MutableRefObject<NodeJS.Timeout | null>;
  idleDurationIntervalRef: React.MutableRefObject<NodeJS.Timeout | null>;
  lastActivityRef: React.MutableRefObject<number>;
}

export function useIdleTimer(
  options: IdleTimerOptions,
  refs: IdleTimerRefs,
  setIsIdle: (value: boolean) => void,
  setIdleDurationMs: React.Dispatch<React.SetStateAction<number>>
): IdleTimerReturn {
  const { idleTimeoutMs, onIdleStart, onIdleEnd } = options;
  const { isIdleRef, isPausedRef } = refs;

  const idleTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const idleDurationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastActivityRef = useRef<number>(Date.now());

  const resetIdleTimer = useCallback(() => {
    lastActivityRef.current = Date.now();

    if (isIdleRef.current) {
      setIsIdle(false);
      setIdleDurationMs(0);
      if (idleDurationIntervalRef.current) {
        clearInterval(idleDurationIntervalRef.current);
        idleDurationIntervalRef.current = null;
      }
      onIdleEnd?.();
    }

    if (idleTimeoutRef.current) {
      clearTimeout(idleTimeoutRef.current);
    }

    idleTimeoutRef.current = setTimeout(() => {
      setIsIdle(true);
      setIdleDurationMs(0);
      idleDurationIntervalRef.current = setInterval(() => {
        setIdleDurationMs((prev) => prev + 1000);
      }, 1000);
      onIdleStart?.();
    }, idleTimeoutMs);
  }, [idleTimeoutMs, onIdleStart, onIdleEnd, isIdleRef, setIsIdle, setIdleDurationMs]);

  return { resetIdleTimer, idleTimeoutRef, idleDurationIntervalRef, lastActivityRef };
}

interface SessionPersistenceOptions {
  chapterId: string;
  sessionId: string | null;
  isTracking: boolean;
}

interface SessionPersistenceRefs {
  sessionTimeMsRef: React.MutableRefObject<number>;
  pageMsRef: React.MutableRefObject<number>;
  currentPageRef: React.MutableRefObject<number>;
}

export function useSessionPersistence(
  options: SessionPersistenceOptions,
  refs: SessionPersistenceRefs
): void {
  const { chapterId, sessionId, isTracking } = options;
  const { sessionTimeMsRef, pageMsRef, currentPageRef } = refs;

  useEffect(() => {
    if (!isTracking || !sessionId || !chapterId) return;

    const saveCurrentSession = () => {
      saveSession(chapterId, {
        sessionId,
        sessionTimeMs: sessionTimeMsRef.current,
        currentPage: currentPageRef.current,
        pageTimeMs: pageMsRef.current,
        lastUpdated: Date.now(),
      });
    };

    const saveInterval = setInterval(saveCurrentSession, 5000);

    const handleBeforeUnload = () => saveCurrentSession();
    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      clearInterval(saveInterval);
      window.removeEventListener("beforeunload", handleBeforeUnload);
      saveCurrentSession();
    };
  }, [isTracking, sessionId, chapterId, sessionTimeMsRef, pageMsRef, currentPageRef]);
}

interface VisibilityHandlerOptions {
  syncToBackend: () => Promise<void>;
  resetIdleTimer: () => void;
  setIsPaused: (paused: boolean) => void;
}

export function useVisibilityHandler(options: VisibilityHandlerOptions): void {
  const { syncToBackend, resetIdleTimer, setIsPaused } = options;

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsPaused(true);
        syncToBackend();
      } else {
        setIsPaused(false);
        resetIdleTimer();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [syncToBackend, resetIdleTimer, setIsPaused]);
}

export function useActivityListeners(
  resetIdleTimer: () => void,
  enabled: boolean
): void {
  useEffect(() => {
    if (!enabled) return;

    ACTIVITY_EVENTS.forEach((event) => {
      document.addEventListener(event, resetIdleTimer, { passive: true });
    });

    return () => {
      ACTIVITY_EVENTS.forEach((event) => {
        document.removeEventListener(event, resetIdleTimer);
      });
    };
  }, [resetIdleTimer, enabled]);
}

interface ChapterChangeOptions {
  chapterId: string;
  sessionId: string | null;
  chapterIdRef: React.MutableRefObject<string>;
  syncToBackend: (isSessionEnd?: boolean) => Promise<void>;
  resetState: () => void;
}

export function useChapterChange(options: ChapterChangeOptions): void {
  const { chapterId, sessionId, chapterIdRef, syncToBackend, resetState } = options;

  useEffect(() => {
    if (sessionId && chapterId !== chapterIdRef.current) {
      clearSession(chapterIdRef.current);
      syncToBackend(true);
      resetState();
    }
  }, [chapterId, sessionId, syncToBackend, resetState, chapterIdRef]);
}
