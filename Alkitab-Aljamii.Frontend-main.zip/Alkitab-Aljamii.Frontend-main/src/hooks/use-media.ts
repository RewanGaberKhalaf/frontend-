"use client";

import { useState, useCallback } from "react";
import { toast } from "sonner";
import {
  mediaApi,
  type MediaItem,
  type MediaType,
  type MediaQueryParams,
} from "@/lib/api";

export interface UseMediaOptions {
  /** Initial filter by type */
  initialType?: MediaType | "all";
  /** Initial page size */
  initialLimit?: number;
}

export interface UseMediaReturn {
  /** Current media items */
  items: MediaItem[];
  /** Total count of items */
  total: number;
  /** Current page */
  page: number;
  /** Items per page */
  limit: number;
  /** Total pages */
  totalPages: number;
  /** Loading state */
  isLoading: boolean;
  /** Uploading state */
  isUploading: boolean;
  /** Current filter type */
  filterType: MediaType | "all";
  /** Current search query */
  searchQuery: string;
  /** Fetch/refresh media items */
  fetchMedia: (params?: Partial<MediaQueryParams>) => Promise<void>;
  /** Upload a new media file */
  uploadMedia: (file: File, name?: string, tags?: string[]) => Promise<MediaItem | null>;
  /** Delete a media item */
  deleteMedia: (id: string) => Promise<boolean>;
  /** Update media metadata */
  updateMedia: (id: string, name?: string, tags?: string[]) => Promise<MediaItem | null>;
  /** Set filter type */
  setFilterType: (type: MediaType | "all") => void;
  /** Set search query */
  setSearchQuery: (query: string) => void;
  /** Set current page */
  setPage: (page: number) => void;
}

/**
 * Hook for managing media library operations
 */
export function useMedia(options: UseMediaOptions = {}): UseMediaReturn {
  const { initialType = "all", initialLimit = 20 } = options;

  const [items, setItems] = useState<MediaItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit] = useState(initialLimit);
  const [totalPages, setTotalPages] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [filterType, setFilterType] = useState<MediaType | "all">(initialType);
  const [searchQuery, setSearchQuery] = useState("");

  /**
   * Fetch media items from API
   */
  const fetchMedia = useCallback(
    async (params?: Partial<MediaQueryParams>) => {
      setIsLoading(true);
      try {
        const response = await mediaApi.getAll({
          type: params?.type ?? filterType,
          search: params?.search ?? (searchQuery || undefined),
          page: params?.page ?? page,
          limit: params?.limit ?? limit,
          tags: params?.tags,
        });

        // Handle potentially undefined response
        setItems(response?.items ?? []);
        setTotal(response?.meta?.total ?? 0);
        setTotalPages(response?.meta?.totalPages ?? 0);
        if (params?.page) setPage(params.page);
      } catch (error) {
        console.error("Failed to fetch media:", error);
        toast.error("Failed to load media library");
        // Reset to empty state on error
        setItems([]);
        setTotal(0);
        setTotalPages(0);
      } finally {
        setIsLoading(false);
      }
    },
    [filterType, searchQuery, page, limit]
  );

  /**
   * Upload a new media file
   */
  const uploadMedia = useCallback(
    async (file: File, name?: string, tags?: string[]): Promise<MediaItem | null> => {
      setIsUploading(true);
      try {
        const media = await mediaApi.upload({ file, name, tags });

        // Add to beginning of list
        setItems((prev) => [media, ...prev]);
        setTotal((prev) => prev + 1);

        toast.success("Media uploaded successfully");
        return media;
      } catch (error) {
        console.error("Failed to upload media:", error);
        toast.error("Failed to upload media");
        return null;
      } finally {
        setIsUploading(false);
      }
    },
    []
  );

  /**
   * Delete a media item
   */
  const deleteMedia = useCallback(async (id: string): Promise<boolean> => {
    try {
      await mediaApi.delete(id);

      // Remove from list
      setItems((prev) => prev.filter((item) => item.id !== id));
      setTotal((prev) => prev - 1);

      toast.success("Media deleted");
      return true;
    } catch (error) {
      console.error("Failed to delete media:", error);
      toast.error("Failed to delete media");
      return false;
    }
  }, []);

  /**
   * Update media metadata
   */
  const updateMedia = useCallback(
    async (id: string, name?: string, tags?: string[]): Promise<MediaItem | null> => {
      try {
        const updated = await mediaApi.update(id, { name, tags });

        // Update in list
        setItems((prev) =>
          prev.map((item) => (item.id === id ? updated : item))
        );

        toast.success("Media updated");
        return updated;
      } catch (error) {
        console.error("Failed to update media:", error);
        toast.error("Failed to update media");
        return null;
      }
    },
    []
  );

  /**
   * Set filter type and refetch
   */
  const handleSetFilterType = useCallback(
    (type: MediaType | "all") => {
      setFilterType(type);
      setPage(1);
    },
    []
  );

  /**
   * Set search query
   */
  const handleSetSearchQuery = useCallback((query: string) => {
    setSearchQuery(query);
    setPage(1);
  }, []);

  return {
    items,
    total,
    page,
    limit,
    totalPages,
    isLoading,
    isUploading,
    filterType,
    searchQuery,
    fetchMedia,
    uploadMedia,
    deleteMedia,
    updateMedia,
    setFilterType: handleSetFilterType,
    setSearchQuery: handleSetSearchQuery,
    setPage,
  };
}

export default useMedia;
