'use client';

import { useEffect, useCallback, useState } from 'react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { useRouter } from 'next/navigation';
import { useNotificationStore, useAuthStore } from '@/stores';
import type { Notification, QueryNotificationsParams, NotificationPreferences, UpdatePreferencesRequest } from '@/lib/api/notifications';

interface UseNotificationsResult {
  notifications: Notification[];
  unreadCount: number;
  isLoading: boolean;
  isConnected: boolean;
  hasNextPage: boolean;
  total: number;
  error: string | null;
  markAsRead: (ids: string[]) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotifications: (ids: string[]) => Promise<void>;
  loadMore: () => Promise<void>;
  refresh: () => Promise<void>;
  navigateToNotification: (notification: Notification) => void;
}

interface UseNotificationPreferencesResult {
  preferences: NotificationPreferences | null;
  isLoading: boolean;
  error: string | null;
  updatePreferences: (data: UpdatePreferencesRequest) => Promise<void>;
  refresh: () => Promise<void>;
}

/**
 * Hook for managing notifications list and actions
 */
export function useNotifications(params?: QueryNotificationsParams): UseNotificationsResult {
  const t = useTranslations('notifications');
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const {
    notifications,
    unreadCount,
    isLoading,
    isConnected,
    hasNextPage,
    total,
    error,
    fetchNotifications,
    fetchMoreNotifications,
    fetchUnreadCount,
    markAsRead: storeMarkAsRead,
    markAllAsRead: storeMarkAllAsRead,
    deleteNotifications: storeDeleteNotifications,
    connectSSE,
    disconnectSSE,
  } = useNotificationStore();

  // Initialize connection when authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      return;
    }

    fetchNotifications(params);
    fetchUnreadCount();
    connectSSE();

    return () => {
      disconnectSSE();
    };
  }, [isAuthenticated, params, fetchNotifications, fetchUnreadCount, connectSSE, disconnectSSE]);

  const markAsRead = useCallback(async (ids: string[]) => {
    try {
      await storeMarkAsRead(ids);
    } catch (err) {
      console.error('Failed to mark as read:', err);
      toast.error(t('preferences.saveError'));
    }
  }, [storeMarkAsRead, t]);

  const markAllAsRead = useCallback(async () => {
    try {
      await storeMarkAllAsRead();
      toast.success(t('markAllRead'));
    } catch (err) {
      console.error('Failed to mark all as read:', err);
      toast.error(t('preferences.saveError'));
    }
  }, [storeMarkAllAsRead, t]);

  const deleteNotifications = useCallback(async (ids: string[]) => {
    try {
      await storeDeleteNotifications(ids);
    } catch (err) {
      console.error('Failed to delete notifications:', err);
      toast.error(t('preferences.saveError'));
    }
  }, [storeDeleteNotifications, t]);

  const loadMore = useCallback(async () => {
    await fetchMoreNotifications();
  }, [fetchMoreNotifications]);

  const refresh = useCallback(async () => {
    await Promise.all([fetchNotifications(params), fetchUnreadCount()]);
  }, [fetchNotifications, fetchUnreadCount, params]);

  const navigateToNotification = useCallback((notification: Notification) => {
    if (!notification.isRead) {
      storeMarkAsRead([notification.id]);
    }
    if (notification.deepLink) {
      router.push(notification.deepLink);
    }
  }, [storeMarkAsRead, router]);

  return {
    notifications,
    unreadCount,
    isLoading,
    isConnected,
    hasNextPage,
    total,
    error,
    markAsRead,
    markAllAsRead,
    deleteNotifications,
    loadMore,
    refresh,
    navigateToNotification,
  };
}

/**
 * Hook for managing notification preferences
 */
export function useNotificationPreferences(): UseNotificationPreferencesResult {
  const t = useTranslations('notifications');
  const { isAuthenticated } = useAuthStore();
  const {
    preferences,
    isLoadingPreferences: isLoading,
    error,
    fetchPreferences,
    updatePreferences: storeUpdatePreferences,
  } = useNotificationStore();

  useEffect(() => {
    if (isAuthenticated) {
      fetchPreferences();
    }
  }, [isAuthenticated, fetchPreferences]);

  const updatePreferences = useCallback(async (data: UpdatePreferencesRequest) => {
    try {
      await storeUpdatePreferences(data);
      toast.success(t('preferences.saveSuccess'));
    } catch (err) {
      console.error('Failed to update preferences:', err);
      toast.error(t('preferences.saveError'));
    }
  }, [storeUpdatePreferences, t]);

  const refresh = useCallback(async () => {
    await fetchPreferences();
  }, [fetchPreferences]);

  return {
    preferences,
    isLoading,
    error,
    updatePreferences,
    refresh,
  };
}

/**
 * Simple hook for just the unread count (optimized for header badge)
 */
export function useUnreadNotificationCount(): { count: number; refresh: () => void } {
  const { unreadCount, fetchUnreadCount } = useNotificationStore();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) {
      fetchUnreadCount();
    }
  }, [isAuthenticated, fetchUnreadCount]);

  return {
    count: unreadCount,
    refresh: fetchUnreadCount,
  };
}
