'use client';

import { useState, useEffect, useCallback } from 'react';
import { subjectsApi } from '@/lib/api/subjects';
import { facultiesApi } from '@/lib/api/faculties';
import type { FilterOption } from '@/components/shared/filters/select-filter';
import type { Faculty, Subject } from '@/types';

interface UseFilterOptionsResult {
  options: FilterOption[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

interface SubjectFilterParams {
  facultyId?: string;
  limit?: number;
}

interface FacultyFilterParams {
  limit?: number;
}

/**
 * Hook to load subjects as filter options.
 */
export function useSubjectOptions(params?: SubjectFilterParams): UseFilterOptionsResult {
  const [options, setOptions] = useState<FilterOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOptions = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await subjectsApi.getAll({
        facultyId: params?.facultyId,
        limit: params?.limit ?? 100,
      });
      setOptions(
        response.items.map((item) => ({
          value: item.id,
          label: item.name,
          labelAr: item.nameAr,
        }))
      );
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load subjects';
      setError(message);
      setOptions([]);
    } finally {
      setIsLoading(false);
    }
  }, [params?.facultyId, params?.limit]);

  useEffect(() => {
    fetchOptions();
  }, [fetchOptions]);

  return { options, isLoading, error, refetch: fetchOptions };
}

/**
 * Hook to load faculties as filter options.
 */
export function useFacultyOptions(params?: FacultyFilterParams): UseFilterOptionsResult {
  const [options, setOptions] = useState<FilterOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOptions = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await facultiesApi.getAll({
        limit: params?.limit ?? 100,
      });
      setOptions(
        response.items.map((item: Faculty) => ({
          value: item.id,
          label: item.name,
          labelAr: item.nameAr,
        }))
      );
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load faculties';
      setError(message);
      setOptions([]);
    } finally {
      setIsLoading(false);
    }
  }, [params?.limit]);

  useEffect(() => {
    fetchOptions();
  }, [fetchOptions]);

  return { options, isLoading, error, refetch: fetchOptions };
}

/**
 * Generic hook for creating static filter options from translation keys.
 * Useful for status enums, roles, etc.
 */
export function useStaticOptions<T extends string>(
  values: T[],
  getLabel: (value: T) => string
): FilterOption[] {
  return values.map((value) => ({
    value,
    label: getLabel(value),
  }));
}
