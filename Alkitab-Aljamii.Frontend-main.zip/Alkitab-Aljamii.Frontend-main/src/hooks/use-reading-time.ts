"use client";

import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { readingTimeApi } from "@/lib/api/reading-time";
import { quizApi } from "@/lib/api/quiz";
import { useReadingTimeDisplayStore } from "@/stores/reading-time-store";
import type { PageTimeRecord } from "@/types";
import type { UseReadingTimeOptions, UseReadingTimeReturn, PageTimeRecord as LocalPageTimeRecord } from "./reading-time-types";
import { formatTime, generateSessionId, loadSession, clearSession } from "./reading-time-utils";
import { useIdleTimer, useSessionPersistence, useVisibilityHandler, useActivityListeners, useChapterChange } from "./use-reading-time-effects";

export function useReadingTime(options: UseReadingTimeOptions): UseReadingTimeReturn {
  const { chapterId, bookId, enabled = true, idleTimeoutMs = 120000, syncIntervalMs = 30000, onSessionStart, onSessionEnd, onIdleStart, onIdleEnd } = options;

  const setDisplayState = useReadingTimeDisplayStore((s) => s.setDisplayState);
  const resetDisplayStore = useReadingTimeDisplayStore((s) => s.reset);

  // State
  const [sessionTimeMs, setSessionTimeMs] = useState(0);
  const [totalChapterTimeMs, setTotalChapterTimeMs] = useState(0);
  const [isIdle, setIsIdle] = useState(false);
  const [idleDurationMs, setIdleDurationMs] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [currentPage, setCurrentPageState] = useState(1);
  const [pageTimeMs, setPageTimeMs] = useState(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [lastSyncAt, setLastSyncAt] = useState<Date | null>(null);

  // Refs
  const tickIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const syncIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const pendingTimeRef = useRef<number>(0);
  const pageRecordsRef = useRef<Map<number, LocalPageTimeRecord>>(new Map());
  const isIdleRef = useRef(false);
  const isPausedRef = useRef(false);
  const sessionIdRef = useRef<string | null>(null);
  const chapterIdRef = useRef(chapterId);
  const sessionTimeMsRef = useRef(sessionTimeMs);
  const pageMsRef = useRef(pageTimeMs);
  const currentPageRef = useRef(currentPage);
  const backendTotalTimeMsRef = useRef<number>(0); // Total time from backend (before this session)
  const syncedTimeMsRef = useRef<number>(0); // Time synced to backend during this session

  // Keep refs in sync
  useEffect(() => { isIdleRef.current = isIdle; }, [isIdle]);
  useEffect(() => { isPausedRef.current = isPaused; }, [isPaused]);
  useEffect(() => { sessionIdRef.current = sessionId; }, [sessionId]);
  useEffect(() => { chapterIdRef.current = chapterId; }, [chapterId]);
  useEffect(() => { sessionTimeMsRef.current = sessionTimeMs; }, [sessionTimeMs]);
  useEffect(() => { pageMsRef.current = pageTimeMs; }, [pageTimeMs]);
  useEffect(() => { currentPageRef.current = currentPage; }, [currentPage]);

  // Idle timer hook
  const { resetIdleTimer, idleTimeoutRef, idleDurationIntervalRef } = useIdleTimer(
    { idleTimeoutMs, onIdleStart, onIdleEnd },
    { isIdleRef, isPausedRef },
    setIsIdle,
    setIdleDurationMs
  );

  // Sync to backend
  const syncToBackend = useCallback(async (isSessionEnd = false) => {
    if (pendingTimeRef.current <= 0 || !chapterIdRef.current) return;
    const timeToSync = pendingTimeRef.current;
    pendingTimeRef.current = 0;

    try {
      const pageRecords: PageTimeRecord[] = Array.from(pageRecordsRef.current.entries()).map(
        ([pageNumber, record]) => ({ pageNumber, timeSpentMs: record.timeMs, firstViewedAt: record.firstSeen, lastViewedAt: record.lastSeen, viewCount: record.views })
      );
      await readingTimeApi.updateReadingTime({ chapterId: chapterIdRef.current, sessionId: sessionIdRef.current || undefined, readingTimeMs: timeToSync, pageRecords: pageRecords.length > 0 ? pageRecords : undefined, isSessionEnd });
      setLastSyncAt(new Date());
      syncedTimeMsRef.current += timeToSync;
      setTotalChapterTimeMs(backendTotalTimeMsRef.current + syncedTimeMsRef.current);
      pageRecordsRef.current.forEach((record) => { record.timeMs = 0; });
    } catch (error) {
      pendingTimeRef.current += timeToSync;
      console.error("[useReadingTime] Failed to sync:", error);
    }
  }, []);

  // Use extracted hooks
  useVisibilityHandler({ syncToBackend, resetIdleTimer, setIsPaused });
  useActivityListeners(resetIdleTimer, enabled && isTracking);
  useSessionPersistence({ chapterId, sessionId, isTracking }, { sessionTimeMsRef, pageMsRef, currentPageRef });
  useChapterChange({
    chapterId, sessionId, chapterIdRef, syncToBackend,
    resetState: useCallback(() => {
      setSessionTimeMs(0); setPageTimeMs(0); pageRecordsRef.current.clear(); pendingTimeRef.current = 0; setCurrentPageState(1);
    }, []),
  });

  // Update page time record
  const updatePageTime = useCallback((deltaMs: number, page: number) => {
    const now = new Date().toISOString();
    const existing = pageRecordsRef.current.get(page);
    if (existing) { existing.timeMs += deltaMs; existing.lastSeen = now; }
    else { pageRecordsRef.current.set(page, { timeMs: deltaMs, firstSeen: now, lastSeen: now, views: 1 }); }
  }, []);

  // Handle page change
  const setCurrentPage = useCallback((newPage: number) => {
    setCurrentPageState((prevPage) => {
      if (newPage === prevPage) return prevPage;
      const now = new Date().toISOString();
      const existing = pageRecordsRef.current.get(newPage);
      if (existing) { existing.views += 1; existing.lastSeen = now; }
      else { pageRecordsRef.current.set(newPage, { timeMs: 0, firstSeen: now, lastSeen: now, views: 1 }); }
      setPageTimeMs(0);
      return newPage;
    });
  }, []);

  // Start tracking effect
  useEffect(() => {
    if (!enabled || !chapterId) { setIsTracking(false); return; }

    const existingSession = loadSession(chapterId);
    if (existingSession) {
      setSessionId(existingSession.sessionId); setSessionTimeMs(existingSession.sessionTimeMs);
      setPageTimeMs(existingSession.pageTimeMs); setCurrentPageState(existingSession.currentPage);
    } else {
      setSessionId(generateSessionId()); setSessionTimeMs(0); setPageTimeMs(0);
    }

    // Reset synced time for new chapter
    syncedTimeMsRef.current = 0;

    // Fetch initial total time from backend
    quizApi.getChapterProgress(chapterId)
      .then((progress) => {
        const backendTotal = progress?.readingTimeMs ?? 0;
        backendTotalTimeMsRef.current = backendTotal;
        setTotalChapterTimeMs(backendTotal);
      })
      .catch((err) => {
        console.error("[useReadingTime] Failed to fetch initial progress:", err);
        backendTotalTimeMsRef.current = 0;
      });

    setIsTracking(true);
    pageRecordsRef.current.clear();
    pendingTimeRef.current = 0;
    onSessionStart?.();

    let internalSessionTimeMs = existingSession?.sessionTimeMs ?? 0;

    tickIntervalRef.current = setInterval(() => {
      if (!isIdleRef.current && !isPausedRef.current) {
        internalSessionTimeMs += 100;
        pendingTimeRef.current += 100;
      }
    }, 100);

    const displayUpdateInterval = setInterval(() => {
      // Total = backend total (fetched on mount) + time synced this session + pending time
      const currentTotalMs = backendTotalTimeMsRef.current + syncedTimeMsRef.current + pendingTimeRef.current;
      setDisplayState({
        formattedTime: formatTime(internalSessionTimeMs),
        formattedTotalTime: formatTime(currentTotalMs),
        totalTimeMs: currentTotalMs,
        isIdle: isIdleRef.current,
        isPaused: isPausedRef.current,
        isTracking: true,
      });
    }, 1000);

    syncIntervalRef.current = setInterval(() => {
      if (!isIdleRef.current && !isPausedRef.current) syncToBackend();
    }, syncIntervalMs);

    resetIdleTimer();

    return () => {
      if (tickIntervalRef.current) clearInterval(tickIntervalRef.current);
      if (syncIntervalRef.current) clearInterval(syncIntervalRef.current);
      if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
      if (idleDurationIntervalRef.current) clearInterval(idleDurationIntervalRef.current);
      clearInterval(displayUpdateInterval);
      syncToBackend(true);
      resetDisplayStore();
      onSessionEnd?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, chapterId, bookId]);

  // Track page time
  useEffect(() => {
    if (!isTracking || isIdle || isPaused) return;
    const pageTickInterval = setInterval(() => {
      if (!isIdleRef.current && !isPausedRef.current) updatePageTime(100, currentPage);
    }, 100);
    return () => clearInterval(pageTickInterval);
  }, [isTracking, isIdle, isPaused, currentPage, updatePageTime]);

  // Manual controls
  const pause = useCallback(() => { setIsPaused(true); syncToBackend(); }, [syncToBackend]);
  const resume = useCallback(() => { setIsPaused(false); resetIdleTimer(); }, [resetIdleTimer]);

  return useMemo(() => ({
    sessionTimeMs, totalChapterTimeMs, isIdle, idleDurationMs, formattedIdleDuration: formatTime(idleDurationMs),
    isPaused, currentPage, pageTimeMs, pause, resume, setCurrentPage, sessionId, isTracking, lastSyncAt,
    formattedSessionTime: formatTime(sessionTimeMs), formattedPageTime: formatTime(pageTimeMs),
  }), [sessionTimeMs, totalChapterTimeMs, isIdle, idleDurationMs, isPaused, currentPage, pageTimeMs, pause, resume, setCurrentPage, sessionId, isTracking, lastSyncAt]);
}

export default useReadingTime;
