'use client';

import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { useDebouncedCallback } from 'use-debounce';
import { usersApi, type UserFilterParams } from '@/lib/api/users';
import type { User, FacultyRole } from '@/types';

interface UseUsersResult {
  users: User[];
  isLoading: boolean;
  error: string | null;
  meta: { total: number; totalPages: number } | null;
  filters: UserFilterParams;
  searchValue: string;
  handleSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleRoleFilter: (role: string) => void;
  handleFacultyFilter: (facultyId: string) => void;
  refetch: () => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  restoreUser: (id: string) => Promise<void>;
  updatePassword: (id: string, password: string) => Promise<void>;
}

export function useUsers(): UseUsersResult {
  const t = useTranslations();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [filters, setFilters] = useState<UserFilterParams>({
    page: 1,
    limit: 10,
  });
  const [meta, setMeta] = useState<{
    total: number;
    totalPages: number;
  } | null>(null);

  const fetchUsers = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await usersApi.getAll(filters);
      setUsers(response.items);
      setMeta({
        total: response.meta.total,
        totalPages: response.meta.totalPages,
      });
    } catch (err) {
      console.error('Failed to fetch users:', err);
      setError('Failed to load users');
    } finally {
      setIsLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const debouncedSearch = useDebouncedCallback((value: string) => {
    setFilters((prev) => ({
      ...prev,
      search: value || undefined,
      page: 1,
    }));
  }, 300);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchValue(value);
    debouncedSearch(value);
  };

  const handleRoleFilter = (role: string) => {
    setFilters((prev) => ({
      ...prev,
      role: role === 'all' ? undefined : (role as FacultyRole),
      page: 1,
    }));
  };

  const handleFacultyFilter = (facultyId: string) => {
    setFilters((prev) => ({
      ...prev,
      facultyId: facultyId === 'all' ? undefined : facultyId,
      page: 1,
    }));
  };

  const deleteUser = async (id: string) => {
    try {
      await usersApi.delete(id);
      toast.success(t('users.deleteSuccess'));
      fetchUsers();
    } catch (error) {
      console.error('Failed to delete user:', error);
      toast.error(t('users.deleteError'));
      throw error;
    }
  };

  const restoreUser = async (id: string) => {
    try {
      await usersApi.restore(id);
      toast.success(t('users.restoreSuccess'));
      fetchUsers();
    } catch (error) {
      console.error('Failed to restore user:', error);
      toast.error(t('users.restoreError'));
      throw error;
    }
  };

  const updatePassword = async (id: string, password: string) => {
    if (password.length < 8) {
      toast.error(t('users.passwordTooShort'));
      throw new Error('Password too short');
    }
    try {
      await usersApi.updatePassword(id, password);
      toast.success(t('users.passwordUpdateSuccess'));
    } catch (error) {
      console.error('Failed to update password:', error);
      toast.error(t('users.passwordUpdateError'));
      throw error;
    }
  };

  return {
    users,
    isLoading,
    error,
    meta,
    filters,
    searchValue,
    handleSearchChange,
    handleRoleFilter,
    handleFacultyFilter,
    refetch: fetchUsers,
    deleteUser,
    restoreUser,
    updatePassword,
  };
}
