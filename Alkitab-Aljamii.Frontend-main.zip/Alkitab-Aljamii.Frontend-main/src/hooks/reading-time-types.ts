export interface UseReadingTimeOptions {
  /** Chapter ID to track */
  chapterId: string;
  /** Book ID for context */
  bookId: string;
  /** Enable/disable tracking */
  enabled?: boolean;
  /** Idle timeout in ms (default: 120000 = 2 min) */
  idleTimeoutMs?: number;
  /** Sync interval in ms (default: 30000 = 30 sec) */
  syncIntervalMs?: number;
  /** Callback when session starts */
  onSessionStart?: () => void;
  /** Callback when session ends */
  onSessionEnd?: () => void;
  /** Callback when idle starts */
  onIdleStart?: () => void;
  /** Callback when idle ends */
  onIdleEnd?: () => void;
}

export interface UseReadingTimeReturn {
  /** Current session duration in ms */
  sessionTimeMs: number;
  /** Total time on this chapter (from all sessions) */
  totalChapterTimeMs: number;
  /** Is currently idle */
  isIdle: boolean;
  /** How long user has been idle in ms */
  idleDurationMs: number;
  /** Formatted idle duration */
  formattedIdleDuration: string;
  /** Is manually paused or tab hidden */
  isPaused: boolean;
  /** Current page number */
  currentPage: number;
  /** Time on current page in ms */
  pageTimeMs: number;
  /** Pause tracking */
  pause: () => void;
  /** Resume tracking */
  resume: () => void;
  /** Set current page (for page change tracking) */
  setCurrentPage: (page: number) => void;
  /** Current session ID */
  sessionId: string | null;
  /** Is tracking active */
  isTracking: boolean;
  /** Last sync timestamp */
  lastSyncAt: Date | null;
  /** Formatted session time (MM:SS or HH:MM:SS) */
  formattedSessionTime: string;
  /** Formatted page time (MM:SS) */
  formattedPageTime: string;
}

export interface PersistedSession {
  sessionId: string;
  sessionTimeMs: number;
  currentPage: number;
  pageTimeMs: number;
  lastUpdated: number;
}

export interface PageTimeRecord {
  timeMs: number;
  firstSeen: string;
  lastSeen: string;
  views: number;
}
