import { Suspense } from 'react';
import { getTranslations } from 'next-intl/server';
import { BookOpen } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LoginForm } from '@/components/auth';

export default async function LoginPage() {
  const t = await getTranslations();

  return (
    <div className="space-y-6">
      {/* Mobile branding - shown only on smaller screens */}
      <div className="lg:hidden text-center space-y-3">
        <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <BookOpen className="h-8 w-8" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground">{t('app.name')}</h1>
        </div>
      </div>

      <Card>
        <CardHeader className="text-center space-y-1">
          <CardTitle className="text-2xl">{t('auth.loginTitle')}</CardTitle>
          <CardDescription>{t('auth.loginSubtitle')}</CardDescription>
        </CardHeader>
        <CardContent>
          <Suspense fallback={<div className="flex justify-center py-4">{t('common.loading')}</div>}>
            <LoginForm />
          </Suspense>
        </CardContent>
      </Card>
    </div>
  );
}
