import { Suspense } from 'react';
import { getTranslations } from 'next-intl/server';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CompleteProfileForm } from '@/components/auth';

export default async function CompleteProfilePage() {
  const t = await getTranslations();

  return (
    <Card>
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">{t('auth.completeProfileTitle')}</CardTitle>
        <CardDescription>{t('auth.completeProfileSubtitle')}</CardDescription>
      </CardHeader>
      <CardContent>
        <Suspense fallback={<div>{t('common.loading')}</div>}>
          <CompleteProfileForm />
        </Suspense>
      </CardContent>
    </Card>
  );
}
