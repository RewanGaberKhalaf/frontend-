import Image from 'next/image';
import { LocaleSwitcher } from '@/components/shared/locale-switcher';
import { ToggleTheme } from '@/components/toggleTheme/toggleTheme';

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="relative flex min-h-screen">
      {/* Left side - Branding panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-white/10" />
        <div className="absolute -bottom-32 -right-32 w-[500px] h-[500px] rounded-full bg-white/5" />
        <div className="absolute top-1/2 left-1/4 w-64 h-64 rounded-full bg-white/5" />

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center items-center w-full px-8 text-primary-foreground">
          <div className="space-y-8 w-full max-w-lg">
            {/* Logo */}
            <div className="bg-white/95 rounded-2xl p-4 shadow-lg">
              <Image
                src="/logo-large.png"
                alt="Alexandria University"
                width={500}
                height={125}
                className="w-full h-auto object-contain"
                priority
              />
            </div>

            <div className="text-center">
              <h1 className="text-3xl font-bold tracking-tight">
                Digital Library
              </h1>
              <p className="text-lg text-white/80 mt-3 leading-relaxed">
                Access your courses, lecture materials, and academic resources all in one place.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="flex flex-1 flex-col bg-background">
        {/* Top bar with logo for mobile */}
        <div className="flex items-center justify-between gap-2 p-4">
          {/* Mobile logo */}
          <div className="lg:hidden">
            <Image
              src="/logo-large.png"
              alt="Alexandria University"
              width={180}
              height={45}
              className="h-10 w-auto object-contain"
              priority
            />
          </div>
          <div className="hidden lg:block" />
          <div className="flex items-center gap-2">
            <ToggleTheme />
            <LocaleSwitcher />
          </div>
        </div>

        {/* Form container */}
        <div className="flex flex-1 items-center justify-center p-6">
          <div className="w-full max-w-md">
            {children}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Alexandria University
        </div>
      </div>
    </div>
  );
}
