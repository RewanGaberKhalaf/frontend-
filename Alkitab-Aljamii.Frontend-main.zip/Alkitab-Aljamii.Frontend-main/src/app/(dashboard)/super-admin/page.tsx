'use client';

import { useState, useEffect } from 'react';
import { Users, Building2, BookOpen, Loader2, Clock, ArrowRight, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { statsApi, facultiesApi, type SuperAdminStats, type FacultyAdminConflict } from '@/lib/api';
import { ChartTooltip, ChartLegend } from '@/components/shared/chart-tooltip';
import { AdminConflictAlert } from '@/components/faculties';
import { LayoutDashboard } from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  approved: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  rejected: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
};

export default function SuperAdminDashboard() {
  const t = useTranslations();
  const locale = useLocale();
  void locale; // Used for locale-aware rendering

  const [stats, setStats] = useState<SuperAdminStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [conflicts, setConflicts] = useState<FacultyAdminConflict[]>([]);
  const [conflictsLoading, setConflictsLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const data = await statsApi.getSuperAdminStats();
        setStats(data);
      } catch {
        toast.error(t('dashboard.failedToLoadStats'));
      } finally {
        setIsLoading(false);
      }
    };
    loadStats();
  }, [t]);

  const loadConflicts = async () => {
    try {
      const data = await facultiesApi.getAdminConflicts();
      setConflicts(data);
    } catch {
      // Silently fail - conflicts are not critical
    } finally {
      setConflictsLoading(false);
    }
  };

  useEffect(() => {
    loadConflicts();
  }, [locale]);

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const statCards = [
    { title: t('dashboard.superAdmin.totalUsers'), value: stats?.totalUsers ?? 0, icon: Users, desc: t('dashboard.superAdmin.registeredUsers'), href: '/super-admin/users', color: 'text-blue-600' },
    { title: t('dashboard.superAdmin.faculties'), value: stats?.totalFaculties ?? 0, icon: Building2, desc: t('dashboard.superAdmin.academicDepartments'), href: '/super-admin/faculties', color: 'text-purple-600' },
    { title: t('dashboard.superAdmin.subjects'), value: stats?.totalSubjects ?? 0, icon: BookOpen, desc: t('dashboard.superAdmin.coursesOffered'), href: '/super-admin/subjects', color: 'text-emerald-600' },
    { title: t('dashboard.superAdmin.books'), value: stats?.totalBooks ?? 0, icon: BookOpen, desc: t('dashboard.superAdmin.pendingCount', { count: stats?.pendingBooks ?? 0 }), href: '/super-admin/books', color: 'text-orange-600' },
  ];

  const bookStatusData = [
    { name: t('books.approved'), value: stats?.approvedBooks ?? 0, color: '#10b981' },
    { name: t('books.pending'), value: stats?.pendingBooks ?? 0, color: '#f59e0b' },
    { name: t('books.rejected'), value: stats?.rejectedBooks ?? 0, color: '#ef4444' },
    { name: t('books.published'), value: stats?.publishedBooks ?? 0, color: '#3b82f6' },
  ].filter(item => item.value > 0);

  const booksByFacultyData = (stats?.booksByFaculty ?? [])
    .filter(item => item.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5)
    .map(item => ({ ...item, name: item.facultyName }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('dashboard.title')}</h2>
          <p className="text-muted-foreground">{t('dashboard.superAdmin.subtitle')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/super-admin/users/new">
            <Button variant="outline" size="sm"><UserPlus className="me-2 h-4 w-4" />{t('users.addUser')}</Button>
          </Link>
          {(stats?.pendingBooks ?? 0) > 0 && (
            <Link href="/super-admin/books?status=pending">
              <Button size="sm"><Clock className="me-2 h-4 w-4" />{t('dashboard.superAdmin.reviewPending', { count: stats?.pendingBooks ?? 0 })}</Button>
            </Link>
          )}
        </div>
      </div>

      {/* Faculty Admin Conflicts Alert */}
      {!conflictsLoading && (
        <AdminConflictAlert conflicts={conflicts} onConflictResolved={loadConflicts} />
      )}

      {/* Stat Cards */}
      <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
        {statCards.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-xl sm:text-2xl font-bold">{stat.value.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground truncate">{stat.desc}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
        {/* Book Status Pie Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.superAdmin.bookStatus')}</CardTitle>
          </CardHeader>
          <CardContent>
            {bookStatusData.length > 0 ? (
              <div className="space-y-2">
                <div className="h-[180px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={bookStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {bookStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<ChartTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <ChartLegend items={bookStatusData} />
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">{t('common.noData')}</p>
            )}
          </CardContent>
        </Card>

        {/* Total Books */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.superAdmin.totalBooks')}</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center h-[220px]">
            <div className="text-5xl font-bold text-primary">{stats?.totalBooks ?? 0}</div>
            <p className="text-sm text-muted-foreground mt-2">{t('dashboard.superAdmin.booksInSystem')}</p>
            <div className="flex gap-4 mt-4 text-sm">
              <div className="text-center">
                <div className="font-semibold text-green-600">{stats?.publishedBooks ?? 0}</div>
                <div className="text-xs text-muted-foreground">{t('books.published')}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-blue-600">{stats?.approvedBooks ?? 0}</div>
                <div className="text-xs text-muted-foreground">{t('books.approved')}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Books by Faculty Bar Chart */}
        <Card className="md:col-span-2 xl:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.superAdmin.booksByFaculty')}</CardTitle>
          </CardHeader>
          <CardContent>
            {booksByFacultyData.length > 0 ? (
              <div className="h-[200px]" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={booksByFacultyData}
                    layout="vertical"
                    margin={{ left: 0, right: 16, top: 5, bottom: 5 }}
                  >
                    <XAxis type="number" hide />
                    <YAxis
                      type="category"
                      dataKey="facultyName"
                      width={95}
                      tick={{ fontSize: 11 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value: string) => value.length > 14 ? `${value.slice(0, 14)}...` : value}
                    />
                    <Tooltip content={<ChartTooltip />} cursor={false} />
                    <Bar
                      dataKey="count"
                      fill="#3b82f6"
                      radius={[0, 4, 4, 0]}
                      barSize={20}
                      activeBar={{ fill: '#2563eb' }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">{t('common.noData')}</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Row */}
      <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        {/* Recent Books */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-sm font-medium">{t('dashboard.superAdmin.recentBooks')}</CardTitle>
              <CardDescription className="text-xs">{t('dashboard.superAdmin.latestBooks')}</CardDescription>
            </div>
            <Link href="/super-admin/books">
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(stats?.recentBooks ?? []).length > 0 ? (
              <div className="space-y-2">
                {stats?.recentBooks.map((book) => (
                  <div key={book.id} className="flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{book.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{book.subjectName} &bull; {book.authorName}</p>
                    </div>
                    <Badge variant="secondary" className={`shrink-0 text-xs ${STATUS_COLORS[book.status]}`}>
                      {t(`status.${book.status}`)}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">{t('dashboard.noRecentBooks')}</p>
            )}
          </CardContent>
        </Card>

        {/* Recent Users */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-sm font-medium">{t('dashboard.superAdmin.recentUsers')}</CardTitle>
              <CardDescription className="text-xs">{t('dashboard.superAdmin.newRegistrations')}</CardDescription>
            </div>
            <Link href="/super-admin/users">
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(stats?.recentUsers ?? []).length > 0 ? (
              <div className="space-y-2">
                {stats?.recentUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{user.firstName} {user.lastName}</p>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0">
                      {new Date(user.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">{t('dashboard.noRecentUsers')}</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">{t('dashboard.quickActions')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Link href="/super-admin/faculties/new">
            <Button variant="outline" size="sm"><Building2 className="me-2 h-4 w-4" />{t('faculties.addFaculty')}</Button>
          </Link>
          <Link href="/super-admin/users/new">
            <Button variant="outline" size="sm"><UserPlus className="me-2 h-4 w-4" />{t('users.addUser')}</Button>
          </Link>
          <Link href="/super-admin/books">
            <Button variant="outline" size="sm"><BookOpen className="me-2 h-4 w-4" />{t('dashboard.superAdmin.manageBooks')}</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
