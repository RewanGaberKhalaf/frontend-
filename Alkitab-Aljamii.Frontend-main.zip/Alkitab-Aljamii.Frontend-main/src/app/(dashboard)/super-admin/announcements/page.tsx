'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { AnnouncementList } from '@/components/notifications';
import { facultiesApi } from '@/lib/api/faculties';
import { subjectsApi } from '@/lib/api/subjects';
import type { Faculty, Subject } from '@/types';

export default function SuperAdminAnnouncementsPage() {
  const t = useTranslations('notifications.announcements');
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);

  // Load all faculties and subjects
  useEffect(() => {
    const loadData = async () => {
      try {
        const [facultiesRes, subjectsRes] = await Promise.all([
          facultiesApi.getAll({ limit: 100 }),
          subjectsApi.getAll({ limit: 500 }),
        ]);
        setFaculties(facultiesRes.items);
        setSubjects(subjectsRes.items);
      } catch {
        // Silently fail
      }
    };
    loadData();
  }, []);

  return (
    <AnnouncementList
      faculties={faculties}
      subjects={subjects}
      allowedRoles={['faculty_admin', 'professor', 'student']}
      hideFacultySelect={false}
      hideSubjectSelect={false}
      hideRoleSelect={false}
      title={t('title')}
      description="Send announcements to any users across the platform"
    />
  );
}
