'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Building2, Search, Upload } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { QuickUploadModal } from '@/components/bulkImport';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, ConfirmDialog, PageHeader } from '@/components/shared';
import { useFacultyColumns } from '@/components/faculties';
import { useServerTable } from '@/hooks';
import { facultiesApi, type FacultyFilterParams } from '@/lib/api/faculties';
import type { Faculty } from '@/types';

type FacultyFilters = Omit<FacultyFilterParams, keyof import('@/types').PaginationParams>;

export default function FacultiesPage() {
  const t = useTranslations('faculties');
  const tCommon = useTranslations('common');
  const router = useRouter();

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [facultyToDelete, setFacultyToDelete] = useState<Faculty | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const {
    data: faculties,
    meta,
    isLoading,
    searchValue,
    filters,
    setPage,
    setPageSize,
    setSearch,
    setFilter,
    refetch,
  } = useServerTable<Faculty, FacultyFilters>({
    fetchFn: facultiesApi.getAll,
    initialPageSize: 10,
  });

  const handleStatusFilter = (value: string) => {
    setFilter('isActive', value === 'all' ? undefined : value === 'active');
  };

  const handleDelete = async () => {
    if (!facultyToDelete) return;
    try {
      await facultiesApi.delete(facultyToDelete.id);
      toast.success(t('deleteSuccess'));
      refetch();
    } catch {
      toast.error(t('deleteError'));
    } finally {
      setDeleteDialogOpen(false);
      setFacultyToDelete(null);
    }
  };

  const handleRestore = async (faculty: Faculty) => {
    try {
      await facultiesApi.restore(faculty.id);
      toast.success(t('restoreSuccess'));
      refetch();
    } catch {
      toast.error(t('restoreError'));
    }
  };

  const columns = useFacultyColumns({
    onDelete: (faculty) => {
      setFacultyToDelete(faculty);
      setDeleteDialogOpen(true);
    },
    onRestore: handleRestore,
  });

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  // No specific import types for faculties - show all available templates
  const facultyImportTypes = undefined;

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Building2}
        title={t('title')}
        description={t('subtitle')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setUploadModalOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Excel File
            </Button>
            <Button onClick={() => router.push('/super-admin/faculties/new')}>
              <Plus className="mr-2 h-4 w-4" />
              {t('create')}
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={filters.isActive === undefined ? 'all' : filters.isActive ? 'active' : 'inactive'}
          onValueChange={handleStatusFilter}
        >
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder={t('filterByStatus')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{tCommon('all')}</SelectItem>
            <SelectItem value="active">{t('active')}</SelectItem>
            <SelectItem value="inactive">{t('inactive')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!isLoading && faculties.length === 0 && !searchValue ? (
        <EmptyState
          title={t('noFaculties')}
          description={t('noFacultiesDescription')}
          action={
            <Button onClick={() => router.push('/super-admin/faculties/new')}>
              <Plus className="me-2 h-4 w-4" />
              {t('create')}
            </Button>
          }
        />
      ) : (
        <ServerDataTable
          columns={columns}
          data={faculties}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
        />
      )}

      <ConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        title={t('deleteConfirmTitle')}
        description={t('deleteConfirmDescription')}
        confirmLabel={tCommon('delete')}
        onConfirm={handleDelete}
        destructive
      />

      <QuickUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        allowedImportTypes={facultyImportTypes}
        onUploadComplete={() => {
          toast.success(tCommon('success'));
          refetch();
        }}
      />
    </div>
  );
}
