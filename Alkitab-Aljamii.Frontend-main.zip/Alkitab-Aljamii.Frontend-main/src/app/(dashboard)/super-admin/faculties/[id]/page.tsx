'use client';

import { useState, useEffect, useCallback, use, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Loader2, Trash2, RotateCcw } from 'lucide-react';
import { useTranslations, useLocale } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  FacultyForm,
  FacultyInfoCard,
  MembersTabContent,
  createMemberColumns,
  AdminConflictAlert,
  type UpdateFacultyFormData,
} from '@/components/faculties';
import { ConfirmDialog } from '@/components/shared';
import { facultiesApi, type FacultyAdminConflict } from '@/lib/api';
import type { Faculty, FacultyMember, CreateMemberDto } from '@/types';

export default function FacultyDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const t = useTranslations('faculties');
  const tCommon = useTranslations('common');
  const tRoles = useTranslations('roles');
  const locale = useLocale();
  const router = useRouter();

  const [faculty, setFaculty] = useState<Faculty | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [admins, setAdmins] = useState<FacultyMember[]>([]);
  const [professors, setProfessors] = useState<FacultyMember[]>([]);
  const [students, setStudents] = useState<FacultyMember[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [conflicts, setConflicts] = useState<FacultyAdminConflict[]>([]);

  const loadMembers = useCallback(async () => {
    setLoadingMembers(true);
    try {
      const [adminsResult, profsResult, studentsResult] = await Promise.all([
        facultiesApi.getFacultyAdmins(id),
        facultiesApi.getProfessors(id, { limit: 100 }),
        facultiesApi.getStudents(id, { limit: 100 }),
      ]);
      setAdmins(adminsResult);
      setProfessors(profsResult.items ?? []);
      setStudents(studentsResult.items ?? []);
    } catch (error) {
      console.error('Failed to load members:', error);
      toast.error(t('loadMembersError'));
    } finally {
      setLoadingMembers(false);
    }
  }, [id, t]);

  const loadConflicts = useCallback(async () => {
    try {
      const data = await facultiesApi.getAdminConflicts();
      setConflicts(data);
    } catch {
      // Silently fail - conflicts are not critical
    }
  }, []);

  useEffect(() => {
    const fetchFaculty = async () => {
      try {
        const data = await facultiesApi.getById(id);
        setFaculty(data);
      } catch (error) {
        console.error('Failed to fetch faculty:', error);
        toast.error(t('fetchError'));
        router.push('/super-admin/faculties');
      } finally {
        setIsLoading(false);
      }
    };

    fetchFaculty();
    loadMembers();
  }, [id, router, t, loadMembers]);

  // Refetch conflicts when locale changes
  useEffect(() => {
    loadConflicts();
  }, [locale, loadConflicts]);

  const handleSubmit = async (data: UpdateFacultyFormData) => {
    setIsSaving(true);
    try {
      const updated = await facultiesApi.update(id, data);
      setFaculty(updated);
      toast.success(t('updateSuccess'));
    } catch (error) {
      console.error('Failed to update faculty:', error);
      toast.error(t('updateError'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await facultiesApi.delete(id);
      toast.success(t('deleteSuccess'));
      router.push('/super-admin/faculties');
    } catch (error) {
      console.error('Failed to delete faculty:', error);
      toast.error(t('deleteError'));
    } finally {
      setIsDeleting(false);
      setShowDeleteDialog(false);
    }
  };

  const handleRestore = async () => {
    try {
      const restored = await facultiesApi.restore(id);
      setFaculty(restored);
      toast.success(t('restoreSuccess'));
    } catch (error) {
      console.error('Failed to restore faculty:', error);
      toast.error(t('restoreError'));
    }
  };

  const handleCreateProfessor = async (data: CreateMemberDto) => {
    try {
      await facultiesApi.createProfessor(id, data);
      toast.success(t('professorAddedSuccess'));
      loadMembers();
    } catch (error: unknown) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const err = error as any;
      const message = err?.response?.data?.message ?? t('addProfessorError');
      toast.error(message);
      throw error;
    }
  };

  const handleCreateStudent = async (data: CreateMemberDto) => {
    try {
      await facultiesApi.createStudent(id, data);
      toast.success(t('studentAddedSuccess'));
      loadMembers();
    } catch (error: unknown) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const err = error as any;
      const message = err?.response?.data?.message ?? t('addStudentError');
      toast.error(message);
      throw error;
    }
  };

  const handleRemoveProfessor = useCallback(async (professorId: string) => {
    setRemovingId(professorId);
    try {
      await facultiesApi.removeProfessor(id, professorId);
      toast.success(t('professorRemoved'));
      setProfessors((prev) => prev.filter((p) => p.id !== professorId));
    } catch {
      toast.error(t('removeProfessorError'));
    } finally {
      setRemovingId(null);
    }
  }, [id, t]);

  const handleRemoveStudent = useCallback(async (studentId: string) => {
    setRemovingId(studentId);
    try {
      await facultiesApi.removeStudent(id, studentId);
      toast.success(t('studentRemoved'));
      setStudents((prev) => prev.filter((s) => s.id !== studentId));
    } catch {
      toast.error(t('removeStudentError'));
    } finally {
      setRemovingId(null);
    }
  }, [id, t]);

  const professorColumns = useMemo(() => createMemberColumns({
    nameHeader: tCommon('name'),
    emailHeader: tCommon('email'),
    dateHeader: t('assigned'),
    onRemove: handleRemoveProfessor,
    removingId,
  }), [tCommon, t, handleRemoveProfessor, removingId]);

  const studentColumns = useMemo(() => createMemberColumns({
    nameHeader: tCommon('name'),
    emailHeader: tCommon('email'),
    dateHeader: t('enrolled'),
    onRemove: handleRemoveStudent,
    removingId,
  }), [tCommon, t, handleRemoveStudent, removingId]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!faculty) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0"
            onClick={() => router.push('/super-admin/faculties')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{faculty.name}</h2>
              <Badge variant={faculty.isActive ? 'default' : 'secondary'} className="shrink-0">
                {faculty.isActive ? t('active') : t('inactive')}
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm truncate">{faculty.code}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 ps-10 sm:ps-0">
          {!faculty.isActive ? (
            <Button variant="outline" size="sm" onClick={handleRestore}>
              <RotateCcw className="me-2 h-4 w-4" />
              <span className="hidden sm:inline">{t('restore')}</span>
              <span className="sm:hidden">{t('restore')}</span>
            </Button>
          ) : (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowDeleteDialog(true)}
            >
              <Trash2 className="me-2 h-4 w-4" />
              <span className="hidden sm:inline">{tCommon('delete')}</span>
              <span className="sm:hidden">{tCommon('delete')}</span>
            </Button>
          )}
        </div>
      </div>

      {/* Faculty Admin Conflict Alert */}
      <AdminConflictAlert
        conflicts={conflicts}
        facultyId={id}
        compact
        onConflictResolved={() => {
          loadConflicts();
          loadMembers();
        }}
      />

      <Tabs defaultValue="details" className="space-y-4">
        <TabsList>
          <TabsTrigger value="details">{t('details')}</TabsTrigger>
          <TabsTrigger value="professors">
            {tRoles('professor_plural')} ({faculty.professorsCount ?? professors.length})
          </TabsTrigger>
          <TabsTrigger value="students">
            {tRoles('student_plural')} ({faculty.studentsCount ?? students.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="details">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>{t('edit')}</CardTitle>
                <CardDescription>{t('editDescription')}</CardDescription>
              </CardHeader>
              <CardContent>
                <FacultyForm
                  faculty={faculty}
                  onSubmit={handleSubmit}
                  onCancel={() => router.push('/super-admin/faculties')}
                  isLoading={isSaving}
                />
              </CardContent>
            </Card>

            <FacultyInfoCard
              faculty={faculty}
              admins={admins}
              professorsCount={faculty.professorsCount ?? professors.length}
              studentsCount={faculty.studentsCount ?? students.length}
              labels={{
                title: t('facultyInfo'),
                professors: t('professors'),
                students: t('students'),
                createdAt: t('createdAt'),
                updatedAt: t('updatedAt'),
                notAssigned: 'Not assigned',
              }}
            />
          </div>
        </TabsContent>

        <TabsContent value="professors">
          <MembersTabContent
            title={tRoles('professor_plural')}
            description={t('manageProfessorsDescription')}
            addButtonTitle={t('addProfessor')}
            role="professor"
            members={professors}
            columns={professorColumns}
            isLoading={loadingMembers}
            emptyMessage={t('noProfessorsAssigned')}
            searchPlaceholder={t('searchProfessors')}
            onCreate={handleCreateProfessor}
          />
        </TabsContent>

        <TabsContent value="students">
          <MembersTabContent
            title={tRoles('student_plural')}
            description={t('manageStudentsDescription')}
            addButtonTitle={t('addStudent')}
            role="student"
            members={students}
            columns={studentColumns}
            isLoading={loadingMembers}
            emptyMessage={t('noStudentsEnrolled')}
            searchPlaceholder={t('searchStudents')}
            onCreate={handleCreateStudent}
          />
        </TabsContent>
      </Tabs>

      <ConfirmDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        title={t('deleteConfirmTitle')}
        description={t('deleteConfirmDescription')}
        confirmLabel={tCommon('delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />
    </div>
  );
}
