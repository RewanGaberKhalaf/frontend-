'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FacultyForm, type CreateFacultyFormData } from '@/components/faculties';
import { facultiesApi } from '@/lib/api/faculties';

export default function NewFacultyPage() {
  const t = useTranslations('faculties');
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (data: CreateFacultyFormData) => {
    setIsLoading(true);
    try {
      await facultiesApi.create(data);
      toast.success(t('createSuccess'));
      router.push('/super-admin/faculties');
    } catch (error) {
      console.error('Failed to create faculty:', error);
      toast.error(t('createError'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push('/super-admin/faculties')}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('createTitle')}</h2>
          <p className="text-muted-foreground">{t('createDescription')}</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('facultyInfo')}</CardTitle>
          <CardDescription>
            {t('createDescription')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FacultyForm
            onSubmit={handleSubmit}
            onCancel={() => router.push('/super-admin/faculties')}
            isLoading={isLoading}
          />
        </CardContent>
      </Card>
    </div>
  );
}
