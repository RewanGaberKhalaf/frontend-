'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import {
  Clock,
  Users,
  TrendingUp,
  Building2,
  Activity,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { readingTimeApi } from '@/lib/api/reading-time';
import { ReadingTimeHeatmap } from '@/components/analytics';
import type { PlatformReadingOverview, FacultyReadingComparison } from '@/types';

function formatHours(hours: number): string {
  if (hours < 1) {
    return `${Math.round(hours * 60)}m`;
  }
  if (hours < 100) {
    return `${hours.toFixed(1)}h`;
  }
  return `${Math.round(hours)}h`;
}

function formatMinutes(minutes: number): string {
  if (minutes < 60) {
    return `${Math.round(minutes)}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export default function PlatformReadingTimeAnalyticsPage() {
  const t = useTranslations();

  const [data, setData] = useState<PlatformReadingOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const overview = await readingTimeApi.getPlatformReadingOverview();
        setData(overview);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load reading analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-48" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">{error || 'No data available'}</p>
      </div>
    );
  }

  // Find max values for comparison visualization
  const maxHours = Math.max(...data.facultyComparison.map((f) => f.totalReadingHours), 1);

  // Prepare chart data for faculty comparison
  const facultyChartData = data.facultyComparison.map((f) => ({
    name: f.facultyName.length > 15 ? f.facultyName.slice(0, 15) + '...' : f.facultyName,
    hours: f.totalReadingHours,
    readers: f.activeReaders,
  }));

  const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ payload: typeof facultyChartData[0] }> }) => {
    if (!active || !payload?.[0]) return null;
    const item = payload[0].payload;

    return (
      <div className="bg-popover border rounded-lg shadow-lg p-3 text-sm">
        <p className="font-medium mb-1">{item.name}</p>
        <p className="text-muted-foreground">
          {formatHours(item.hours)} • {item.readers} readers
        </p>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Platform Reading Analytics</h1>
        <p className="text-muted-foreground">Reading engagement across all faculties</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reading Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatHours(data.totalReadingTimeHours)}</div>
            <p className="text-xs text-muted-foreground">
              {data.totalSessions.toLocaleString()} sessions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Readers (7d)</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.activeReaders7d}</div>
            <p className="text-xs text-muted-foreground">
              {data.activeReaders30d} in 30 days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Session</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMinutes(data.avgSessionLengthMinutes)}</div>
            <p className="text-xs text-muted-foreground">
              Per reading session
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Peak Hours</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {data.peakReadingHours.slice(0, 2).map((h) => `${h}:00`).join(', ')}
            </div>
            <p className="text-xs text-muted-foreground">
              Most active times
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Platform Reading Activity */}
      <ReadingTimeHeatmap
        data={data.dailyTrend}
        title="Platform Reading Activity"
        description="Combined reading activity across all students"
        weeks={12}
      />

      {/* Faculty Comparison Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Faculty Comparison
          </CardTitle>
          <CardDescription>
            Reading engagement by faculty
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={facultyChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis
                dataKey="name"
                tick={{ fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis
                tickFormatter={(value) => formatHours(value)}
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="hours" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Faculty Details Table */}
      <Card>
        <CardHeader>
          <CardTitle>Faculty Reading Details</CardTitle>
          <CardDescription>
            Detailed breakdown of reading time by faculty
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Faculty</TableHead>
                <TableHead className="text-right">Total Time</TableHead>
                <TableHead className="text-right">Active Readers</TableHead>
                <TableHead className="text-right">Avg/Student</TableHead>
                <TableHead className="w-[200px]">Share</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.facultyComparison.map((faculty, index) => (
                <TableRow key={faculty.facultyId}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="w-6 h-6 p-0 justify-center">
                        {index + 1}
                      </Badge>
                      <span className="font-medium">{faculty.facultyName}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatHours(faculty.totalReadingHours)}
                  </TableCell>
                  <TableCell className="text-right">
                    {faculty.activeReaders}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatMinutes(faculty.avgTimePerStudent)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={(faculty.totalReadingHours / maxHours) * 100}
                        className="h-2 flex-1"
                      />
                      <span className="text-xs text-muted-foreground w-10 text-right">
                        {Math.round((faculty.totalReadingHours / data.totalReadingTimeHours) * 100)}%
                      </span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {data.facultyComparison.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground">
                    No reading data yet
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
