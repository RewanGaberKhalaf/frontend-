'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  Users,
  Building2,
  BookOpen,
  ClipboardList,
  TrendingUp,
  TrendingDown,
  Activity,
  ChevronRight,
  UserPlus,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type SuperAdminAnalyticsOverview } from '@/lib/api/analytics';
import { cn } from '@/lib/utils';

export default function SuperAdminAnalyticsPage() {
  const t = useTranslations();
  const [data, setData] = useState<SuperAdminAnalyticsOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const overview = await analyticsApi.getSuperAdminOverview();
        setData(overview);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6 min-w-0 overflow-hidden">
        <div>
          <Skeleton className="h-7 sm:h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64 max-w-full" />
        </div>
        <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">{error || 'No data available'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 min-w-0 overflow-hidden">
      {/* Header */}
      <div className="min-w-0">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{t('analytics.platformTitle')}</h1>
        <p className="text-sm text-muted-foreground line-clamp-2">{t('analytics.platformDescription')}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.totalUsers')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              {data.activeUsers30d} {t('analytics.activeMonthly')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.faculties')}</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalFaculties}</div>
            <p className="text-xs text-muted-foreground">
              {data.totalSubjects} {t('analytics.subjects')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgQuizScore')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgQuizScorePlatform.toFixed(1)}%</div>
            <Progress value={data.avgQuizScorePlatform} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.passRate')}</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.overallPassRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {data.totalQuizAttempts} {t('analytics.totalAttempts')}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Platform Trends */}
      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.newUsers')}</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.platformTrends.newUsersLast30d}</div>
            <p className="text-xs text-muted-foreground">
              {data.platformTrends.newUsersLast7d} {t('analytics.last7Days')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.quizAttempts')}</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.platformTrends.quizAttemptsLast30d}</div>
            <p className="text-xs text-muted-foreground">
              {data.platformTrends.quizAttemptsLast7d} {t('analytics.last7Days')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.booksPublished')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.platformTrends.booksPublishedLast30d}</div>
            <p className="text-xs text-muted-foreground">
              {data.publishedBooks} {t('analytics.totalPublished')}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-3 sm:gap-4 md:grid-cols-2">
        {/* Top Performing Faculties */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              {t('analytics.topFaculties')}
            </CardTitle>
            <CardDescription>{t('analytics.topFacultiesDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topFaculties.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noFaculties')}
              </p>
            ) : (
              <div className="space-y-2 sm:space-y-3">
                {data.topFaculties.map((faculty, index) => (
                  <Link
                    key={faculty.facultyId}
                    href={ROUTES.SUPER_ADMIN.ANALYTICS_FACULTY(faculty.facultyId)}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg border hover:bg-muted/50 transition-colors gap-2">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 text-sm font-medium shrink-0">
                          {index + 1}
                        </span>
                        <span className="font-medium truncate">{faculty.facultyName}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant="default">{faculty.metric.toFixed(0)}%</Badge>
                        <ChevronRight className="h-4 w-4 text-muted-foreground hidden sm:block" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Struggling Faculties */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-red-500" />
              {t('analytics.strugglingFaculties')}
            </CardTitle>
            <CardDescription>{t('analytics.strugglingFacultiesDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.strugglingFaculties.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noFaculties')}
              </p>
            ) : (
              <div className="space-y-2 sm:space-y-3">
                {data.strugglingFaculties.map((faculty, index) => (
                  <Link
                    key={faculty.facultyId}
                    href={ROUTES.SUPER_ADMIN.ANALYTICS_FACULTY(faculty.facultyId)}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg border hover:bg-muted/50 transition-colors gap-2">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 text-sm font-medium shrink-0">
                          {index + 1}
                        </span>
                        <span className="font-medium truncate">{faculty.facultyName}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant="destructive">{faculty.metric.toFixed(0)}%</Badge>
                        <ChevronRight className="h-4 w-4 text-muted-foreground hidden sm:block" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Faculty Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('analytics.facultyPerformance')}</CardTitle>
          <CardDescription>{t('analytics.facultyPerformanceDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="px-0 sm:px-6">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[150px]">{t('analytics.faculty')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.professors')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.students')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.subjects')}</TableHead>
                  <TableHead className="text-center w-16">{t('analytics.books')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.avgScore')}</TableHead>
                  <TableHead className="text-center w-24">{t('analytics.engagement')}</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.facultyPerformance.map((faculty) => (
                  <TableRow key={faculty.facultyId}>
                    <TableCell>
                      <div className="min-w-0">
                        <p className="font-medium truncate max-w-[180px]">{faculty.facultyName}</p>
                        <p className="text-xs text-muted-foreground">{faculty.facultyCode}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">{faculty.professorCount}</TableCell>
                    <TableCell className="text-center">{faculty.studentCount}</TableCell>
                    <TableCell className="text-center">{faculty.subjectCount}</TableCell>
                    <TableCell className="text-center">{faculty.bookCount}</TableCell>
                    <TableCell className="text-center">
                      <span className={cn(
                        'font-medium',
                        faculty.avgQuizScore >= 70 ? 'text-green-600' :
                        faculty.avgQuizScore >= 50 ? 'text-yellow-600' : 'text-red-600'
                      )}>
                        {faculty.avgQuizScore.toFixed(0)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={faculty.engagementRate >= 50 ? 'default' : 'secondary'}>
                        {faculty.engagementRate.toFixed(0)}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Link href={ROUTES.SUPER_ADMIN.ANALYTICS_FACULTY(faculty.facultyId)}>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
