'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  ArrowLeft,
  Users,
  BookOpen,
  ClipboardList,
  GraduationCap,
  Activity,
  TrendingUp,
  TrendingDown,
  ChevronRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type FacultyAnalyticsDetail } from '@/lib/api/analytics';
import { cn } from '@/lib/utils';

export default function SuperAdminFacultyAnalyticsPage() {
  const params = useParams();
  const router = useRouter();
  const t = useTranslations();
  const facultyId = params['facultyId'] as string;

  const [data, setData] = useState<FacultyAnalyticsDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const analytics = await analyticsApi.getFacultyAnalyticsDetail(facultyId);
        setData(analytics);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [facultyId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 me-2" />
          {t('common.back')}
        </Button>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">{error || 'No data available'}</p>
        </div>
      </div>
    );
  }

  const { overview } = data;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start sm:items-center gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1 sm:mt-0" asChild>
          <Link href={ROUTES.SUPER_ADMIN.ANALYTICS}>
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{data.facultyName}</h1>
          <p className="text-sm text-muted-foreground">{data.facultyCode}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.totalStudents')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              {overview.activeStudents30d} {t('analytics.activeMonthly')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professors')}</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.totalProfessors}</div>
            <p className="text-xs text-muted-foreground">
              {overview.totalBooks} {t('analytics.booksCreated')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgQuizScore')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.avgQuizScore.toFixed(1)}%</div>
            <Progress value={overview.avgQuizScore} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.passRate')}</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.overallPassRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {overview.totalQuizAttempts} {t('analytics.totalAttempts')}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Content Stats */}
      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.subjects')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.subjectBreakdown.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.books')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.totalBooks}</div>
            <p className="text-xs text-muted-foreground">
              {overview.publishedBooks} {t('analytics.published')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.quizzes')}</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview.totalQuizzes}</div>
          </CardContent>
        </Card>
      </div>

      {/* Top and Struggling Subjects */}
      <div className="grid gap-3 sm:gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              {t('analytics.topSubjects')}
            </CardTitle>
            <CardDescription>{t('analytics.topSubjectsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {overview.topPerformingSubjects.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noSubjects')}
              </p>
            ) : (
              <div className="space-y-2 sm:space-y-3">
                {overview.topPerformingSubjects.map((subject, index) => (
                  <div
                    key={subject.subjectId}
                    className="flex items-center justify-between p-2 sm:p-3 rounded-lg border gap-2"
                  >
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 text-sm font-medium shrink-0">
                        {index + 1}
                      </span>
                      <span className="font-medium truncate">{subject.subjectName}</span>
                    </div>
                    <Badge variant="default" className="shrink-0">{subject.metric.toFixed(0)}%</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-red-500" />
              {t('analytics.strugglingSubjects')}
            </CardTitle>
            <CardDescription>{t('analytics.strugglingSubjectsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {overview.strugglingSubjects.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noSubjects')}
              </p>
            ) : (
              <div className="space-y-2 sm:space-y-3">
                {overview.strugglingSubjects.map((subject, index) => (
                  <div
                    key={subject.subjectId}
                    className="flex items-center justify-between p-2 sm:p-3 rounded-lg border gap-2"
                  >
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 text-sm font-medium shrink-0">
                        {index + 1}
                      </span>
                      <span className="font-medium truncate">{subject.subjectName}</span>
                    </div>
                    <Badge variant="destructive" className="shrink-0">{subject.metric.toFixed(0)}%</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Subject Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('analytics.subjectPerformance')}</CardTitle>
          <CardDescription>{t('analytics.subjectPerformanceDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="px-0 sm:px-6">
          {data.subjectBreakdown.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4 px-6">
              {t('analytics.noSubjects')}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">{t('analytics.subject')}</TableHead>
                    <TableHead className="text-center w-20">{t('analytics.professors')}</TableHead>
                    <TableHead className="text-center w-20">{t('analytics.students')}</TableHead>
                    <TableHead className="text-center w-16">{t('analytics.books')}</TableHead>
                    <TableHead className="text-center w-16">{t('analytics.quizzes')}</TableHead>
                    <TableHead className="text-center w-20">{t('analytics.avgScore')}</TableHead>
                    <TableHead className="text-center w-24">{t('analytics.passRate')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.subjectBreakdown.map((subject) => (
                    <TableRow key={subject.subjectId}>
                      <TableCell>
                        <div className="min-w-0">
                          <p className="font-medium truncate max-w-[180px]">{subject.subjectName}</p>
                          <p className="text-xs text-muted-foreground">{subject.subjectCode}</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">{subject.professorCount}</TableCell>
                      <TableCell className="text-center">{subject.studentCount}</TableCell>
                      <TableCell className="text-center">{subject.bookCount}</TableCell>
                      <TableCell className="text-center">{subject.quizCount}</TableCell>
                      <TableCell className="text-center">
                        <span className={cn(
                          'font-medium',
                          subject.avgQuizScore >= 70 ? 'text-green-600' :
                          subject.avgQuizScore >= 50 ? 'text-yellow-600' : 'text-red-600'
                        )}>
                          {subject.avgQuizScore.toFixed(0)}%
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant={subject.passRate >= 70 ? 'default' : 'secondary'}>
                          {subject.passRate.toFixed(0)}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
