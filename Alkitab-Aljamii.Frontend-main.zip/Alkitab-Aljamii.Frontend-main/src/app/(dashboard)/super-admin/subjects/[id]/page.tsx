'use client';

import { useState, useEffect, useCallback, use } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Loader2, Trash2, Users, GraduationCap, Search } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { EmptyState } from '@/components/shared';
import { AddMemberDialog } from '@/components/faculties/add-member-dialog';
import { subjectsApi } from '@/lib/api/subjects';
import { facultiesApi } from '@/lib/api/faculties';
import { useDebounce } from '@/hooks';
import type { Subject, SubjectAssignment, FacultyMember, PaginationMeta } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export default function SubjectDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const t = useTranslations();
  const { id } = use(params);
  const router = useRouter();
  const [subject, setSubject] = useState<Subject | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Professors state
  const [professors, setProfessors] = useState<SubjectAssignment[]>([]);
  const [professorsMeta, setProfessorsMeta] = useState<PaginationMeta | null>(null);
  const [professorsSearch, setProfessorsSearch] = useState('');
  const [professorsLoading, setProfessorsLoading] = useState(false);
  const debouncedProfessorsSearch = useDebounce(professorsSearch, 300);

  // Students state
  const [students, setStudents] = useState<SubjectAssignment[]>([]);
  const [studentsMeta, setStudentsMeta] = useState<PaginationMeta | null>(null);
  const [studentsSearch, setStudentsSearch] = useState('');
  const [studentsLoading, setStudentsLoading] = useState(false);
  const debouncedStudentsSearch = useDebounce(studentsSearch, 300);

  // For add dialogs
  const [facultyProfessors, setFacultyProfessors] = useState<FacultyMember[]>([]);
  const [facultyStudents, setFacultyStudents] = useState<FacultyMember[]>([]);
  const [removingId, setRemovingId] = useState<string | null>(null);

  const loadSubject = useCallback(async () => {
    try {
      const data = await subjectsApi.getById(id);
      setSubject(data);
      return data;
    } catch {
      toast.error(t('subjects.loadError'));
      router.push('/super-admin/subjects');
      return null;
    }
  }, [id, router, t]);

  const loadProfessors = useCallback(async (search?: string) => {
    setProfessorsLoading(true);
    try {
      const result = await subjectsApi.getAssignments(id, {
        roleInSubject: 'professor',
        search: search || undefined,
        limit: 50,
      });
      setProfessors(result.items);
      setProfessorsMeta(result.meta);
    } catch {
      toast.error(t('subjects.loadAssignmentsError'));
    } finally {
      setProfessorsLoading(false);
    }
  }, [id, t]);

  const loadStudents = useCallback(async (search?: string) => {
    setStudentsLoading(true);
    try {
      const result = await subjectsApi.getAssignments(id, {
        roleInSubject: 'student',
        search: search || undefined,
        limit: 50,
      });
      setStudents(result.items);
      setStudentsMeta(result.meta);
    } catch {
      toast.error(t('subjects.loadAssignmentsError'));
    } finally {
      setStudentsLoading(false);
    }
  }, [id, t]);

  const loadFacultyMembers = useCallback(async (facultyId: string) => {
    try {
      const [profs, studs] = await Promise.all([
        facultiesApi.getProfessors(facultyId, { limit: 100 }),
        facultiesApi.getStudents(facultyId, { limit: 100 }),
      ]);
      setFacultyProfessors(profs.items);
      setFacultyStudents(studs.items);
    } catch {
      // Silently fail - will just show empty available members
    }
  }, []);

  // Initial load
  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      const subjectData = await loadSubject();
      await Promise.all([loadProfessors(), loadStudents()]);
      if (subjectData?.facultyId) {
        await loadFacultyMembers(subjectData.facultyId);
      }
      setIsLoading(false);
    };
    load();
  }, [loadSubject, loadProfessors, loadStudents, loadFacultyMembers]);

  // Search effects
  useEffect(() => {
    if (!isLoading) {
      loadProfessors(debouncedProfessorsSearch);
    }
  }, [debouncedProfessorsSearch, loadProfessors, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      loadStudents(debouncedStudentsSearch);
    }
  }, [debouncedStudentsSearch, loadStudents, isLoading]);

  const handleAddProfessor = async (userId: string) => {
    try {
      await subjectsApi.assignUser(id, userId, 'professor');
      toast.success(t('subjects.professorAssigned'));
      loadProfessors(debouncedProfessorsSearch);
    } catch {
      toast.error(t('subjects.professorAssignError'));
    }
  };

  const handleAddStudent = async (userId: string) => {
    try {
      await subjectsApi.assignUser(id, userId, 'student');
      toast.success(t('subjects.studentEnrolled'));
      loadStudents(debouncedStudentsSearch);
    } catch {
      toast.error(t('subjects.studentEnrollError'));
    }
  };

  const handleRemove = async (userId: string, role: 'professor' | 'student') => {
    setRemovingId(userId);
    try {
      await subjectsApi.removeUser(id, userId);
      toast.success(t('subjects.userRemoved'));
      if (role === 'professor') {
        setProfessors((prev) => prev.filter((a) => a.userId !== userId));
      } else {
        setStudents((prev) => prev.filter((a) => a.userId !== userId));
      }
    } catch {
      toast.error(t('subjects.userRemoveError'));
    } finally {
      setRemovingId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!subject) return null;

  const renderTable = (
    data: SubjectAssignment[],
    role: 'professor' | 'student',
    loading: boolean
  ) => (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>{t('common.name')}</TableHead>
            <TableHead>{t('common.email')}</TableHead>
            <TableHead>{t('subjects.assigned')}</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {loading ? (
            <TableRow>
              <TableCell colSpan={4} className="h-24 text-center">
                <Loader2 className="mx-auto h-6 w-6 animate-spin" />
              </TableCell>
            </TableRow>
          ) : data.length === 0 ? (
            <TableRow>
              <TableCell colSpan={4} className="h-24 text-center">
                {t('table.noResults')}
              </TableCell>
            </TableRow>
          ) : (
            data.map((assignment) => (
              <TableRow key={assignment.id}>
                <TableCell>{assignment.firstName} {assignment.lastName}</TableCell>
                <TableCell>{assignment.email}</TableCell>
                <TableCell>{new Date(assignment.assignedAt).toLocaleDateString()}</TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemove(assignment.userId, role)}
                    disabled={removingId === assignment.userId}
                  >
                    {removingId === assignment.userId ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Trash2 className="h-4 w-4 text-destructive" />
                    )}
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push('/super-admin/subjects')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold tracking-tight">{subject.name}</h2>
            <Badge variant={subject.isActive ? 'default' : 'secondary'}>
              {subject.isActive ? t('subjects.active') : t('subjects.inactive')}
            </Badge>
          </div>
          <p className="text-muted-foreground">{subject.code} • {subject.facultyName}</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('roles.professor_plural')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{professorsMeta?.total ?? professors.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('roles.student_plural')}</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{studentsMeta?.total ?? students.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="professors">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="professors">{t('roles.professor_plural')} ({professorsMeta?.total ?? professors.length})</TabsTrigger>
            <TabsTrigger value="students">{t('roles.student_plural')} ({studentsMeta?.total ?? students.length})</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="professors" className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t('common.search')}
                value={professorsSearch}
                onChange={(e) => setProfessorsSearch(e.target.value)}
                className="pl-8"
              />
            </div>
            <AddMemberDialog
              title={t('subjects.addProfessor')}
              facultyRole="professor"
              onAdd={handleAddProfessor}
              existingMemberIds={professors.map((p) => p.userId)}
              availableMembers={facultyProfessors}
            />
          </div>
          {professors.length === 0 && !professorsSearch && !professorsLoading ? (
            <EmptyState
              title={t('subjects.noProfessorsAssigned')}
              description={t('subjects.addProfessorsDescription')}
            />
          ) : (
            renderTable(professors, 'professor', professorsLoading)
          )}
        </TabsContent>

        <TabsContent value="students" className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t('common.search')}
                value={studentsSearch}
                onChange={(e) => setStudentsSearch(e.target.value)}
                className="pl-8"
              />
            </div>
            <AddMemberDialog
              title={t('subjects.addStudent')}
              facultyRole="student"
              onAdd={handleAddStudent}
              existingMemberIds={students.map((s) => s.userId)}
              availableMembers={facultyStudents}
            />
          </div>
          {students.length === 0 && !studentsSearch && !studentsLoading ? (
            <EmptyState
              title={t('subjects.noStudentsEnrolled')}
              description={t('subjects.addStudentsDescription')}
            />
          ) : (
            renderTable(students, 'student', studentsLoading)
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
