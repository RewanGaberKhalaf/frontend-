'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Pencil, Trash2, Eye, BookOpen, Search, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import { QuickUploadModal } from '@/components/bulkImport';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, PageHeader, TableFilters, ActiveFilters, type FilterConfig, type FilterValues } from '@/components/shared';
import { SubjectForm } from '@/components/subjects';
import { useServerTable } from '@/hooks';
import { subjectsApi, type SubjectFilterParams } from '@/lib/api/subjects';
import { facultiesApi } from '@/lib/api/faculties';
import type { Subject, Faculty, CreateSubjectDto, UpdateSubjectDto, PaginationParams } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';

type SubjectFilters = Omit<SubjectFilterParams, keyof PaginationParams>;

export default function SubjectsPage() {
  const t = useTranslations();
  const locale = useLocale();
  const router = useRouter();
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const {
    data: subjects,
    meta,
    isLoading,
    searchValue,
    sortBy,
    sortOrder,
    filters,
    setPage,
    setPageSize,
    setSearch,
    setSort,
    setFilter,
    refetch,
  } = useServerTable<Subject, SubjectFilters>({
    fetchFn: subjectsApi.getAll,
    initialPageSize: 10,
  });

  // Load faculties for filter dropdown
  useEffect(() => {
    const loadFaculties = async () => {
      try {
        const result = await facultiesApi.getAll({ limit: 100 });
        setFaculties(result.items);
      } catch {
        // Silently fail
      }
    };
    loadFaculties();
  }, []);

  // Filter configuration
  const filterConfigs: FilterConfig[] = useMemo(() => [
    {
      key: 'isActive',
      label: t('subjects.status'),
      options: [
        { value: 'true', label: t('subjects.active') },
        { value: 'false', label: t('subjects.inactive') },
      ],
      multiSelect: false,
    },
    {
      key: 'facultyId',
      label: t('subjects.faculty'),
      options: faculties.map((f) => ({ value: f.id, label: f.name })),
      multiSelect: true,
    },
  ], [t, faculties]);

  // Convert hook filters to FilterValues format
  const filterValues: FilterValues = useMemo(() => ({
    isActive: filters.isActive === undefined ? undefined : String(filters.isActive),
    facultyId: filters.facultyId,
  }), [filters]);

  const handleFilterChange = useCallback((key: string, value: string | string[] | undefined) => {
    if (key === 'isActive') {
      setFilter('isActive', value === undefined ? undefined : value === 'true');
    } else {
      setFilter(key as keyof SubjectFilters, value as SubjectFilters[keyof SubjectFilters]);
    }
  }, [setFilter]);

  const handleClearFilters = useCallback(() => {
    setFilter('isActive', undefined);
    setFilter('facultyId', undefined);
  }, [setFilter]);

  const handleCreate = async (data: CreateSubjectDto) => {
    setIsSubmitting(true);
    try {
      await subjectsApi.create(data as CreateSubjectDto & { facultyId: string });
      toast.success(t('subjects.createSuccess'));
      setDialogOpen(false);
      refetch();
    } catch {
      toast.error(t('subjects.createError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdate = async (data: UpdateSubjectDto) => {
    if (!editingSubject) return;
    setIsSubmitting(true);
    try {
      await subjectsApi.update(editingSubject.id, data);
      toast.success(t('subjects.updateSuccess'));
      setDialogOpen(false);
      setEditingSubject(null);
      refetch();
    } catch {
      toast.error(t('subjects.updateError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm(t('subjects.deleteConfirm'))) return;
    try {
      await subjectsApi.delete(id);
      toast.success(t('subjects.deleteSuccess'));
      refetch();
    } catch {
      toast.error(t('subjects.deleteError'));
    }
  };

  const openCreate = () => { setEditingSubject(null); setDialogOpen(true); };
  const openEdit = (subject: Subject) => { setEditingSubject(subject); setDialogOpen(true); };

  const columns: ColumnDef<Subject>[] = [
    {
      accessorKey: 'name',
      header: t('subjects.name'),
      enableSorting: true,
      cell: ({ row }) => locale === 'ar' && row.original.nameAr ? row.original.nameAr : row.original.name,
    },
    { accessorKey: 'code', header: t('subjects.code'), enableSorting: true },
    { accessorKey: 'facultyName', header: t('subjects.faculty'), enableSorting: false },
    {
      accessorKey: 'isActive',
      header: t('subjects.status'),
      enableSorting: true,
      cell: ({ row }) => (
        <Badge variant={row.original.isActive ? 'success' : 'muted'}>
          {row.original.isActive ? t('subjects.active') : t('subjects.inactive')}
        </Badge>
      ),
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => router.push(`/super-admin/subjects/${row.original.id}`)}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => openEdit(row.original)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => handleDelete(row.original.id)}>
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        </div>
      ),
    },
  ];

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  const hasActiveFilters = filters.isActive !== undefined ||
    (filters.facultyId && (Array.isArray(filters.facultyId) ? filters.facultyId.length > 0 : true));

  const subjectImportTypes = [
    'students_with_subjects',
    'professors_with_subjects',
    'student_enrollments',
    'professor_assignments',
    'student_unenrollments',
    'professor_unassignments',
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        icon={BookOpen}
        title={t('subjects.title')}
        description={t('subjects.subtitle')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setUploadModalOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Excel File
            </Button>
            <Button onClick={openCreate}>
              <Plus className="mr-2 h-4 w-4" />{t('subjects.createSubject')}
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder={t('subjects.searchPlaceholder')}
              value={searchValue}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <TableFilters
            filters={filterConfigs}
            values={filterValues}
            onChange={handleFilterChange}
            onClear={handleClearFilters}
          />
        </div>

        {/* Active filter badges */}
        <ActiveFilters
          filters={filterConfigs}
          values={filterValues}
          onChange={handleFilterChange}
          onClearAll={handleClearFilters}
        />
      </div>

      {!isLoading && subjects.length === 0 && !searchValue && !hasActiveFilters ? (
        <EmptyState title={t('subjects.noSubjects')} description={t('subjects.createFirstSubject')} action={
          <Button onClick={openCreate}><Plus className="me-2 h-4 w-4" />{t('subjects.createSubject')}</Button>
        } />
      ) : (
        <ServerDataTable
          columns={columns}
          data={subjects}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingSubject ? t('subjects.editSubject') : t('subjects.createSubject')}</DialogTitle>
          </DialogHeader>
          <SubjectForm
            subject={editingSubject ?? undefined}
            onSubmit={editingSubject ? handleUpdate : handleCreate}
            onCancel={() => setDialogOpen(false)}
            isLoading={isSubmitting}
          />
        </DialogContent>
      </Dialog>

      <QuickUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        allowedImportTypes={undefined}
        onUploadComplete={() => {
          toast.success(t('common.success'));
          refetch();
        }}
      />
    </div>
  );
}
