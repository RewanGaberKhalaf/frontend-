'use client';

import { useState, useEffect } from 'react';
import { Loader2, Building2, Users, GraduationCap, AlertTriangle, TrendingUp, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  performanceApi,
  type SystemPerformanceOverview,
  type AtRiskAlert,
} from '@/lib/api/performance';
import { EmptyState } from '@/components/shared';
import {
  MetricCard,
  ApiTrendChart,
  AlertCard,
} from '@/components/performance';

export default function SuperAdminPerformancePage() {
  const t = useTranslations();
  const locale = useLocale();
  void locale;
  const router = useRouter();
  const [overview, setOverview] = useState<SystemPerformanceOverview | null>(null);
  const [criticalAlerts, setCriticalAlerts] = useState<AtRiskAlert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const [overviewData, alertsData] = await Promise.all([
          performanceApi.superAdmin.getOverview(),
          performanceApi.superAdmin.getCriticalAlerts(),
        ]);
        setOverview(overviewData);
        setCriticalAlerts(alertsData.alerts);
      } catch {
        toast.error(t('performance.failedToLoad'));
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!overview) {
    return <EmptyState title={t('performance.noData')} description={t('performance.noDataDescription')} />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('performance.title')}</h2>
          <p className="text-muted-foreground">{t('performance.subtitle')}</p>
        </div>
        {overview.totalCriticalAlerts > 0 && (
          <Button size="sm" variant="destructive">
            <AlertTriangle className="me-2 h-4 w-4" />
            {overview.totalCriticalAlerts} {t('performance.criticalAlerts')}
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">{t('performance.tabs.overview')}</TabsTrigger>
          <TabsTrigger value="faculties">{t('performance.tabs.faculties')}</TabsTrigger>
          <TabsTrigger value="alerts">{t('performance.tabs.alerts')}</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Stat Cards */}
          <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-7">
            <MetricCard
              title={t('performance.metrics.totalFaculties')}
              value={overview.totalFaculties}
              icon={Building2}
              iconColor="text-indigo-600"
            />
            <MetricCard
              title={t('performance.metrics.totalStudents')}
              value={overview.totalStudents}
              icon={Users}
              iconColor="text-blue-600"
            />
            <MetricCard
              title={t('performance.metrics.totalProfessors')}
              value={overview.totalProfessors}
              icon={GraduationCap}
              iconColor="text-purple-600"
            />
            <MetricCard
              title={t('performanceMetrics.systemAverageApi')}
              value={overview.systemAverageApi}
              format="number"
              icon={TrendingUp}
              iconColor="text-green-600"
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.apiTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.apiDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.apiCompletion')}</li>
                    <li>{t('performanceMetrics.apiQuizQuality')}</li>
                    <li>{t('performanceMetrics.apiEngagement')}</li>
                    <li>{t('performanceMetrics.apiConsistency')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.atRiskStudents')}
              value={overview.totalAtRiskStudents}
              icon={AlertTriangle}
              iconColor={overview.totalAtRiskStudents > 0 ? 'text-orange-600' : 'text-muted-foreground'}
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.atRiskStudentsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.atRiskStudentsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.atRiskCriteria1')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria2')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria3')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria4')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.criticalAlerts')}
              value={overview.totalCriticalAlerts}
              icon={AlertTriangle}
              iconColor={overview.totalCriticalAlerts > 0 ? 'text-red-600' : 'text-muted-foreground'}
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.criticalAlertsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.criticalAlertsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.criticalAlertsCriteria1')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria2')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria3')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria4')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.activeInterventions')}
              value={overview.totalActiveInterventions}
              icon={TrendingUp}
              iconColor="text-cyan-600"
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.activeInterventionsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.activeInterventionsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.activeInterventionsCriteria1')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria2')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria3')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria4')}</li>
                  </ul>
                </div>
              }
            />
          </div>

          {/* API Trend */}
          <ApiTrendChart
            data={overview.apiTrend}
            title={t('performanceMetrics.systemAverageApi')}
            subtitle={t('performance.cards.last30Days')}
            height={250}
          />

          {/* Faculty Summary Cards */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                {t('performance.cards.facultySummary')}
              </CardTitle>
              <CardDescription className="text-xs">{t('performance.cards.facultySummaryDesc')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                {overview.faculties.map((faculty) => (
                  <Card
                    key={faculty.facultyId}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => router.push(`/super-admin/performance/faculty/${faculty.facultyId}`)}
                  >
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="font-medium">{faculty.facultyName}</h4>
                          {faculty.facultyNameAr && (
                            <p className="text-xs text-muted-foreground">{faculty.facultyNameAr}</p>
                          )}
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-2xl font-bold">{Math.round(faculty.averageApi)}</p>
                          <p className="text-xs text-muted-foreground">{t('performance.metrics.avgApi')}</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold">{faculty.studentCount}</p>
                          <p className="text-xs text-muted-foreground">{t('performance.table.students')}</p>
                        </div>
                        <div>
                          <p className={`text-2xl font-bold ${faculty.atRiskCount > 0 ? 'text-orange-600' : ''}`}>
                            {faculty.atRiskCount}
                          </p>
                          <p className="text-xs text-muted-foreground">{t('performance.metrics.atRisk')}</p>
                        </div>
                        <div>
                          <p className={`text-2xl font-bold ${faculty.criticalAlertCount > 0 ? 'text-red-600' : ''}`}>
                            {faculty.criticalAlertCount}
                          </p>
                          <p className="text-xs text-muted-foreground">{t('performance.metrics.critical')}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="faculties" className="space-y-6 mt-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                {t('performance.cards.facultyComparison')}
              </CardTitle>
              <CardDescription className="text-xs">{t('performance.cards.facultyComparisonDesc')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('performance.table.faculty')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.students')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.professors')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.avgApi')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.atRisk')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.criticalAlerts')}</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {overview.faculties.length > 0 ? (
                      overview.faculties.map((faculty) => (
                        <TableRow
                          key={faculty.facultyId}
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => router.push(`/super-admin/performance/faculty/${faculty.facultyId}`)}
                        >
                          <TableCell>
                            <div>
                              <p className="font-medium">{faculty.facultyName}</p>
                              {faculty.facultyNameAr && (
                                <p className="text-xs text-muted-foreground">{faculty.facultyNameAr}</p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">{faculty.studentCount}</TableCell>
                          <TableCell className="text-center">{faculty.professorCount}</TableCell>
                          <TableCell className="text-center">
                            <span className={
                              faculty.averageApi >= 70 ? 'text-green-600 font-semibold' :
                              faculty.averageApi >= 50 ? 'text-yellow-600 font-semibold' :
                              'text-red-600 font-semibold'
                            }>
                              {Math.round(faculty.averageApi)}
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            {faculty.atRiskCount > 0 ? (
                              <span className="text-orange-600 font-medium">{faculty.atRiskCount}</span>
                            ) : (
                              <span className="text-muted-foreground">0</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {faculty.criticalAlertCount > 0 ? (
                              <span className="text-red-600 font-medium">{faculty.criticalAlertCount}</span>
                            ) : (
                              <span className="text-muted-foreground">0</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          {t('performance.table.noFacultyData')}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6 mt-6">
          {criticalAlerts.length > 0 ? (
            <div className="grid gap-3 grid-cols-1 md:grid-cols-2">
              {criticalAlerts.map((alert) => (
                <AlertCard key={alert.id} alert={alert} />
              ))}
            </div>
          ) : (
            <EmptyState
              title={t('performance.alerts.noCritical')}
              description={t('performance.alerts.noCriticalDescription')}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
