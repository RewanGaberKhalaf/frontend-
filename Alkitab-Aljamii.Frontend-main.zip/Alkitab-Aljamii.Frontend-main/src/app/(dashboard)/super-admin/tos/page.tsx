'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { tosApi, type UniversityTos, type FacultyTosListItem } from '@/lib/api';
import { TosEditor, FacultyTosList } from '@/components/tos';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export default function SuperAdminTosPage() {
  const t = useTranslations('tos');
  const [activeTab, setActiveTab] = useState<'university' | 'faculties'>('university');
  const [universityTos, setUniversityTos] = useState<UniversityTos | null>(null);
  const [facultyList, setFacultyList] = useState<FacultyTosListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [uniTos, faculties] = await Promise.all([
        tosApi.getUniversityTos(),
        tosApi.getAllFacultyTos(),
      ]);
      setUniversityTos(uniTos);
      setFacultyList(faculties);
    } catch (error) {
      toast.error('Failed to load Terms of Service');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSaveUniversity = async (contentJson?: string, contentJsonAr?: string) => {
    const result = await tosApi.updateUniversityTos({ contentJson, contentJsonAr });
    setUniversityTos(result);
  };

  const handlePublishUniversity = async () => {
    const result = await tosApi.publishUniversityTos();
    setUniversityTos(result);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-[600px] w-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">{t('manageTos')}</h1>
        <p className="text-muted-foreground">{t('description')}</p>
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'university' | 'faculties')}>
        <TabsList>
          <TabsTrigger value="university">{t('universityTos')}</TabsTrigger>
          <TabsTrigger value="faculties">{t('allFaculties')}</TabsTrigger>
        </TabsList>

        <TabsContent value="university" className="mt-6">
          {universityTos && (
            <TosEditor
              title={t('universityTos')}
              description={t('universityDescription')}
              contentJson={universityTos.contentJson}
              contentJsonAr={universityTos.contentJsonAr}
              publishedContentJson={universityTos.publishedContentJson}
              publishedContentJsonAr={universityTos.publishedContentJsonAr}
              version={universityTos.version}
              isIndexed={universityTos.isIndexed}
              publishedAt={universityTos.publishedAt}
              onSave={handleSaveUniversity}
              onPublish={handlePublishUniversity}
            />
          )}
        </TabsContent>

        <TabsContent value="faculties" className="mt-6">
          <FacultyTosList faculties={facultyList} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
