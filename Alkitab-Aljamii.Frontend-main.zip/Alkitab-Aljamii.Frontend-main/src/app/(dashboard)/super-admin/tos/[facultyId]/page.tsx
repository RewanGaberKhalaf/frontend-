'use client';

import { useState, useEffect, useCallback, use } from 'react';
import { useTranslations } from 'next-intl';
import { useRouter } from 'next/navigation';
import { tosApi, type FacultyTos } from '@/lib/api';
import { TosEditor } from '@/components/tos';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

interface PageProps {
  params: Promise<{ facultyId: string }>;
}

export default function SuperAdminFacultyTosPage({ params }: PageProps) {
  const { facultyId } = use(params);
  const t = useTranslations('tos');
  const tCommon = useTranslations('common');
  const router = useRouter();

  const [facultyTos, setFacultyTos] = useState<FacultyTos | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const tos = await tosApi.getFacultyTosBySuperAdmin(facultyId);
      setFacultyTos(tos);
    } catch (error) {
      toast.error('Failed to load Faculty Terms of Service');
      router.push('/super-admin/tos');
    } finally {
      setIsLoading(false);
    }
  }, [facultyId, router]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSave = async (contentJson?: string, contentJsonAr?: string) => {
    const result = await tosApi.updateFacultyTosBySuperAdmin(facultyId, { contentJson, contentJsonAr });
    setFacultyTos(result);
  };

  const handlePublish = async () => {
    const result = await tosApi.publishFacultyTosBySuperAdmin(facultyId);
    setFacultyTos(result);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-10 w-32" />
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-[600px] w-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => router.push('/super-admin/tos')}
        className="mb-4"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        {tCommon('back')}
      </Button>

      <div className="space-y-2">
        <h1 className="text-3xl font-bold">
          {facultyTos?.facultyName || t('facultyTos')}
        </h1>
        <p className="text-muted-foreground">{t('facultyDescription')}</p>
      </div>

      {facultyTos && (
        <TosEditor
          title={t('facultyTos')}
          description={t('facultyDescription')}
          contentJson={facultyTos.contentJson}
          contentJsonAr={facultyTos.contentJsonAr}
          publishedContentJson={facultyTos.publishedContentJson}
          publishedContentJsonAr={facultyTos.publishedContentJsonAr}
          version={facultyTos.version}
          isIndexed={facultyTos.isIndexed}
          publishedAt={facultyTos.publishedAt}
          onSave={handleSave}
          onPublish={handlePublish}
        />
      )}
    </div>
  );
}
