'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Users, Search, Upload } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, ConfirmDialog, PageHeader } from '@/components/shared';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { PasswordResetDialog, useUserColumns } from '@/components/users';
import { QuickUploadModal } from '@/components/bulkImport';
import { useServerTable } from '@/hooks';
import { usersApi, type UserFilterParams } from '@/lib/api/users';
import { facultiesApi } from '@/lib/api/faculties';
import { useAuthStore } from '@/stores';
import type { User, Faculty, FacultyRole } from '@/types';

type UserFilters = Omit<UserFilterParams, keyof import('@/types').PaginationParams>;

export default function UsersPage() {
  const t = useTranslations();
  const router = useRouter();
  const currentUser = useAuthStore((state) => state.user);

  // Faculties for filter dropdown
  const [faculties, setFaculties] = useState<Faculty[]>([]);

  // Dialog states
  const [deleteUser, setDeleteUser] = useState<User | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [passwordUser, setPasswordUser] = useState<User | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  // Server-side table state
  const {
    data: users,
    meta,
    isLoading,
    error,
    searchValue,
    sortBy,
    sortOrder,
    filters,
    setPage,
    setPageSize,
    setSearch,
    setSort,
    setFilter,
    refetch,
  } = useServerTable<User, UserFilters>({
    fetchFn: usersApi.getAll,
    initialPageSize: 10,
    initialFilters: {},
  });

  // Fetch faculties for filter dropdown
  useEffect(() => {
    const fetchFaculties = async () => {
      try {
        const response = await facultiesApi.getAll({ limit: 100 });
        setFaculties(response.items);
      } catch (err) {
        console.error('Failed to fetch faculties:', err);
      }
    };
    fetchFaculties();
  }, []);

  // Handle user deletion
  const handleDelete = async () => {
    if (!deleteUser) return;
    setIsDeleting(true);
    try {
      await usersApi.delete(deleteUser.id);
      toast.success(t('users.deleteSuccess'));
      refetch();
    } catch {
      toast.error(t('users.deleteError'));
    } finally {
      setIsDeleting(false);
      setDeleteUser(null);
    }
  };

  // Handle user restore
  const handleRestore = async (user: User) => {
    try {
      await usersApi.restore(user.id);
      toast.success(t('users.restoreSuccess'));
      refetch();
    } catch {
      toast.error(t('users.restoreError'));
    }
  };

  // Handle password update
  const handlePasswordUpdate = async (password: string) => {
    if (!passwordUser) return;
    try {
      await usersApi.updatePassword(passwordUser.id, password);
      toast.success(t('users.passwordUpdateSuccess'));
      setPasswordUser(null);
    } catch {
      toast.error(t('users.passwordUpdateError'));
    }
  };

  // Handle role filter change
  const handleRoleFilter = (value: string) => {
    setFilter('role', value === 'all' ? undefined : value as FacultyRole);
  };

  // Handle faculty filter change
  const handleFacultyFilter = (value: string) => {
    setFilter('facultyId', value === 'all' ? undefined : value);
  };

  // Handle status filter change
  const handleStatusFilter = (value: string) => {
    setFilter('isActive', value === 'all' ? undefined : value === 'active');
  };

  const columns = useUserColumns({
    currentUserId: currentUser?.id,
    onDelete: setDeleteUser,
    onRestore: handleRestore,
    onResetPassword: setPasswordUser,
  });

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  const userImportTypes = [
    'students_only',
    'professors_only',
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Users}
        title={t('users.title')}
        description={t('users.subtitle')}
        badge={meta && <Badge variant="secondary">{meta.total} {t('users.usersTotal')}</Badge>}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setUploadModalOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              {t('bulkImport.uploadExcel')}
            </Button>
            <Button onClick={() => router.push('/super-admin/users/new')}>
              <Plus className="mr-2 h-4 w-4" />
              {t('users.create')}
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('common.search') + '...'}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={filters.role ?? 'all'}
          onValueChange={handleRoleFilter}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={t('users.filterByRole')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('users.allRoles')}</SelectItem>
            <SelectItem value="faculty_admin">{t('roles.FACULTY_ADMIN')}</SelectItem>
            <SelectItem value="professor">{t('roles.PROFESSOR')}</SelectItem>
            <SelectItem value="student">{t('roles.STUDENT')}</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={filters.facultyId ?? 'all'}
          onValueChange={handleFacultyFilter}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder={t('users.filterByFaculty')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('users.allFaculties')}</SelectItem>
            {faculties.map((faculty) => (
              <SelectItem key={faculty.id} value={faculty.id}>
                {faculty.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={filters.isActive === undefined ? 'all' : filters.isActive ? 'active' : 'inactive'}
          onValueChange={handleStatusFilter}
        >
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder={t('users.filterByStatus')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('common.all')}</SelectItem>
            <SelectItem value="active">{t('users.active')}</SelectItem>
            <SelectItem value="inactive">{t('users.inactive')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-md bg-destructive/10 p-4 text-destructive">
          {error}
        </div>
      )}

      {/* Table or Empty state */}
      {!isLoading && users.length === 0 && !searchValue && !filters.role && !filters.facultyId ? (
        <EmptyState
          title={t('users.noUsersFound')}
          description={t('users.noUsersDescription')}
          action={
            <Button onClick={() => router.push('/super-admin/users/new')}>
              <Plus className="mr-2 h-4 w-4" />
              {t('users.create')}
            </Button>
          }
        />
      ) : (
        <ServerDataTable
          columns={columns}
          data={users}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      )}

      <ConfirmDialog
        open={!!deleteUser}
        onOpenChange={(open) => !open && setDeleteUser(null)}
        title={t('users.deleteConfirmTitle')}
        description={t('users.deleteConfirmDescription')}
        confirmLabel={t('users.delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />

      <PasswordResetDialog
        open={!!passwordUser}
        onOpenChange={(open) => !open && setPasswordUser(null)}
        onSubmit={handlePasswordUpdate}
      />

      <QuickUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        allowedImportTypes={userImportTypes as any}
        onUploadComplete={() => {
          toast.success(t('bulkImport.uploadSuccess'));
          refetch();
        }}
      />
    </div>
  );
}
