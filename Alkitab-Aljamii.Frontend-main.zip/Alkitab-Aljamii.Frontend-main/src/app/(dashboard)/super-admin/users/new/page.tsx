'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { UserForm, type CreateUserFormData } from '@/components/users';
import { usersApi } from '@/lib/api/users';
import { useAuthStore } from '@/stores';

export default function NewUserPage() {
  const t = useTranslations();
  const router = useRouter();
  const currentUser = useAuthStore((state) => state.user);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (data: CreateUserFormData) => {
    setIsLoading(true);
    try {
      await usersApi.create(data);
      toast.success(t('users.createSuccess'));
      router.push('/super-admin/users');
    } catch (error: unknown) {
      const axiosError = error as { response?: { data?: { message?: unknown } } };
      const errMsg = axiosError.response?.data?.message;

      if (typeof errMsg == "object") {
        toast.error(t('users.passwordError'));
      }
      else if (typeof errMsg == "string") {
        toast.error(t('users.emailError'));
      }
      else {
        toast.error(t('users.createError'))
      }
     
       
     
      
     
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('users.createTitle')}</h2>
          <p className="text-muted-foreground">{t('users.createDescription')}</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('users.userDetails')}</CardTitle>
        </CardHeader>
        <CardContent>
          <UserForm
            onSubmit={handleSubmit}
            onCancel={() => router.back()}
            isLoading={isLoading}
            canCreateSuperAdmin={currentUser?.isSuperAdmin ?? false}
          />
        </CardContent>
      </Card>
    </div>
  );
}
