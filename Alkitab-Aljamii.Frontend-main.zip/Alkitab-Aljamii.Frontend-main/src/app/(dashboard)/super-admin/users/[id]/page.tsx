'use client';

import { useState, useEffect, use } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Loader2, Trash2, RotateCcw, KeyRound, Shield } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  UserForm,
  PasswordResetDialog,
  ManageFacultyRoles,
  UserInfoCard,
  UserAssociationsCard,
  type UpdateUserFormData,
} from '@/components/users';
import { ConfirmDialog } from '@/components/shared';
import { usersApi, type UserAssociations } from '@/lib/api/users';
import { FACULTY_ROLE_LABELS } from '@/lib/constants/user';
import type { User } from '@/types';

export default function UserDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const t = useTranslations();
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [associations, setAssociations] = useState<UserAssociations | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const refreshData = async () => {
    const [userData, assocData] = await Promise.all([
      usersApi.getById(id),
      usersApi.getAssociations(id),
    ]);
    setUser(userData);
    setAssociations(assocData);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        await refreshData();
      } catch (error) {
        console.error('Failed to fetch user:', error);
        toast.error(t('users.fetchError'));
        router.push('/super-admin/users');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
    // refreshData is a stable function that only depends on id
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, router, t]);

  const handleSubmit = async (data: UpdateUserFormData) => {
    setIsSaving(true);
    try {
      const updated = await usersApi.update(id, data);
      setUser(updated);
      toast.success(t('users.updateSuccess'));
    } catch (error) {
      console.error('Failed to update user:', error);
      toast.error(t('users.updateError'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await usersApi.delete(id);
      toast.success(t('users.deleteSuccess'));
      router.push('/super-admin/users');
    } catch (error) {
      console.error('Failed to delete user:', error);
      toast.error(t('users.deleteError'));
    } finally {
      setIsDeleting(false);
      setShowDeleteDialog(false);
    }
  };

  const handleRestore = async () => {
    try {
      const restored = await usersApi.restore(id);
      setUser(restored);
      toast.success(t('users.restoreSuccess'));
    } catch (error) {
      console.error('Failed to restore user:', error);
      toast.error(t('users.restoreError'));
    }
  };

  const handleUpdatePassword = async (password: string) => {
    await usersApi.updatePassword(id, password);
    toast.success(t('users.passwordUpdateSuccess'));
    setShowPasswordDialog(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) return null;

  const getRoleDisplay = () => {
    if (user.isSuperAdmin) return 'Super Admin';
    if (!user.facultyRoles || user.facultyRoles.length === 0) return 'No Roles';
    const uniqueRoles = [...new Set(user.facultyRoles.map(fr => fr.role))];
    return uniqueRoles.map(r => FACULTY_ROLE_LABELS[r]).join(', ');
  };

  const hasFacultyRoles = user.facultyRoles && user.facultyRoles.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-bold tracking-tight">{user.firstName} {user.lastName}</h2>
              <Badge variant={user.isActive ? 'default' : 'secondary'}>
                {user.isActive ? t('users.active') : t('users.inactive')}
              </Badge>
              {user.isSuperAdmin && (
                <Badge variant="destructive" className="gap-1">
                  <Shield className="h-3 w-3" />
                  Super Admin
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground">{user.email}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowPasswordDialog(true)}>
            <KeyRound className="mr-2 h-4 w-4" />
            {t('users.resetPassword')}
          </Button>
          {!user.isActive ? (
            <Button variant="outline" size="sm" onClick={handleRestore}>
              <RotateCcw className="mr-2 h-4 w-4" />
              {t('users.restore')}
            </Button>
          ) : (
            <Button variant="destructive" size="sm" onClick={() => setShowDeleteDialog(true)}>
              <Trash2 className="mr-2 h-4 w-4" />
              {t('users.delete')}
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>{t('users.editUser')}</CardTitle>
            <CardDescription>{t('users.editDescription')}</CardDescription>
          </CardHeader>
          <CardContent>
            <UserForm user={user} onSubmit={handleSubmit} onCancel={() => router.back()} isLoading={isSaving} />
          </CardContent>
        </Card>

        <UserInfoCard
          labels={{
            title: t('users.userInfo'),
            role: t('users.role'),
            lastLogin: t('users.lastLogin'),
            createdAt: t('users.createdAt'),
            updatedAt: t('users.updatedAt'),
            never: t('users.never'),
            nationalId: t('users.nationalId'),
            createdVia: t('users.createdVia'),
            profileStatus: t('users.profileStatus'),
            profileComplete: t('users.profileComplete'),
            profileIncomplete: t('users.profileIncomplete'),
            manual: t('users.manual'),
            webhook: t('users.webhook'),
            notSet: t('users.notSet'),
          }}
          roleDisplay={getRoleDisplay()}
          lastLogin={user.lastLogin}
          createdAt={user.createdAt}
          updatedAt={user.updatedAt}
          nationalId={user.nationalId}
          profileCompleted={user.profileCompleted}
          createdVia={user.createdVia}
        />
      </div>

      {!user.isSuperAdmin && (
        <Card>
          <CardHeader>
            <CardTitle>{t('users.manageFacultyRoles')}</CardTitle>
            <CardDescription>{t('users.manageFacultyRolesDescription')}</CardDescription>
          </CardHeader>
          <CardContent>
            <ManageFacultyRoles user={user} onUpdate={refreshData} />
          </CardContent>
        </Card>
      )}

      {associations && !user.isSuperAdmin && hasFacultyRoles && (
        <UserAssociationsCard
          associations={associations}
          labels={{
            title: t('users.associations'),
            description: t('users.associationsDescription'),
            faculties: t('nav.faculties'),
            subjects: t('nav.courses'),
            notAssignedToFaculty: t('users.notAssignedToFaculty'),
            notAssignedToSubject: t('users.notAssignedToSubject'),
          }}
        />
      )}

      <ConfirmDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        title={t('users.deleteConfirmTitle')}
        description={t('users.deleteConfirmDescription')}
        confirmLabel={t('users.delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />

      <PasswordResetDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onSubmit={handleUpdatePassword}
      />
    </div>
  );
}
