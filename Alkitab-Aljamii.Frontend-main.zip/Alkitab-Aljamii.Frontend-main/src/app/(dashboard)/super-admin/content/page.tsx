'use client';

import { useTranslations } from 'next-intl';
import { DeprecatedFeature } from '@/components/shared';
import { ROUTES } from '@/lib/constants/routes';

export default function ContentPage() {
  const t = useTranslations();

  return (
    <DeprecatedFeature
      redirectTo={ROUTES.SUPER_ADMIN.SUBJECTS}
      redirectLabel={t('deprecated.goToBooks')}
    />
  );
}
