'use client';

import { useEffect } from 'react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layout';
import { AuthGuard } from '@/components/auth';
import { ChatWidget } from '@/components/chat';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Check for context switch message (when user's role was revoked but they have other roles)
  useEffect(() => {
    const contextSwitchMsg = localStorage.getItem('auth_context_switch');
    if (contextSwitchMsg) {
      toast.warning(contextSwitchMsg, { duration: 6000 });
      localStorage.removeItem('auth_context_switch');
    }
  }, []);

  return (
    <AuthGuard>
      <MainLayout>{children}</MainLayout>
      <ChatWidget />
    </AuthGuard>
  );
}
