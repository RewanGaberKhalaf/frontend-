'use client';

import { useTranslations } from 'next-intl';
import { DeprecatedFeature } from '@/components/shared';

export default function ContentPreviewPage() {
  const t = useTranslations();

  return (
    <DeprecatedFeature
      redirectTo="/professor/books"
      redirectLabel={t('deprecated.goToBooks')}
    />
  );
}
