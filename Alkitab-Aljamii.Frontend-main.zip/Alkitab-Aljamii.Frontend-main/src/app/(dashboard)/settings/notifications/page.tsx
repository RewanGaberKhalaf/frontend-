'use client';

import { useEffect } from 'react';
import { Settings, Bell, Mail, Clock, Moon, MessageSquare } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader } from '@/components/shared';
import { useNotificationStore, useNotificationToastsEnabled, useSetNotificationToasts } from '@/stores';
import type { UpdatePreferencesRequest } from '@/lib/api/notifications';

export default function NotificationSettingsPage() {
  const t = useTranslations('notifications');
  const tCommon = useTranslations('common');

  const {
    preferences,
    isLoadingPreferences,
    fetchPreferences,
    updatePreferences,
  } = useNotificationStore();

  const toastsEnabled = useNotificationToastsEnabled();
  const setToastsEnabled = useSetNotificationToasts();

  const { register, handleSubmit, watch, setValue, reset } = useForm<UpdatePreferencesRequest>({
    defaultValues: {
      inAppEnabled: true,
      emailEnabled: true,
      digestEnabled: false,
      digestIntervalMinutes: 60,
      quietHoursEnabled: false,
      quietHoursStart: '22:00',
      quietHoursEnd: '08:00',
    },
  });

  // Load preferences on mount
  useEffect(() => {
    fetchPreferences();
  }, [fetchPreferences]);

  // Update form when preferences load
  useEffect(() => {
    if (preferences) {
      reset({
        inAppEnabled: preferences.inAppEnabled,
        emailEnabled: preferences.emailEnabled,
        digestEnabled: preferences.digestEnabled,
        digestIntervalMinutes: preferences.digestIntervalMinutes,
        quietHoursEnabled: preferences.quietHoursEnabled,
        quietHoursStart: preferences.quietHoursStart || '22:00',
        quietHoursEnd: preferences.quietHoursEnd || '08:00',
      });
    }
  }, [preferences, reset]);

  const onSubmit = async (data: UpdatePreferencesRequest) => {
    try {
      await updatePreferences(data);
      toast.success(t('preferences.saveSuccess'));
    } catch {
      toast.error(t('preferences.saveError'));
    }
  };

  const inAppEnabled = watch('inAppEnabled');
  const emailEnabled = watch('emailEnabled');
  const digestEnabled = watch('digestEnabled');
  const quietHoursEnabled = watch('quietHoursEnabled');

  if (isLoadingPreferences && !preferences) {
    return (
      <div className="space-y-6">
        <PageHeader
          icon={Settings}
          title={t('preferences.title')}
        />
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
                <Skeleton className="h-4 w-72" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-10 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Settings}
        title={t('preferences.title')}
      />

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* In-App Notifications */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Bell className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">{t('preferences.inAppEnabled')}</CardTitle>
                <CardDescription>{t('preferences.inAppEnabledDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Switch
              checked={inAppEnabled}
              onCheckedChange={(checked) => setValue('inAppEnabled', checked)}
            />
          </CardContent>
        </Card>

        {/* Toast Notifications (client-side only, not persisted to server) */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <MessageSquare className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">{t('preferences.toastsEnabled')}</CardTitle>
                <CardDescription>{t('preferences.toastsEnabledDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Switch
              checked={toastsEnabled}
              onCheckedChange={setToastsEnabled}
            />
          </CardContent>
        </Card>

        {/* Email Notifications */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Mail className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">{t('preferences.emailEnabled')}</CardTitle>
                <CardDescription>{t('preferences.emailEnabledDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Switch
              checked={emailEnabled}
              onCheckedChange={(checked) => setValue('emailEnabled', checked)}
            />
          </CardContent>
        </Card>

        {/* Digest Mode */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">{t('preferences.digestEnabled')}</CardTitle>
                <CardDescription>{t('preferences.digestEnabledDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Switch
              checked={digestEnabled}
              onCheckedChange={(checked) => setValue('digestEnabled', checked)}
            />
            {digestEnabled && (
              <>
                <Separator />
                <div className="space-y-2">
                  <Label htmlFor="digestInterval">{t('preferences.digestInterval')}</Label>
                  <Input
                    id="digestInterval"
                    type="number"
                    min={15}
                    max={1440}
                    {...register('digestIntervalMinutes', { valueAsNumber: true })}
                    className="w-32"
                  />
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Quiet Hours */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Moon className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">{t('preferences.quietHoursEnabled')}</CardTitle>
                <CardDescription>{t('preferences.quietHoursEnabledDescription')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Switch
              checked={quietHoursEnabled}
              onCheckedChange={(checked) => setValue('quietHoursEnabled', checked)}
            />
            {quietHoursEnabled && (
              <>
                <Separator />
                <div className="flex items-center gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quietStart">{t('preferences.quietHoursStart')}</Label>
                    <Input
                      id="quietStart"
                      type="time"
                      {...register('quietHoursStart')}
                      className="w-32"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="quietEnd">{t('preferences.quietHoursEnd')}</Label>
                    <Input
                      id="quietEnd"
                      type="time"
                      {...register('quietHoursEnd')}
                      className="w-32"
                    />
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Submit */}
        <div className="flex justify-end">
          <Button type="submit" disabled={isLoadingPreferences}>
            {tCommon('save')}
          </Button>
        </div>
      </form>
    </div>
  );
}
