'use client';

import { useTranslations } from 'next-intl';
import { DeprecatedFeature } from '@/components/shared';
import { ROUTES } from '@/lib/constants/routes';

export default function ContentApprovalPage() {
  const t = useTranslations();

  return (
    <DeprecatedFeature
      redirectTo={ROUTES.FACULTY_ADMIN.BOOK_APPROVAL}
      redirectLabel={t('deprecated.goToBooks')}
    />
  );
}
