'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AnnouncementList } from '@/components/notifications';
import { subjectsApi } from '@/lib/api/subjects';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import type { Subject } from '@/types';

export default function FacultyAdminAnnouncementsPage() {
  const t = useTranslations('notifications.announcements');
  const tMembers = useTranslations('members');
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [subjects, setSubjects] = useState<Subject[]>([]);

  // Load faculty's subjects
  useEffect(() => {
    if (!currentFacultyId) return;

    const loadSubjects = async () => {
      try {
        const result = await subjectsApi.getAll({ facultyId: currentFacultyId });
        setSubjects(result.items);
      } catch {
        // Silently fail
      }
    };
    loadSubjects();
  }, [currentFacultyId]);

  if (!currentFacultyId) {
    return (
      <div className="flex items-center justify-center py-12">
        <Alert className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {tMembers('noFacultySelected')}. {tMembers('selectFacultyHint', { role: 'announcements' })}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <AnnouncementList
      subjects={subjects}
      allowedRoles={['professor', 'student']}
      defaultFacultyId={currentFacultyId}
      hideFacultySelect={true}
      hideRoleSelect={false}
      title={t('title')}
      description="Send announcements to professors and students in your faculty"
    />
  );
}
