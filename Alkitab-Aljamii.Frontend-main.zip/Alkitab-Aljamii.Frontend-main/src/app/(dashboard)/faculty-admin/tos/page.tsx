'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { tosApi, type FacultyTos } from '@/lib/api';
import { TosEditor } from '@/components/tos';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export default function FacultyAdminTosPage() {
  const t = useTranslations('tos');
  const [facultyTos, setFacultyTos] = useState<FacultyTos | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const tos = await tosApi.getMyFacultyTos();
      setFacultyTos(tos);
    } catch (error) {
      toast.error('Failed to load Faculty Terms of Service');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSave = async (contentJson?: string, contentJsonAr?: string) => {
    const result = await tosApi.updateMyFacultyTos({ contentJson, contentJsonAr });
    setFacultyTos(result);
  };

  const handlePublish = async () => {
    const result = await tosApi.publishMyFacultyTos();
    setFacultyTos(result);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-[600px] w-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">{t('myFacultyTos')}</h1>
        <p className="text-muted-foreground">{t('facultyDescription')}</p>
      </div>

      {facultyTos && (
        <TosEditor
          title={facultyTos.facultyName || t('facultyTos')}
          description={t('facultyDescription')}
          contentJson={facultyTos.contentJson}
          contentJsonAr={facultyTos.contentJsonAr}
          publishedContentJson={facultyTos.publishedContentJson}
          publishedContentJsonAr={facultyTos.publishedContentJsonAr}
          version={facultyTos.version}
          isIndexed={facultyTos.isIndexed}
          publishedAt={facultyTos.publishedAt}
          onSave={handleSave}
          onPublish={handlePublish}
        />
      )}
    </div>
  );
}
