'use client';

import { useTranslations } from 'next-intl';
import { DeprecatedFeature } from '@/components/shared';
import { ROUTES } from '@/lib/constants/routes';

export default function CourseMappingsPage() {
  const t = useTranslations();

  return (
    <DeprecatedFeature
      redirectTo={ROUTES.FACULTY_ADMIN.SUBJECTS}
      redirectLabel={t('nav.courses')}
    />
  );
}
