'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import {
  quizApi,
  type QuestionBank,
  type Question,
  type Difficulty,
  type QuestionType,
} from '@/lib/api/quiz';

export interface QuestionsMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export function useFacultyQuestionBankDetail(bankId: string) {
  const t = useTranslations();

  // Bank state
  const [bank, setBank] = useState<QuestionBank | null>(null);
  const [bankLoading, setBankLoading] = useState(true);
  const [bankError, setBankError] = useState<string | null>(null);

  // Questions state
  const [questions, setQuestions] = useState<Question[]>([]);
  const [questionsLoading, setQuestionsLoading] = useState(true);
  const [questionsMeta, setQuestionsMeta] = useState<QuestionsMeta | null>(null);

  // Filters
  const [searchValue, setSearchValue] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState<Difficulty | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<QuestionType | 'all'>('all');
  const [page, setPage] = useState(1);

  // Expanded questions for viewing options
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null);

  // Fetch bank details
  useEffect(() => {
    const fetchBank = async () => {
      setBankLoading(true);
      setBankError(null);
      try {
        const data = await quizApi.getQuestionBank(bankId);
        setBank(data);
      } catch (err) {
        console.error('Failed to fetch bank:', err);
        setBankError(t('questionBanks.fetchError'));
      } finally {
        setBankLoading(false);
      }
    };
    fetchBank();
  }, [bankId, t]);

  // Fetch questions
  const fetchQuestions = useCallback(async () => {
    setQuestionsLoading(true);
    try {
      const response = await quizApi.getQuestions(bankId, {
        page,
        limit: 10,
        search: searchValue || undefined,
        difficulty: difficultyFilter !== 'all' ? difficultyFilter : undefined,
        questionType: typeFilter !== 'all' ? typeFilter : undefined,
      });
      setQuestions(response.items);
      setQuestionsMeta(response.meta);
    } catch (err) {
      console.error('Failed to fetch questions:', err);
      toast.error(t('questions.fetchError'));
    } finally {
      setQuestionsLoading(false);
    }
  }, [bankId, page, searchValue, difficultyFilter, typeFilter, t]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  // Debounced search - reset page when search changes
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchValue]);

  // Handle difficulty filter change
  const handleDifficultyFilter = useCallback((value: Difficulty | 'all') => {
    setDifficultyFilter(value);
    setPage(1);
  }, []);

  // Handle type filter change
  const handleTypeFilter = useCallback((value: QuestionType | 'all') => {
    setTypeFilter(value);
    setPage(1);
  }, []);

  return {
    // Bank state
    bank,
    bankLoading,
    bankError,
    // Questions state
    questions,
    questionsLoading,
    questionsMeta,
    // Filters
    searchValue,
    setSearchValue,
    difficultyFilter,
    typeFilter,
    page,
    setPage,
    // Expanded state
    expandedQuestion,
    setExpandedQuestion,
    // Handlers
    handleDifficultyFilter,
    handleTypeFilter,
  };
}

export function getDifficultyVariant(difficulty: Difficulty): 'default' | 'secondary' | 'destructive' {
  const variants: Record<Difficulty, 'default' | 'secondary' | 'destructive'> = {
    easy: 'default',
    medium: 'secondary',
    hard: 'destructive',
  };
  return variants[difficulty];
}
