'use client';

import { useParams, useRouter } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import { Database, Search, ArrowLeft, Filter, CheckCircle2, XCircle, BookOpen, ClipboardList } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader } from '@/components/shared';
import type { Difficulty, QuestionType } from '@/lib/api/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';
import { useFacultyQuestionBankDetail, getDifficultyVariant } from './use-faculty-question-bank-detail';
import { useState, useEffect } from 'react';
import { quizApi, type Quiz } from '@/lib/api/quiz';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function FacultyAdminQuestionBankDetailPage() {
  const t = useTranslations();
  const locale = useLocale();
  const router = useRouter();
  const params = useParams();
  const bankId = params['id'] as string;
  const isArabic = locale === 'ar';

  const {
    bank,
    bankLoading,
    bankError,
    questions,
    questionsLoading,
    questionsMeta,
    searchValue,
    setSearchValue,
    difficultyFilter,
    typeFilter,
    page,
    setPage,
    expandedQuestion,
    setExpandedQuestion,
    handleDifficultyFilter,
    handleTypeFilter,
  } = useFacultyQuestionBankDetail(bankId);

  // Quizzes state
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [quizzesLoading, setQuizzesLoading] = useState(false);

  // Fetch quizzes for this bank
  useEffect(() => {
    const fetchQuizzes = async () => {
      setQuizzesLoading(true);
      try {
        const data = await quizApi.getQuizzesByQuestionBank(bankId);
        setQuizzes(data);
      } catch (err) {
        console.error('Failed to fetch quizzes:', err);
      } finally {
        setQuizzesLoading(false);
      }
    };
    fetchQuizzes();
  }, [bankId]);

  const getDifficultyBadge = (difficulty: Difficulty) => {
    const labels: Record<Difficulty, string> = {
      easy: t('questions.easy'),
      medium: t('questions.medium'),
      hard: t('questions.hard'),
    };
    return <Badge variant={getDifficultyVariant(difficulty)}>{labels[difficulty]}</Badge>;
  };

  const getTypeBadge = (type: QuestionType) => (
    <Badge variant="outline">
      {type === 'multiple_choice' ? t('questions.multipleChoice') : t('questions.trueFalse')}
    </Badge>
  );

  if (bankLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (bankError || !bank) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <p className="text-destructive mb-4">{bankError || t('questionBanks.notFound')}</p>
        <Button onClick={() => router.push(ROUTES.FACULTY_ADMIN.QUESTION_BANKS)}><ArrowLeft className="mr-2 h-4 w-4" />{t('common.back')}</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 min-w-0 overflow-hidden">
      {/* Header */}
      <div className="flex items-start gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1" onClick={() => router.push(ROUTES.FACULTY_ADMIN.QUESTION_BANKS)}><ArrowLeft className="h-5 w-5" /></Button>
        <div className="flex-1 min-w-0">
          <PageHeader
            icon={Database}
            title={isArabic && bank.nameAr ? bank.nameAr : bank.name}
            description={isArabic && bank.descriptionAr ? bank.descriptionAr : bank.description || t('questionBanks.noDescription')}
            badge={<Badge variant={bank.isActive ? 'default' : 'secondary'}>{bank.isActive ? t('common.active') : t('common.inactive')}</Badge>}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="rounded-lg border bg-card p-4 col-span-2 sm:col-span-1">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1"><BookOpen className="h-4 w-4" /><span>{t('questionBanks.subject')}</span></div>
          <p className="font-medium truncate">{isArabic && bank.subjectNameAr ? bank.subjectNameAr : bank.subjectName}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground">{t('questionBanks.totalQuestions')}</p>
          <p className="text-2xl font-bold">{bank.totalQuestions}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-green-200 dark:border-green-800">
          <p className="text-sm text-muted-foreground">{t('questions.easy')}</p>
          <p className="text-2xl font-bold text-green-600">{bank.easyCount}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-yellow-200 dark:border-yellow-800">
          <p className="text-sm text-muted-foreground">{t('questions.medium')}</p>
          <p className="text-2xl font-bold text-yellow-600">{bank.mediumCount}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-red-200 dark:border-red-800">
          <p className="text-sm text-muted-foreground">{t('questions.hard')}</p>
          <p className="text-2xl font-bold text-red-600">{bank.hardCount}</p>
        </div>
      </div>

      {/* Tabs for Questions and Quizzes */}
      <Tabs defaultValue="questions" className="space-y-6">
        <TabsList>
          <TabsTrigger value="questions" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            {t('questions.title')} ({bank.totalQuestions})
          </TabsTrigger>
          <TabsTrigger value="quizzes" className="flex items-center gap-2">
            <ClipboardList className="h-4 w-4" />
            {t('quizzes.title')} ({quizzes.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="questions" className="space-y-6">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-3 rounded-lg border bg-card p-3 sm:p-4">
        <div className="relative flex-1 min-w-0 sm:min-w-[200px] sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder={t('questions.searchPlaceholder')} value={searchValue} onChange={(e) => setSearchValue(e.target.value)} className="pl-9" />
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <Select value={difficultyFilter} onValueChange={(v) => handleDifficultyFilter(v as Difficulty | 'all')}>
            <SelectTrigger className="w-[140px] sm:w-[160px]"><Filter className="mr-2 h-4 w-4 hidden sm:block" /><SelectValue placeholder={t('questions.filterByDifficulty')} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              <SelectItem value="easy">{t('questions.easy')}</SelectItem>
              <SelectItem value="medium">{t('questions.medium')}</SelectItem>
              <SelectItem value="hard">{t('questions.hard')}</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={(v) => handleTypeFilter(v as QuestionType | 'all')}>
            <SelectTrigger className="w-[140px] sm:w-[180px]"><Filter className="mr-2 h-4 w-4 hidden sm:block" /><SelectValue placeholder={t('questions.filterByType')} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              <SelectItem value="multiple_choice">{t('questions.multipleChoice')}</SelectItem>
              <SelectItem value="true_false">{t('questions.trueFalse')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Questions List */}
      <div className="rounded-md border">
        {questionsLoading ? (
          <div className="p-4 space-y-4">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
        ) : questions.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            {searchValue || difficultyFilter !== 'all' || typeFilter !== 'all' ? t('questions.noResults') : t('questions.noQuestions')}
          </div>
        ) : (
          <Accordion type="single" collapsible value={expandedQuestion || undefined} onValueChange={(val) => setExpandedQuestion(val || null)}>
            {questions.map((question, index) => (
              <AccordionItem key={question.id} value={question.id}>
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex items-start gap-3 text-left w-full">
                    <span className="text-muted-foreground shrink-0 mt-0.5">{(page - 1) * 10 + index + 1}.</span>
                    <div className="flex-1 min-w-0 space-y-1">
                      <p className="font-medium line-clamp-2">{isArabic && question.questionTextAr ? question.questionTextAr : question.questionText}</p>
                      <div className="flex flex-wrap items-center gap-2">
                        {getTypeBadge(question.questionType)}
                        {getDifficultyBadge(question.difficulty)}
                        <Badge variant="outline">{question.points} {t('questions.points')}</Badge>
                        {question.isActive ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <XCircle className="h-4 w-4 text-muted-foreground" />}
                      </div>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <div className="ms-7 space-y-3">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">{t('questions.options')}:</p>
                      <div className="space-y-1.5">
                        {question.options.sort((a, b) => a.order - b.order).map((option) => (
                          <div key={option.id} className={cn('flex items-start gap-2 p-2 rounded-md text-sm', option.isCorrect ? 'bg-green-100 dark:bg-green-900/30 border border-green-300 dark:border-green-700' : 'bg-muted/50')}>
                            {option.isCorrect && <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />}
                            <span className={cn(!option.isCorrect && 'ms-6')}>{isArabic && option.textAr ? option.textAr : option.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    {(question.explanation || question.explanationAr) && (
                      <div className="space-y-1">
                        <p className="text-sm font-medium text-muted-foreground">{t('questions.explanation')}:</p>
                        <p className="text-sm text-muted-foreground bg-muted/50 p-2 rounded-md">{isArabic && question.explanationAr ? question.explanationAr : question.explanation}</p>
                      </div>
                    )}
                    {question.timesUsed > 0 && (
                      <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2 border-t">
                        <span>{t('questions.timesUsed')}: {question.timesUsed}</span>
                        <span className={cn(question.correctRate >= 70 ? 'text-green-600' : question.correctRate >= 40 ? 'text-yellow-600' : 'text-red-600')}>{t('questions.correctRate')}: {question.correctRate.toFixed(1)}%</span>
                      </div>
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        )}

        {/* Pagination */}
        {questionsMeta && questionsMeta.totalPages > 1 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-t px-3 sm:px-4 py-3">
            <p className="text-sm text-muted-foreground text-center sm:text-left">{t('common.showingOf', { from: (questionsMeta.page - 1) * questionsMeta.limit + 1, to: Math.min(questionsMeta.page * questionsMeta.limit, questionsMeta.total), total: questionsMeta.total })}</p>
            <div className="flex items-center justify-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setPage(page - 1)} disabled={page <= 1}>{t('common.previous')}</Button>
              <span className="text-sm">{questionsMeta.page} / {questionsMeta.totalPages}</span>
              <Button variant="outline" size="sm" onClick={() => setPage(page + 1)} disabled={page >= questionsMeta.totalPages}>{t('common.next')}</Button>
            </div>
          </div>
        )}
      </div>
        </TabsContent>

        <TabsContent value="quizzes" className="space-y-6">
          {/* Quizzes List */}
          <div className="rounded-md border overflow-x-auto">
            <Table className="table-fixed">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[30%] min-w-[200px]">{t('quizzes.name')}</TableHead>
                  <TableHead className="w-[140px] text-center">{t('quizzes.totalQuestions')}</TableHead>
                  <TableHead className="w-[90px] text-center">{t('quizzes.timeLimit')}</TableHead>
                  <TableHead className="w-[90px] text-center">{t('quizzes.passingScore')}</TableHead>
                  <TableHead className="w-[90px]">{t('common.status')}</TableHead>
                  <TableHead className="w-[100px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quizzesLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-20" /></TableCell>
                    </TableRow>
                  ))
                ) : quizzes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      {t('quizzes.noQuizzes')}
                    </TableCell>
                  </TableRow>
                ) : (
                  quizzes.map((quiz) => (
                    <TableRow key={quiz.id}>
                      <TableCell>
                        <div className="min-w-0">
                          <p className="font-medium truncate">{isArabic && quiz.titleAr ? quiz.titleAr : quiz.title}</p>
                          {!isArabic && quiz.titleAr && <p className="text-sm text-muted-foreground truncate" dir="rtl">{quiz.titleAr}</p>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1 text-xs">
                          <span className="px-1.5 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">{quiz.easyQuestions}</span>
                          <span className="px-1.5 py-0.5 rounded bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400">{quiz.mediumQuestions}</span>
                          <span className="px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">{quiz.hardQuestions}</span>
                          <span className="ms-1 font-medium">= {quiz.totalQuestions}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center">
                          {quiz.timeLimit ? `${quiz.timeLimit} min` : '-'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center font-medium">{quiz.passingScore}%</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={quiz.isActive ? 'default' : 'secondary'}>
                          {quiz.isActive ? t('common.active') : t('common.inactive')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-muted-foreground">{t('common.viewOnly')}</span>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
