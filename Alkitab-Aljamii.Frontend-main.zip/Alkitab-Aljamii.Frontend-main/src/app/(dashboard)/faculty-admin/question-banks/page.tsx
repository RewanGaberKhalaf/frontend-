'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Database, BookOpen, HelpCircle, Eye } from 'lucide-react';
import { useTranslations, useLocale } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  EmptyState,
  PageHeader,
  FilterBar,
  FilterGroup,
  SearchInput,
  SubjectFilter,
  StatusFilter,
} from '@/components/shared';
import { useServerTable } from '@/hooks';
import {
  quizApi,
  type QuestionBank,
  type QuestionBankQueryParams,
} from '@/lib/api/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';

type BankFilters = Omit<QuestionBankQueryParams, 'page' | 'limit'>;

export default function FacultyAdminQuestionBanksPage() {
  const t = useTranslations();
  const locale = useLocale();
  const router = useRouter();
  const searchParams = useSearchParams();
  const isArabic = locale === 'ar';

  // Get initial subject from URL
  const initialSubjectId = searchParams.get('subjectId') || undefined;

  // Server-side table state
  const {
    data: banks,
    meta,
    isLoading,
    error,
    searchValue,
    filters,
    setPage,
    setSearch,
    setFilter,
  } = useServerTable<QuestionBank, BankFilters>({
    fetchFn: quizApi.getQuestionBanks,
    initialPageSize: 10,
    initialFilters: { subjectId: initialSubjectId },
  });

  // Handle subject filter with URL sync
  const handleSubjectFilter = (subjectId: string | undefined) => {
    setFilter('subjectId', subjectId);
    // Update URL
    const url = new URL(window.location.href);
    if (subjectId) {
      url.searchParams.set('subjectId', subjectId);
    } else {
      url.searchParams.delete('subjectId');
    }
    router.replace(url.pathname + url.search);
  };

  // Handle status filter
  const handleStatusFilter = (value: boolean | undefined) => {
    setFilter('isActive', value);
  };

  const getDifficultyColor = (count: number, total: number) => {
    const percentage = total > 0 ? (count / total) * 100 : 0;
    if (percentage < 20) return 'text-muted-foreground';
    if (percentage < 40) return 'text-yellow-600';
    return 'text-green-600';
  };

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Database}
        title={t('questionBanks.title')}
        description={t('questionBanks.description')}
        badge={
          meta && (
            <Badge variant="secondary">
              {meta.total} {t('questionBanks.banksTotal')}
            </Badge>
          )
        }
      />

      {/* Filters */}
      <FilterBar>
        <SearchInput value={searchValue} onChange={setSearch} />
        <FilterGroup>
          <SubjectFilter
            value={filters.subjectId}
            onChange={handleSubjectFilter}
          />
          <StatusFilter
            value={filters.isActive}
            onChange={handleStatusFilter}
          />
        </FilterGroup>
      </FilterBar>

      {/* Error state */}
      {error && (
        <div className="rounded-md bg-destructive/10 p-4 text-destructive">
          {error}
        </div>
      )}

      {/* Table or Empty state */}
      {!isLoading && banks.length === 0 && !searchValue && !filters.subjectId ? (
        <EmptyState
          title={t('questionBanks.nobanks')}
          description={t('questionBanks.nobanksDescription')}
        />
      ) : (
        <div className="rounded-md border overflow-x-auto">
          <Table className="table-fixed">
            <TableHeader>
              <TableRow>
                <TableHead className="w-[30%] min-w-[200px]">{t('questionBanks.name')}</TableHead>
                <TableHead className="w-[20%] min-w-[150px]">{t('questionBanks.subject')}</TableHead>
                <TableHead className="w-[80px] text-center">
                  {t('questionBanks.questions')}
                </TableHead>
                <TableHead className="w-[160px] text-center">
                  {t('questionBanks.difficulty')}
                </TableHead>
                <TableHead className="w-[90px]">{t('common.status')}</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Skeleton className="h-5 w-40" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-5 w-32" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-5 w-16 mx-auto" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-5 w-24 mx-auto" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-5 w-16" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-8 w-16" />
                    </TableCell>
                  </TableRow>
                ))
              ) : banks.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    {t('questionBanks.noResults')}
                  </TableCell>
                </TableRow>
              ) : (
                banks.map((bank) => (
                  <TableRow key={bank.id}>
                    <TableCell>
                      <div className="min-w-0">
                        <p className="font-medium truncate">{bank.name}</p>
                        {bank.nameAr && (
                          <p className="text-sm text-muted-foreground truncate" dir="rtl">
                            {bank.nameAr}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 min-w-0">
                        <BookOpen className="h-4 w-4 text-muted-foreground shrink-0" />
                        <span className="truncate">
                          {isArabic && bank.subjectNameAr ? bank.subjectNameAr : bank.subjectName}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <HelpCircle className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{bank.totalQuestions}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-2 text-xs">
                        <span
                          className={cn(
                            'px-1.5 py-0.5 rounded',
                            getDifficultyColor(bank.easyCount, bank.totalQuestions),
                            'bg-green-100 dark:bg-green-900/30'
                          )}
                        >
                          E: {bank.easyCount}
                        </span>
                        <span
                          className={cn(
                            'px-1.5 py-0.5 rounded',
                            getDifficultyColor(bank.mediumCount, bank.totalQuestions),
                            'bg-yellow-100 dark:bg-yellow-900/30'
                          )}
                        >
                          M: {bank.mediumCount}
                        </span>
                        <span
                          className={cn(
                            'px-1.5 py-0.5 rounded',
                            getDifficultyColor(bank.hardCount, bank.totalQuestions),
                            'bg-red-100 dark:bg-red-900/30'
                          )}
                        >
                          H: {bank.hardCount}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={bank.isActive ? 'default' : 'secondary'}>
                        {bank.isActive ? t('common.active') : t('common.inactive')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          router.push(ROUTES.FACULTY_ADMIN.QUESTION_BANK_DETAIL(bank.id))
                        }
                      >
                        <Eye className="h-4 w-4 me-1" />
                        {t('common.view')}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {meta && meta.totalPages > 1 && (
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-t px-3 sm:px-4 py-3">
              <p className="text-sm text-muted-foreground text-center sm:text-left">
                {t('common.showingOf', {
                  from: (meta.page - 1) * meta.limit + 1,
                  to: Math.min(meta.page * meta.limit, meta.total),
                  total: meta.total,
                })}
              </p>
              <div className="flex items-center justify-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(meta.page - 1)}
                  disabled={meta.page <= 1}
                >
                  {t('common.previous')}
                </Button>
                <span className="text-sm">
                  {meta.page} / {meta.totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(meta.page + 1)}
                  disabled={meta.page >= meta.totalPages}
                >
                  {t('common.next')}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
