'use client';

import { useState, useEffect } from 'react';
import { Loader2, Users, AlertTriangle, TrendingUp, GraduationCap, BookOpen, ArrowRight, Settings, Info } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  performanceApi,
  type FacultyPerformanceOverview,
  type SubjectPerformanceOverview,
  type ProfessorPerformanceSummary,
} from '@/lib/api/performance';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import { EmptyState } from '@/components/shared';
import {
  MetricCard,
  RiskDistributionChart,
  ApiTrendChart,
} from '@/components/performance';

export default function FacultyAdminPerformancePage() {
  const t = useTranslations();
  const locale = useLocale();
  void locale;
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [overview, setOverview] = useState<FacultyPerformanceOverview | null>(null);
  const [subjects, setSubjects] = useState<SubjectPerformanceOverview[]>([]);
  const [professors, setProfessors] = useState<ProfessorPerformanceSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const loadData = async () => {
      if (!currentFacultyId) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      try {
        const [overviewData, subjectsData, professorsData] = await Promise.all([
          performanceApi.facultyAdmin.getOverview(),
          performanceApi.facultyAdmin.getSubjects(),
          performanceApi.facultyAdmin.getProfessors(),
        ]);
        setOverview(overviewData);
        setSubjects(subjectsData);
        setProfessors(professorsData);
      } catch {
        toast.error(t('performance.failedToLoad'));
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [currentFacultyId]);

  if (!currentFacultyId) {
    return <EmptyState title={t('dashboard.facultyAdmin.noFacultySelected')} description={t('dashboard.facultyAdmin.selectFacultyHeader')} />;
  }

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!overview) {
    return <EmptyState title={t('performance.noData')} description={t('performance.noDataDescription')} />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('performance.facultyTitle')}</h2>
          <p className="text-muted-foreground">{t('performance.facultySubtitle')}</p>
        </div>
        <div className="flex gap-2">
          {overview.criticalAlertCount > 0 && (
            <Button size="sm" variant="destructive">
              <AlertTriangle className="me-2 h-4 w-4" />
              {overview.criticalAlertCount} {t('performance.criticalAlerts')}
            </Button>
          )}
          <Button size="sm" variant="outline" asChild>
            <Link href="/faculty-admin/performance/settings">
              <Settings className="me-2 h-4 w-4" />
              {t('performance.alertSettings')}
            </Link>
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">{t('performance.tabs.overview')}</TabsTrigger>
          <TabsTrigger value="subjects">{t('performance.tabs.subjects')}</TabsTrigger>
          <TabsTrigger value="professors">{t('performance.tabs.professors')}</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Stat Cards */}
          <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
            <MetricCard
              title={t('performance.metrics.totalStudents')}
              value={overview.totalStudents}
              icon={Users}
              iconColor="text-blue-600"
            />
            <MetricCard
              title={t('performance.metrics.totalProfessors')}
              value={overview.totalProfessors}
              icon={GraduationCap}
              iconColor="text-purple-600"
            />
            <MetricCard
              title={t('performanceMetrics.facultyAverageApi')}
              value={overview.averageApi}
              format="number"
              icon={TrendingUp}
              iconColor="text-green-600"
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.apiTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.apiDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.apiCompletion')}</li>
                    <li>{t('performanceMetrics.apiQuizQuality')}</li>
                    <li>{t('performanceMetrics.apiEngagement')}</li>
                    <li>{t('performanceMetrics.apiConsistency')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.atRiskStudents')}
              value={overview.atRiskStudentCount}
              icon={AlertTriangle}
              iconColor={overview.atRiskStudentCount > 0 ? 'text-orange-600' : 'text-muted-foreground'}
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.atRiskStudentsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.atRiskStudentsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.atRiskCriteria1')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria2')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria3')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria4')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.criticalAlerts')}
              value={overview.criticalAlertCount}
              icon={AlertTriangle}
              iconColor={overview.criticalAlertCount > 0 ? 'text-red-600' : 'text-muted-foreground'}
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.criticalAlertsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.criticalAlertsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.criticalAlertsCriteria1')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria2')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria3')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria4')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.activeInterventions')}
              value={overview.activeInterventions}
              icon={TrendingUp}
              iconColor="text-cyan-600"
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.activeInterventionsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.activeInterventionsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.activeInterventionsCriteria1')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria2')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria3')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria4')}</li>
                  </ul>
                </div>
              }
            />
          </div>

          {/* Charts Row */}
          <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
            <RiskDistributionChart
              distribution={overview.riskDistribution}
              title={t('performance.cards.studentRiskDistribution')}
            />
            <ApiTrendChart
              data={overview.apiTrend}
              title={t('performance.cards.facultyApiTrend')}
              subtitle={t('performance.cards.last30Days')}
            />
          </div>

          {/* Additional Metrics */}
          <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-1">
                  {t('performanceMetrics.completionRate')}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button type="button" className="text-muted-foreground hover:text-foreground transition-colors">
                        <Info className="h-3.5 w-3.5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs" sideOffset={5}>
                      <div className="space-y-1.5 text-start">
                        <p className="font-medium">{t('performanceMetrics.completionRateTitle')}</p>
                        <p className="text-muted-foreground">{t('performanceMetrics.completionRateDescription')}</p>
                        <ul className="list-disc ps-4 space-y-0.5 text-xs">
                          <li>{t('performanceMetrics.completionRateCriteria1')}</li>
                          <li>{t('performanceMetrics.completionRateCriteria2')}</li>
                          <li>{t('performanceMetrics.completionRateCriteria3')}</li>
                        </ul>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{Math.round(overview.averageCompletionRate)}%</div>
                <p className="text-xs text-muted-foreground">{t('performance.cards.averageAcrossStudents')}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-1">
                  {t('performanceMetrics.quizPerformance')}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button type="button" className="text-muted-foreground hover:text-foreground transition-colors">
                        <Info className="h-3.5 w-3.5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs" sideOffset={5}>
                      <div className="space-y-1.5 text-start">
                        <p className="font-medium">{t('performanceMetrics.quizPerformanceTitle')}</p>
                        <p className="text-muted-foreground">{t('performanceMetrics.quizPerformanceDescription')}</p>
                        <ul className="list-disc ps-4 space-y-0.5 text-xs">
                          <li>{t('performanceMetrics.quizPerformanceCriteria1')}</li>
                          <li>{t('performanceMetrics.quizPerformanceCriteria2')}</li>
                          <li>{t('performanceMetrics.quizPerformanceCriteria3')}</li>
                        </ul>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{Math.round(overview.averageQuizScore)}%</div>
                <p className="text-xs text-muted-foreground">{t('performance.cards.averageQuizScore')}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">{t('performance.cards.pendingAlerts')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-yellow-600">{overview.pendingAlertCount}</div>
                <p className="text-xs text-muted-foreground">{t('performance.cards.awaitingAcknowledgment')}</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="subjects" className="space-y-6 mt-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                {t('performance.cards.subjectPerformance')}
              </CardTitle>
              <CardDescription className="text-xs">{t('performance.cards.subjectPerformanceDesc')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('performance.table.subject')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.students')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.avgApi')}</TableHead>
                      <TableHead className="text-center">{t('performanceMetrics.completionRate')}</TableHead>
                      <TableHead className="text-center">{t('performanceMetrics.quizPerformance')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.atRisk')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {subjects.length > 0 ? (
                      subjects.map((subject) => (
                        <TableRow key={subject.subjectId}>
                          <TableCell>
                            <p className="font-medium">{subject.subjectName}</p>
                            {subject.subjectNameAr && (
                              <p className="text-xs text-muted-foreground">{subject.subjectNameAr}</p>
                            )}
                          </TableCell>
                          <TableCell className="text-center">{subject.studentCount}</TableCell>
                          <TableCell className="text-center">
                            <span className={
                              subject.averageApi >= 70 ? 'text-green-600 font-semibold' :
                              subject.averageApi >= 50 ? 'text-yellow-600 font-semibold' :
                              'text-red-600 font-semibold'
                            }>
                              {Math.round(subject.averageApi)}
                            </span>
                          </TableCell>
                          <TableCell className="text-center">{Math.round(subject.averageCompletionRate)}%</TableCell>
                          <TableCell className="text-center">{Math.round(subject.averageQuizScore)}%</TableCell>
                          <TableCell className="text-center">
                            {subject.atRiskCount > 0 ? (
                              <span className="text-orange-600 font-medium">{subject.atRiskCount}</span>
                            ) : (
                              <span className="text-muted-foreground">0</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          {t('performance.table.noSubjectData')}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="professors" className="space-y-6 mt-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <GraduationCap className="h-4 w-4" />
                {t('performance.cards.professorPerformance')}
              </CardTitle>
              <CardDescription className="text-xs">{t('performance.cards.professorPerformanceDesc')}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('performance.table.professor')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.students')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.avgStudentApi')}</TableHead>
                      <TableHead className="text-center">{t('performance.table.atRisk')}</TableHead>
                      <TableHead className="text-center">{t('performanceMetrics.activeInterventions')}</TableHead>
                      <TableHead className="text-center">{t('performanceMetrics.interventionSuccessRate')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {professors.length > 0 ? (
                      professors.map((prof) => (
                        <TableRow key={prof.userId}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{prof.firstName} {prof.lastName}</p>
                              {prof.email && (
                                <p className="text-xs text-muted-foreground">{prof.email}</p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">{prof.studentCount}</TableCell>
                          <TableCell className="text-center">
                            <span className={
                              prof.averageStudentApi >= 70 ? 'text-green-600 font-semibold' :
                              prof.averageStudentApi >= 50 ? 'text-yellow-600 font-semibold' :
                              'text-red-600 font-semibold'
                            }>
                              {Math.round(prof.averageStudentApi)}
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            {prof.atRiskStudentCount > 0 ? (
                              <span className="text-orange-600 font-medium">{prof.atRiskStudentCount}</span>
                            ) : (
                              <span className="text-muted-foreground">0</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">{prof.activeInterventions}</TableCell>
                          <TableCell className="text-center">
                            {prof.completedInterventions > 0 ? (
                              <span className="text-green-600 font-medium">
                                {Math.round(prof.interventionSuccessRate)}%
                              </span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          {t('performance.table.noProfessorData')}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
