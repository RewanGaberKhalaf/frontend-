'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Pencil, Trash2, Eye, BookOpen, Search, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { QuickUploadModal } from '@/components/bulkImport';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, PageHeader } from '@/components/shared';
import { SubjectForm } from '@/components/subjects';
import { useServerTable } from '@/hooks';
import { subjectsApi, type SubjectFilterParams } from '@/lib/api/subjects';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import type { Subject, CreateSubjectDto, UpdateSubjectDto, PaginationParams } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';

type SubjectFilters = Omit<SubjectFilterParams, keyof PaginationParams>;

export default function FacultySubjectsPage() {
  const t = useTranslations();
  const router = useRouter();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const fetchSubjects = useCallback(
    (params: PaginationParams & SubjectFilters) => {
      if (!currentFacultyId) {
        return Promise.resolve({
          items: [],
          meta: { total: 0, page: 1, limit: 10, totalPages: 0, hasNextPage: false, hasPreviousPage: false },
        });
      }
      return subjectsApi.getByFaculty(currentFacultyId, params);
    },
    [currentFacultyId]
  );

  const {
    data: subjects,
    meta,
    isLoading,
    searchValue,
    sortBy,
    sortOrder,
    filters,
    setPage,
    setPageSize,
    setSearch,
    setSort,
    setFilter,
    refetch,
  } = useServerTable<Subject, SubjectFilters>({
    fetchFn: fetchSubjects,
    initialPageSize: 10,
    fetchOnMount: !!currentFacultyId,
    deps: [currentFacultyId],
  });

  const handleStatusFilter = (value: string) => {
    setFilter('isActive', value === 'all' ? undefined : value === 'active');
  };

  const handleCreate = async (data: CreateSubjectDto) => {
    if (!currentFacultyId) return;
    setIsSubmitting(true);
    try {
      await subjectsApi.create({ ...data, facultyId: currentFacultyId });
      toast.success(t('subjects.createSuccess'));
      setDialogOpen(false);
      refetch();
    } catch {
      toast.error(t('subjects.createError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdate = async (data: UpdateSubjectDto) => {
    if (!editingSubject) return;
    setIsSubmitting(true);
    try {
      await subjectsApi.update(editingSubject.id, data);
      toast.success(t('subjects.updateSuccess'));
      setDialogOpen(false);
      setEditingSubject(null);
      refetch();
    } catch {
      toast.error(t('subjects.updateError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm(t('subjects.deleteConfirm'))) return;
    try {
      await subjectsApi.delete(id);
      toast.success(t('subjects.deleteSuccess'));
      refetch();
    } catch {
      toast.error(t('subjects.deleteError'));
    }
  };

  const openCreate = () => { setEditingSubject(null); setDialogOpen(true); };
  const openEdit = (subject: Subject) => { setEditingSubject(subject); setDialogOpen(true); };

  const columns: ColumnDef<Subject>[] = [
    { accessorKey: 'name', header: t('subjects.name'), enableSorting: true },
    { accessorKey: 'code', header: t('subjects.code'), enableSorting: true },
    {
      accessorKey: 'isActive',
      header: t('subjects.status'),
      enableSorting: true,
      cell: ({ row }) => (
        <Badge variant={row.original.isActive ? 'success' : 'muted'}>
          {row.original.isActive ? t('subjects.active') : t('subjects.inactive')}
        </Badge>
      ),
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" onClick={() => router.push(`/faculty-admin/subjects/${row.original.id}`)}>
                <Eye className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('tooltips.subjects.view')}</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" onClick={() => openEdit(row.original)}>
                <Pencil className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('tooltips.subjects.edit')}</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" onClick={() => handleDelete(row.original.id)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('tooltips.subjects.delete')}</TooltipContent>
          </Tooltip>
        </div>
      ),
    },
  ];

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  if (!currentFacultyId) {
    return <EmptyState title={t('dashboard.facultyAdmin.noFacultySelected')} description={t('dashboard.facultyAdmin.selectFacultyHeader')} />;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={BookOpen}
        title={t('subjects.title')}
        description={t('subjects.facultySubtitle')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setUploadModalOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Excel File
            </Button>
            <Button onClick={openCreate}>
              <Plus className="mr-2 h-4 w-4" />{t('subjects.createSubject')}
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('subjects.searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={filters.isActive === undefined ? 'all' : filters.isActive ? 'active' : 'inactive'}
          onValueChange={handleStatusFilter}
        >
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder={t('subjects.filterByStatus')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('common.all')}</SelectItem>
            <SelectItem value="active">{t('subjects.active')}</SelectItem>
            <SelectItem value="inactive">{t('subjects.inactive')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!isLoading && subjects.length === 0 && !searchValue ? (
        <EmptyState title={t('subjects.noSubjects')} description={t('subjects.createFirstSubject')} action={
          <Button onClick={openCreate}><Plus className="me-2 h-4 w-4" />{t('subjects.createSubject')}</Button>
        } />
      ) : (
        <ServerDataTable
          columns={columns}
          data={subjects}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingSubject ? t('subjects.editSubject') : t('subjects.createSubject')}</DialogTitle>
          </DialogHeader>
          <SubjectForm
            subject={editingSubject ?? undefined}
            onSubmit={editingSubject ? handleUpdate : handleCreate}
            onCancel={() => setDialogOpen(false)}
            isLoading={isSubmitting}
          />
        </DialogContent>
      </Dialog>

      <QuickUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        allowedImportTypes={undefined}
        onUploadComplete={() => {
          toast.success(t('common.success'));
          refetch();
        }}
      />
    </div>
  );
}
