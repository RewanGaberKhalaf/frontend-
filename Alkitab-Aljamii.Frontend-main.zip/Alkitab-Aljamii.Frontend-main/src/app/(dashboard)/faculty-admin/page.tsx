'use client';

import { useState, useEffect } from 'react';
import { Users, CheckSquare, Clock, Loader2, BookOpen, ArrowRight, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip as UITooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { statsApi, type FacultyAdminStats } from '@/lib/api';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import { EmptyState } from '@/components/shared';
import { ChartTooltip, ChartLegend } from '@/components/shared/chart-tooltip';
import { LayoutDashboard } from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  approved: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  rejected: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
};

export default function FacultyAdminDashboard() {
  const t = useTranslations();
  const locale = useLocale();
  void locale; // Used for locale-aware rendering

  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [stats, setStats] = useState<FacultyAdminStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      if (!currentFacultyId) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      try {
        const data = await statsApi.getFacultyAdminStats();
        setStats(data);
      } catch {
        toast.error(t('dashboard.failedToLoadStats'));
      } finally {
        setIsLoading(false);
      }
    };
    loadStats();
  }, [currentFacultyId, t]);

  if (!currentFacultyId) {
    return <EmptyState title={t('dashboard.facultyAdmin.noFacultySelected')} description={t('dashboard.facultyAdmin.selectFacultyHeader')} />;
  }

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const statCards = [
    { title: t('dashboard.facultyAdmin.professors'), value: stats?.totalProfessors ?? 0, icon: Users, desc: t('dashboard.facultyAdmin.inYourFaculty'), href: '/faculty-admin/professors', color: 'text-blue-600' },
    { title: t('dashboard.facultyAdmin.students'), value: stats?.totalStudents ?? 0, icon: Users, desc: t('dashboard.facultyAdmin.enrolledStudents'), href: '/faculty-admin/students', color: 'text-purple-600' },
    { title: t('dashboard.facultyAdmin.subjects'), value: stats?.totalSubjects ?? 0, icon: BookOpen, desc: t('dashboard.facultyAdmin.activeCourses'), href: '/faculty-admin/subjects', color: 'text-emerald-600' },
    { title: t('dashboard.facultyAdmin.pending'), value: stats?.pendingBooks ?? 0, icon: Clock, desc: t('dashboard.facultyAdmin.awaitingReview'), href: '/faculty-admin/book-approval', color: (stats?.pendingBooks ?? 0) > 0 ? 'text-yellow-600' : 'text-muted-foreground' },
  ];

  const bookStatusData = [
    { name: t('books.approved'), value: stats?.approvedBooks ?? 0, color: '#10b981' },
    { name: t('books.pending'), value: stats?.pendingBooks ?? 0, color: '#f59e0b' },
    { name: t('books.rejected'), value: stats?.rejectedBooks ?? 0, color: '#ef4444' },
    { name: t('books.published'), value: stats?.publishedBooks ?? 0, color: '#3b82f6' },
  ].filter(item => item.value > 0);

  const booksBySubjectData = (stats?.booksBySubject ?? [])
    .sort((a, b) => b.count - a.count)
    .slice(0, 5)
    .map(item => ({ ...item, name: item.subjectName }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('dashboard.title')}</h2>
          <p className="text-muted-foreground">{t('dashboard.facultyAdmin.subtitle')}</p>
        </div>
        {(stats?.pendingBooks ?? 0) > 0 && (
          <Link href="/faculty-admin/book-approval">
            <Button size="sm"><CheckSquare className="me-2 h-4 w-4" />{t('dashboard.facultyAdmin.reviewBooks')} ({stats?.pendingBooks})</Button>
          </Link>
        )}
      </div>

      {/* Stat Cards */}
      <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
        {statCards.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-xs sm:text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className={`text-xl sm:text-2xl font-bold ${stat.color}`}>{stat.value.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground truncate">{stat.desc}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Main Content Area */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {/* Pending Review Queue */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="h-4 w-4 text-yellow-600" />
                {t('dashboard.facultyAdmin.pendingQueue')}
              </CardTitle>
              <CardDescription className="text-xs">{t('dashboard.facultyAdmin.oldestFirst')}</CardDescription>
            </div>
            {(stats?.pendingQueue ?? []).length > 0 && (
              <Link href="/faculty-admin/book-approval">
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
                </Button>
              </Link>
            )}
          </CardHeader>
          <CardContent>
            {(stats?.pendingQueue ?? []).length > 0 ? (
              <div className="space-y-2">
                {stats?.pendingQueue.map((content) => (
                  <div key={content.id} className="flex items-center justify-between gap-2 p-2 rounded-lg border border-yellow-200 dark:border-yellow-900/50 bg-yellow-50/50 dark:bg-yellow-900/10">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{content.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{content.subjectName} &bull; {content.authorName}</p>
                    </div>
                    <UITooltip>
                      <TooltipTrigger asChild>
                        <Link href={`/faculty-admin/book-approval/preview/${content.id}`}>
                          <Button variant="outline" size="sm" className="h-8 w-8 p-0"><Eye className="h-4 w-4" /></Button>
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent>{t('tooltips.books.preview')}</TooltipContent>
                    </UITooltip>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <CheckSquare className="h-8 w-8 mx-auto text-green-500 mb-2" />
                <p className="text-sm text-muted-foreground">{t('dashboard.facultyAdmin.noPendingContent')}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Book Status */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.facultyAdmin.bookStatus')}</CardTitle>
          </CardHeader>
          <CardContent>
            {bookStatusData.length > 0 ? (
              <div className="space-y-2">
                <div className="h-[180px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={bookStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {bookStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<ChartTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <ChartLegend items={bookStatusData} />
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">{t('common.noData')}</p>
            )}
          </CardContent>
        </Card>

        {/* Total Books */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.facultyAdmin.totalBooks')}</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center h-[220px]">
            <div className="text-5xl font-bold text-primary">{stats?.totalBooks ?? 0}</div>
            <p className="text-sm text-muted-foreground mt-2">{t('dashboard.facultyAdmin.booksInFaculty')}</p>
            <div className="flex gap-4 mt-4 text-sm">
              <div className="text-center">
                <div className="font-semibold text-green-600">{stats?.publishedBooks ?? 0}</div>
                <div className="text-xs text-muted-foreground">{t('books.published')}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-blue-600">{stats?.approvedBooks ?? 0}</div>
                <div className="text-xs text-muted-foreground">{t('books.approved')}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
        {/* Books by Subject */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.facultyAdmin.booksBySubject')}</CardTitle>
            <CardDescription className="text-xs">{t('dashboard.facultyAdmin.topSubjects')}</CardDescription>
          </CardHeader>
          <CardContent>
            {booksBySubjectData.length > 0 ? (
              <div className="h-[200px]" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={booksBySubjectData}
                    layout="vertical"
                    margin={{ left: 0, right: 16, top: 5, bottom: 5 }}
                  >
                    <XAxis type="number" hide />
                    <YAxis
                      type="category"
                      dataKey="subjectName"
                      width={95}
                      tick={{ fontSize: 11 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value: string) => value.length > 14 ? `${value.slice(0, 14)}...` : value}
                    />
                    <Tooltip content={<ChartTooltip />} cursor={false} />
                    <Bar
                      dataKey="count"
                      fill="#3b82f6"
                      radius={[0, 4, 4, 0]}
                      barSize={20}
                      activeBar={{ fill: '#2563eb' }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">{t('common.noData')}</p>
            )}
          </CardContent>
        </Card>

        {/* Recent Books */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-sm font-medium">{t('dashboard.facultyAdmin.recentBooks')}</CardTitle>
              <CardDescription className="text-xs">{t('dashboard.facultyAdmin.latestBooks')}</CardDescription>
            </div>
            <Link href="/faculty-admin/book-approval">
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(stats?.recentBooks ?? []).length > 0 ? (
              <div className="space-y-2">
                {stats?.recentBooks.map((book) => (
                  <div key={book.id} className="flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{book.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{book.subjectName} &bull; {book.authorName}</p>
                    </div>
                    <Badge variant="secondary" className={`shrink-0 text-xs ${STATUS_COLORS[book.status]}`}>
                      {t(`status.${book.status}`)}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">{t('dashboard.noRecentBooks')}</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">{t('dashboard.quickActions')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Link href="/faculty-admin/book-approval">
            <Button variant="outline" size="sm"><CheckSquare className="me-2 h-4 w-4" />{t('dashboard.facultyAdmin.reviewBooks')}</Button>
          </Link>
          <Link href="/faculty-admin/professors">
            <Button variant="outline" size="sm"><Users className="me-2 h-4 w-4" />{t('dashboard.facultyAdmin.manageProfessors')}</Button>
          </Link>
          <Link href="/faculty-admin/students">
            <Button variant="outline" size="sm"><Users className="me-2 h-4 w-4" />{t('dashboard.facultyAdmin.manageStudents')}</Button>
          </Link>
          <Link href="/faculty-admin/subjects">
            <Button variant="outline" size="sm"><BookOpen className="me-2 h-4 w-4" />{t('dashboard.facultyAdmin.manageSubjects')}</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
