'use client';

import { useState } from 'react';
import { BookText, Eye, Check, X, Send, Search, MoreHorizontal } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, PageHeader } from '@/components/shared';
import { Badge } from '@/components/ui/badge';
import { useServerTable } from '@/hooks';
import { booksApi } from '@/lib/api/books';
import { ROUTES } from '@/lib/constants/routes';
import type { ColumnDef } from '@tanstack/react-table';
import type { BookListItem, BookStatus, BookQueryParams, PaginationParams } from '@/types';

const statusVariants: Record<BookStatus, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  draft: 'secondary',
  pending_review: 'outline',
  approved: 'default',
  rejected: 'destructive',
  published: 'default',
};

const statusLabels: Record<BookStatus, string> = {
  draft: 'Draft',
  pending_review: 'Pending Review',
  approved: 'Approved',
  rejected: 'Rejected',
  published: 'Published',
};

type BookFilters = Omit<BookQueryParams, keyof PaginationParams>;

export default function BookApprovalPage() {
  const t = useTranslations();
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectingBookId, setRejectingBookId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const {
    data: books,
    meta,
    isLoading,
    searchValue,
    sortBy,
    sortOrder,
    filters,
    setPage,
    setPageSize,
    setSearch,
    setSort,
    setFilter,
    refetch,
  } = useServerTable<BookListItem, BookFilters>({
    fetchFn: booksApi.getAll,
    initialPageSize: 10,
    initialFilters: { status: 'pending_review' },
  });

  const handleStatusFilter = (value: string) => {
    setFilter('status', value === 'all' ? undefined : value as BookStatus);
  };

  const handleApprove = async (bookId: string) => {
    try {
      await booksApi.approve(bookId);
      toast.success(t('books.approveSuccess'));
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  };

  const handleReject = async () => {
    if (!rejectingBookId || !rejectionReason.trim()) return;

    try {
      await booksApi.reject(rejectingBookId, { reason: rejectionReason.trim() });
      toast.success(t('books.rejectSuccess'));
      setRejectDialogOpen(false);
      setRejectingBookId(null);
      setRejectionReason('');
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  };

  const handlePublish = async (bookId: string) => {
    try {
      await booksApi.publish(bookId);
      toast.success(t('books.publishSuccess'));
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  };

  const handleUnpublish = async (bookId: string) => {
    try {
      await booksApi.unpublish(bookId);
      toast.success(t('books.unpublishSuccess'));
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  };

  const openRejectDialog = (bookId: string) => {
    setRejectingBookId(bookId);
    setRejectionReason('');
    setRejectDialogOpen(true);
  };

  const columns: ColumnDef<BookListItem>[] = [
    {
      accessorKey: 'title',
      header: t('books.bookTitle'),
      enableSorting: true,
      cell: ({ row }) => (
        <div>
          <div className="font-medium">{row.original.title}</div>
          {row.original.titleAr && (
            <div className="text-sm text-muted-foreground" dir="rtl">
              {row.original.titleAr}
            </div>
          )}
        </div>
      ),
    },
    {
      accessorKey: 'authorName',
      header: t('content.author'),
      enableSorting: false,
    },
    { accessorKey: 'subjectName', header: t('subjects.title'), enableSorting: false },
    {
      accessorKey: 'chapterCount',
      header: t('books.chapters'),
      enableSorting: false,
      cell: ({ row }) => (
        <span className="text-muted-foreground">{row.original.chapterCount}</span>
      ),
    },
    {
      accessorKey: 'status',
      header: t('content.status'),
      enableSorting: true,
      cell: ({ row }) => (
        <Badge variant={statusVariants[row.original.status]}>
          {statusLabels[row.original.status]}
        </Badge>
      ),
    },
    {
      accessorKey: 'updatedAt',
      header: t('common.lastUpdated'),
      enableSorting: true,
      cell: ({ row }) => new Date(row.original.updatedAt).toLocaleDateString(),
    },
    {
      id: 'actions',
      cell: ({ row }) => {
        const book = row.original;

        return (
          <Tooltip>
            <DropdownMenu>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href={ROUTES.FACULTY_ADMIN.BOOK_PREVIEW(book.id)}>
                  <Eye className="h-4 w-4 me-2" />
                  {t('common.preview')}
                </Link>
              </DropdownMenuItem>

              {book.status === 'pending_review' && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handleApprove(book.id)}>
                    <Check className="h-4 w-4 me-2" />
                    {t('books.approveBook')}
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={() => openRejectDialog(book.id)}
                  >
                    <X className="h-4 w-4 me-2" />
                    {t('books.rejectBook')}
                  </DropdownMenuItem>
                </>
              )}

              {book.status === 'approved' && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handlePublish(book.id)}>
                    <Send className="h-4 w-4 me-2" />
                    {t('books.publishBook')}
                  </DropdownMenuItem>
                </>
              )}

              {book.status === 'published' && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handleUnpublish(book.id)}>
                    <X className="h-4 w-4 me-2" />
                    {t('books.unpublishBook')}
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
            </DropdownMenu>
            <TooltipContent>{t('tooltips.actions.moreActions')}</TooltipContent>
          </Tooltip>
        );
      },
    },
  ];

  const pendingCount = books.filter((b) => b.status === 'pending_review').length;

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  return (
    <div className="space-y-6">
      <PageHeader
        icon={BookText}
        title={t('books.bookApproval')}
        description={t('books.bookApprovalDescription')}
        badge={
          meta && meta.total > 0 ? (
            <Badge variant="secondary">{meta.total}</Badge>
          ) : null
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('books.searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={(filters.status as string) ?? 'pending_review'}
          onValueChange={handleStatusFilter}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={t('content.filterByStatus')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('common.all')}</SelectItem>
            <SelectItem value="pending_review">{statusLabels.pending_review}</SelectItem>
            <SelectItem value="approved">{statusLabels.approved}</SelectItem>
            <SelectItem value="rejected">{statusLabels.rejected}</SelectItem>
            <SelectItem value="published">{statusLabels.published}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!isLoading && books.length === 0 && !searchValue ? (
        <EmptyState
          title={t('books.noPendingBooks')}
          description={t('books.noPendingBooksDescription')}
        />
      ) : (
        <ServerDataTable
          columns={columns}
          data={books}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      )}

      {/* Reject Dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('books.rejectBook')}</DialogTitle>
            <DialogDescription>
              {t('books.rejectionReasonPlaceholder')}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder={t('books.rejectionReasonPlaceholder')}
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              rows={4}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={!rejectionReason.trim()}
            >
              <X className="h-4 w-4 me-2" />
              {t('books.rejectBook')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
