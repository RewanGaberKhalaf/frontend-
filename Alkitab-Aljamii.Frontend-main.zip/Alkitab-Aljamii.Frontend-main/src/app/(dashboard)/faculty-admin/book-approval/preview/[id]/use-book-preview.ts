'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { booksApi } from '@/lib/api/books';
import { ROUTES } from '@/lib/constants/routes';
import type { Book, Chapter, BookStatus, ChapterFeedbackDto } from '@/types';

export const statusVariants: Record<BookStatus, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  draft: 'secondary',
  pending_review: 'outline',
  approved: 'default',
  rejected: 'destructive',
  published: 'default',
};

export const statusLabels: Record<BookStatus, string> = {
  draft: 'Draft',
  pending_review: 'Pending Review',
  approved: 'Approved',
  rejected: 'Rejected',
  published: 'Published',
};

export interface TocItem {
  id: string;
  text: string;
  level: number;
}

export function extractTableOfContents(html: string): TocItem[] {
  if (!html || typeof window === 'undefined') return [];

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const headers = doc.querySelectorAll('h1, h2, h3, h4, h5, h6');

    const toc: TocItem[] = [];
    headers.forEach((header, index) => {
      const level = parseInt(header.tagName.charAt(1));
      const text = header.textContent?.trim() || '';
      if (text) {
        toc.push({
          id: `heading-${index}`,
          text,
          level,
        });
      }
    });

    return toc;
  } catch {
    return [];
  }
}

export function useBookPreview(bookId: string) {
  const router = useRouter();
  const t = useTranslations();

  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [activeChapterId, setActiveChapterId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [chapterFeedback, setChapterFeedback] = useState<Record<string, string>>({});
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(new Set());
  const [previewMode, setPreviewMode] = useState<'chapter' | 'book'>('chapter');
  const [quizConfigChapter, setQuizConfigChapter] = useState<{ id: string; title: string } | null>(null);

  const activeChapter = chapters.find((ch) => ch.id === activeChapterId);

  // Full book HTML for preview (all chapters combined)
  const fullBookHtml = useMemo(() => {
    return chapters
      .map((chapter, index) => {
        const pageBreak = index > 0 ? '<div style="page-break-before: always;"></div>' : '';
        return pageBreak + (chapter.content || '');
      })
      .join('\n');
  }, [chapters]);

  // Chapter titles for full book preview
  const chapterTitles = useMemo(() => {
    return chapters.map((ch) => ch.title);
  }, [chapters]);

  // Memoized TOC for each chapter
  const chapterTocs = useMemo(() => {
    const tocs: Record<string, TocItem[]> = {};
    chapters.forEach((chapter) => {
      tocs[chapter.id] = extractTableOfContents(chapter.content || '');
    });
    return tocs;
  }, [chapters]);

  // Load book data
  useEffect(() => {
    const loadBook = async () => {
      try {
        setIsLoading(true);
        const [bookData, chaptersData] = await Promise.all([
          booksApi.getById(bookId),
          booksApi.getChapters(bookId),
        ]);
        setBook(bookData);
        setChapters(chaptersData);

        if (chaptersData.length > 0 && chaptersData[0]) {
          setActiveChapterId(chaptersData[0].id);
          setExpandedChapters(new Set([chaptersData[0].id]));
        }
      } catch {
        toast.error(t('common.error'));
        router.push(ROUTES.FACULTY_ADMIN.BOOK_APPROVAL);
      } finally {
        setIsLoading(false);
      }
    };

    loadBook();
  }, [bookId, router, t]);

  const handleApprove = useCallback(async () => {
    try {
      const updatedBook = await booksApi.approve(bookId);
      setBook(updatedBook);
      toast.success(t('books.approveSuccess'));
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  }, [bookId, t]);

  const handleReject = useCallback(async () => {
    if (!rejectionReason.trim()) return;

    // Build chapter feedback array from non-empty entries
    const feedbackEntries: ChapterFeedbackDto[] = Object.entries(chapterFeedback)
      .filter(([, feedback]) => feedback.trim().length > 0)
      .map(([chapterId, feedback]) => ({
        chapterId,
        feedback: feedback.trim(),
      }));

    try {
      const updatedBook = await booksApi.reject(bookId, {
        reason: rejectionReason.trim(),
        chapterFeedback: feedbackEntries.length > 0 ? feedbackEntries : undefined,
      });
      setBook(updatedBook);
      setRejectDialogOpen(false);
      setRejectionReason('');
      setChapterFeedback({});
      toast.success(t('books.rejectSuccess'));
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  }, [bookId, rejectionReason, chapterFeedback, t]);

  const updateChapterFeedback = useCallback((chapterId: string, feedback: string) => {
    setChapterFeedback((prev) => ({
      ...prev,
      [chapterId]: feedback,
    }));
  }, []);

  const handlePublish = useCallback(async () => {
    try {
      const updatedBook = await booksApi.publish(bookId);
      setBook(updatedBook);
      toast.success(t('books.publishSuccess'));
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  }, [bookId, t]);

  const handleUnpublish = useCallback(async () => {
    try {
      const updatedBook = await booksApi.unpublish(bookId);
      setBook(updatedBook);
      toast.success(t('books.unpublishSuccess'));
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      toast.error(message);
    }
  }, [bookId, t]);

  const toggleChapterExpand = useCallback((chapterId: string) => {
    setExpandedChapters((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) {
        next.delete(chapterId);
      } else {
        next.add(chapterId);
      }
      return next;
    });
  }, []);

  return {
    // State
    book,
    chapters,
    activeChapterId,
    activeChapter,
    isLoading,
    rejectDialogOpen,
    rejectionReason,
    chapterFeedback,
    expandedChapters,
    previewMode,
    quizConfigChapter,
    // Computed
    fullBookHtml,
    chapterTitles,
    chapterTocs,
    // Setters
    setActiveChapterId,
    setRejectDialogOpen,
    setRejectionReason,
    setPreviewMode,
    setQuizConfigChapter,
    // Actions
    handleApprove,
    handleReject,
    handlePublish,
    handleUnpublish,
    toggleChapterExpand,
    updateChapterFeedback,
  };
}
