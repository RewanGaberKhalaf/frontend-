'use client';

import { useParams } from 'next/navigation';
import { useTranslations } from 'next-intl';
import {
  ArrowLeft,
  Check,
  X,
  Send,
  ChevronDown,
  ChevronRight,
  AlertCircle,
  FileText,
  Library,
  ClipboardList,
} from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { ROUTES } from '@/lib/constants/routes';
import { PaginatedPreview } from '@/components/shared/rich-text-editor/paginated-preview';
import { ChapterQuizConfigDialog } from '@/components/quiz';
import { useBookPreview, statusVariants, statusLabels } from './use-book-preview';

export default function BookPreviewPage() {
  const params = useParams();
  const t = useTranslations();
  const bookId = params['id'] as string;

  const {
    book,
    chapters,
    activeChapterId,
    activeChapter,
    isLoading,
    rejectDialogOpen,
    rejectionReason,
    chapterFeedback,
    expandedChapters,
    previewMode,
    quizConfigChapter,
    fullBookHtml,
    chapterTitles,
    chapterTocs,
    setActiveChapterId,
    setRejectDialogOpen,
    setRejectionReason,
    setPreviewMode,
    setQuizConfigChapter,
    handleApprove,
    handleReject,
    handlePublish,
    handleUnpublish,
    toggleChapterExpand,
    updateChapterFeedback,
  } = useBookPreview(bookId);

  if (isLoading) {
    return (
      <div className="h-full flex">
        <div className="w-64 border-r p-4 space-y-4">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
        </div>
        <div className="flex-1 p-4">
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="flex items-center justify-center h-full">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t('common.error')}</AlertTitle>
          <AlertDescription>{t('books.notFound')}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      {/* Header */}
      <div className="shrink-0 border-b bg-background p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href={ROUTES.FACULTY_ADMIN.BOOK_APPROVAL}>
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div>
              <h1 className="text-xl font-semibold">{book.title}</h1>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>{book.authorName}</span>
                <span>-</span>
                <span>{book.subjectName}</span>
                <span>-</span>
                <Badge variant={statusVariants[book.status]}>{statusLabels[book.status]}</Badge>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Preview mode toggle */}
            <div className="flex items-center border rounded-md">
              <Button
                variant={previewMode === 'chapter' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setPreviewMode('chapter')}
                className="rounded-e-none"
              >
                <FileText className="h-4 w-4 me-2" />
                {t('books.chapterView')}
              </Button>
              <Button
                variant={previewMode === 'book' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setPreviewMode('book')}
                className="rounded-s-none"
              >
                <Library className="h-4 w-4 me-2" />
                {t('books.fullBook')}
              </Button>
            </div>

            {book.status === 'pending_review' && (
              <>
                <Button variant="outline" onClick={() => setRejectDialogOpen(true)}>
                  <X className="h-4 w-4 me-2" />
                  {t('books.rejectBook')}
                </Button>
                <Button onClick={handleApprove}>
                  <Check className="h-4 w-4 me-2" />
                  {t('books.approveBook')}
                </Button>
              </>
            )}
            {book.status === 'approved' && (
              <Button onClick={handlePublish}>
                <Send className="h-4 w-4 me-2" />
                {t('books.publishBook')}
              </Button>
            )}
            {book.status === 'published' && (
              <Button variant="outline" onClick={handleUnpublish}>
                <X className="h-4 w-4 me-2" />
                {t('books.unpublishBook')}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex min-h-0">
        {/* Sidebar - Chapter list (only show in chapter mode) */}
        {previewMode === 'chapter' && (
          <div className="w-64 max-w-64 border-r bg-muted/30 flex flex-col shrink-0 overflow-hidden">
            <div className="p-3 border-b">
              <span className="font-medium text-sm">{t('books.chapters')}</span>
            </div>

            <div className="flex-1 overflow-y-auto overflow-x-hidden">
              <div className="p-2 space-y-1">
                {chapters.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    {t('books.noChapters')}
                  </p>
                ) : (
                  chapters.map((chapter, index) => {
                    const toc = chapterTocs[chapter.id] || [];
                    const isExpanded = expandedChapters.has(chapter.id);
                    const isActive = activeChapterId === chapter.id;

                    return (
                      <div key={chapter.id} className="flex flex-col overflow-hidden">
                        {/* Chapter row */}
                        <div
                          className={cn(
                            'flex items-center gap-2 rounded-md px-2 py-1.5 cursor-pointer transition-colors',
                            isActive ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                          )}
                          onClick={() => setActiveChapterId(chapter.id)}
                        >
                          <button
                            className="shrink-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleChapterExpand(chapter.id);
                            }}
                          >
                            {isExpanded ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                          </button>
                          <span
                            className="text-sm flex-1 min-w-0 truncate"
                            title={`${index + 1}. ${chapter.title}`}
                          >
                            {index + 1}. {chapter.title}
                          </span>
                          {/* Quiz config button */}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 shrink-0"
                            title={t('quizzes.viewConfig')}
                            onClick={(e) => {
                              e.stopPropagation();
                              setQuizConfigChapter({ id: chapter.id, title: chapter.title });
                            }}
                          >
                            <ClipboardList className="h-3.5 w-3.5" />
                          </Button>
                        </div>

                        {/* Table of Contents - shown when chapter is expanded */}
                        {isExpanded && (
                          <div className="mt-1 ms-6 ps-2 border-s-2 border-primary/30 overflow-hidden">
                            {toc.length > 0 ? (
                              toc.map((item, tocIndex) => (
                                <div
                                  key={`${chapter.id}-toc-${tocIndex}`}
                                  className={cn(
                                    'text-xs py-0.5 cursor-pointer truncate text-muted-foreground hover:text-foreground',
                                    item.level === 1 && 'font-medium',
                                    item.level === 2 && 'ps-2',
                                    item.level === 3 && 'ps-4',
                                    item.level >= 4 && 'ps-6'
                                  )}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (!isActive) {
                                      setActiveChapterId(chapter.id);
                                    }
                                  }}
                                  title={item.text}
                                >
                                  {item.text}
                                </div>
                              ))
                            ) : (
                              <div className="text-xs text-muted-foreground italic py-1">
                                {t('books.noHeadingsFound')}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}

        {/* Content area */}
        <div className="flex-1 overflow-hidden bg-muted/30">
          {previewMode === 'chapter' ? (
            // Chapter view - single chapter at a time
            activeChapter ? (
              <div className="h-full overflow-auto">
                <PaginatedPreview
                  html={activeChapter.content || ''}
                  title={activeChapter.title}
                  showSettings={false}
                  showPrint={false}
                  showPageNumbers
                  singlePageMode
                />
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground h-full">
                <p>{t('books.noChapters')}</p>
              </div>
            )
          ) : (
            // Full book view - all chapters with page breaks
            chapters.length > 0 ? (
              <div className="h-full overflow-auto">
                <PaginatedPreview
                  html={fullBookHtml}
                  title={book.title}
                  chapterTitles={chapterTitles}
                  showSettings={false}
                  showPrint={false}
                  showPageNumbers
                  singlePageMode
                />
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground h-full">
                <p>{t('books.noChapters')}</p>
              </div>
            )
          )}
        </div>
      </div>

      {/* Reject Dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('books.rejectBook')}</DialogTitle>
            <DialogDescription>
              {t('books.feedback.dialogDescription')}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* General Feedback */}
            <div className="space-y-2">
              <label className="text-sm font-medium">
                {t('books.feedback.generalFeedback')} <span className="text-destructive">*</span>
              </label>
              <Textarea
                placeholder={t('books.feedback.generalPlaceholder')}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={3}
              />
              <p className="text-xs text-muted-foreground">
                {t('books.feedback.generalHint')}
              </p>
            </div>

            {/* Per-Chapter Feedback */}
            {chapters.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">
                    {t('books.feedback.chapterFeedback')}
                  </label>
                  <span className="text-xs text-muted-foreground">
                    {t('books.feedback.optional')}
                  </span>
                </div>
                <div className="space-y-3 max-h-[300px] overflow-y-auto rounded-lg border p-3 bg-muted/30">
                  {chapters.map((chapter, index) => (
                    <div key={chapter.id} className="space-y-1.5">
                      <label className="text-sm text-muted-foreground">
                        {index + 1}. {chapter.title}
                      </label>
                      <Textarea
                        placeholder={t('books.feedback.chapterPlaceholder')}
                        value={chapterFeedback[chapter.id] || ''}
                        onChange={(e) => updateChapterFeedback(chapter.id, e.target.value)}
                        rows={2}
                        className="text-sm"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={!rejectionReason.trim() || rejectionReason.trim().length < 10}
            >
              <X className="h-4 w-4 me-2" />
              {t('books.rejectBook')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Chapter Quiz Config Dialog (read-only for admin) */}
      {quizConfigChapter && book && (
        <ChapterQuizConfigDialog
          open={!!quizConfigChapter}
          onOpenChange={(open) => !open && setQuizConfigChapter(null)}
          chapterId={quizConfigChapter.id}
          chapterTitle={quizConfigChapter.title}
          subjectId={book.subjectId}
          readOnly
        />
      )}
    </div>
  );
}
