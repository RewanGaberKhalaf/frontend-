'use client';

import { useState, useEffect } from 'react';
import { Upload, Plus } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/shared';
import { UploadModal, TemplateCard, Template, ImportType } from '@/components/bulkImport';
import { importsApi } from '@/lib/api';
import { EmptyState } from '@/components/shared';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { EditTemplateModal } from '@/components/bulkImport/edit-template-modal';

export default function FacultyAdminTemplateManagementPage() {
  const t = useTranslations();
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [templateToDelete, setTemplateToDelete] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);

  // Load templates from API
  const fetchTemplates = async () => {
    try {
      setIsLoading(true);
      const fetchedTemplates = await importsApi.getTemplates();

      // قائمة بالقيم الصحيحة للـ ImportType
      const validImportTypes: ImportType[] = [
        'students_only',
        'students_with_subjects',
        'professors_only',
        'professors_with_subjects',
        'student_enrollments',
        'professor_assignments',
        'student_unenrollments',
        'professor_unassignments',
      ];

      const mappedTemplates: Template[] = fetchedTemplates.map((t: any) => {
        // تحويل importType إلى union مع default value
        const importType = validImportTypes.includes(t.importType as ImportType)
          ? (t.importType as ImportType)
          : 'students_only';

        // تحويل columnMappings وإضافة isMatched افتراضي
        const columnMappings = (t.columnMappings || []).map((c: any) => ({
          excelColumn: c.excelColumn,
          databaseColumn: c.databaseColumn,
          isMatched: false, // default
        }));

        return {
          ...t,
          importType,
          columnMappings,
          facultyId: t.facultyId || 'unknown', // 👈 إضافة الـ facultyId المطلوبة
        };
      });

      setTemplates(mappedTemplates);
    } catch (err) {
      console.error('Failed to load templates:', err);
      toast.error('Failed to load templates');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const handleUploadComplete = async () => {
    toast.success(t('bulkImport.uploadSuccess'));
    await fetchTemplates();
  };

  const handleEditTemplate = (template: Template) => {
    setEditingTemplate(template);
  };

  const handleDeleteTemplate = (templateId: string) => {
    setTemplateToDelete(templateId);
  };

  const confirmDelete = async () => {
    if (!templateToDelete) return;

    try {
      await importsApi.deleteTemplate(templateToDelete);
      setTemplates(templates.filter((t) => t.id !== templateToDelete));
      toast.success('Template deleted successfully');
    } catch (err) {
      toast.error('Failed to delete template');
    } finally {
      setTemplateToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Upload}
        title={t('templateManagement.title')}
        description={t('templateManagement.description')}
        action={
          <Button onClick={() => setUploadModalOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Create Template
          </Button>
        }
      />

      {/* Templates Grid */}
      {templates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <TemplateCard
              key={template.id}
              template={template}
              onEdit={handleEditTemplate}
              onDelete={handleDeleteTemplate}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Upload}
          title="No templates yet"
          description="Create your first template by uploading an Excel file and mapping its columns."
          action={
            <Button onClick={() => setUploadModalOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Template
            </Button>
          }
        />
      )}

      {/* Upload Modal */}
      <UploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        onUploadComplete={handleUploadComplete}
        role="faculty-admin"
      />

      {/* Edit Template Modal */}
      <EditTemplateModal
        open={!!editingTemplate}
        template={editingTemplate}
        onClose={() => setEditingTemplate(null)}
        onSuccess={fetchTemplates}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!templateToDelete} onOpenChange={() => setTemplateToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the template.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
