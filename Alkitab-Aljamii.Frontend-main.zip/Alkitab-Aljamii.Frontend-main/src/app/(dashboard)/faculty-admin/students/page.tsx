'use client';

import { useState, useCallback } from 'react';
import { Loader2, Trash2, Users, Search, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, PageHeader } from '@/components/shared';
import { CreateMemberDialog } from '@/components/faculties/create-member-dialog';
import { QuickUploadModal } from '@/components/bulkImport';
import { useServerTable } from '@/hooks';
import { useFacultyContextStore } from '@/stores';
import { facultiesApi } from '@/lib/api/faculties';
import type { FacultyMember, CreateMemberDto, PaginationParams } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';

export default function StudentsPage() {
  const t = useTranslations();
  const { currentFacultyId, getCurrentFaculty } = useFacultyContextStore();
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const fetchStudents = useCallback(
    (params: PaginationParams) => {
      if (!currentFacultyId) {
        return Promise.resolve({
          items: [],
          meta: { total: 0, page: 1, limit: 10, totalPages: 0, hasNextPage: false, hasPreviousPage: false },
        });
      }
      return facultiesApi.getStudents(currentFacultyId, params);
    },
    [currentFacultyId]
  );

  const {
    data: students,
    meta,
    isLoading,
    searchValue,
    setPage,
    setPageSize,
    setSearch,
    refetch,
  } = useServerTable<FacultyMember>({
    fetchFn: fetchStudents,
    initialPageSize: 10,
    fetchOnMount: !!currentFacultyId,
    deps: [currentFacultyId],
  });

  const handleCreate = async (data: CreateMemberDto) => {
    if (!currentFacultyId) return;
    try {
      await facultiesApi.createStudent(currentFacultyId, data);
      toast.success(t('members.students.addSuccess'));
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('members.students.addError');
      toast.error(message);
      throw error;
    }
  };

  const handleRemove = async (studentId: string) => {
    if (!currentFacultyId) return;
    setRemovingId(studentId);
    try {
      await facultiesApi.removeStudent(currentFacultyId, studentId);
      toast.success(t('members.students.removeSuccess'));
      refetch();
    } catch {
      toast.error(t('members.students.removeError'));
    } finally {
      setRemovingId(null);
    }
  };

  const columns: ColumnDef<FacultyMember>[] = [
    {
      id: 'name',
      header: t('members.name'),
      cell: ({ row }) => `${row.original.firstName} ${row.original.lastName}`,
    },
    { accessorKey: 'email', header: t('members.email') },
    {
      accessorKey: 'assignedAt',
      header: t('members.enrolled'),
      cell: ({ row }) => new Date(row.original.assignedAt).toLocaleDateString(),
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleRemove(row.original.id)}
              disabled={removingId === row.original.id}
            >
              {removingId === row.original.id ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Trash2 className="h-4 w-4 text-destructive" />
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent>{t('tooltips.students.remove')}</TooltipContent>
        </Tooltip>
      ),
    },
  ];

  const faculty = getCurrentFaculty();

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  if (!currentFacultyId) {
    return (
      <EmptyState
        title={t('members.noFacultySelected')}
        description={t('members.selectFacultyHint', { role: t('nav.students').toLowerCase() })}
      />
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Users}
        title={t('members.students.title')}
        description={faculty?.name ? t('members.students.subtitle', { faculty: faculty.name }) : t('members.students.subtitleGeneric')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setUploadModalOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Excel File
            </Button>
            <CreateMemberDialog
              title={t('members.students.addStudent')}
              role="student"
              onCreate={handleCreate}
            />
          </div>
        }
      />

      {/* Search */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('members.students.searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {!isLoading && students.length === 0 && !searchValue ? (
        <EmptyState
          title={t('members.students.noStudentsYet')}
          description={t('members.students.addToGetStarted')}
          action={
            <CreateMemberDialog
              title={t('members.students.addStudent')}
              role="student"
              onCreate={handleCreate}
            />
          }
        />
      ) : (
        <ServerDataTable
          columns={columns}
          data={students}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
        />
      )}

      <QuickUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        allowedImportTypes={['students_only']}
        onUploadComplete={() => {
          toast.success(t('bulkImport.uploadSuccess'));
          refetch();
        }}
      />
    </div>
  );
}
