'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import {
  Clock,
  Users,
  BookOpen,
  TrendingUp,
  Library,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { readingTimeApi } from '@/lib/api/reading-time';
import { ReadingTimeHeatmap } from '@/components/analytics';
import type { FacultyReadingOverview, BookReadingSummary, SubjectReadingSummary } from '@/types';

function formatHours(hours: number): string {
  if (hours < 1) {
    return `${Math.round(hours * 60)}m`;
  }
  return `${hours.toFixed(1)}h`;
}

function formatMinutes(minutes: number): string {
  if (minutes < 60) {
    return `${Math.round(minutes)}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export default function FacultyReadingTimeAnalyticsPage() {
  const router = useRouter();
  const t = useTranslations();

  const [data, setData] = useState<FacultyReadingOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const overview = await readingTimeApi.getFacultyReadingOverview();
        setData(overview);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load reading analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-48" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">{error || 'No data available'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Reading Time Analytics</h1>
        <p className="text-muted-foreground">Faculty-wide reading engagement overview</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reading Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatHours(data.totalReadingTimeHours)}</div>
            <p className="text-xs text-muted-foreground">
              All students combined
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Readers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.activeReaders7d}</div>
            <p className="text-xs text-muted-foreground">
              In the last 7 days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Daily Reading</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMinutes(data.avgDailyReadingMinutes)}</div>
            <p className="text-xs text-muted-foreground">
              Per active student
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Subjects</CardTitle>
            <Library className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.subjectBreakdown.length}</div>
            <p className="text-xs text-muted-foreground">
              With reading activity
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Reading Activity Heatmap */}
      <ReadingTimeHeatmap
        data={data.weeklyTrend}
        title="Faculty Reading Activity"
        description="Combined reading activity across all students"
        weeks={12}
      />

      {/* Two-column layout for tables */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Top Books */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Top Books by Reading Time
            </CardTitle>
            <CardDescription>
              Most engaged books in the faculty
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Book</TableHead>
                  <TableHead className="text-right">Time</TableHead>
                  <TableHead className="text-right">Readers</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.topBooks.slice(0, 10).map((book, index) => (
                  <TableRow key={book.bookId}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="w-6 h-6 p-0 justify-center">
                          {index + 1}
                        </Badge>
                        <span className="font-medium truncate max-w-[180px]">
                          {book.bookTitle}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {formatMinutes(book.totalTimeMinutes)}
                    </TableCell>
                    <TableCell className="text-right">
                      {book.uniqueReaders}
                    </TableCell>
                  </TableRow>
                ))}
                {data.topBooks.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-muted-foreground">
                      No reading data yet
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Subject Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Library className="h-5 w-5" />
              Reading by Subject
            </CardTitle>
            <CardDescription>
              Reading time distribution across subjects
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead className="text-right">Time</TableHead>
                  <TableHead className="text-right">Books</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.subjectBreakdown.slice(0, 10).map((subject) => (
                  <TableRow key={subject.subjectId}>
                    <TableCell>
                      <span className="font-medium truncate max-w-[180px] block">
                        {subject.subjectName}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      {formatMinutes(subject.totalTimeMinutes)}
                    </TableCell>
                    <TableCell className="text-right">
                      {subject.bookCount}
                    </TableCell>
                  </TableRow>
                ))}
                {data.subjectBreakdown.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center text-muted-foreground">
                      No reading data yet
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
