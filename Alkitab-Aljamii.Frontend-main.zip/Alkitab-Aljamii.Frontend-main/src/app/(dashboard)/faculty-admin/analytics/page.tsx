'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  Users,
  BookOpen,
  ClipboardList,
  TrendingUp,
  TrendingDown,
  GraduationCap,
  ChevronRight,
  Activity,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type FacultyAnalyticsOverview } from '@/lib/api/analytics';
import { cn } from '@/lib/utils';

export default function FacultyAnalyticsPage() {
  const t = useTranslations();
  const [data, setData] = useState<FacultyAnalyticsOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const overview = await analyticsApi.getFacultyOverview();
        setData(overview);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6 min-w-0 overflow-hidden">
        <div>
          <Skeleton className="h-7 sm:h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64 max-w-full" />
        </div>
        <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">{error || 'No data available'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 min-w-0 overflow-hidden">
      {/* Header */}
      <div className="min-w-0">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{t('analytics.facultyTitle')}</h1>
        <p className="text-sm text-muted-foreground truncate">{data.facultyName}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.totalStudents')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              {data.activeStudents30d} {t('analytics.activeMonthly')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professors')}</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalProfessors}</div>
            <p className="text-xs text-muted-foreground">
              {data.totalBooks} {t('analytics.booksCreated')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgQuizScore')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgQuizScore.toFixed(1)}%</div>
            <Progress value={data.avgQuizScore} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.passRate')}</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.overallPassRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {data.totalQuizAttempts} {t('analytics.totalAttempts')}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-3 sm:gap-4 md:grid-cols-2">
        {/* Top Performing Subjects */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              {t('analytics.topSubjects')}
            </CardTitle>
            <CardDescription>{t('analytics.topSubjectsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topPerformingSubjects.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noSubjects')}
              </p>
            ) : (
              <div className="space-y-2 sm:space-y-3">
                {data.topPerformingSubjects.map((subject, index) => (
                  <Link
                    key={subject.subjectId}
                    href={ROUTES.FACULTY_ADMIN.ANALYTICS_SUBJECT(subject.subjectId)}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg border hover:bg-muted/50 transition-colors gap-2">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 text-sm font-medium shrink-0">
                          {index + 1}
                        </span>
                        <span className="font-medium truncate">{subject.subjectName}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant="default">{subject.metric.toFixed(0)}%</Badge>
                        <ChevronRight className="h-4 w-4 text-muted-foreground hidden sm:block" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Struggling Subjects */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-red-500" />
              {t('analytics.strugglingSubjects')}
            </CardTitle>
            <CardDescription>{t('analytics.strugglingSubjectsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.strugglingSubjects.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noSubjects')}
              </p>
            ) : (
              <div className="space-y-2 sm:space-y-3">
                {data.strugglingSubjects.map((subject, index) => (
                  <Link
                    key={subject.subjectId}
                    href={ROUTES.FACULTY_ADMIN.ANALYTICS_SUBJECT(subject.subjectId)}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg border hover:bg-muted/50 transition-colors gap-2">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 text-sm font-medium shrink-0">
                          {index + 1}
                        </span>
                        <span className="font-medium truncate">{subject.subjectName}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant="destructive">{subject.metric.toFixed(0)}%</Badge>
                        <ChevronRight className="h-4 w-4 text-muted-foreground hidden sm:block" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Subject Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('analytics.subjectPerformance')}</CardTitle>
          <CardDescription>{t('analytics.subjectPerformanceDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="px-0 sm:px-6">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[150px]">{t('analytics.subject')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.professors')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.students')}</TableHead>
                  <TableHead className="text-center w-16">{t('analytics.books')}</TableHead>
                  <TableHead className="text-center w-16">{t('analytics.quizzes')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.avgScore')}</TableHead>
                  <TableHead className="text-center w-24">{t('analytics.passRate')}</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.subjectPerformance.map((subject) => (
                  <TableRow key={subject.subjectId}>
                    <TableCell>
                      <div className="min-w-0">
                        <p className="font-medium truncate max-w-[180px]">{subject.subjectName}</p>
                        <p className="text-xs text-muted-foreground">{subject.subjectCode}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">{subject.professorCount}</TableCell>
                    <TableCell className="text-center">{subject.studentCount}</TableCell>
                    <TableCell className="text-center">{subject.bookCount}</TableCell>
                    <TableCell className="text-center">{subject.quizCount}</TableCell>
                    <TableCell className="text-center">
                      <span className={cn(
                        'font-medium',
                        subject.avgQuizScore >= 70 ? 'text-green-600' :
                        subject.avgQuizScore >= 50 ? 'text-yellow-600' : 'text-red-600'
                      )}>
                        {subject.avgQuizScore.toFixed(0)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={subject.passRate >= 70 ? 'default' : 'secondary'}>
                        {subject.passRate.toFixed(0)}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Link href={ROUTES.FACULTY_ADMIN.ANALYTICS_SUBJECT(subject.subjectId)}>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
