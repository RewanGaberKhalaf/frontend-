'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  ArrowLeft,
  Users,
  BookOpen,
  ClipboardList,
  GraduationCap,
  Activity,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type SubjectAnalyticsDetail } from '@/lib/api/analytics';
import { cn } from '@/lib/utils';

const statusVariants: Record<string, 'default' | 'secondary' | 'outline'> = {
  draft: 'secondary',
  pending_review: 'outline',
  approved: 'default',
  rejected: 'secondary',
  published: 'default',
};

export default function SubjectAnalyticsPage() {
  const params = useParams();
  const router = useRouter();
  const t = useTranslations();
  const subjectId = params['subjectId'] as string;

  const [data, setData] = useState<SubjectAnalyticsDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const analytics = await analyticsApi.getSubjectAnalytics(subjectId);
        setData(analytics);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [subjectId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 me-2" />
          {t('common.back')}
        </Button>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">{error || 'No data available'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start sm:items-center gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1 sm:mt-0" asChild>
          <Link href={ROUTES.FACULTY_ADMIN.ANALYTICS}>
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{data.subjectName}</h1>
          <p className="text-sm text-muted-foreground">{data.subjectCode}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professors')}</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.professors?.length ?? 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.books')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.books?.length ?? 0}</div>
            <p className="text-xs text-muted-foreground">
              {(data.books ?? []).filter(b => b.status === 'published').length} {t('analytics.published')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.quizzes')}</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.quizzes?.length ?? 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.students')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.studentEngagement?.totalStudents ?? 0}</div>
            <p className="text-xs text-muted-foreground">
              {data.studentEngagement?.activeThisMonth ?? 0} {t('analytics.activeMonthly')}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Student Engagement Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            {t('analytics.studentEngagement')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:gap-4 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5">
            <div className="text-center p-3 sm:p-4 rounded-lg bg-muted/50">
              <div className="text-xl sm:text-2xl font-bold">{data.studentEngagement?.totalStudents ?? 0}</div>
              <p className="text-xs sm:text-sm text-muted-foreground">{t('analytics.total')}</p>
            </div>
            <div className="text-center p-3 sm:p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
              <div className="text-xl sm:text-2xl font-bold text-green-600 dark:text-green-400">{data.studentEngagement?.activeToday ?? 0}</div>
              <p className="text-xs sm:text-sm text-muted-foreground">{t('analytics.activeToday')}</p>
            </div>
            <div className="text-center p-3 sm:p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
              <div className="text-xl sm:text-2xl font-bold text-blue-600 dark:text-blue-400">{data.studentEngagement?.activeThisWeek ?? 0}</div>
              <p className="text-xs sm:text-sm text-muted-foreground">{t('analytics.activeWeek')}</p>
            </div>
            <div className="text-center p-3 sm:p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
              <div className="text-xl sm:text-2xl font-bold text-purple-600 dark:text-purple-400">{data.studentEngagement?.activeThisMonth ?? 0}</div>
              <p className="text-xs sm:text-sm text-muted-foreground">{t('analytics.activeMonth')}</p>
            </div>
            <div className="text-center p-3 sm:p-4 rounded-lg bg-red-50 dark:bg-red-900/20 col-span-2 sm:col-span-1">
              <div className="text-xl sm:text-2xl font-bold text-red-600 dark:text-red-400">{data.studentEngagement?.neverActive ?? 0}</div>
              <p className="text-xs sm:text-sm text-muted-foreground">{t('analytics.neverActive')}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs for Professors, Books, Quizzes */}
      <Tabs defaultValue="professors">
        <TabsList>
          <TabsTrigger value="professors">{t('analytics.professors')}</TabsTrigger>
          <TabsTrigger value="books">{t('analytics.books')}</TabsTrigger>
          <TabsTrigger value="quizzes">{t('analytics.quizzes')}</TabsTrigger>
        </TabsList>

        <TabsContent value="professors">
          <Card>
            <CardHeader>
              <CardTitle>{t('analytics.professorPerformance')}</CardTitle>
              <CardDescription>{t('analytics.professorPerformanceDesc')}</CardDescription>
            </CardHeader>
            <CardContent className="px-0 sm:px-6">
              {(data.professors?.length ?? 0) === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4 px-6">
                  {t('analytics.noProfessors')}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="min-w-[120px]">{t('analytics.name')}</TableHead>
                        <TableHead className="min-w-[180px]">{t('analytics.email')}</TableHead>
                        <TableHead className="text-center w-16">{t('analytics.books')}</TableHead>
                        <TableHead className="text-center w-16">{t('analytics.quizzes')}</TableHead>
                        <TableHead className="text-center w-24">{t('analytics.avgStudentScore')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(data.professors ?? []).map((professor) => (
                        <TableRow key={professor.userId}>
                          <TableCell className="font-medium">{professor.name}</TableCell>
                          <TableCell className="text-muted-foreground truncate max-w-[200px]">{professor.email}</TableCell>
                          <TableCell className="text-center">{professor.booksCount}</TableCell>
                          <TableCell className="text-center">{professor.quizzesCount}</TableCell>
                          <TableCell className="text-center">
                            <span className={cn(
                              'font-medium',
                              professor.avgStudentScore >= 70 ? 'text-green-600' :
                              professor.avgStudentScore >= 50 ? 'text-yellow-600' : 'text-red-600'
                            )}>
                              {professor.avgStudentScore.toFixed(0)}%
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="books">
          <Card>
            <CardHeader>
              <CardTitle>{t('analytics.bookOverview')}</CardTitle>
              <CardDescription>{t('analytics.bookOverviewDesc')}</CardDescription>
            </CardHeader>
            <CardContent className="px-0 sm:px-6">
              {(data.books?.length ?? 0) === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4 px-6">
                  {t('analytics.noBooks')}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="min-w-[150px]">{t('analytics.title')}</TableHead>
                        <TableHead className="min-w-[120px]">{t('analytics.professorLabel')}</TableHead>
                        <TableHead className="text-center w-24">{t('analytics.status')}</TableHead>
                        <TableHead className="text-center w-20">{t('analytics.readers')}</TableHead>
                        <TableHead className="text-center w-24">{t('analytics.completion')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(data.books ?? []).map((book) => (
                        <TableRow key={book.bookId}>
                          <TableCell className="font-medium truncate max-w-[180px]">{book.title}</TableCell>
                          <TableCell className="text-muted-foreground truncate max-w-[150px]">{book.professorName}</TableCell>
                          <TableCell className="text-center">
                            <Badge variant={statusVariants[book.status] || 'secondary'}>
                              {book.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">{book.readers}</TableCell>
                          <TableCell className="text-center">{book.completionRate.toFixed(0)}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quizzes">
          <Card>
            <CardHeader>
              <CardTitle>{t('analytics.quizOverview')}</CardTitle>
              <CardDescription>{t('analytics.quizOverviewDesc')}</CardDescription>
            </CardHeader>
            <CardContent className="px-0 sm:px-6">
              {(data.quizzes?.length ?? 0) === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4 px-6">
                  {t('analytics.noQuizzes')}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="min-w-[150px]">{t('analytics.title')}</TableHead>
                        <TableHead className="min-w-[120px]">{t('analytics.professorLabel')}</TableHead>
                        <TableHead className="text-center w-20">{t('analytics.attempts')}</TableHead>
                        <TableHead className="text-center w-20">{t('analytics.avgScore')}</TableHead>
                        <TableHead className="text-center w-24">{t('analytics.passRate')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(data.quizzes ?? []).map((quiz) => (
                        <TableRow key={quiz.quizId}>
                          <TableCell className="font-medium truncate max-w-[180px]">{quiz.title}</TableCell>
                          <TableCell className="text-muted-foreground truncate max-w-[150px]">{quiz.professorName}</TableCell>
                          <TableCell className="text-center">{quiz.attempts}</TableCell>
                          <TableCell className="text-center">
                            <span className={cn(
                              'font-medium',
                              quiz.avgScore >= 70 ? 'text-green-600' :
                              quiz.avgScore >= 50 ? 'text-yellow-600' : 'text-red-600'
                            )}>
                              {quiz.avgScore.toFixed(0)}%
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant={quiz.passRate >= 70 ? 'default' : 'secondary'}>
                              {quiz.passRate.toFixed(0)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
