'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import {
  Loader2,
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  LogIn,
  LogOut,
  Key,
  UserPlus,
  Shield,
  FileText,
  RefreshCw,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  auditApi,
  AuditAction,
  AuditCategory,
  type AuditLog,
  type PaginatedAuditLogResponse,
} from '@/lib/api';

const ACTION_ICONS: Record<string, typeof LogIn> = {
  LOGIN: LogIn,
  LOGOUT: LogOut,
  LOGIN_FAILED: AlertTriangle,
  PASSWORD_CHANGED: Key,
  USER_CREATED: UserPlus,
  ROLE_ASSIGNED: Shield,
  CONTENT_APPROVED: FileText,
};

const CATEGORY_COLORS: Record<string, string> = {
  AUTHENTICATION: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  USER_MANAGEMENT: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
  ROLE_MANAGEMENT: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-400',
  FACULTY_MANAGEMENT: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400',
  SUBJECT_MANAGEMENT: 'bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400',
  CONTENT_MANAGEMENT: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
  BOOK_MANAGEMENT: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400',
  QUESTION_MANAGEMENT: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-400',
  SYSTEM: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400',
};

const ACTION_COLORS: Record<string, string> = {
  LOGIN: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  LOGOUT: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400',
  LOGIN_FAILED: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  PASSWORD_CHANGED: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  USER_CREATED: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  USER_DELETED: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  ROLE_ASSIGNED: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
  ROLE_REMOVED: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
  CONTENT_APPROVED: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  CONTENT_REJECTED: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
};

export default function FacultyAuditLogsPage() {
  const t = useTranslations();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [actionFilter, setActionFilter] = useState<string>('all');

  const loadLogs = useCallback(async () => {
    setIsLoading(true);
    try {
      const response: PaginatedAuditLogResponse = await auditApi.getAll({
        page,
        limit: 20,
        ...(search && { search }),
        ...(categoryFilter !== 'all' && { category: categoryFilter as AuditCategory }),
        ...(actionFilter !== 'all' && { action: actionFilter as AuditAction }),
      });
      setLogs(response.items);
      setTotalPages(response.meta.totalPages);
      setTotal(response.meta.total);
    } catch {
      toast.error(t('audit.failedToLoad'));
    } finally {
      setIsLoading(false);
    }
  }, [page, search, categoryFilter, actionFilter, t]);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadLogs();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  const getActionIcon = (action: string) => {
    const Icon = ACTION_ICONS[action] || FileText;
    return <Icon className="h-4 w-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('audit.title')}</h2>
          <p className="text-muted-foreground">{t('audit.facultySubtitle')}</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => loadLogs()}>
          <RefreshCw className="me-2 h-4 w-4" />
          {t('common.refresh')}
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Filter className="h-4 w-4" />
            {t('audit.filters')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearch} className="flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={t('audit.searchPlaceholder')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="ps-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={(v) => { setCategoryFilter(v); setPage(1); }}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder={t('audit.allCategories')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('audit.allCategories')}</SelectItem>
                {Object.values(AuditCategory).map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {t(`audit.categories.${cat}`)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={actionFilter} onValueChange={(v) => { setActionFilter(v); setPage(1); }}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder={t('audit.allActions')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('audit.allActions')}</SelectItem>
                {Object.values(AuditAction).map((action) => (
                  <SelectItem key={action} value={action}>
                    {t(`audit.actions.${action}`)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button type="submit">{t('common.search')}</Button>
          </form>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">{t('audit.logEntries')}</CardTitle>
          <CardDescription>
            {t('audit.showingEntries', { count: logs.length, total })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : logs.length === 0 ? (
            <div className="flex h-64 flex-col items-center justify-center text-muted-foreground">
              <FileText className="h-12 w-12 mb-4 opacity-50" />
              <p>{t('audit.noLogs')}</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">{t('audit.timestamp')}</TableHead>
                      <TableHead>{t('audit.user')}</TableHead>
                      <TableHead>{t('audit.action')}</TableHead>
                      <TableHead>{t('audit.category')}</TableHead>
                      <TableHead>{t('audit.description')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="font-mono text-xs">
                          {formatDate(log.createdAt)}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm font-medium truncate max-w-[200px]">
                              {log.userEmail || t('audit.anonymous')}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={`gap-1 ${ACTION_COLORS[log.action] || ''}`}
                          >
                            {getActionIcon(log.action)}
                            {t(`audit.actions.${log.action}`)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={CATEGORY_COLORS[log.category] || ''}
                          >
                            {t(`audit.categories.${log.category}`)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm truncate max-w-[300px] block">
                            {log.description || '-'}
                          </span>
                          {log.targetName && (
                            <span className="text-xs text-muted-foreground block">
                              {log.targetType}: {log.targetName}
                            </span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-between mt-4">
                <p className="text-sm text-muted-foreground">
                  {t('table.page')} {page} {t('table.of')} {totalPages}
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    {t('common.previous')}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={page >= totalPages}
                  >
                    {t('common.next')}
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
