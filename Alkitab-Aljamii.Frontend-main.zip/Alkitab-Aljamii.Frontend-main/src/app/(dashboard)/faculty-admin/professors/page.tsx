'use client';

import { useState, useCallback } from 'react';
import { Loader2, Trash2, GraduationCap, Search, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { ServerDataTable } from '@/components/shared/data-table';
import { EmptyState, PageHeader } from '@/components/shared';
import { CreateMemberDialog } from '@/components/faculties/create-member-dialog';
import { QuickUploadModal } from '@/components/bulkImport';
import { useServerTable } from '@/hooks';
import { useFacultyContextStore } from '@/stores';
import { facultiesApi } from '@/lib/api/faculties';
import type { FacultyMember, CreateMemberDto, PaginationParams } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';

export default function ProfessorsPage() {
  const t = useTranslations();
  const { currentFacultyId, getCurrentFaculty } = useFacultyContextStore();
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  const fetchProfessors = useCallback(
    (params: PaginationParams) => {
      if (!currentFacultyId) {
        return Promise.resolve({
          items: [],
          meta: { total: 0, page: 1, limit: 10, totalPages: 0, hasNextPage: false, hasPreviousPage: false },
        });
      }
      return facultiesApi.getProfessors(currentFacultyId, params);
    },
    [currentFacultyId]
  );

  const {
    data: professors,
    meta,
    isLoading,
    searchValue,
    setPage,
    setPageSize,
    setSearch,
    refetch,
  } = useServerTable<FacultyMember>({
    fetchFn: fetchProfessors,
    initialPageSize: 10,
    fetchOnMount: !!currentFacultyId,
    deps: [currentFacultyId],
  });

  const handleCreate = async (data: CreateMemberDto) => {
    if (!currentFacultyId) return;
    try {
      await facultiesApi.createProfessor(currentFacultyId, data);
      toast.success(t('members.professors.addSuccess'));
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('members.professors.addError');
      toast.error(message);
      throw error;
    }
  };

  const handleRemove = async (professorId: string) => {
    if (!currentFacultyId) return;
    setRemovingId(professorId);
    try {
      await facultiesApi.removeProfessor(currentFacultyId, professorId);
      toast.success(t('members.professors.removeSuccess'));
      refetch();
    } catch {
      toast.error(t('members.professors.removeError'));
    } finally {
      setRemovingId(null);
    }
  };

  const columns: ColumnDef<FacultyMember>[] = [
    {
      id: 'name',
      header: t('members.name'),
      cell: ({ row }) => `${row.original.firstName} ${row.original.lastName}`,
    },
    { accessorKey: 'email', header: t('members.email') },
    {
      accessorKey: 'assignedAt',
      header: t('members.joined'),
      cell: ({ row }) => new Date(row.original.assignedAt).toLocaleDateString(),
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleRemove(row.original.id)}
              disabled={removingId === row.original.id}
            >
              {removingId === row.original.id ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Trash2 className="h-4 w-4 text-destructive" />
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent>{t('tooltips.professors.remove')}</TooltipContent>
        </Tooltip>
      ),
    },
  ];

  const faculty = getCurrentFaculty();

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  if (!currentFacultyId) {
    return (
      <EmptyState
        title={t('members.noFacultySelected')}
        description={t('members.selectFacultyHint', { role: t('nav.professors').toLowerCase() })}
      />
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={GraduationCap}
        title={t('members.professors.title')}
        description={faculty?.name ? t('members.professors.subtitle', { faculty: faculty.name }) : t('members.professors.subtitleGeneric')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setUploadModalOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Excel File
            </Button>
            <CreateMemberDialog
              title={t('members.professors.addProfessor')}
              role="professor"
              onCreate={handleCreate}
            />
          </div>
        }
      />

      {/* Search */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('members.professors.searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {!isLoading && professors.length === 0 && !searchValue ? (
        <EmptyState
          title={t('members.professors.noProfessorsYet')}
          description={t('members.professors.addToGetStarted')}
          action={
            <CreateMemberDialog
              title={t('members.professors.addProfessor')}
              role="professor"
              onCreate={handleCreate}
            />
          }
        />
      ) : (
        <ServerDataTable
          columns={columns}
          data={professors}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
        />
      )}

      <QuickUploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        allowedImportTypes={['professors_only']}
        onUploadComplete={() => {
          toast.success(t('bulkImport.uploadSuccess'));
          refetch();
        }}
      />
    </div>
  );
}
