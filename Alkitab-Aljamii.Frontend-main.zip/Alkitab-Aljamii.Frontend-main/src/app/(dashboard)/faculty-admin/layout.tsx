'use client';

import { AuthGuard } from '@/components/auth';

export default function FacultyAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AuthGuard allowedRoles={['faculty_admin']}>{children}</AuthGuard>;
}
