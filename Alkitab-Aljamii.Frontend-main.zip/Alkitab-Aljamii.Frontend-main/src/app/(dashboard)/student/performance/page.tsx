'use client';

import { useState, useEffect } from 'react';
import { Loader2, Target, Lightbulb, TrendingUp, BookOpen, Clock, Flame, Award } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { performanceApi, type StudentDashboard } from '@/lib/api/performance';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import { EmptyState } from '@/components/shared';
import {
  ApiScoreCard,
  MetricCard,
  GoalProgressCard,
  SubjectPerformanceCard,
  RecommendationCard,
  ApiTrendChart,
} from '@/components/performance';
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

export default function StudentPerformancePage() {
  const t = useTranslations();
  const locale = useLocale();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [dashboard, setDashboard] = useState<StudentDashboard | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const loadDashboard = async () => {
      if (!currentFacultyId) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      try {
        const data = await performanceApi.student.getDashboard();
        setDashboard(data);
      } catch {
        toast.error(t('performanceMetrics.student.loadPerformanceError'));
      } finally {
        setIsLoading(false);
      }
    };
    loadDashboard();
  }, [currentFacultyId]);

  if (!currentFacultyId) {
    return <EmptyState title={t('performanceMetrics.student.noFacultySelected')} description={t('performanceMetrics.student.noFacultySelectedDescription')} />;
  }

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!dashboard) {
    return <EmptyState title={t('performanceMetrics.student.noPerformanceData')} description={t('performanceMetrics.student.noPerformanceDataDescription')} />;
  }

  const { profile, subjects, activeGoals, recommendations, benchmarks } = dashboard;

  const radarData = benchmarks.map(b => ({
    metric: b.metric,
    student: b.studentValue,
    faculty: b.facultyAverage,
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('performanceMetrics.student.myPerformance')}</h2>
          <p className="text-muted-foreground">{t('performanceMetrics.student.trackAcademicProgress')}</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => performanceApi.student.refreshMetrics()}>
          <TrendingUp className="me-2 h-4 w-4" />
          {t('performanceMetrics.student.refreshMetrics')}
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">{t('performanceMetrics.student.overview')}</TabsTrigger>
          <TabsTrigger value="subjects">{t('performanceMetrics.student.subjects')}</TabsTrigger>
          <TabsTrigger value="goals">{t('performanceMetrics.student.goals')}</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Main Score and Metrics */}
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
            <ApiScoreCard
              score={profile.academicPerformanceIndex}
              trend={profile.apiTrend}
              percentile={profile.facultyPercentile}
              className="md:col-span-2 lg:col-span-1 lg:row-span-2"
              size="lg"
            />
            <MetricCard
              title={t('performance.student.completionRate')}
              value={profile.overallCompletionRate}
              format="percent"
              subtitle={`${profile.chaptersCompleted}/${profile.totalChaptersAvailable} chapters`}
              icon={BookOpen}
              iconColor="text-blue-600"
            />
            <MetricCard
              title={t('performance.student.quizAverage')}
              value={profile.averageQuizScore}
              format="percent"
              subtitle={`${profile.quizzesPassed}/${profile.totalQuizzesTaken} passed`}
              icon={Award}
              iconColor="text-purple-600"
            />
            <MetricCard
              title={t('performance.student.studyTime')}
              value={profile.totalStudyTimeMinutes}
              format="time"
              subtitle={`${Math.round(profile.avgDailyStudyTimeMinutes)}m daily avg`}
              icon={Clock}
              iconColor="text-emerald-600"
            />
            <MetricCard
              title={t('performance.student.currentStreak')}
              value={`${profile.currentStreak} days`}
              subtitle={`Best: ${profile.longestStreak} days`}
              icon={Flame}
              iconColor="text-orange-600"
            />
            <MetricCard
              title={t('performance.student.engagementScore')}
              value={profile.engagementScore}
              format="number"
              subtitle={`${profile.activeDaysLast30} active days (30d)`}
              icon={TrendingUp}
              iconColor="text-cyan-600"
            />
          </div>

          {/* Charts Row */}
          <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
            {/* Benchmarks Radar */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">{t('performance.student.performanceVsFaculty')}</CardTitle>
                <CardDescription className="text-xs">{t('performance.student.howYouCompare')}</CardDescription>
              </CardHeader>
              <CardContent>
                {radarData.length > 0 ? (
                  <div className="h-[250px]" dir="ltr">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid className="stroke-muted/30" />
                        <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11 }} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
                        <Radar
                          name={t('performance.student.you')}
                          dataKey="student"
                          stroke="#3b82f6"
                          fill="#3b82f6"
                          fillOpacity={0.3}
                        />
                        <Radar
                          name={t('performance.student.facultyAvg')}
                          dataKey="faculty"
                          stroke="#94a3b8"
                          fill="#94a3b8"
                          fillOpacity={0.1}
                        />
                        <Tooltip />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">{t('performance.student.noBenchmarkData')}</p>
                )}
              </CardContent>
            </Card>

            {/* API Trend - Placeholder since we need history endpoint */}
            <ApiTrendChart
              data={[]} // Would come from getHistory endpoint
              title={t('performance.student.performanceTrend')}
              subtitle={t('performance.cards.last30Days')}
            />
          </div>

          {/* Recommendations */}
          {recommendations.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-yellow-600" />
                  {t('performance.student.studyRecommendations')}
                </CardTitle>
                <CardDescription className="text-xs">{t('performance.student.personalizedSuggestions')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                  {recommendations.slice(0, 3).map((rec) => (
                    <RecommendationCard key={rec.id} recommendation={rec} locale={locale} />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="subjects" className="space-y-6 mt-6">
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {subjects.length > 0 ? (
              subjects.map((subject) => (
                <SubjectPerformanceCard key={subject.subjectId} subject={subject} locale={locale} />
              ))
            ) : (
              <div className="col-span-full">
                <EmptyState
                  title={t('performance.student.noSubjectData')}
                  description={t('performance.student.noSubjectDataDescription')}
                />
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-6 mt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">{t('performance.student.activeGoals')}</h3>
              <p className="text-sm text-muted-foreground">{t('performance.student.activeGoalsDescription')}</p>
            </div>
            <Button size="sm">
              <Target className="me-2 h-4 w-4" />
              {t('performance.student.setNewGoal')}
            </Button>
          </div>
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {activeGoals.length > 0 ? (
              activeGoals.map((goal) => (
                <GoalProgressCard key={goal.id} goal={goal} locale={locale} />
              ))
            ) : (
              <div className="col-span-full">
                <EmptyState
                  title={t('performance.student.noActiveGoals')}
                  description={t('performance.student.noActiveGoalsDescription')}
                />
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
