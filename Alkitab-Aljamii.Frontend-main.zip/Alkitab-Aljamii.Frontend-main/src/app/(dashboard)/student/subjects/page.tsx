'use client';

import { useState, useEffect, useCallback } from 'react';
import { BookOpen, Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, PageHeader } from '@/components/shared';
import { subjectsApi } from '@/lib/api/subjects';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import type { Subject } from '@/types';
import Link from 'next/link';

export default function StudentSubjectsPage() {
  const t = useTranslations();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadSubjects = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const params = currentFacultyId ? { facultyId: currentFacultyId } : {};
      const result = await subjectsApi.getAll(params);
      setSubjects(result.items);
    } catch {
      setError(t('subjects.loadError'));
    } finally {
      setIsLoading(false);
    }
  }, [currentFacultyId, t]);

  useEffect(() => { loadSubjects(); }, [loadSubjects]);

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <ErrorState
        title={t('subjects.loadError')}
        description={t('errors.tryAgainLater')}
        onRetry={loadSubjects}
        isRetrying={isLoading}
      />
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        icon={BookOpen}
        title={t('subjects.mySubjects')}
        description={t('subjects.studentSubtitle')}
        badge={subjects.length > 0 && <Badge variant="secondary">{subjects.length}</Badge>}
      />

      {subjects.length === 0 ? (
        <EmptyState
          title={t('subjects.noSubjectsEnrolled')}
          description={t('subjects.noSubjectsEnrolledDescription')}
          icon={BookOpen}
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {subjects.map((subject) => (
            <Card key={subject.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{subject.name}</CardTitle>
                    <CardDescription>{subject.code}</CardDescription>
                  </div>
                  <Badge variant={subject.isActive ? 'default' : 'secondary'}>
                    {subject.isActive ? t('subjects.active') : t('subjects.inactive')}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {subject.facultyName && (
                  <p className="text-xs text-muted-foreground">{subject.facultyName}</p>
                )}
                {subject.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">{subject.description}</p>
                )}
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/student/books?subjectId=${subject.id}`}>
                    <BookOpen className="me-2 h-4 w-4" />{t('subjects.viewBooks')}
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
