'use client';

import { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import { toast } from 'sonner';
import { ChevronLeft, ChevronRight, Send, Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { QuizTimer, QuestionDisplay, QuizNavigation } from '@/components/quiz';
import { quizApi, type QuizAttemptDetail } from '@/lib/api/quiz';
import { ROUTES } from '@/lib/constants/routes';

export default function StudentQuizTakePage() {
  const t = useTranslations();
  const locale = useLocale();
  const router = useRouter();
  const params = useParams();
  const searchParams = useSearchParams();
  const quizId = params['id'] as string;
  const attemptId = searchParams.get('attemptId');

  const [attempt, setAttempt] = useState<QuizAttemptDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [showTimeUpDialog, setShowTimeUpDialog] = useState(false);

  // Copy/Screenshot protection
  useEffect(() => {
    // Disable copy/paste/cut
    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
      toast.error(t('quizTaking.copyDisabled') || 'Copying is disabled during quiz');
    };

    // Disable context menu (right-click)
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // Disable keyboard shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      // Disable PrintScreen
      if (e.key === 'PrintScreen') {
        e.preventDefault();
        toast.error(t('quizTaking.screenshotDisabled') || 'Screenshots are disabled during quiz');
      }
      // Disable Ctrl/Cmd + C, P, S, A
      if ((e.ctrlKey || e.metaKey) && ['c', 'p', 's', 'a', 'u'].includes(e.key.toLowerCase())) {
        e.preventDefault();
      }
      // Disable F12 (DevTools)
      if (e.key === 'F12') {
        e.preventDefault();
      }
    };

    document.addEventListener('copy', handleCopy);
    document.addEventListener('cut', handleCopy);
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('cut', handleCopy);
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [t]);

  // Load attempt
  useEffect(() => {
    if (!attemptId) {
      toast.error(t('quizTaking.noAttempt'));
      router.push(ROUTES.STUDENT.QUIZ(quizId));
      return;
    }

    const fetchAttempt = async () => {
      setIsLoading(true);
      try {
        const data = await quizApi.getActiveAttempt(attemptId);
        if (data.status !== 'in_progress') {
          // Already submitted, redirect to result
          router.push(ROUTES.STUDENT.QUIZ_RESULT(attemptId));
          return;
        }
        setAttempt(data);
        setAnswers(data.answers || {});
      } catch (err) {
        console.error('Failed to fetch attempt:', err);
        toast.error(t('quizTaking.fetchError'));
        router.push(ROUTES.STUDENT.QUIZ(quizId));
      } finally {
        setIsLoading(false);
      }
    };

    fetchAttempt();
  }, [attemptId, quizId, router, t]);

  // Handle option selection (local state only - submitted at the end)
  const handleSelectOption = useCallback((optionKey: string) => {
    if (!attempt) return;

    const currentQuestion = attempt.questions[currentQuestionIndex];
    if (!currentQuestion) return;

    // Use question.id as the key (backend sends id, not questionId)
    const questionId = currentQuestion.questionId || currentQuestion.id;
    setAnswers((prev) => ({
      ...prev,
      [questionId]: optionKey,
    }));
  }, [attempt, currentQuestionIndex]);

  // Handle time up
  const handleTimeUp = useCallback(async () => {
    if (!attemptId) return;
    setShowTimeUpDialog(true);

    // Auto-submit with current answers when time is up
    try {
      await quizApi.submitQuizAttempt(attemptId, answers);

      // Process chapter quiz completion
      try {
        await quizApi.processQuizCompletion(attemptId);
      } catch {
        // Not a chapter quiz or processing failed
      }
    } catch {
      // Still show dialog
    }
  }, [attemptId, answers]);

  // Handle submit
  const handleSubmit = async () => {
    if (!attemptId) return;

    setIsSubmitting(true);
    try {
      await quizApi.submitQuizAttempt(attemptId, answers);

      // Process chapter quiz completion to unlock next chapter if passed
      try {
        const unlockResult = await quizApi.processQuizCompletion(attemptId);
        if (unlockResult?.success && unlockResult?.chapterTitle) {
          toast.success(t('quizTaking.chapterUnlockedToast', { chapter: unlockResult.chapterTitle }));
        }
      } catch {
        // Not a chapter quiz or processing failed - that's OK
      }

      toast.success(t('quizTaking.submitSuccess'));
      router.push(ROUTES.STUDENT.QUIZ_RESULT(attemptId));
    } catch (err) {
      const message = err instanceof Error ? err.message : t('quizTaking.submitError');
      toast.error(message);
    } finally {
      setIsSubmitting(false);
      setShowSubmitConfirm(false);
    }
  };

  // Navigate to time up result
  const handleTimeUpConfirm = () => {
    if (attemptId) {
      router.push(ROUTES.STUDENT.QUIZ_RESULT(attemptId));
    }
  };

  // Get answered questions
  const answeredQuestions = new Set(
    Object.keys(answers).map((qId) => {
      const idx = attempt?.questions.findIndex((q) => (q.questionId || q.id) === qId);
      return idx ?? -1;
    }).filter((idx) => idx >= 0)
  );

  // Current question
  const currentQuestion = attempt?.questions[currentQuestionIndex];

  if (isLoading || !attempt) {
    return (
      <div className="h-[calc(100vh-4rem)] flex">
        <div className="flex-1 p-8">
          <Skeleton className="h-8 w-full mb-4" />
          <Skeleton className="h-64 w-full" />
        </div>
        <div className="w-64 border-s p-4">
          <Skeleton className="h-full w-full" />
        </div>
      </div>
    );
  }

  const isArabic = locale === 'ar';
  const quizTitle = isArabic && attempt.quizTitleAr ? attempt.quizTitleAr : attempt.quizTitle;

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      {/* Header */}
      <div className="shrink-0 border-b bg-background px-4 py-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h1 className="font-semibold truncate">{quizTitle}</h1>
            <p className="text-sm text-muted-foreground">
              {t('quizTaking.questionOf', {
                current: currentQuestionIndex + 1,
                total: attempt.totalQuestions,
              })}
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            {/* Timer - always visible (countdown for timed, elapsed for untimed) */}
            <QuizTimer
              timeLimit={attempt.timeLimit}
              startTime={attempt.startedAt}
              onTimeUp={attempt.timeLimit ? handleTimeUp : undefined}
            />

            {/* Submit button */}
            <Button
              onClick={() => setShowSubmitConfirm(true)}
              disabled={isSubmitting}
              size="sm"
              className="sm:size-default"
            >
              <Send className="me-2 h-4 w-4" />
              {t('quizTaking.submit')}
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content - Disable text selection for copy protection */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 select-none">
        {/* Question area */}
        <div className="flex-1 overflow-auto p-4 sm:p-8">
          <div className="max-w-3xl mx-auto">
            {currentQuestion && (
              <QuestionDisplay
                question={currentQuestion}
                questionNumber={currentQuestionIndex + 1}
                selectedOptionId={answers[currentQuestion.questionId || currentQuestion.id] || null}
                onSelectOption={handleSelectOption}
              />
            )}

            {/* Navigation buttons */}
            <div className="flex items-center justify-between mt-8 pt-6 border-t gap-3">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestionIndex((i) => Math.max(0, i - 1))}
                disabled={currentQuestionIndex === 0}
                size="sm"
                className="sm:size-default"
              >
                <ChevronLeft className="me-1 h-4 w-4" />
                <span className="hidden sm:inline">{t('common.previous')}</span>
                <span className="sm:hidden">{t('common.prev')}</span>
              </Button>

              {currentQuestionIndex < attempt.questions.length - 1 ? (
                <Button
                  onClick={() => setCurrentQuestionIndex((i) => i + 1)}
                  size="sm"
                  className="sm:size-default"
                >
                  <span className="hidden sm:inline">{t('common.next')}</span>
                  <span className="sm:hidden">{t('common.next')}</span>
                  <ChevronRight className="ms-1 h-4 w-4" />
                </Button>
              ) : (
                <Button onClick={() => setShowSubmitConfirm(true)} size="sm" className="sm:size-default">
                  <Send className="me-2 h-4 w-4" />
                  {t('quizTaking.submit')}
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Question navigator sidebar */}
        <div className="w-full lg:w-64 shrink-0 border-t lg:border-t-0 lg:border-s bg-muted/30 p-4 overflow-auto max-h-64 lg:max-h-none">
          <QuizNavigation
            totalQuestions={attempt.questions.length}
            currentQuestion={currentQuestionIndex}
            answeredQuestions={answeredQuestions}
            onSelectQuestion={setCurrentQuestionIndex}
          />
        </div>
      </div>

      {/* Submit Confirmation Dialog */}
      <AlertDialog open={showSubmitConfirm} onOpenChange={setShowSubmitConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('quizTaking.submitTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {answeredQuestions.size < attempt.questions.length ? (
                <span className="text-yellow-600">
                  {t('quizTaking.unansweredWarning', {
                    count: attempt.questions.length - answeredQuestions.size,
                  })}
                </span>
              ) : (
                t('quizTaking.submitConfirm')
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="me-2 h-4 w-4 animate-spin" />
                  {t('quizTaking.submitting')}
                </>
              ) : (
                t('quizTaking.submitConfirmButton')
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Time Up Dialog */}
      <AlertDialog open={showTimeUpDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-6 w-6 text-red-500" />
              <AlertDialogTitle>{t('quizTaking.timeUp')}</AlertDialogTitle>
            </div>
            <AlertDialogDescription>
              {t('quizTaking.timeUpDescription')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handleTimeUpConfirm}>
              {t('quizTaking.viewResults')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
