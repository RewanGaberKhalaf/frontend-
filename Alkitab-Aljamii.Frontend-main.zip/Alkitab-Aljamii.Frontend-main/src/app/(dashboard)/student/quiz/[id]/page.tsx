'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import { toast } from 'sonner';
import {
  ClipboardList,
  Clock,
  Target,
  HelpCircle,
  ArrowRight,
  History,
  CheckCircle2,
  XCircle,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader } from '@/components/shared';
import { quizApi, type Quiz, type QuizAttempt } from '@/lib/api/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export default function StudentQuizInfoPage() {
  const t = useTranslations();
  const locale = useLocale();
  const router = useRouter();
  const params = useParams();
  const quizId = params['id'] as string;
  const isArabic = locale === 'ar';

  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isStarting, setIsStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cooldownInfo, setCooldownInfo] = useState<{
    active: boolean;
    endsAt: Date | null;
    remainingMinutes: number;
  } | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const [quizData, attemptsResponse] = await Promise.all([
          quizApi.getQuiz(quizId),
          quizApi.getMyAttempts(quizId),
        ]);
        setQuiz(quizData);
        setAttempts(attemptsResponse.items);
      } catch (err) {
        console.error('Failed to fetch quiz:', err);
        setError(t('quizzes.fetchError'));
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [quizId, t]);

  const handleStartQuiz = async () => {
    setIsStarting(true);
    setCooldownInfo(null);
    try {
      const attempt = await quizApi.startQuizAttempt(quizId);
      router.push(`${ROUTES.STUDENT.QUIZ_TAKE(quizId)}?attemptId=${attempt.id}`);
    } catch (err: unknown) {
      // Check for cooldown error
      const errorData = err as { response?: { data?: { error?: string; cooldownEndsAt?: string; remainingMinutes?: number } } };
      if (errorData?.response?.data?.error === 'COOLDOWN_ACTIVE') {
        const data = errorData.response.data;
        setCooldownInfo({
          active: true,
          endsAt: data.cooldownEndsAt ? new Date(data.cooldownEndsAt) : null,
          remainingMinutes: data.remainingMinutes || 0,
        });
        toast.error(t('quizTaking.cooldownActive'));
      } else {
        const message = err instanceof Error ? err.message : t('quizTaking.startError');
        toast.error(message);
      }
    } finally {
      setIsStarting(false);
    }
  };

  // Check if student can start a new attempt
  const canStartNewAttempt = () => {
    if (!quiz) return false;
    if (!quiz.isActive) return false;

    // Check if already in progress
    const inProgress = attempts.find((a) => a.status === 'in_progress');
    if (inProgress) return false;

    // Note: No max attempts check - unlimited retries allowed
    // Cooldown is checked server-side when starting

    return true;
  };

  const inProgressAttempt = attempts.find((a) => a.status === 'in_progress');
  const bestAttempt = attempts.reduce((best, current) => {
    if (!best || (current.score !== null && (best.score === null || current.score > best.score))) {
      return current;
    }
    return best;
  }, null as QuizAttempt | null);

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto space-y-6 py-8">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (error || !quiz) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <p className="text-destructive mb-4">{error || t('quizzes.notFound')}</p>
        <Button onClick={() => router.back()}>{t('common.back')}</Button>
      </div>
    );
  }

  const title = isArabic && quiz.titleAr ? quiz.titleAr : quiz.title;
  const description = isArabic && quiz.descriptionAr ? quiz.descriptionAr : quiz.description;

  return (
    <div className="max-w-2xl mx-auto space-y-6 py-8">
      <PageHeader
        icon={ClipboardList}
        title={title}
        description={description || undefined}
        badge={
          quiz.isActive ? (
            <Badge variant="default">{t('common.active')}</Badge>
          ) : (
            <Badge variant="secondary">{t('common.inactive')}</Badge>
          )
        }
      />

      {/* Quiz Info Card */}
      <div className="rounded-lg border bg-card p-6 space-y-6">
        <h2 className="font-semibold">{t('quizTaking.quizDetails')}</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <HelpCircle className="h-4 w-4 shrink-0" />
              <span>{t('quizzes.totalQuestions')}</span>
            </div>
            <p className="text-xl font-bold">{quiz.totalQuestions}</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4 shrink-0" />
              <span>{t('quizzes.timeLimit')}</span>
            </div>
            <p className="text-xl font-bold">
              {quiz.timeLimit ? `${quiz.timeLimit} min` : t('quizTaking.noLimit')}
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Target className="h-4 w-4 shrink-0" />
              <span>{t('quizzes.passingScore')}</span>
            </div>
            <p className="text-xl font-bold">{quiz.passingScore}%</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <History className="h-4 w-4 shrink-0" />
              <span>{t('quizzes.yourAttempts')}</span>
            </div>
            <p className="text-xl font-bold">{attempts.length}</p>
          </div>
        </div>

        {/* Best Score */}
        {bestAttempt && bestAttempt.score !== null && (
          <div className="p-4 rounded-lg bg-muted/50">
            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground">
                {t('quizTaking.yourBestScore')}
              </span>
              <div className="flex items-center gap-2 shrink-0">
                {bestAttempt.passed ? (
                  <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600 shrink-0" />
                )}
                <span
                  className={cn(
                    'text-2xl font-bold',
                    bestAttempt.passed ? 'text-green-600' : 'text-red-600'
                  )}
                >
                  {bestAttempt.score.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Cooldown Notice */}
        {cooldownInfo?.active && (
          <div className="p-4 rounded-lg bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800">
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-yellow-600 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-yellow-800 dark:text-yellow-200">
                  {t('quizTaking.cooldownTitle')}
                </p>
                <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                  {t('quizTaking.cooldownMessage', { minutes: cooldownInfo.remainingMinutes })}
                </p>
                {cooldownInfo.endsAt && (
                  <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-2">
                    {t('quizTaking.cooldownEndsAt')}: {format(cooldownInfo.endsAt, 'HH:mm')}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Start/Continue Button */}
        <div className="pt-4 border-t">
          {inProgressAttempt ? (
            <Button
              size="lg"
              className="w-full"
              onClick={() =>
                router.push(`${ROUTES.STUDENT.QUIZ_TAKE(quizId)}?attemptId=${inProgressAttempt.id}`)
              }
            >
              {t('quizTaking.continueQuiz')}
              <ArrowRight className="ms-2 h-4 w-4" />
            </Button>
          ) : canStartNewAttempt() ? (
            <Button
              size="lg"
              className="w-full"
              onClick={handleStartQuiz}
              disabled={isStarting || cooldownInfo?.active}
            >
              {isStarting ? (
                <>
                  <Loader2 className="me-2 h-4 w-4 animate-spin" />
                  {t('quizTaking.starting')}
                </>
              ) : cooldownInfo?.active ? (
                <>
                  <Clock className="me-2 h-4 w-4" />
                  {t('quizTaking.waitToRetry')}
                </>
              ) : (
                <>
                  {attempts.length > 0 ? t('quizTaking.retryQuiz') : t('quizTaking.startQuiz')}
                  <ArrowRight className="ms-2 h-4 w-4" />
                </>
              )}
            </Button>
          ) : (
            <Button size="lg" className="w-full" disabled>
              {t('quizTaking.cannotStart')}
            </Button>
          )}
        </div>
      </div>

      {/* Previous Attempts */}
      {attempts.length > 0 && (
        <div className="rounded-lg border bg-card p-6 space-y-4">
          <h2 className="font-semibold">{t('quizTaking.previousAttempts')}</h2>

          <div className="space-y-3">
            {attempts.map((attempt) => (
              <div
                key={attempt.id}
                className={cn(
                  'flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-3 rounded-lg border',
                  attempt.status === 'in_progress' && 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950/20'
                )}
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground shrink-0">
                    #{attempt.attemptNumber}
                  </span>
                  {attempt.status === 'in_progress' ? (
                    <Badge variant="outline">{t('quizAttempts.inProgress')}</Badge>
                  ) : attempt.passed ? (
                    <Badge variant="default">{t('quizAttempts.passed')}</Badge>
                  ) : (
                    <Badge variant="secondary">{t('quizAttempts.failed')}</Badge>
                  )}
                </div>
                <div className="flex items-center gap-4">
                  {attempt.score !== null && (
                    <span
                      className={cn(
                        'font-bold',
                        attempt.passed ? 'text-green-600' : 'text-red-600'
                      )}
                    >
                      {attempt.score.toFixed(1)}%
                    </span>
                  )}
                  {attempt.submittedAt && (
                    <span className="text-sm text-muted-foreground whitespace-nowrap">
                      {format(new Date(attempt.submittedAt), 'MMM d, HH:mm')}
                    </span>
                  )}
                  {attempt.status !== 'in_progress' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="shrink-0"
                      onClick={() => router.push(ROUTES.STUDENT.QUIZ_RESULT(attempt.id))}
                    >
                      {t('common.view')}
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
