'use client';

import { useState, useEffect } from 'react';
import { BookOpen, BookText, Loader2, ArrowRight, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip as UITooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { statsApi, type StudentStats } from '@/lib/api';
import { useAuthStore, useFacultyContextStore } from '@/stores';

export default function StudentDashboard() {
  const t = useTranslations();
  const { user } = useAuthStore();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [stats, setStats] = useState<StudentStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      setIsLoading(true);
      try {
        const data = await statsApi.getStudentStats();
        setStats(data);
      } catch {
        toast.error(t('dashboard.failedToLoadStats'));
      } finally {
        setIsLoading(false);
      }
    };
    loadStats();
  }, [currentFacultyId, t]);

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">
            {t('dashboard.welcomeUser', { name: user?.firstName ?? t('roles.STUDENT') })}
          </h2>
          <p className="text-muted-foreground">{t('dashboard.student.subtitle')}</p>
        </div>
        <Link href="/student/books">
          <Button size="sm"><BookText className="me-2 h-4 w-4" />{t('dashboard.student.browseBooks')}</Button>
        </Link>
      </div>

      {/* Stat Cards */}
      <div className="grid gap-4 grid-cols-2">
        <Link href="/student/subjects">
          <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">{t('dashboard.student.mySubjects')}</CardTitle>
              <BookOpen className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold text-blue-600">{(stats?.totalSubjects ?? 0).toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">{t('dashboard.student.enrolledCourses')}</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/student/books">
          <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">{t('dashboard.student.availableBooks')}</CardTitle>
              <BookText className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold text-purple-600">{(stats?.availableBooks ?? 0).toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">{t('dashboard.student.booksToExplore')}</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Main Content Row */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {/* Recent Books */}
        <Card className="md:col-span-2 lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-sm font-medium">{t('dashboard.student.recentBooks')}</CardTitle>
              <CardDescription className="text-xs">{t('dashboard.student.newlyAvailable')}</CardDescription>
            </div>
            <Link href="/student/books">
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(stats?.recentBooks ?? []).length > 0 ? (
              <div className="flex flex-col gap-3">
                {stats?.recentBooks.map((book) => (
                  <Link key={book.id} href={`/student/books/${book.id}`} className="block">
                    <div className="flex items-center justify-between gap-2 p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{book.title}</p>
                        <p className="text-xs text-muted-foreground truncate">{book.subjectName} &bull; {book.authorName}</p>
                      </div>
                      <UITooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0"><Eye className="h-4 w-4" /></Button>
                        </TooltipTrigger>
                        <TooltipContent>{t('tooltips.books.preview')}</TooltipContent>
                      </UITooltip>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <BookText className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">{t('dashboard.student.noBooksYet')}</p>
              </div>
            )}
          </CardContent>
        </Card>

      </div>

      {/* My Subjects */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-sm font-medium">{t('dashboard.student.mySubjects')}</CardTitle>
            <CardDescription className="text-xs">{t('dashboard.student.subjectsWithMaterials')}</CardDescription>
          </div>
          <Link href="/student/subjects">
            <Button variant="ghost" size="sm" className="h-8 text-xs">
              {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {(stats?.subjects ?? []).length > 0 ? (
            <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {stats?.subjects.map((subject) => (
                <Link key={subject.id} href={`/student/books?subjectId=${subject.id}`}>
                  <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{subject.name}</p>
                          <p className="text-xs text-muted-foreground">{subject.code}</p>
                        </div>
                        <Badge variant="secondary" className="shrink-0">{subject.bookCount} {t('common.books')}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <BookOpen className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">{t('dashboard.student.noSubjectsEnrolled')}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">{t('dashboard.quickActions')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Link href="/student/subjects">
            <Button variant="outline" size="sm"><BookOpen className="me-2 h-4 w-4" />{t('dashboard.student.mySubjects')}</Button>
          </Link>
          <Link href="/student/books">
            <Button variant="outline" size="sm"><BookText className="me-2 h-4 w-4" />{t('dashboard.student.browseBooks')}</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
