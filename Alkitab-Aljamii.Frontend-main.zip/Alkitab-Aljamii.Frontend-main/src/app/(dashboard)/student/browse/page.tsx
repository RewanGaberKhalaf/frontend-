'use client';

import { useTranslations } from 'next-intl';
import { DeprecatedFeature } from '@/components/shared';
import { ROUTES } from '@/lib/constants/routes';

export default function BrowseContentPage() {
  const t = useTranslations();

  return (
    <DeprecatedFeature
      redirectTo={ROUTES.STUDENT.BOOKS}
      redirectLabel={t('deprecated.goToBooks')}
    />
  );
}
