'use client';

import { useState, useEffect } from 'react';
import { BookText, Eye, Search } from 'lucide-react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { EmptyState, PageHeader } from '@/components/shared';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useServerTable } from '@/hooks';
import { booksApi } from '@/lib/api/books';
import { subjectsApi } from '@/lib/api/subjects';
import { ROUTES } from '@/lib/constants/routes';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import type { BookListItem, Subject, BookQueryParams, PaginationParams } from '@/types';

type BookFilters = Omit<BookQueryParams, keyof PaginationParams>;

export default function StudentBooksPage() {
  const t = useTranslations();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [subjects, setSubjects] = useState<Subject[]>([]);

  const {
    data: books,
    meta,
    isLoading,
    searchValue,
    filters,
    setPage,
    setSearch,
    setFilter,
  } = useServerTable<BookListItem, BookFilters>({
    fetchFn: booksApi.getAll,
    initialPageSize: 12,
    initialFilters: { status: 'published' },
  });

  // Load subjects for filter
  useEffect(() => {
    const loadSubjects = async () => {
      try {
        const params = currentFacultyId ? { facultyId: currentFacultyId } : {};
        const result = await subjectsApi.getAll(params);
        setSubjects(result.items);
      } catch {
        // Silently fail
      }
    };
    loadSubjects();
  }, [currentFacultyId]);

  const handleSubjectFilter = (value: string) => {
    setFilter('subjectId', value === 'all' ? undefined : value);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        icon={BookText}
        title={t('nav.books')}
        description={t('books.browseDescription')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('books.searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={(filters.subjectId as string) ?? 'all'}
          onValueChange={handleSubjectFilter}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder={t('content.filterBySubject')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('content.allSubjects')}</SelectItem>
            {subjects.map((subject) => (
              <SelectItem key={subject.id} value={subject.id}>
                {subject.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Books Grid */}
      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2 mt-2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3 mt-2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : books.length === 0 ? (
        <EmptyState
          title={t('books.noBooksAvailable')}
          description={t('books.noBooksAvailableDescription')}
        />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {books.map((book) => (
              <Card key={book.id} className="flex flex-col hover:shadow-md transition-shadow">
                <CardHeader className="flex-1">
                  <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
                  {book.titleAr && (
                    <CardDescription dir="rtl" className="line-clamp-1">
                      {book.titleAr}
                    </CardDescription>
                  )}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
                    <span>{book.authorName}</span>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      {book.chapterCount} {t('books.chapters')}
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={ROUTES.STUDENT.BOOK_READER(book.id)}>
                        <Eye className="h-4 w-4 me-2" />
                        {t('common.view')}
                      </Link>
                    </Button>
                  </div>
                  {book.subjectName && (
                    <Badge variant="secondary" className="mt-3">
                      {book.subjectName}
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {meta && meta.totalPages > 1 && (
            <div className="flex justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(meta.page - 1)}
                disabled={!meta.hasPreviousPage}
              >
                {t('common.previous')}
              </Button>
              <span className="flex items-center px-4 text-sm text-muted-foreground">
                {t('pagination.pageOf', { page: meta.page, total: meta.totalPages })}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(meta.page + 1)}
                disabled={!meta.hasNextPage}
              >
                {t('common.next')}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
