"use client";

import { useState, useEffect } from "react";
import { useTranslations, useLocale } from "next-intl";
import {
  Download,
  FileText,
  Image,
  Music,
  Video,
  Archive,
  Lock,
  Loader2,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Link as LinkIcon,
  ExternalLink,
  Youtube,
  Globe,
  FolderOpen,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import { booksApi } from "@/lib/api/books";
import type { GroupedBookResources, BookResource, FileCategory, LinkType } from "@/types";

interface ResourcesPanelProps {
  bookId: string;
  activeChapterId?: string;
}

const FILE_ICONS: Record<FileCategory, React.ElementType> = {
  document: FileText,
  image: Image,
  audio: Music,
  video: Video,
  archive: Archive,
  link: LinkIcon,
};

const LINK_TYPE_ICONS: Record<LinkType, React.ElementType> = {
  youtube: Youtube,
  vimeo: Video,
  website: Globe,
  document: FileText,
  drive: FolderOpen,
  other: LinkIcon,
};

function formatFileSize(bytes: number | null): string {
  if (!bytes) return "";
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

function getLinkDomain(url: string): string {
  try {
    const domain = new URL(url).hostname.replace("www.", "");
    return domain;
  } catch {
    return url;
  }
}

export function ResourcesPanel({ bookId, activeChapterId }: ResourcesPanelProps) {
  const t = useTranslations("resources");
  const locale = useLocale();
  const isArabic = locale === "ar";

  const [resources, setResources] = useState<GroupedBookResources | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(new Set());
  const [isBookLevelExpanded, setIsBookLevelExpanded] = useState(true);

  useEffect(() => {
    const loadResources = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const data = await booksApi.getStudentResources(bookId);
        setResources(data);

        // Auto-expand active chapter resources
        if (activeChapterId && data.chapterLevel[activeChapterId]?.length) {
          setExpandedChapters(new Set([activeChapterId]));
        }
      } catch {
        setError(t("loadError"));
      } finally {
        setIsLoading(false);
      }
    };
    loadResources();
  }, [bookId, activeChapterId, t]);

  const handleDownload = async (resource: BookResource) => {
    if (!resource.isAccessible) {
      toast.error(t("lockedMessage"));
      return;
    }

    // For link resources, open in new tab
    if (resource.resourceType === "link" && resource.url) {
      window.open(resource.url, "_blank", "noopener,noreferrer");
      return;
    }

    // For file resources, download
    try {
      setDownloadingId(resource.id);
      const { url, fileName } = await booksApi.getResourceDownloadUrl(bookId, resource.id);

      // Create a temporary link to trigger download
      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;
      link.target = "_blank";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success(t("downloadStarted"));
    } catch {
      toast.error(t("downloadError"));
    } finally {
      setDownloadingId(null);
    }
  };

  const toggleChapter = (chapterId: string) => {
    setExpandedChapters((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) {
        next.delete(chapterId);
      } else {
        next.add(chapterId);
      }
      return next;
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
        <AlertCircle className="h-8 w-8 text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">{error}</p>
      </div>
    );
  }

  const hasBookResources = resources?.bookLevel && resources.bookLevel.length > 0;
  const hasChapterResources = resources?.chapterLevel && Object.keys(resources.chapterLevel).length > 0;

  if (!hasBookResources && !hasChapterResources) {
    return (
      <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
        <FileText className="h-8 w-8 text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">{t("noResources")}</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-full">
      <div className="py-2 space-y-2">
        {/* Info note about resource access */}
        <div className="mx-3 mb-2 p-2 rounded-md bg-muted/50 border border-muted">
          <p className="text-[10px] text-muted-foreground leading-relaxed">
            {t("accessNote")}
          </p>
        </div>
        {/* Book-level resources */}
        {hasBookResources && (
          <Collapsible open={isBookLevelExpanded} onOpenChange={setIsBookLevelExpanded}>
            <CollapsibleTrigger asChild>
              <button className="w-full flex items-center justify-between px-3 py-2 hover:bg-muted/50 transition-colors">
                <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  {t("bookLevel")}
                </span>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="h-5 text-[10px] px-1.5">
                    {resources!.bookLevel.length}
                  </Badge>
                  {isBookLevelExpanded ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="space-y-1 px-2">
                {resources!.bookLevel.map((resource) => (
                  <ResourceItem
                    key={resource.id}
                    resource={resource}
                    isArabic={isArabic}
                    isDownloading={downloadingId === resource.id}
                    onDownload={() => handleDownload(resource)}
                    t={t}
                  />
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Chapter-level resources */}
        {hasChapterResources &&
          Object.entries(resources!.chapterLevel).map(([chapterId, chapterResources]) => {
            const isExpanded = expandedChapters.has(chapterId);
            const isActive = chapterId === activeChapterId;
            const firstResource = chapterResources[0];
            const chapterTitle = isArabic
              ? firstResource?.chapterTitleAr || firstResource?.chapterTitle
              : firstResource?.chapterTitle;
            const allLocked = chapterResources.every((r) => !r.isAccessible);

            return (
              <Collapsible
                key={chapterId}
                open={isExpanded}
                onOpenChange={() => toggleChapter(chapterId)}
              >
                <CollapsibleTrigger asChild>
                  <button
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2 hover:bg-muted/50 transition-colors",
                      isActive && "bg-primary/5"
                    )}
                  >
                    <span
                      className={cn(
                        "text-xs font-medium truncate max-w-[140px]",
                        allLocked && "text-muted-foreground"
                      )}
                      title={chapterTitle || undefined}
                    >
                      {chapterTitle || t("chapterResources")}
                    </span>
                    <div className="flex items-center gap-2">
                      {allLocked && <Lock className="h-3 w-3 text-muted-foreground" />}
                      <Badge
                        variant={isActive ? "default" : "secondary"}
                        className="h-5 text-[10px] px-1.5"
                      >
                        {chapterResources.length}
                      </Badge>
                      {isExpanded ? (
                        <ChevronUp className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="space-y-1 px-2">
                    {chapterResources.map((resource) => (
                      <ResourceItem
                        key={resource.id}
                        resource={resource}
                        isArabic={isArabic}
                        isDownloading={downloadingId === resource.id}
                        onDownload={() => handleDownload(resource)}
                        t={t}
                      />
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          })}
      </div>
    </ScrollArea>
  );
}

interface ResourceItemProps {
  resource: BookResource;
  isArabic: boolean;
  isDownloading: boolean;
  onDownload: () => void;
  t: ReturnType<typeof useTranslations<"resources">>;
}

function ResourceItem({
  resource,
  isArabic,
  isDownloading,
  onDownload,
  t,
}: ResourceItemProps) {
  const isLink = resource.resourceType === "link";
  const Icon = isLink
    ? (LINK_TYPE_ICONS[resource.linkType as LinkType] || LinkIcon)
    : (FILE_ICONS[resource.fileCategory] || FileText);
  const title = isArabic
    ? resource.titleAr || resource.title
    : resource.title;
  const description = isArabic
    ? resource.descriptionAr || resource.description
    : resource.description;

  return (
    <div
      className={cn(
        "flex items-start gap-2 p-2 rounded-md transition-colors",
        resource.isAccessible
          ? "hover:bg-muted/50 cursor-pointer"
          : "opacity-60"
      )}
      onClick={resource.isAccessible ? onDownload : undefined}
    >
      <div
        className={cn(
          "shrink-0 w-8 h-8 rounded flex items-center justify-center",
          resource.isAccessible
            ? isLink
              ? "bg-blue-100 dark:bg-blue-900/30"
              : "bg-primary/10"
            : "bg-muted"
        )}
      >
        {resource.isAccessible ? (
          <Icon className={cn("h-4 w-4", isLink ? "text-blue-600 dark:text-blue-400" : "text-primary")} />
        ) : (
          <Lock className="h-4 w-4 text-muted-foreground" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p
          className={cn(
            "text-sm font-medium truncate",
            !resource.isAccessible && "text-muted-foreground"
          )}
          title={title}
        >
          {title}
        </p>
        {description && (
          <p className="text-xs text-muted-foreground line-clamp-1" title={description}>
            {description}
          </p>
        )}
        <p className="text-[10px] text-muted-foreground mt-0.5">
          {isLink ? getLinkDomain(resource.url || "") : formatFileSize(resource.fileSize)}
        </p>
      </div>
      {resource.isAccessible && (
        <Button
          variant="ghost"
          size="icon"
          className="shrink-0 h-8 w-8"
          disabled={isDownloading}
          onClick={(e) => {
            e.stopPropagation();
            onDownload();
          }}
        >
          {isDownloading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : isLink ? (
            <ExternalLink className="h-4 w-4" />
          ) : (
            <Download className="h-4 w-4" />
          )}
        </Button>
      )}
    </div>
  );
}
