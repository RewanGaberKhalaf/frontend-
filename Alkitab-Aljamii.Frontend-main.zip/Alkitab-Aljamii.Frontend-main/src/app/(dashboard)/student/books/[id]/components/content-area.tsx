"use client";

import { useTranslations } from "next-intl";
import { AlertCircle, BookOpen, Loader2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ChapterLockedOverlay } from "@/components/quiz";
import { SecureBookViewer } from "@/components/shared/secure-book-viewer";
import { ReadingTimeDisplay } from "@/components/reading-time";
import type { StudentChapterMetadata, Annotation, CreateAnnotationDto } from "@/types";
import type { ChapterQuizStatus, ChapterProgress } from "@/lib/api/quiz";

interface ContentAreaProps {
  bookId: string;
  activeChapter: StudentChapterMetadata | undefined;
  isCurrentChapterLocked: boolean;
  isLoadingContent: boolean;
  contentError: string | null;
  watermarkText: string;
  isArabic: boolean;
  annotations: Annotation[];
  currentPage: number;
  targetPage: number | undefined;
  focusedAnnotationId: string | null;
  currentUserId: string | undefined;
  isReadingTimeTracking: boolean;
  activeChapterQuizStatus: ChapterQuizStatus | null;
  previousChapterQuizStatus: ChapterQuizStatus | null;
  activeChapterIndex: number;
  chapters: StudentChapterMetadata[];
  chapterProgress: Record<string, ChapterProgress>;
  onAnnotationCreate: (data: CreateAnnotationDto) => Promise<void>;
  onAnnotationClick: (annotation: Annotation) => void;
  onPageChange: (page: number) => void;
  onPageContentChange?: (content: string, chapterId: string | undefined) => void;
  onGoToPrevious: () => void;
}

export function ContentArea({
  bookId,
  activeChapter,
  isCurrentChapterLocked,
  isLoadingContent,
  contentError,
  watermarkText,
  isArabic,
  annotations,
  currentPage,
  targetPage,
  focusedAnnotationId,
  currentUserId,
  isReadingTimeTracking,
  activeChapterQuizStatus,
  previousChapterQuizStatus,
  activeChapterIndex,
  chapters,
  chapterProgress,
  onAnnotationCreate,
  onAnnotationClick,
  onPageChange,
  onPageContentChange,
  onGoToPrevious,
}: ContentAreaProps) {
  const t = useTranslations();

  if (isCurrentChapterLocked) {
    // Check if previous chapter is unlocked using progress data (more up-to-date)
    const prevChapter = activeChapterIndex > 0 ? chapters[activeChapterIndex - 1] : null;
    const isPrevChapterUnlocked = prevChapter
      ? (chapterProgress[prevChapter.id]?.isUnlocked ?? prevChapter.isUnlocked)
      : false;

    // Show the PREVIOUS chapter's quiz status since that's what needs to be passed
    // to unlock this chapter (unless this is chapter 1, use current chapter's status)
    const quizStatusToShow = activeChapterIndex > 0 ? previousChapterQuizStatus : activeChapterQuizStatus;

    return (
      <ChapterLockedOverlay
        chapterTitle={activeChapter?.title || ""}
        quizStatus={quizStatusToShow}
        onGoToPrevious={onGoToPrevious}
        canGoToPrevious={activeChapterIndex > 0 && isPrevChapterUnlocked}
      />
    );
  }

  if (isLoadingContent) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">{t("common.loading")}</p>
        </div>
      </div>
    );
  }

  if (contentError) {
    return (
      <div className="h-full flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t("common.error")}</AlertTitle>
          <AlertDescription>{contentError}</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (activeChapter) {
    return (
      <SecureBookViewer
        mode="server"
        bookId={bookId}
        chapterId={activeChapter.id}
        title={isArabic && activeChapter?.titleAr ? activeChapter.titleAr : activeChapter?.title}
        watermarkText={watermarkText}
        showWatermark
        enableProtection
        blockDevTools
        detectDevTools
        showPageNumbers
        enableAnnotations
        annotations={annotations}
        onAnnotationCreate={onAnnotationCreate}
        onAnnotationClick={onAnnotationClick}
        currentPageForAnnotation={currentPage}
        targetPage={targetPage}
        onPageChange={onPageChange}
        onPageContentChange={onPageContentChange}
        focusedAnnotationId={focusedAnnotationId}
        currentUserId={currentUserId}
        readingTimeSlot={isReadingTimeTracking && <ReadingTimeDisplay variant="compact" />}
      />
    );
  }

  return (
    <div className="h-full flex items-center justify-center text-muted-foreground">
      <div className="text-center">
        <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>{t("books.selectChapter")}</p>
      </div>
    </div>
  );
}
