"use client";

import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { useTranslations, useLocale } from "next-intl";
import { toast } from "sonner";
import { AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { booksApi } from "@/lib/api/books";
import { quizApi, type ChapterProgress, type ChapterQuizStatus } from "@/lib/api/quiz";
import { annotationsApi } from "@/lib/api/annotations";
import { ROUTES } from "@/lib/constants/routes";
import { AnnotationSidebar } from "@/components/annotations";
import { IdlePromptDialog } from "@/components/reading-time";
import { useAuthStore, useAnnotationStore, useChatStore } from "@/stores";
import { useReadingTime } from "@/hooks/use-reading-time";
import type { Book, StudentChapterMetadata, Annotation, CreateAnnotationDto } from "@/types";
import { ReaderHeader, ChapterSidebar, ContentArea } from "./components";

export default function StudentBookReaderPage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const t = useTranslations();
  const locale = useLocale();
  const user = useAuthStore((state) => state.user);
  const bookId = params["id"] as string;
  const annotationIdFromUrl = searchParams.get("annotation");
  const isArabic = locale === "ar";

  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<StudentChapterMetadata[]>([]);
  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [contentError, setContentError] = useState<string | null>(null);
  const [chapterProgress, setChapterProgress] = useState<Record<string, ChapterProgress>>({});
  const [activeChapterQuizStatus, setActiveChapterQuizStatus] = useState<ChapterQuizStatus | null>(
    null
  );
  const [previousChapterQuizStatus, setPreviousChapterQuizStatus] = useState<ChapterQuizStatus | null>(
    null
  );
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [targetPage, setTargetPage] = useState<number | undefined>(undefined);
  const [focusedAnnotationId, setFocusedAnnotationId] = useState<string | null>(null);
  const [showChapterList, setShowChapterList] = useState(false);

  const setContext = useAnnotationStore((s) => s.setContext);
  const setSidebarOpen = useAnnotationStore((s) => s.setSidebarOpen);
  const isSidebarOpen = useAnnotationStore((s) => s.isSidebarOpen);
  const fetchStoreAnnotations = useAnnotationStore((s) => s.fetchAnnotations);
  const selectAnnotation = useAnnotationStore((s) => s.selectAnnotation);
  const setChatContext = useChatStore((s) => s.setContext);

  const activeChapter = chapters[activeChapterIndex];
  // Use progress data for unlock status when available (more up-to-date after quiz completion)
  const isCurrentChapterUnlocked = activeChapter
    ? (chapterProgress[activeChapter.id]?.isUnlocked ?? activeChapter.isUnlocked)
    : false;
  const isCurrentChapterLocked = !isCurrentChapterUnlocked;

  const readingTime = useReadingTime({
    chapterId: activeChapter?.id || "",
    bookId,
    enabled: !!activeChapter?.id && !isCurrentChapterLocked,
  });

  const unlockedCount = useMemo(
    () =>
      chapters.filter(
        (ch) => chapterProgress[ch.id]?.isUnlocked ?? ch.isUnlocked
      ).length,
    [chapters, chapterProgress]
  );

  const watermarkText = useMemo(() => {
    if (user?.email) return user.email;
    if (user?.firstName) return `${user.firstName} ${user.lastName || ""}`.trim();
    return t("content.protectedContent");
  }, [user, t]);

  const chapterInfos = useMemo(
    () => chapters.map((ch) => ({ id: ch.id, title: ch.title })),
    [chapters]
  );

  useEffect(() => {
    if (bookId) setContext(bookId);
  }, [bookId, setContext]);

  useEffect(() => {
    const fetchAnnotations = async () => {
      if (!activeChapter || !isCurrentChapterUnlocked) {
        setAnnotations([]);
        return;
      }
      try {
        const data = await annotationsApi.getChapterAnnotations(activeChapter.id, { limit: 100 });
        setAnnotations(data.items);
      } catch {
        // Silent fail
      }
    };
    fetchAnnotations();
  }, [activeChapter, isCurrentChapterUnlocked]);

  const handleAnnotationCreate = useCallback(
    async (data: CreateAnnotationDto) => {
      try {
        const annotation = await annotationsApi.create({
          ...data,
          bookId,
          chapterId: activeChapter?.id,
          pageNumber: currentPage,
        });
        setAnnotations((prev) => [annotation, ...prev]);
        fetchStoreAnnotations();
        toast.success(t("annotations.created"));
      } catch {
        toast.error(t("annotations.createError"));
      }
    },
    [bookId, activeChapter?.id, currentPage, fetchStoreAnnotations, t]
  );

  const targetPageRef = useRef(targetPage);
  targetPageRef.current = targetPage;
  const readingTimeRef = useRef(readingTime);
  readingTimeRef.current = readingTime;

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
    readingTimeRef.current.setCurrentPage(page);
    if (targetPageRef.current && page === targetPageRef.current) {
      setTargetPage(undefined);
    }
  }, []);

  // Update chat context when page content changes
  const handlePageContentChange = useCallback(
    (content: string, chapterId: string | undefined) => {
      setChatContext({
        bookId,
        chapterId,
        currentPage: currentPage,
        pageContent: content,
      });
    },
    [bookId, currentPage, setChatContext]
  );

  const handleAnnotationClick = useCallback(
    (annotation: Annotation) => {
      setSidebarOpen(true);
      selectAnnotation(annotation);
      if (annotation.chapterId && annotation.chapterId !== activeChapter?.id) {
        const chapterIndex = chapters.findIndex((ch) => ch.id === annotation.chapterId);
        if (chapterIndex !== -1) setActiveChapterIndex(chapterIndex);
      }
      if (annotation.pageNumber) setTargetPage(annotation.pageNumber);
      setTimeout(() => {
        setFocusedAnnotationId(annotation.id);
        setTimeout(() => setFocusedAnnotationId(null), 4000);
      }, 500);
    },
    [activeChapter?.id, chapters, setSidebarOpen, selectAnnotation]
  );

  useEffect(() => {
    const loadBook = async () => {
      try {
        setIsLoading(true);
        const [bookData, chaptersData] = await Promise.all([
          booksApi.getById(bookId),
          booksApi.getStudentChapters(bookId),
        ]);

        if (bookData.status !== "published") {
          toast.error(t("books.notAvailable"));
          router.push(ROUTES.STUDENT.BOOKS);
          return;
        }

        setBook(bookData);
        setChapters(chaptersData);

        try {
          await quizApi.initializeBookProgress(bookId);
          const progressData = await quizApi.getBookProgress(bookId);
          const progressMap: Record<string, ChapterProgress> = {};
          progressData.chapters.forEach((cp) => {
            progressMap[cp.chapterId] = cp;
          });
          setChapterProgress(progressMap);
        } catch {
          // Progress might fail if no quiz requirements
        }
      } catch {
        toast.error(t("common.error"));
        router.push(ROUTES.STUDENT.BOOKS);
      } finally {
        setIsLoading(false);
      }
    };
    loadBook();
  }, [bookId, router, t]);

  // Refresh progress when page becomes visible (e.g., returning from quiz)
  useEffect(() => {
    const refreshProgress = async () => {
      try {
        const progressData = await quizApi.getBookProgress(bookId);
        const progressMap: Record<string, ChapterProgress> = {};
        progressData.chapters.forEach((cp) => {
          progressMap[cp.chapterId] = cp;
        });
        setChapterProgress(progressMap);
      } catch {
        // Silent fail
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        refreshProgress();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [bookId]);

  const loadSecureContent = useCallback(async () => {
    if (!activeChapter || !isCurrentChapterUnlocked) return;
    try {
      setIsLoadingContent(true);
      setContentError(null);
      await booksApi.getSecureChapterContent(bookId, activeChapter.id);
    } catch (error) {
      setContentError(error instanceof Error ? error.message : t("common.error"));
    } finally {
      setIsLoadingContent(false);
    }
  }, [activeChapter, bookId, t, isCurrentChapterUnlocked]);

  useEffect(() => {
    loadSecureContent();
  }, [loadSecureContent]);

  useEffect(() => {
    const fetchQuizStatus = async () => {
      if (!activeChapter) {
        setActiveChapterQuizStatus(null);
        setPreviousChapterQuizStatus(null);
        return;
      }
      try {
        const status = await quizApi.getChapterQuizStatus(activeChapter.id);
        setActiveChapterQuizStatus(status);
      } catch {
        setActiveChapterQuizStatus(null);
      }

      // Also fetch previous chapter's quiz status (needed when current is locked)
      const prevChapter = activeChapterIndex > 0 ? chapters[activeChapterIndex - 1] : null;
      if (prevChapter) {
        try {
          const prevStatus = await quizApi.getChapterQuizStatus(prevChapter.id);
          setPreviousChapterQuizStatus(prevStatus);
        } catch {
          setPreviousChapterQuizStatus(null);
        }
      } else {
        setPreviousChapterQuizStatus(null);
      }
    };
    fetchQuizStatus();
  }, [activeChapter, activeChapterIndex, chapters]);

  // Handle annotation deep link from URL
  useEffect(() => {
    if (!annotationIdFromUrl || chapters.length === 0 || isLoading) return;

    const handleAnnotationDeepLink = async () => {
      try {
        const annotation = await annotationsApi.getById(annotationIdFromUrl);
        if (!annotation) return;

        // Find the chapter index
        const chapterIndex = chapters.findIndex((ch) => ch.id === annotation.chapterId);
        if (chapterIndex !== -1) {
          setActiveChapterIndex(chapterIndex);
        }

        // Open sidebar and focus the annotation
        setSidebarOpen(true);
        selectAnnotation(annotation);

        if (annotation.pageNumber) {
          setTargetPage(annotation.pageNumber);
        }

        // Focus the annotation after a delay to let the page render
        setTimeout(() => {
          setFocusedAnnotationId(annotation.id);
          setTimeout(() => setFocusedAnnotationId(null), 4000);
        }, 1000);
      } catch {
        // Annotation might not exist or user doesn't have access
        console.error("Failed to load annotation from URL");
      }
    };

    handleAnnotationDeepLink();
  }, [annotationIdFromUrl, chapters, isLoading, setSidebarOpen, selectAnnotation]);

  const goToPreviousChapter = () => {
    if (activeChapterIndex > 0) setActiveChapterIndex((prev) => prev - 1);
  };

  const goToNextChapter = () => {
    if (activeChapterIndex < chapters.length - 1) setActiveChapterIndex((prev) => prev + 1);
  };

  const handleChapterSelect = (index: number) => {
    setActiveChapterIndex(index);
    setShowChapterList(false);
  };

  if (isLoading) {
    return (
      <div className="h-full flex">
        <div className="w-72 border-r p-4 space-y-4">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
        </div>
        <div className="flex-1 p-4">
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="flex items-center justify-center h-full">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t("common.error")}</AlertTitle>
          <AlertDescription>{t("books.notFound")}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <ReaderHeader
        book={book}
        isArabic={isArabic}
        activeChapterIndex={activeChapterIndex}
        chaptersLength={chapters.length}
        annotationsCount={annotations.length}
        isSidebarOpen={isSidebarOpen}
        showChapterList={showChapterList}
        onToggleChapterList={() => setShowChapterList(!showChapterList)}
        onToggleSidebar={() => setSidebarOpen(!isSidebarOpen)}
        onPreviousChapter={goToPreviousChapter}
        onNextChapter={goToNextChapter}
      />

      <div className="flex-1 flex min-h-0 relative">
        {showChapterList && (
          <div
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
            onClick={() => setShowChapterList(false)}
          />
        )}

        <ChapterSidebar
          bookId={bookId}
          chapters={chapters}
          activeChapterIndex={activeChapterIndex}
          chapterProgress={chapterProgress}
          activeChapterQuizStatus={activeChapterQuizStatus}
          activeChapter={activeChapter}
          unlockedCount={unlockedCount}
          showChapterList={showChapterList}
          onChapterSelect={handleChapterSelect}
          onTakeQuiz={() =>
            activeChapterQuizStatus?.quizId &&
            router.push(ROUTES.STUDENT.QUIZ(activeChapterQuizStatus.quizId))
          }
        />

        <div className="flex-1 overflow-hidden bg-muted/30">
          <ContentArea
            bookId={bookId}
            activeChapter={activeChapter}
            isCurrentChapterLocked={isCurrentChapterLocked}
            isLoadingContent={isLoadingContent}
            contentError={contentError}
            watermarkText={watermarkText}
            isArabic={isArabic}
            annotations={annotations}
            currentPage={currentPage}
            targetPage={targetPage}
            focusedAnnotationId={focusedAnnotationId}
            currentUserId={user?.id}
            isReadingTimeTracking={readingTime.isTracking}
            activeChapterQuizStatus={activeChapterQuizStatus}
            previousChapterQuizStatus={previousChapterQuizStatus}
            activeChapterIndex={activeChapterIndex}
            chapters={chapters}
            chapterProgress={chapterProgress}
            onAnnotationCreate={handleAnnotationCreate}
            onAnnotationClick={handleAnnotationClick}
            onPageChange={handlePageChange}
            onPageContentChange={handlePageContentChange}
            onGoToPrevious={goToPreviousChapter}
          />
        </div>

        <AnnotationSidebar chapters={chapterInfos} onAnnotationClick={handleAnnotationClick} />
      </div>

      <IdlePromptDialog
        isIdle={readingTime.isIdle}
        idleDuration={readingTime.formattedIdleDuration}
        onContinueReading={readingTime.resume}
      />
    </div>
  );
}
