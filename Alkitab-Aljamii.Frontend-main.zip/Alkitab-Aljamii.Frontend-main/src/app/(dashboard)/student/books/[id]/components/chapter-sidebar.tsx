"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Lock, Unlock, CheckCircle2, BookOpen, FileText } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { StudentChapterMetadata } from "@/types";
import type { ChapterProgress, ChapterQuizStatus } from "@/lib/api/quiz";
import { QuizCard } from "./quiz-card";
import { ResourcesPanel } from "./resources-panel";

type SidebarTab = "chapters" | "resources";

interface ChapterSidebarProps {
  bookId: string;
  chapters: StudentChapterMetadata[];
  activeChapterIndex: number;
  chapterProgress: Record<string, ChapterProgress>;
  activeChapterQuizStatus: ChapterQuizStatus | null;
  activeChapter: StudentChapterMetadata | undefined;
  unlockedCount: number;
  showChapterList: boolean;
  onChapterSelect: (index: number) => void;
  onTakeQuiz: () => void;
}

export function ChapterSidebar({
  bookId,
  chapters,
  activeChapterIndex,
  chapterProgress,
  activeChapterQuizStatus,
  activeChapter,
  unlockedCount,
  showChapterList,
  onChapterSelect,
  onTakeQuiz,
}: ChapterSidebarProps) {
  const t = useTranslations();
  const [activeTab, setActiveTab] = useState<SidebarTab>("chapters");

  return (
    <div
      className={cn(
        "w-72 max-w-72 shrink-0 border-r flex flex-col overflow-hidden bg-background",
        "fixed md:relative inset-y-0 start-0 z-50 md:z-auto",
        "transform transition-transform duration-200 ease-in-out md:transform-none",
        showChapterList ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        "top-[calc(3.5rem+1px)] md:top-0 h-[calc(100%-3.5rem-1px)] md:h-auto"
      )}
    >
      {/* Quiz Card - if chapter has quiz */}
      {activeChapterQuizStatus?.hasQuiz && activeChapter && (chapterProgress[activeChapter.id]?.isUnlocked ?? activeChapter.isUnlocked) && (
        <div className="shrink-0 p-3 border-b">
          <QuizCard quizStatus={activeChapterQuizStatus} onTakeQuiz={onTakeQuiz} />
        </div>
      )}

      {/* Tab Navigation */}
      <div className="flex border-b shrink-0">
        <button
          className={cn(
            "flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-medium transition-colors",
            activeTab === "chapters"
              ? "text-primary border-b-2 border-primary bg-primary/5"
              : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
          )}
          onClick={() => setActiveTab("chapters")}
        >
          <BookOpen className="h-4 w-4" />
          <span>{t("books.chapters")}</span>
          <Badge variant="secondary" className="h-5 text-[10px] px-1.5 ms-1">
            {unlockedCount}/{chapters.length}
          </Badge>
        </button>
        <button
          className={cn(
            "flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-medium transition-colors",
            activeTab === "resources"
              ? "text-primary border-b-2 border-primary bg-primary/5"
              : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
          )}
          onClick={() => setActiveTab("resources")}
        >
          <FileText className="h-4 w-4" />
          <span>{t("resources.title")}</span>
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === "chapters" ? (
        <ScrollArea className="flex-1 min-w-0 w-full" viewportClassName="!overflow-x-hidden">
          <div className="py-1">
            {chapters.map((chapter, index) => {
              const progress = chapterProgress[chapter.id];
              const isActive = activeChapterIndex === index;
              // Use progress data for unlock status when available (more up-to-date after quiz completion)
              const isUnlocked = progress?.isUnlocked ?? chapter.isUnlocked;
              const hasPassed = progress?.passedAt != null;
              const hasQuiz = progress?.quizRequired ?? false;

              return (
                <div
                  key={chapter.id}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2.5 cursor-pointer transition-colors min-w-0",
                    isActive ? "bg-primary/10 border-s-2 border-primary" : "hover:bg-muted/50"
                  )}
                  onClick={() => onChapterSelect(index)}
                >
                  {/* Status icon */}
                  <div className="shrink-0">
                    {hasPassed ? (
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                    ) : isUnlocked ? (
                      <Unlock className="h-4 w-4 text-primary" />
                    ) : (
                      <Lock className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>

                  {/* Title - truncate with ellipsis */}
                  <span
                    className={cn(
                      "flex-1 min-w-0 text-sm truncate",
                      isActive && "font-medium",
                      !isUnlocked && "text-muted-foreground"
                    )}
                    title={`${index + 1}. ${chapter.title}`}
                  >
                    {index + 1}. {chapter.title}
                  </span>

                  {/* Badges */}
                  {hasQuiz && !hasPassed && isUnlocked && (
                    <Badge variant="secondary" className="shrink-0 h-5 text-[10px] px-1.5">
                      {t("quizzes.quiz")}
                    </Badge>
                  )}
                  {hasPassed && progress?.bestScore != null && (
                    <Badge
                      variant="outline"
                      className="shrink-0 h-5 text-[10px] px-1.5 text-green-600 border-green-600"
                    >
                      {progress.bestScore}%
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
        </ScrollArea>
      ) : (
        <div className="flex-1 overflow-hidden">
          <ResourcesPanel bookId={bookId} activeChapterId={activeChapter?.id} />
        </div>
      )}
    </div>
  );
}
