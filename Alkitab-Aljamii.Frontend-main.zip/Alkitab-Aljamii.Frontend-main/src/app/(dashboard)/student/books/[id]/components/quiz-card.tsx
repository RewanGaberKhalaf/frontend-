"use client";

import { useState, useEffect } from "react";
import { useTranslations } from "next-intl";
import { CheckCircle2, Play, RotateCcw, Target, Trophy, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { ChapterQuizStatus } from "@/lib/api/quiz";

interface QuizCardProps {
  quizStatus: ChapterQuizStatus;
  onTakeQuiz: () => void;
}

function formatTimeRemaining(ms: number): string {
  if (ms <= 0) return "0:00";
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

export function QuizCard({ quizStatus, onTakeQuiz }: QuizCardProps) {
  const t = useTranslations();

  const {
    hasPassed,
    bestScore,
    attemptCount,
    passingThreshold,
    canAttempt,
    isCooldownActive,
    cooldownEndsAt,
  } = quizStatus;

  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);

  useEffect(() => {
    if (!isCooldownActive || !cooldownEndsAt) {
      setTimeRemaining(null);
      return;
    }

    const updateTime = () => {
      const remaining = new Date(cooldownEndsAt).getTime() - Date.now();
      setTimeRemaining(remaining > 0 ? remaining : 0);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [isCooldownActive, cooldownEndsAt]);

  // Note: unlimited retries allowed - no max attempts check
  const canTakeQuiz = canAttempt;
  const isInCooldown = isCooldownActive && timeRemaining !== null && timeRemaining > 0;

  return (
    <div
      className={cn(
        "rounded-lg p-3 border",
        hasPassed ? "bg-green-500/10 border-green-500/30" : "bg-primary/5 border-primary/20"
      )}
    >
      {/* Header */}
      <div className="flex items-center gap-2 mb-2">
        {hasPassed ? (
          <Trophy className="h-4 w-4 text-green-500" />
        ) : (
          <Target className="h-4 w-4 text-primary" />
        )}
        <span className="font-medium text-sm">{t("chapterQuiz.title")}</span>
        {hasPassed && <CheckCircle2 className="h-4 w-4 text-green-500 ms-auto" />}
      </div>

      {/* Stats */}
      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
        <span>
          {passingThreshold}% {t("quizzes.toPass")}
        </span>
        {bestScore != null && (
          <>
            <span className="text-muted-foreground/50">|</span>
            <span className={bestScore >= passingThreshold ? "text-green-500" : "text-amber-500"}>
              {t("chapterProgress.bestScore")}: {bestScore}%
            </span>
          </>
        )}
        {attemptCount > 0 && (
          <>
            <span className="text-muted-foreground/50">|</span>
            <span>{attemptCount} {t("quizzes.attempts")}</span>
          </>
        )}
      </div>

      {/* Progress bar */}
      {bestScore != null && !hasPassed && (
        <div className="h-1 bg-muted rounded-full overflow-hidden mb-3">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-green-500 transition-all"
            style={{ width: `${Math.min((bestScore / passingThreshold) * 100, 100)}%` }}
          />
        </div>
      )}

      {/* Cooldown indicator */}
      {isInCooldown && (
        <div className="flex items-center justify-center gap-2 text-sm text-amber-600 bg-amber-500/10 rounded-md p-2 mb-3">
          <Clock className="h-4 w-4" />
          <span>
            {t("quizzes.cooldownActive")} {formatTimeRemaining(timeRemaining)}
          </span>
        </div>
      )}

      {/* Button */}
      <Button
        size="sm"
        className={cn("w-full", hasPassed ? "bg-green-600 hover:bg-green-700" : "")}
        onClick={onTakeQuiz}
        disabled={(!canTakeQuiz && !hasPassed) || isInCooldown}
      >
        {isInCooldown ? (
          <>
            <Clock className="h-3.5 w-3.5 me-1.5" />
            {t("quizzes.cooldownActive")}
          </>
        ) : canTakeQuiz ? (
          <>
            {attemptCount > 0 ? (
              <>
                <RotateCcw className="h-3.5 w-3.5 me-1.5" />
                {t("chapterProgress.retakeQuiz")}
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5 me-1.5" />
                {t("chapterProgress.takeQuiz")}
              </>
            )}
          </>
        ) : hasPassed ? (
          t("chapterQuiz.viewQuiz")
        ) : (
          t("quizTaking.cannotStart")
        )}
      </Button>
    </div>
  );
}
