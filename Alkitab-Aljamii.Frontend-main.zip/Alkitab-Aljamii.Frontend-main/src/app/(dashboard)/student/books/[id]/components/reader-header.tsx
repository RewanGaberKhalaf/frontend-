"use client";

import Link from "next/link";
import { ArrowLeft, ChevronLeft, ChevronRight, BookOpen, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ROUTES } from "@/lib/constants/routes";
import type { Book, Annotation } from "@/types";

interface ReaderHeaderProps {
  book: Book;
  isArabic: boolean;
  activeChapterIndex: number;
  chaptersLength: number;
  annotationsCount: number;
  isSidebarOpen: boolean;
  showChapterList: boolean;
  onToggleChapterList: () => void;
  onToggleSidebar: () => void;
  onPreviousChapter: () => void;
  onNextChapter: () => void;
}

export function ReaderHeader({
  book,
  isArabic,
  activeChapterIndex,
  chaptersLength,
  annotationsCount,
  isSidebarOpen,
  showChapterList,
  onToggleChapterList,
  onToggleSidebar,
  onPreviousChapter,
  onNextChapter,
}: ReaderHeaderProps) {
  return (
    <div className="shrink-0 border-b bg-background px-2 sm:px-4 py-2 sm:py-3">
      <div className="flex items-center justify-between gap-2 sm:gap-4">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="shrink-0 h-8 w-8 sm:h-9 sm:w-9"
          >
            <Link href={ROUTES.STUDENT.BOOKS}>
              <ArrowLeft className="h-4 w-4 sm:h-5 sm:w-5" />
            </Link>
          </Button>
          {/* Chapter list toggle - mobile only */}
          <Button
            variant="outline"
            size="icon"
            className="shrink-0 h-8 w-8 md:hidden"
            onClick={onToggleChapterList}
          >
            <BookOpen className="h-4 w-4" />
          </Button>
          <div className="min-w-0 hidden sm:block">
            <h1 className="font-semibold truncate text-sm sm:text-base">
              {isArabic && book.titleAr ? book.titleAr : book.title}
            </h1>
            <p className="text-xs text-muted-foreground truncate">{book.authorName}</p>
          </div>
        </div>

        {/* Chapter navigation */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={onPreviousChapter}
            disabled={activeChapterIndex === 0}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-xs sm:text-sm text-muted-foreground min-w-[40px] sm:min-w-[50px] text-center">
            {activeChapterIndex + 1} / {chaptersLength}
          </span>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={onNextChapter}
            disabled={activeChapterIndex === chaptersLength - 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>

          {/* Annotation sidebar toggle */}
          <Button
            variant={isSidebarOpen ? "secondary" : "outline"}
            size="icon"
            className="h-8 w-8 relative"
            onClick={onToggleSidebar}
          >
            <MessageSquare className="h-4 w-4" />
            {annotationsCount > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] text-primary-foreground flex items-center justify-center">
                {annotationsCount > 99 ? "99+" : annotationsCount}
              </span>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
