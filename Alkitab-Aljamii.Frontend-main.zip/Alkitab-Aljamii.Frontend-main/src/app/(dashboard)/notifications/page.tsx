'use client';

import { useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Bell, Check, Trash2, RefreshCw, Filter } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader, EmptyState } from '@/components/shared';
import { NotificationItem } from '@/components/notifications';
import { useNotificationStore } from '@/stores';
import type { Notification, NotificationType } from '@/lib/api/notifications';
import { useState } from 'react';

const NOTIFICATION_TYPES: NotificationType[] = [
  'annotation_digest',
  'new_annotation',
  'comment_reply',
  'announcement',
  'comment_response',
  'course_update',
  'batch_import_complete',
  'batch_import_failed',
  'system_alert',
];

export default function NotificationsPage() {
  const t = useTranslations('notifications');
  const tCommon = useTranslations('common');
  const router = useRouter();

  const {
    notifications,
    unreadCount,
    isLoading,
    hasNextPage,
    isLoadingMore,
    total,
    fetchNotifications,
    fetchMoreNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotifications,
  } = useNotificationStore();

  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [readFilter, setReadFilter] = useState<string>('all');

  // Fetch notifications on mount and when filters change
  useEffect(() => {
    const params: Record<string, unknown> = {};
    if (typeFilter !== 'all') params['type'] = typeFilter;
    if (readFilter !== 'all') params['isRead'] = readFilter === 'read';
    fetchNotifications(params);
  }, [fetchNotifications, typeFilter, readFilter]);

  const handleNotificationClick = useCallback(
    (notification: Notification) => {
      if (!notification.isRead) {
        markAsRead([notification.id]);
      }
      if (notification.deepLink) {
        router.push(notification.deepLink);
      }
    },
    [markAsRead, router]
  );

  const handleSelectAll = useCallback(() => {
    if (selectedIds.size === notifications.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(notifications.map((n) => n.id)));
    }
  }, [notifications, selectedIds.size]);

  const handleSelect = useCallback((id: string, checked: boolean) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) {
        next.add(id);
      } else {
        next.delete(id);
      }
      return next;
    });
  }, []);

  const handleMarkSelectedAsRead = useCallback(async () => {
    if (selectedIds.size === 0) return;
    try {
      await markAsRead(Array.from(selectedIds));
      setSelectedIds(new Set());
      toast.success(t('markAllRead'));
    } catch {
      toast.error(t('preferences.saveError'));
    }
  }, [selectedIds, markAsRead, t]);

  const handleDeleteSelected = useCallback(async () => {
    if (selectedIds.size === 0) return;
    try {
      await deleteNotifications(Array.from(selectedIds));
      setSelectedIds(new Set());
      toast.success(tCommon('success'));
    } catch {
      toast.error(t('preferences.saveError'));
    }
  }, [selectedIds, deleteNotifications, t, tCommon]);

  const handleMarkAllAsRead = useCallback(async () => {
    try {
      await markAllAsRead();
      toast.success(t('markAllRead'));
    } catch {
      toast.error(t('preferences.saveError'));
    }
  }, [markAllAsRead, t]);

  const handleRefresh = useCallback(() => {
    const params: Record<string, unknown> = {};
    if (typeFilter !== 'all') params['type'] = typeFilter;
    if (readFilter !== 'all') params['isRead'] = readFilter === 'read';
    fetchNotifications(params);
  }, [fetchNotifications, typeFilter, readFilter]);

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Bell}
        title={t('title')}
        description={t('emptyDescription')}
        badge={total > 0 && <Badge variant="secondary">{total}</Badge>}
        action={
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Button variant="outline" size="sm" onClick={handleMarkAllAsRead}>
                <Check className="me-2 h-4 w-4" />
                {t('markAllRead')}
              </Button>
            )}
            <Button variant="outline" size="icon" onClick={handleRefresh} disabled={isLoading}>
              <RefreshCw className={isLoading ? 'animate-spin h-4 w-4' : 'h-4 w-4'} />
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={t('types.announcement')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{tCommon('all')}</SelectItem>
            {NOTIFICATION_TYPES.map((type) => (
              <SelectItem key={type} value={type}>
                {t(`types.${type}`)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={readFilter} onValueChange={setReadFilter}>
          <SelectTrigger className="w-[150px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{tCommon('all')}</SelectItem>
            <SelectItem value="unread">{t('unread')}</SelectItem>
            <SelectItem value="read">{t('preferences.inAppEnabled')}</SelectItem>
          </SelectContent>
        </Select>

        {selectedIds.size > 0 && (
          <div className="flex items-center gap-2 ms-auto">
            <span className="text-sm text-muted-foreground">
              {selectedIds.size} {tCommon('selected')}
            </span>
            <Button variant="outline" size="sm" onClick={handleMarkSelectedAsRead}>
              <Check className="me-2 h-4 w-4" />
              {t('markAllRead')}
            </Button>
            <Button variant="outline" size="sm" onClick={handleDeleteSelected}>
              <Trash2 className="me-2 h-4 w-4" />
              {tCommon('delete')}
            </Button>
          </div>
        )}
      </div>

      {/* Notification List */}
      {isLoading && notifications.length === 0 ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-start gap-3 p-4 border rounded-lg">
              <Skeleton className="h-10 w-10 rounded-full shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-1/4" />
              </div>
            </div>
          ))}
        </div>
      ) : notifications.length === 0 ? (
        <EmptyState
          title={t('empty')}
          description={t('emptyDescription')}
          icon={Bell}
        />
      ) : (
        <div className="space-y-2">
          {/* Select all checkbox */}
          <div className="flex items-center gap-3 px-3 py-2 border-b">
            <Checkbox
              checked={selectedIds.size === notifications.length && notifications.length > 0}
              onCheckedChange={handleSelectAll}
            />
            <span className="text-sm text-muted-foreground">
              {tCommon('all')}
            </span>
          </div>

          {notifications.map((notification) => (
            <div key={notification.id} className="flex items-start gap-3">
              <div className="pt-4 ps-3">
                <Checkbox
                  checked={selectedIds.has(notification.id)}
                  onCheckedChange={(checked) => handleSelect(notification.id, checked as boolean)}
                />
              </div>
              <div className="flex-1">
                <NotificationItem
                  notification={notification}
                  onClick={handleNotificationClick}
                  onMarkAsRead={(id) => markAsRead([id])}
                />
              </div>
            </div>
          ))}

          {/* Load more */}
          {hasNextPage && (
            <div className="pt-4 text-center">
              <Button
                variant="outline"
                onClick={fetchMoreNotifications}
                disabled={isLoadingMore}
              >
                {isLoadingMore ? t('loading') : t('loadMore')}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
