'use client';

import { MoreHorizontal, Pencil, Trash2, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TableCell, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import type { Question, Difficulty, QuestionType } from '@/lib/api/quiz';

interface QuestionTableRowProps {
  question: Question;
  t: (key: string) => string;
  onEdit: (question: Question) => void;
  onDelete: (question: Question) => void;
}

export function getDifficultyBadge(difficulty: Difficulty, t: (key: string) => string) {
  const variants: Record<Difficulty, { variant: 'default' | 'secondary' | 'destructive'; label: string }> = {
    easy: { variant: 'default', label: t('questions.easy') },
    medium: { variant: 'secondary', label: t('questions.medium') },
    hard: { variant: 'destructive', label: t('questions.hard') },
  };
  const { variant, label } = variants[difficulty];
  return <Badge variant={variant}>{label}</Badge>;
}

export function getTypeBadge(type: QuestionType, t: (key: string) => string) {
  return (
    <Badge variant="outline">
      {type === 'multiple_choice' ? t('questions.multipleChoice') : t('questions.trueFalse')}
    </Badge>
  );
}

export function QuestionTableRow({ question, t, onEdit, onDelete }: QuestionTableRowProps) {
  return (
    <TableRow>
      <TableCell>
        <div className="space-y-1 min-w-0">
          <p className="font-medium line-clamp-2">{question.questionText}</p>
          {question.questionTextAr && (
            <p className="text-sm text-muted-foreground truncate" dir="rtl">
              {question.questionTextAr}
            </p>
          )}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="shrink-0">{question.options.length} {t('questions.optionsCount')}</span>
            {question.correctRate > 0 && (
              <>
                <span>•</span>
                <span className={cn(
                  'shrink-0',
                  question.correctRate >= 70 ? 'text-green-600' :
                  question.correctRate >= 40 ? 'text-yellow-600' : 'text-red-600'
                )}>
                  {question.correctRate.toFixed(0)}% {t('questions.correctRate')}
                </span>
              </>
            )}
          </div>
        </div>
      </TableCell>
      <TableCell>{getTypeBadge(question.questionType, t)}</TableCell>
      <TableCell>{getDifficultyBadge(question.difficulty, t)}</TableCell>
      <TableCell className="text-center font-medium">{question.points}</TableCell>
      <TableCell>
        {question.isActive ? (
          <CheckCircle2 className="h-5 w-5 text-green-600" />
        ) : (
          <XCircle className="h-5 w-5 text-muted-foreground" />
        )}
      </TableCell>
      <TableCell>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onEdit(question)}>
              <Pencil className="mr-2 h-4 w-4" />
              {t('common.edit')}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onDelete(question)}
              className="text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              {t('common.delete')}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </TableCell>
    </TableRow>
  );
}
