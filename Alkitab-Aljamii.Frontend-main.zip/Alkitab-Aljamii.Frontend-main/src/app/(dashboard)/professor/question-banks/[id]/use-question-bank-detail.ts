'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import {
  quizApi,
  type QuestionBank,
  type Question,
  type CreateQuestionData,
  type UpdateQuestionData,
  type Difficulty,
  type QuestionType,
} from '@/lib/api/quiz';

interface QuestionsMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export function useQuestionBankDetail(bankId: string) {
  const t = useTranslations();

  // Bank state
  const [bank, setBank] = useState<QuestionBank | null>(null);
  const [bankLoading, setBankLoading] = useState(true);
  const [bankError, setBankError] = useState<string | null>(null);

  // Questions state
  const [questions, setQuestions] = useState<Question[]>([]);
  const [questionsLoading, setQuestionsLoading] = useState(true);
  const [questionsMeta, setQuestionsMeta] = useState<QuestionsMeta | null>(null);

  // Filters
  const [searchValue, setSearchValue] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState<Difficulty | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<QuestionType | 'all'>('all');
  const [page, setPage] = useState(1);

  // Dialog states
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [editQuestion, setEditQuestion] = useState<Question | null>(null);
  const [deleteQuestion, setDeleteQuestion] = useState<Question | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Fetch bank details
  useEffect(() => {
    const fetchBank = async () => {
      setBankLoading(true);
      setBankError(null);
      try {
        const data = await quizApi.getQuestionBank(bankId);
        setBank(data);
      } catch (err) {
        console.error('Failed to fetch bank:', err);
        setBankError(t('questionBanks.fetchError'));
      } finally {
        setBankLoading(false);
      }
    };
    fetchBank();
  }, [bankId, t]);

  // Fetch questions
  const fetchQuestions = useCallback(async () => {
    setQuestionsLoading(true);
    try {
      const response = await quizApi.getQuestions(bankId, {
        page,
        limit: 10,
        search: searchValue || undefined,
        difficulty: difficultyFilter !== 'all' ? difficultyFilter : undefined,
        questionType: typeFilter !== 'all' ? typeFilter : undefined,
      });
      setQuestions(response.items);
      setQuestionsMeta(response.meta);
    } catch (err) {
      console.error('Failed to fetch questions:', err);
      toast.error(t('questions.fetchError'));
    } finally {
      setQuestionsLoading(false);
    }
  }, [bankId, page, searchValue, difficultyFilter, typeFilter, t]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchValue]);

  // Refresh bank data
  const refreshBank = useCallback(async () => {
    const updatedBank = await quizApi.getQuestionBank(bankId);
    setBank(updatedBank);
  }, [bankId]);

  // Handle create
  const handleCreate = async (data: CreateQuestionData | UpdateQuestionData) => {
    setIsSubmitting(true);
    try {
      await quizApi.createQuestion(bankId, data as CreateQuestionData);
      toast.success(t('questions.createSuccess'));
      setCreateDialogOpen(false);
      fetchQuestions();
      await refreshBank();
    } catch {
      toast.error(t('questions.createError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle update
  const handleUpdate = async (data: CreateQuestionData | UpdateQuestionData) => {
    if (!editQuestion) return;
    setIsSubmitting(true);
    try {
      await quizApi.updateQuestion(bankId, editQuestion.id, data);
      toast.success(t('questions.updateSuccess'));
      setEditQuestion(null);
      fetchQuestions();
      await refreshBank();
    } catch {
      toast.error(t('questions.updateError'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle delete
  const handleDelete = async () => {
    if (!deleteQuestion) return;
    setIsDeleting(true);
    try {
      await quizApi.deleteQuestion(bankId, deleteQuestion.id);
      toast.success(t('questions.deleteSuccess'));
      setDeleteQuestion(null);
      fetchQuestions();
      await refreshBank();
    } catch {
      toast.error(t('questions.deleteError'));
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle import success
  const handleImportSuccess = async () => {
    fetchQuestions();
    await refreshBank();
  };

  return {
    // Bank
    bank,
    bankLoading,
    bankError,
    // Questions
    questions,
    questionsLoading,
    questionsMeta,
    // Filters
    searchValue,
    setSearchValue,
    difficultyFilter,
    setDifficultyFilter,
    typeFilter,
    setTypeFilter,
    page,
    setPage,
    // Dialogs
    createDialogOpen,
    setCreateDialogOpen,
    importDialogOpen,
    setImportDialogOpen,
    editQuestion,
    setEditQuestion,
    deleteQuestion,
    setDeleteQuestion,
    isSubmitting,
    isDeleting,
    // Actions
    handleCreate,
    handleUpdate,
    handleDelete,
    handleImportSuccess,
  };
}
