'use client';

import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { Database, Plus, Search, ArrowLeft, Filter, Upload, ClipboardList } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { ConfirmDialog, PageHeader } from '@/components/shared';
import { QuestionFormWizard, QuestionImportDialog } from '@/components/quiz';
import type { Difficulty, QuestionType } from '@/lib/api/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { useQuestionBankDetail } from './use-question-bank-detail';
import { QuestionTableRow, getDifficultyBadge, getTypeBadge } from './question-table-row';
import { useState, useEffect } from 'react';
import { quizApi, type Quiz } from '@/lib/api/quiz';

export default function QuestionBankDetailPage() {
  const t = useTranslations();
  const router = useRouter();
  const params = useParams();
  const bankId = params['id'] as string;

  const {
    bank,
    bankLoading,
    bankError,
    questions,
    questionsLoading,
    questionsMeta,
    searchValue,
    setSearchValue,
    difficultyFilter,
    setDifficultyFilter,
    typeFilter,
    setTypeFilter,
    page,
    setPage,
    createDialogOpen,
    setCreateDialogOpen,
    importDialogOpen,
    setImportDialogOpen,
    editQuestion,
    setEditQuestion,
    deleteQuestion,
    setDeleteQuestion,
    isSubmitting,
    isDeleting,
    handleCreate,
    handleUpdate,
    handleDelete,
    handleImportSuccess,
  } = useQuestionBankDetail(bankId);

  // Quizzes state
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [quizzesLoading, setQuizzesLoading] = useState(false);

  // Fetch quizzes for this bank
  useEffect(() => {
    const fetchQuizzes = async () => {
      setQuizzesLoading(true);
      try {
        const data = await quizApi.getQuizzesByQuestionBank(bankId);
        setQuizzes(data);
      } catch (err) {
        console.error('Failed to fetch quizzes:', err);
      } finally {
        setQuizzesLoading(false);
      }
    };
    fetchQuizzes();
  }, [bankId]);

  if (bankLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (bankError || !bank) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <p className="text-destructive mb-4">{bankError || t('questionBanks.notFound')}</p>
        <Button onClick={() => router.push(ROUTES.PROFESSOR.QUESTION_BANKS)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t('common.back')}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 min-w-0 overflow-hidden">
      {/* Header */}
      <div className="flex items-start gap-3 sm:gap-4">
        <Button
          variant="ghost"
          size="icon"
          className="shrink-0 mt-1"
          onClick={() => router.push(ROUTES.PROFESSOR.QUESTION_BANKS)}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <PageHeader
            icon={Database}
            title={bank.name}
            description={bank.description || t('questionBanks.noDescription')}
            badge={
              <Badge variant={bank.isActive ? 'default' : 'secondary'}>
                {bank.isActive ? t('common.active') : t('common.inactive')}
              </Badge>
            }
            action={
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setImportDialogOpen(true)}>
                  <Upload className="mr-2 h-4 w-4" />
                  {t('questions.import.button')}
                </Button>
                <Button onClick={() => setCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  {t('questions.add')}
                </Button>
              </div>
            }
          />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground">{t('questionBanks.subject')}</p>
          <p className="text-lg font-medium">{bank.subjectName}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground">{t('questionBanks.totalQuestions')}</p>
          <p className="text-2xl font-bold">{bank.totalQuestions}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-green-200 dark:border-green-800">
          <p className="text-sm text-muted-foreground">{t('questions.easy')}</p>
          <p className="text-2xl font-bold text-green-600">{bank.easyCount}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-yellow-200 dark:border-yellow-800">
          <p className="text-sm text-muted-foreground">{t('questions.medium')}</p>
          <p className="text-2xl font-bold text-yellow-600">{bank.mediumCount}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-red-200 dark:border-red-800">
          <p className="text-sm text-muted-foreground">{t('questions.hard')}</p>
          <p className="text-2xl font-bold text-red-600">{bank.hardCount}</p>
        </div>
      </div>

      {/* Tabs for Questions and Quizzes */}
      <Tabs defaultValue="questions" className="space-y-6">
        <TabsList>
          <TabsTrigger value="questions" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            {t('questions.title')} ({bank.totalQuestions})
          </TabsTrigger>
          <TabsTrigger value="quizzes" className="flex items-center gap-2">
            <ClipboardList className="h-4 w-4" />
            {t('quizzes.title')} ({quizzes.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="questions" className="space-y-6">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-3 rounded-lg border bg-card p-3 sm:p-4">
        <div className="relative flex-1 min-w-0 sm:min-w-[200px] sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('questions.searchPlaceholder')}
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <Select
            value={difficultyFilter}
            onValueChange={(v) => {
              setDifficultyFilter(v as Difficulty | 'all');
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[140px] sm:w-[160px]">
              <Filter className="mr-2 h-4 w-4 hidden sm:block" />
              <SelectValue placeholder={t('questions.filterByDifficulty')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              <SelectItem value="easy">{t('questions.easy')}</SelectItem>
              <SelectItem value="medium">{t('questions.medium')}</SelectItem>
              <SelectItem value="hard">{t('questions.hard')}</SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={typeFilter}
            onValueChange={(v) => {
              setTypeFilter(v as QuestionType | 'all');
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[140px] sm:w-[180px]">
              <Filter className="mr-2 h-4 w-4 hidden sm:block" />
              <SelectValue placeholder={t('questions.filterByType')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              <SelectItem value="multiple_choice">{t('questions.multipleChoice')}</SelectItem>
              <SelectItem value="true_false">{t('questions.trueFalse')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Questions Table */}
      <div className="rounded-md border overflow-x-auto">
        <Table className="table-fixed">
          <TableHeader>
            <TableRow>
              <TableHead className="w-[40%] min-w-[250px]">{t('questions.question')}</TableHead>
              <TableHead className="w-[120px]">{t('questions.type')}</TableHead>
              <TableHead className="w-[100px]">{t('questions.difficulty')}</TableHead>
              <TableHead className="w-[70px] text-center">{t('questions.points')}</TableHead>
              <TableHead className="w-[70px]">{t('common.status')}</TableHead>
              <TableHead className="w-[60px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {questionsLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-5 w-full" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-8 mx-auto" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                </TableRow>
              ))
            ) : questions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  {searchValue || difficultyFilter !== 'all' || typeFilter !== 'all'
                    ? t('questions.noResults')
                    : t('questions.noQuestions')}
                </TableCell>
              </TableRow>
            ) : (
              questions.map((question) => (
                <QuestionTableRow
                  key={question.id}
                  question={question}
                  t={t}
                  onEdit={setEditQuestion}
                  onDelete={setDeleteQuestion}
                />
              ))
            )}
          </TableBody>
        </Table>

        {/* Pagination */}
        {questionsMeta && questionsMeta.totalPages > 1 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-t px-3 sm:px-4 py-3">
            <p className="text-sm text-muted-foreground text-center sm:text-left">
              {t('common.showingOf', {
                from: (questionsMeta.page - 1) * questionsMeta.limit + 1,
                to: Math.min(questionsMeta.page * questionsMeta.limit, questionsMeta.total),
                total: questionsMeta.total,
              })}
            </p>
            <div className="flex items-center justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(page - 1)}
                disabled={page <= 1}
              >
                {t('common.previous')}
              </Button>
              <span className="text-sm">
                {questionsMeta.page} / {questionsMeta.totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(page + 1)}
                disabled={page >= questionsMeta.totalPages}
              >
                {t('common.next')}
              </Button>
            </div>
          </div>
        )}
      </div>
        </TabsContent>

        <TabsContent value="quizzes" className="space-y-6">
          {/* Quizzes List */}
          <div className="rounded-md border overflow-x-auto">
            <Table className="table-fixed">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[30%] min-w-[200px]">{t('quizzes.name')}</TableHead>
                  <TableHead className="w-[140px] text-center">{t('quizzes.totalQuestions')}</TableHead>
                  <TableHead className="w-[90px] text-center">{t('quizzes.timeLimit')}</TableHead>
                  <TableHead className="w-[90px] text-center">{t('quizzes.passingScore')}</TableHead>
                  <TableHead className="w-[90px]">{t('common.status')}</TableHead>
                  <TableHead className="w-[100px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quizzesLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-20" /></TableCell>
                    </TableRow>
                  ))
                ) : quizzes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      {t('quizzes.noQuizzes')}
                    </TableCell>
                  </TableRow>
                ) : (
                  quizzes.map((quiz) => (
                    <TableRow key={quiz.id}>
                      <TableCell>
                        <div className="min-w-0">
                          <p className="font-medium truncate">{quiz.title}</p>
                          {quiz.titleAr && <p className="text-sm text-muted-foreground truncate" dir="rtl">{quiz.titleAr}</p>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1 text-xs">
                          <span className="px-1.5 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">{quiz.easyQuestions}</span>
                          <span className="px-1.5 py-0.5 rounded bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400">{quiz.mediumQuestions}</span>
                          <span className="px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">{quiz.hardQuestions}</span>
                          <span className="ms-1 font-medium">= {quiz.totalQuestions}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center">
                          {quiz.timeLimit ? `${quiz.timeLimit} min` : '-'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center font-medium">{quiz.passingScore}%</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={quiz.isActive ? 'default' : 'secondary'}>
                          {quiz.isActive ? t('common.active') : t('common.inactive')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => router.push(ROUTES.PROFESSOR.QUIZ_DETAIL(quiz.id))}
                        >
                          {t('common.view')}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{t('questions.add')}</DialogTitle>
            <DialogDescription>{t('questions.addDescription')}</DialogDescription>
          </DialogHeader>
          <div className="overflow-y-auto flex-1 px-1">
            <QuestionFormWizard
              subjectId={bank.subjectId}
              onSubmit={handleCreate}
              onCancel={() => setCreateDialogOpen(false)}
              isLoading={isSubmitting}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editQuestion} onOpenChange={(open) => !open && setEditQuestion(null)}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{t('questions.edit')}</DialogTitle>
            <DialogDescription>{t('questions.editDescription')}</DialogDescription>
          </DialogHeader>
          <div className="overflow-y-auto flex-1 px-1">
            {editQuestion && (
              <QuestionFormWizard
                question={editQuestion}
                subjectId={bank.subjectId}
                onSubmit={handleUpdate}
                onCancel={() => setEditQuestion(null)}
                isLoading={isSubmitting}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={!!deleteQuestion}
        onOpenChange={(open) => !open && setDeleteQuestion(null)}
        title={t('questions.deleteTitle')}
        description={t('questions.deleteDescription')}
        confirmLabel={t('common.delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />

      {/* Import Dialog */}
      <QuestionImportDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
        bankId={bankId}
        onSuccess={handleImportSuccess}
      />
    </div>
  );
}
