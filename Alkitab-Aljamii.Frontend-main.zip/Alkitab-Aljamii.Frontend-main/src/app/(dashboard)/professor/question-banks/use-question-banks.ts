'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { useServerTable } from '@/hooks';
import {
  quizApi,
  type QuestionBank,
  type QuestionBankQueryParams,
  type CreateQuestionBankData,
  type UpdateQuestionBankData,
} from '@/lib/api/quiz';
import { subjectsApi } from '@/lib/api/subjects';

export interface SubjectOption {
  id: string;
  name: string;
  nameAr?: string | null;
}

type BankFilters = Omit<QuestionBankQueryParams, 'page' | 'limit'>;

export function useQuestionBanks() {
  const t = useTranslations();

  // Subjects for filter
  const [subjects, setSubjects] = useState<SubjectOption[]>([]);

  // Dialog states
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editBank, setEditBank] = useState<QuestionBank | null>(null);
  const [deleteBank, setDeleteBank] = useState<QuestionBank | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Server-side table state
  const tableState = useServerTable<QuestionBank, BankFilters>({
    fetchFn: quizApi.getQuestionBanks,
    initialPageSize: 10,
    initialFilters: {},
  });

  const { setFilter, refetch } = tableState;

  // Fetch subjects for filter
  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        const response = await subjectsApi.getAll({ limit: 100 });
        setSubjects(response.items);
      } catch (err) {
        console.error('Failed to fetch subjects:', err);
      }
    };
    fetchSubjects();
  }, []);

  // Handle create
  const handleCreate = useCallback(async (data: CreateQuestionBankData | UpdateQuestionBankData) => {
    setIsSubmitting(true);
    try {
      await quizApi.createQuestionBank(data as CreateQuestionBankData);
      toast.success(t('questionBanks.createSuccess'));
      setCreateDialogOpen(false);
      refetch();
    } catch {
      toast.error(t('questionBanks.createError'));
    } finally {
      setIsSubmitting(false);
    }
  }, [refetch, t]);

  // Handle update
  const handleUpdate = useCallback(async (data: CreateQuestionBankData | UpdateQuestionBankData) => {
    if (!editBank) return;
    setIsSubmitting(true);
    try {
      await quizApi.updateQuestionBank(editBank.id, data);
      toast.success(t('questionBanks.updateSuccess'));
      setEditBank(null);
      refetch();
    } catch {
      toast.error(t('questionBanks.updateError'));
    } finally {
      setIsSubmitting(false);
    }
  }, [editBank, refetch, t]);

  // Handle delete
  const handleDelete = useCallback(async () => {
    if (!deleteBank) return;
    setIsDeleting(true);
    try {
      await quizApi.deleteQuestionBank(deleteBank.id);
      toast.success(t('questionBanks.deleteSuccess'));
      setDeleteBank(null);
      refetch();
    } catch {
      toast.error(t('questionBanks.deleteError'));
    } finally {
      setIsDeleting(false);
    }
  }, [deleteBank, refetch, t]);

  // Handle subject filter
  const handleSubjectFilter = useCallback((value: string) => {
    setFilter('subjectId', value === 'all' ? undefined : value);
  }, [setFilter]);

  // Handle status filter
  const handleStatusFilter = useCallback((value: string) => {
    setFilter('isActive', value === 'all' ? undefined : value === 'active');
  }, [setFilter]);

  return {
    // Table state
    ...tableState,
    // Subjects
    subjects,
    // Dialog states
    createDialogOpen,
    setCreateDialogOpen,
    editBank,
    setEditBank,
    deleteBank,
    setDeleteBank,
    isSubmitting,
    isDeleting,
    // Handlers
    handleCreate,
    handleUpdate,
    handleDelete,
    handleSubjectFilter,
    handleStatusFilter,
  };
}

export function getDifficultyColor(count: number, total: number) {
  const percentage = total > 0 ? (count / total) * 100 : 0;
  if (percentage < 20) return 'text-muted-foreground';
  if (percentage < 40) return 'text-yellow-600';
  return 'text-green-600';
}
