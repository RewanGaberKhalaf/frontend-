'use client';

import { useRouter } from 'next/navigation';
import { Plus, Database, Search, BookOpen, HelpCircle, MoreHorizontal, Pencil, Trash2, Eye } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState, ConfirmDialog, PageHeader } from '@/components/shared';
import { QuestionBankForm } from '@/components/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';
import { useQuestionBanks, getDifficultyColor } from './use-question-banks';

export default function QuestionBanksPage() {
  const t = useTranslations();
  const router = useRouter();

  const {
    data: banks,
    meta,
    isLoading,
    error,
    searchValue,
    filters,
    setPage,
    setSearch,
    subjects,
    createDialogOpen,
    setCreateDialogOpen,
    editBank,
    setEditBank,
    deleteBank,
    setDeleteBank,
    isSubmitting,
    isDeleting,
    handleCreate,
    handleUpdate,
    handleDelete,
    handleSubjectFilter,
    handleStatusFilter,
  } = useQuestionBanks();

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Database}
        title={t('questionBanks.title')}
        description={t('questionBanks.description')}
        badge={
          meta && (
            <Badge variant="secondary">
              {meta.total} {t('questionBanks.banksTotal')}
            </Badge>
          )
        }
        action={
          <Button onClick={() => setCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            {t('questionBanks.create')}
          </Button>
        }
      />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-3 rounded-lg border bg-card p-3 sm:p-4">
        <div className="relative flex-1 min-w-0 sm:min-w-[200px] sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('common.search') + '...'}
            value={searchValue}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <Select
            value={filters.subjectId ?? 'all'}
            onValueChange={handleSubjectFilter}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder={t('questionBanks.filterBySubject')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              {subjects.map((subject) => (
                <SelectItem key={subject.id} value={subject.id}>
                  {subject.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={
              filters.isActive === undefined
                ? 'all'
                : filters.isActive
                  ? 'active'
                  : 'inactive'
            }
            onValueChange={handleStatusFilter}
          >
            <SelectTrigger className="w-[120px] sm:w-[140px]">
              <SelectValue placeholder={t('common.status')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              <SelectItem value="active">{t('common.active')}</SelectItem>
              <SelectItem value="inactive">{t('common.inactive')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-md bg-destructive/10 p-4 text-destructive">
          {error}
        </div>
      )}

      {/* Table or Empty state */}
      {!isLoading && banks.length === 0 && !searchValue && !filters.subjectId ? (
        <EmptyState
          title={t('questionBanks.nobanks')}
          description={t('questionBanks.nobanksDescription')}
          action={
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              {t('questionBanks.create')}
            </Button>
          }
        />
      ) : (
        <div className="rounded-md border overflow-x-auto">
          <Table className="table-fixed">
            <TableHeader>
              <TableRow>
                <TableHead className="w-[25%] min-w-[180px]">{t('questionBanks.name')}</TableHead>
                <TableHead className="w-[20%] min-w-[150px]">{t('questionBanks.subject')}</TableHead>
                <TableHead className="w-[80px] text-center">
                  {t('questionBanks.questions')}
                </TableHead>
                <TableHead className="w-[140px] text-center">
                  {t('questionBanks.difficulty')}
                </TableHead>
                <TableHead className="w-[90px]">{t('common.status')}</TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                  </TableRow>
                ))
              ) : banks.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    {t('questionBanks.noResults')}
                  </TableCell>
                </TableRow>
              ) : (
                banks.map((bank) => (
                  <TableRow key={bank.id}>
                    <TableCell>
                      <div className="min-w-0">
                        <p className="font-medium truncate">{bank.name}</p>
                        {bank.nameAr && (
                          <p className="text-sm text-muted-foreground truncate" dir="rtl">
                            {bank.nameAr}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 min-w-0">
                        <BookOpen className="h-4 w-4 text-muted-foreground shrink-0" />
                        <span className="truncate">{bank.subjectName}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <HelpCircle className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{bank.totalQuestions}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-2 text-xs">
                        <span className={cn('px-1.5 py-0.5 rounded', getDifficultyColor(bank.easyCount, bank.totalQuestions), 'bg-green-100 dark:bg-green-900/30')}>
                          E: {bank.easyCount}
                        </span>
                        <span className={cn('px-1.5 py-0.5 rounded', getDifficultyColor(bank.mediumCount, bank.totalQuestions), 'bg-yellow-100 dark:bg-yellow-900/30')}>
                          M: {bank.mediumCount}
                        </span>
                        <span className={cn('px-1.5 py-0.5 rounded', getDifficultyColor(bank.hardCount, bank.totalQuestions), 'bg-red-100 dark:bg-red-900/30')}>
                          H: {bank.hardCount}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={bank.isActive ? 'default' : 'secondary'}>
                        {bank.isActive ? t('common.active') : t('common.inactive')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => router.push(ROUTES.PROFESSOR.QUESTION_BANK_DETAIL(bank.id))}>
                            <Eye className="mr-2 h-4 w-4" />
                            {t('common.view')}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setEditBank(bank)}>
                            <Pencil className="mr-2 h-4 w-4" />
                            {t('common.edit')}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setDeleteBank(bank)} className="text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            {t('common.delete')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {meta && meta.totalPages > 1 && (
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-t px-3 sm:px-4 py-3">
              <p className="text-sm text-muted-foreground text-center sm:text-left">
                {t('common.showingOf', {
                  from: (meta.page - 1) * meta.limit + 1,
                  to: Math.min(meta.page * meta.limit, meta.total),
                  total: meta.total,
                })}
              </p>
              <div className="flex items-center justify-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setPage(meta.page - 1)} disabled={meta.page <= 1}>
                  {t('common.previous')}
                </Button>
                <span className="text-sm">{meta.page} / {meta.totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setPage(meta.page + 1)} disabled={meta.page >= meta.totalPages}>
                  {t('common.next')}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('questionBanks.create')}</DialogTitle>
            <DialogDescription>{t('questionBanks.createDescription')}</DialogDescription>
          </DialogHeader>
          <QuestionBankForm onSubmit={handleCreate} onCancel={() => setCreateDialogOpen(false)} isLoading={isSubmitting} />
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editBank} onOpenChange={(open) => !open && setEditBank(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('questionBanks.edit')}</DialogTitle>
            <DialogDescription>{t('questionBanks.editDescription')}</DialogDescription>
          </DialogHeader>
          {editBank && (
            <QuestionBankForm bank={editBank} onSubmit={handleUpdate} onCancel={() => setEditBank(null)} isLoading={isSubmitting} />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={!!deleteBank}
        onOpenChange={(open) => !open && setDeleteBank(null)}
        title={t('questionBanks.deleteTitle')}
        description={t('questionBanks.deleteDescription', { name: deleteBank?.name ?? '' })}
        confirmLabel={t('common.delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />
    </div>
  );
}
