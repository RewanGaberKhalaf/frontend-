'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { AnnouncementList } from '@/components/notifications';
import { subjectsApi } from '@/lib/api/subjects';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import type { Subject } from '@/types';

export default function ProfessorAnnouncementsPage() {
  const t = useTranslations('notifications.announcements');
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [subjects, setSubjects] = useState<Subject[]>([]);

  // Load professor's subjects
  useEffect(() => {
    const loadSubjects = async () => {
      try {
        const params = currentFacultyId ? { facultyId: currentFacultyId } : {};
        const result = await subjectsApi.getAll(params);
        setSubjects(result.items);
      } catch {
        // Silently fail
      }
    };
    loadSubjects();
  }, [currentFacultyId]);

  return (
    <AnnouncementList
      subjects={subjects}
      allowedRoles={['student']}
      defaultFacultyId={currentFacultyId ?? undefined}
      hideFacultySelect={true}
      hideRoleSelect={true}
      title={t('title')}
      description="Send announcements to students in your subjects"
    />
  );
}
