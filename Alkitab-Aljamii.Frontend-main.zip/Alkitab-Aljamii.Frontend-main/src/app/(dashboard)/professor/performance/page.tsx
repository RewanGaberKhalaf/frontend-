'use client';

import { useState, useEffect } from 'react';
import { Loader2, Users, AlertTriangle, TrendingUp, CheckCircle, ArrowRight, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations, useLocale } from 'next-intl';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { performanceApi, type ProfessorDashboard, type AtRiskAlert } from '@/lib/api/performance';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import { EmptyState } from '@/components/shared';
import {
  MetricCard,
  RiskBadge,
  AlertCard,
  StudentTable,
} from '@/components/performance';

export default function ProfessorPerformancePage() {
  const t = useTranslations();
  const locale = useLocale();
  void locale;
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [dashboard, setDashboard] = useState<ProfessorDashboard | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const loadDashboard = async () => {
      if (!currentFacultyId) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      try {
        const data = await performanceApi.professor.getDashboard();
        setDashboard(data);
      } catch {
        toast.error(t('performance.failedToLoad'));
      } finally {
        setIsLoading(false);
      }
    };
    loadDashboard();
  }, [currentFacultyId]);

  const handleAcknowledgeAlert = async (alertId: string) => {
    try {
      await performanceApi.professor.acknowledgeAlert(alertId);
      toast.success(t('performance.alerts.acknowledged'));
      // Refresh dashboard
      const data = await performanceApi.professor.getDashboard();
      setDashboard(data);
    } catch {
      toast.error(t('performance.alerts.acknowledgeFailed'));
    }
  };

  const handleResolveAlert = async (alertId: string) => {
    try {
      await performanceApi.professor.resolveAlert(alertId);
      toast.success(t('performance.alerts.resolved'));
      // Refresh dashboard
      const data = await performanceApi.professor.getDashboard();
      setDashboard(data);
    } catch {
      toast.error(t('performance.alerts.resolveFailed'));
    }
  };

  if (!currentFacultyId) {
    return <EmptyState title={t('dashboard.facultyAdmin.noFacultySelected')} description={t('dashboard.facultyAdmin.noFacultySelectedDescription')} />;
  }

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!dashboard) {
    return <EmptyState title={t('performance.noData')} description={t('performance.noDataDescription')} />;
  }

  const { totalStudents, averageApi, atRiskCount, pendingAlerts, activeInterventions, topPerformers, atRiskStudents, recentAlerts } = dashboard;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('performance.professor.classPerformance')}</h2>
          <p className="text-muted-foreground">{t('performance.professor.monitorStudents')}</p>
        </div>
        {pendingAlerts > 0 && (
          <Button size="sm" variant="destructive" asChild>
            <Link href="/professor/performance/alerts">
              <AlertTriangle className="me-2 h-4 w-4" />
              {t('performance.professor.pendingAlertsCount', { count: pendingAlerts })}
            </Link>
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">{t('performance.tabs.overview')}</TabsTrigger>
          <TabsTrigger value="students">{t('performance.professor.allStudents')}</TabsTrigger>
          <TabsTrigger value="at-risk">{t('performance.professor.atRisk')}</TabsTrigger>
          <TabsTrigger value="alerts">{t('performance.alerts.title')}</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Stat Cards */}
          <div className="grid gap-4 grid-cols-2 md:grid-cols-5">
            <MetricCard
              title={t('performance.professor.totalStudents')}
              value={totalStudents}
              icon={Users}
              iconColor="text-blue-600"
            />
            <MetricCard
              title={t('performanceMetrics.classAverageApi')}
              value={averageApi}
              format="number"
              icon={TrendingUp}
              iconColor="text-green-600"
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.apiTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.apiDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.apiCompletion')}</li>
                    <li>{t('performanceMetrics.apiQuizQuality')}</li>
                    <li>{t('performanceMetrics.apiEngagement')}</li>
                    <li>{t('performanceMetrics.apiConsistency')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.atRiskStudents')}
              value={atRiskCount}
              icon={AlertTriangle}
              iconColor={atRiskCount > 0 ? 'text-orange-600' : 'text-muted-foreground'}
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.atRiskStudentsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.atRiskStudentsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.atRiskCriteria1')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria2')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria3')}</li>
                    <li>{t('performanceMetrics.atRiskCriteria4')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performance.professor.pendingAlerts')}
              value={pendingAlerts}
              icon={AlertTriangle}
              iconColor={pendingAlerts > 0 ? 'text-red-600' : 'text-muted-foreground'}
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.criticalAlertsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.criticalAlertsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.criticalAlertsCriteria1')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria2')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria3')}</li>
                    <li>{t('performanceMetrics.criticalAlertsCriteria4')}</li>
                  </ul>
                </div>
              }
            />
            <MetricCard
              title={t('performanceMetrics.activeInterventions')}
              value={activeInterventions}
              icon={CheckCircle}
              iconColor="text-purple-600"
              infoTooltip={
                <div className="space-y-1.5 text-start">
                  <p className="font-medium">{t('performanceMetrics.activeInterventionsTitle')}</p>
                  <p className="text-muted-foreground">{t('performanceMetrics.activeInterventionsDescription')}</p>
                  <ul className="list-disc ps-4 space-y-0.5 text-xs">
                    <li>{t('performanceMetrics.activeInterventionsCriteria1')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria2')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria3')}</li>
                    <li>{t('performanceMetrics.activeInterventionsCriteria4')}</li>
                  </ul>
                </div>
              }
            />
          </div>

          {/* Top Performers and At-Risk */}
          <div className="grid gap-4 grid-cols-1 lg:grid-cols-2">
            {/* Top Performers */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-600" />
                    {t('performance.professor.topPerformers')}
                  </CardTitle>
                  <CardDescription className="text-xs">{t('performance.professor.topPerformersDesc')}</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                {topPerformers.length > 0 ? (
                  <div className="space-y-2">
                    {topPerformers.slice(0, 5).map((student, index) => (
                      <div
                        key={student.userId}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-xs font-medium text-green-700 dark:text-green-400">
                            {index + 1}
                          </div>
                          <div>
                            <p className="text-sm font-medium">{student.firstName} {student.lastName}</p>
                            <p className="text-xs text-muted-foreground">{student.email}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-600">{Math.round(student.academicPerformanceIndex)}</p>
                          <p className="text-xs text-muted-foreground">API</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-6">{t('performance.professor.noStudentData')}</p>
                )}
              </CardContent>
            </Card>

            {/* At-Risk Students */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-orange-600" />
                    {t('performance.professor.atRiskStudents')}
                  </CardTitle>
                  <CardDescription className="text-xs">{t('performance.professor.atRiskStudentsDesc')}</CardDescription>
                </div>
                {atRiskStudents.length > 0 && (
                  <Button variant="ghost" size="sm" className="h-8 text-xs" asChild>
                    <Link href="/professor/performance?tab=at-risk">
                      {t('common.viewAll')} <ArrowRight className="ms-1 h-3 w-3" />
                    </Link>
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {atRiskStudents.length > 0 ? (
                  <div className="space-y-2">
                    {atRiskStudents.slice(0, 5).map((student) => (
                      <div
                        key={student.userId}
                        className="flex items-center justify-between p-2 rounded-lg border border-orange-200 dark:border-orange-800 bg-orange-50/50 dark:bg-orange-900/10"
                      >
                        <div className="flex items-center gap-3">
                          <div>
                            <p className="text-sm font-medium">{student.firstName} {student.lastName}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <RiskBadge level={student.riskLevel} size="sm" />
                              {student.activeAlerts > 0 && (
                                <span className="text-xs text-orange-600">{t('performance.professor.alertsCount', { count: student.activeAlerts })}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <p className="text-lg font-bold text-orange-600">{Math.round(student.academicPerformanceIndex)}</p>
                            <p className="text-xs text-muted-foreground">API</p>
                          </div>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <CheckCircle className="h-8 w-8 mx-auto text-green-500 mb-2" />
                    <p className="text-sm text-muted-foreground">{t('performance.professor.noAtRiskStudents')}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Recent Alerts */}
          {recentAlerts.length > 0 && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    {t('performance.professor.recentAlerts')}
                  </CardTitle>
                  <CardDescription className="text-xs">{t('performance.professor.recentAlertsDesc')}</CardDescription>
                </div>
                <Button variant="ghost" size="sm" className="h-8 text-xs" asChild>
                  <Link href="/professor/performance?tab=alerts">
                    {t('common.viewAll')} <ArrowRight className="ms-1 h-3 w-3" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 grid-cols-1 md:grid-cols-2">
                  {recentAlerts.slice(0, 4).map((alert) => (
                    <AlertCard
                      key={alert.id}
                      alert={alert}
                      onAcknowledge={handleAcknowledgeAlert}
                      onResolve={handleResolveAlert}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="students" className="space-y-6 mt-6">
          <StudentTable
            students={[...topPerformers, ...atRiskStudents]}
            onViewStudent={(userId) => console.log('View student:', userId)}
          />
        </TabsContent>

        <TabsContent value="at-risk" className="space-y-6 mt-6">
          {atRiskStudents.length > 0 ? (
            <StudentTable
              students={atRiskStudents}
              onViewStudent={(userId) => console.log('View student:', userId)}
            />
          ) : (
            <EmptyState
              title={t('performance.professor.noAtRiskStudents')}
              description={t('performance.professor.allStudentsPerformingWell')}
            />
          )}
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6 mt-6">
          {recentAlerts.length > 0 ? (
            <div className="grid gap-3 grid-cols-1 md:grid-cols-2">
              {recentAlerts.map((alert) => (
                <AlertCard
                  key={alert.id}
                  alert={alert}
                  onAcknowledge={handleAcknowledgeAlert}
                  onResolve={handleResolveAlert}
                />
              ))}
            </div>
          ) : (
            <EmptyState
              title={t('performance.professor.noAlerts')}
              description={t('performance.professor.noAlertsDesc')}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
