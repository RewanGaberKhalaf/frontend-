'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  ArrowLeft,
  Users,
  Clock,
  TrendingUp,
  CheckCircle2,
  XCircle,
  HelpCircle,
  BarChart3,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type QuizAnalytics } from '@/lib/api/analytics';
import { cn, formatRelativeTime } from '@/lib/utils';

const difficultyColors: Record<string, string> = {
  easy: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  medium: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
  hard: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
};

export default function QuizAnalyticsPage() {
  const params = useParams();
  const router = useRouter();
  const t = useTranslations();
  const quizId = params['quizId'] as string;

  const [data, setData] = useState<QuizAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const analytics = await analyticsApi.getQuizAnalytics(quizId);
        setData(analytics);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [quizId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-64" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 me-2" />
          {t('common.back')}
        </Button>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">{error || 'No data available'}</p>
        </div>
      </div>
    );
  }

  const scoreDistributionData = [
    { label: '0-20%', value: data.scoreDistribution['0-20'], color: 'bg-red-500' },
    { label: '21-40%', value: data.scoreDistribution['21-40'], color: 'bg-orange-500' },
    { label: '41-60%', value: data.scoreDistribution['41-60'], color: 'bg-yellow-500' },
    { label: '61-80%', value: data.scoreDistribution['61-80'], color: 'bg-green-400' },
    { label: '81-100%', value: data.scoreDistribution['81-100'], color: 'bg-green-600' },
  ];

  const maxDistribution = Math.max(...scoreDistributionData.map(d => d.value), 1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start sm:items-center gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1 sm:mt-0" asChild>
          <Link href={ROUTES.PROFESSOR.ANALYTICS}>
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{data.quizTitle}</h1>
          <p className="text-sm text-muted-foreground truncate">{data.bankName}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.totalAttempts')}</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalAttempts}</div>
            <p className="text-xs text-muted-foreground">
              {data.uniqueStudents} {t('analytics.uniqueStudents')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgScore')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgScore.toFixed(1)}%</div>
            <Progress value={data.avgScore} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.passRate')}</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.passRate.toFixed(1)}%</div>
            <Progress value={data.passRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgTime')}</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgTimeMinutes.toFixed(0)}</div>
            <p className="text-xs text-muted-foreground">{t('analytics.minutes')}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {/* Score Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>{t('analytics.scoreDistribution')}</CardTitle>
            <CardDescription>{t('analytics.scoreDistributionDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {scoreDistributionData.map((item) => (
                <div key={item.label} className="flex items-center gap-3">
                  <span className="w-16 text-sm text-muted-foreground">{item.label}</span>
                  <div className="flex-1 bg-muted rounded-full h-6 overflow-hidden">
                    <div
                      className={cn('h-full rounded-full transition-all', item.color)}
                      style={{ width: `${(item.value / maxDistribution) * 100}%` }}
                    />
                  </div>
                  <span className="w-8 text-sm font-medium text-end">{item.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Attempts */}
        <Card>
          <CardHeader>
            <CardTitle>{t('analytics.recentAttempts')}</CardTitle>
            <CardDescription>{t('analytics.recentAttemptsDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.recentAttempts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('analytics.noAttempts')}
              </p>
            ) : (
              <div className="space-y-2">
                {data.recentAttempts.slice(0, 8).map((attempt) => (
                  <div key={attempt.attemptId} className="flex items-center justify-between p-2 rounded border gap-2">
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                      {attempt.passed ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 shrink-0" />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{attempt.studentName}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatRelativeTime(new Date(attempt.submittedAt))}
                        </p>
                      </div>
                    </div>
                    <Badge variant={attempt.passed ? 'default' : 'secondary'} className="shrink-0">
                      {attempt.score}%
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Question Analytics */}
      <Card>
        <CardHeader>
          <CardTitle>{t('analytics.questionPerformance')}</CardTitle>
          <CardDescription>{t('analytics.questionPerformanceDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="px-0 sm:px-6">
          {data.questionStats.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4 px-6">
              {t('analytics.noQuestionData')}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[200px]">{t('analytics.question')}</TableHead>
                    <TableHead className="text-center w-24">{t('analytics.difficulty')}</TableHead>
                    <TableHead className="text-center w-20">{t('analytics.timesAnswered')}</TableHead>
                    <TableHead className="text-center min-w-[140px]">{t('analytics.correctRate')}</TableHead>
                    <TableHead className="text-center w-20">{t('analytics.avgTimePerQuestion')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.questionStats.map((question) => (
                    <TableRow key={question.questionId}>
                      <TableCell>
                        <div className="max-w-[250px] sm:max-w-md truncate">{question.questionText}</div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={cn('text-xs', difficultyColors[question.difficulty] || 'bg-gray-100')}>
                          {question.difficulty}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">{question.timesAnswered}</TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Progress value={question.correctRate} className="w-12 sm:w-16 h-2" />
                          <span className={cn(
                            'text-sm font-medium whitespace-nowrap',
                            question.correctRate >= 70 ? 'text-green-600' :
                            question.correctRate >= 40 ? 'text-yellow-600' : 'text-red-600'
                          )}>
                            {question.correctRate.toFixed(0)}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center whitespace-nowrap">
                        {question.avgTimeSeconds.toFixed(0)}s
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
