'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  ArrowLeft,
  BookOpen,
  Users,
  Clock,
  TrendingUp,
  CheckCircle2,
  ClipboardList,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type BookAnalytics } from '@/lib/api/analytics';

const statusVariants: Record<string, 'default' | 'secondary' | 'outline'> = {
  draft: 'secondary',
  pending_review: 'outline',
  approved: 'default',
  rejected: 'secondary',
  published: 'default',
};

export default function BookAnalyticsPage() {
  const params = useParams();
  const router = useRouter();
  const t = useTranslations();
  const bookId = params['bookId'] as string;

  const [data, setData] = useState<BookAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const analytics = await analyticsApi.getBookAnalytics(bookId);
        setData(analytics);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [bookId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 me-2" />
          {t('common.back')}
        </Button>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">{error || 'No data available'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start sm:items-center gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1 sm:mt-0" asChild>
          <Link href={ROUTES.PROFESSOR.ANALYTICS}>
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{data.bookTitle}</h1>
            <Badge variant={statusVariants[data.status] || 'secondary'} className="w-fit">{data.status}</Badge>
          </div>
          <p className="text-sm text-muted-foreground truncate">{data.subjectName}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.totalReaders')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalReaders}</div>
            <p className="text-xs text-muted-foreground">
              {data.activeReaders} {t('analytics.activeRecently')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.chapters')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalChapters}</div>
            <p className="text-xs text-muted-foreground">
              {data.chapters.filter(c => c.hasQuiz).length} {t('analytics.withQuizzes')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgCompletion')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgCompletionRate.toFixed(1)}%</div>
            <Progress value={data.avgCompletionRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.avgReadingTime')}</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgReadingTimeMinutes.toFixed(0)}</div>
            <p className="text-xs text-muted-foreground">{t('analytics.minutes')}</p>
          </CardContent>
        </Card>
      </div>

      {/* Chapter Analytics Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('analytics.chapterBreakdown')}</CardTitle>
          <CardDescription>{t('analytics.chapterBreakdownDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="px-0 sm:px-6">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead className="min-w-[150px]">{t('analytics.chapterTitle')}</TableHead>
                  <TableHead className="text-center w-20">{t('analytics.readers')}</TableHead>
                  <TableHead className="text-center w-24">{t('analytics.completed')}</TableHead>
                  <TableHead className="text-center w-24">{t('analytics.avgTime')}</TableHead>
                  <TableHead className="text-center min-w-[180px]">{t('analytics.quiz')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.chapters.map((chapter) => (
                  <TableRow key={chapter.chapterId}>
                    <TableCell className="font-medium">{chapter.order + 1}</TableCell>
                    <TableCell>
                      <div className="font-medium truncate max-w-[200px]">{chapter.chapterTitle}</div>
                    </TableCell>
                    <TableCell className="text-center">{chapter.totalReaders}</TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        {chapter.completedCount}
                      </div>
                    </TableCell>
                    <TableCell className="text-center whitespace-nowrap">
                      {chapter.avgReadingTimeMinutes.toFixed(0)} {t('analytics.min')}
                    </TableCell>
                    <TableCell className="text-center">
                      {chapter.hasQuiz && chapter.quizStats ? (
                        <div className="space-y-1">
                          <Badge variant="outline" className="text-xs whitespace-nowrap">
                            <ClipboardList className="h-3 w-3 me-1" />
                            {chapter.quizStats.totalAttempts} {t('analytics.attempts')}
                          </Badge>
                          <div className="text-xs text-muted-foreground whitespace-nowrap">
                            {chapter.quizStats.avgScore.toFixed(0)}% | {chapter.quizStats.passRate.toFixed(0)}%
                          </div>
                        </div>
                      ) : chapter.hasQuiz ? (
                        <Badge variant="secondary" className="text-xs">
                          {t('analytics.noAttempts')}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
