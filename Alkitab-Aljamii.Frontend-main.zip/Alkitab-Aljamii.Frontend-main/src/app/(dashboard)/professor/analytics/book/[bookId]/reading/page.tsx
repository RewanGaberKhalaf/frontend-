'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  ArrowLeft,
  Clock,
  Users,
  TrendingUp,
  BookOpen,
  AlertTriangle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ROUTES } from '@/lib/constants/routes';
import { readingTimeApi } from '@/lib/api/reading-time';
import { ChapterReadingChart, StudentReadingTable, ReadingTimeHeatmap } from '@/components/analytics';
import type { BookReadingAnalytics } from '@/types';

function formatMinutes(minutes: number): string {
  if (minutes < 60) {
    return `${Math.round(minutes)}m`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export default function BookReadingAnalyticsPage() {
  const params = useParams();
  const router = useRouter();
  const t = useTranslations();
  const bookId = params['bookId'] as string;

  const [data, setData] = useState<BookReadingAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const analytics = await readingTimeApi.getBookReadingAnalytics(bookId);
        setData(analytics);
      } catch (err) {
        setError(err instanceof Error ? err.message : t('analytics.reading.loadError'));
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [bookId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 me-2" />
          {t('common.back')}
        </Button>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">{error || t('analytics.noData')}</p>
        </div>
      </div>
    );
  }

  const handleStudentClick = (studentId: string) => {
    router.push(ROUTES.PROFESSOR.ANALYTICS + `/book/${bookId}/student/${studentId}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start sm:items-center gap-3 sm:gap-4">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1 sm:mt-0" asChild>
          <Link href={ROUTES.PROFESSOR.ANALYTICS + `/book/${bookId}`}>
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">
              {t('analytics.reading.title')}
            </h1>
          </div>
          <p className="text-sm text-muted-foreground truncate">{data.bookTitle}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.reading.totalReadingTime')}</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMinutes(data.totalReadingTimeMinutes)}</div>
            <p className="text-xs text-muted-foreground">
              {t('analytics.reading.acrossAllStudents')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.reading.uniqueReaders')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.uniqueReaders}</div>
            <p className="text-xs text-muted-foreground">
              {t('analytics.reading.studentsEngaged')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.reading.avgPerStudent')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMinutes(data.avgReadingTimePerStudent)}</div>
            <p className="text-xs text-muted-foreground">
              {t('analytics.reading.averageTime')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.reading.avgPerChapter')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMinutes(data.avgTimePerChapter)}</div>
            <p className="text-xs text-muted-foreground">
              {t('analytics.reading.perChapterAverage')}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for different views */}
      <Tabs defaultValue="chapters" className="space-y-4">
        <TabsList>
          <TabsTrigger value="chapters">{t('analytics.reading.chapterBreakdown')}</TabsTrigger>
          <TabsTrigger value="students">{t('analytics.reading.topReaders')}</TabsTrigger>
          <TabsTrigger value="trends">{t('analytics.reading.trends')}</TabsTrigger>
        </TabsList>

        <TabsContent value="chapters" className="space-y-4">
          <ChapterReadingChart
            data={data.chapterBreakdown}
            title={t('analytics.reading.readingTimeByChapter')}
            description={t('analytics.reading.readingTimeByChapterDesc')}
            valueType="totalTime"
          />

          <ChapterReadingChart
            data={data.chapterBreakdown}
            title={t('analytics.reading.avgTimePerReader')}
            description={t('analytics.reading.avgTimePerReaderDesc')}
            valueType="avgTime"
          />

          {/* Drop-off Analysis */}
          {data.dropoffPoints.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  {t('analytics.reading.dropoffPoints')}
                </CardTitle>
                <CardDescription>
                  {t('analytics.reading.dropoffPointsDesc')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.dropoffPoints.map((point) => (
                    <Alert key={point.chapterId} variant="default">
                      <AlertDescription className="flex items-center justify-between">
                        <span>{point.chapterTitle}</span>
                        <span className="font-medium text-amber-600">
                          {Math.round(point.dropoffRate * 100)}% drop-off
                        </span>
                      </AlertDescription>
                    </Alert>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="students">
          <StudentReadingTable
            data={data.topReaders}
            title={t('analytics.reading.topReaders')}
            description={t('analytics.reading.topReadersDesc')}
            onStudentClick={handleStudentClick}
            showRanking
          />
        </TabsContent>

        <TabsContent value="trends">
          <ReadingTimeHeatmap
            data={data.readingTrend}
            title={t('analytics.reading.readingActivity')}
            description={t('analytics.reading.readingActivityDesc')}
            weeks={12}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
