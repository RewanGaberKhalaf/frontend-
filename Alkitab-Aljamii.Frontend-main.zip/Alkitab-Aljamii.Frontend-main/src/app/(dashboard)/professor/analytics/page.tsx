'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import {
  BookOpen,
  ClipboardList,
  Users,
  TrendingUp,
  Clock,
  ChevronRight,
  BarChart3,
  Activity,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { ROUTES } from '@/lib/constants/routes';
import { analyticsApi, type ProfessorAnalyticsOverview } from '@/lib/api/analytics';
import { cn, formatRelativeTime } from '@/lib/utils';

export default function ProfessorAnalyticsPage() {
  const t = useTranslations();
  const [data, setData] = useState<ProfessorAnalyticsOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const overview = await analyticsApi.getProfessorOverview();
        setData(overview);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-7 sm:h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
        <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <div className="grid gap-3 sm:gap-4 md:grid-cols-2">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">{error || 'No data available'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 min-w-0 overflow-hidden">
      {/* Header */}
      <div className="min-w-0">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight truncate">{t('analytics.professor.title')}</h1>
        <p className="text-sm text-muted-foreground line-clamp-2">{t('analytics.professor.description')}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professor.totalBooks')}</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalBooks}</div>
            <p className="text-xs text-muted-foreground">
              {data.publishedBooks} {t('analytics.professor.publishedBooks')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professor.totalQuizzes')}</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalQuizzes}</div>
            <p className="text-xs text-muted-foreground">
              {t('analytics.professor.avgQuizScore')}: {data.avgQuizScore.toFixed(1)}%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professor.studentsReached')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalStudentsReached}</div>
            <p className="text-xs text-muted-foreground">
              {t('analytics.quiz.uniqueStudents')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.professor.avgCompletion')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.avgBookCompletionRate.toFixed(1)}%</div>
            <Progress value={data.avgBookCompletionRate} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-3 sm:gap-4 md:grid-cols-2">
        {/* Book Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              {t('analytics.professor.bookPerformance')}
            </CardTitle>
            <CardDescription>{t('books.browseDescription')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.bookPerformance.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('books.noBooksYet')}
              </p>
            ) : (
              <div className="space-y-4">
                {data.bookPerformance.slice(0, 5).map((book) => (
                  <Link
                    key={book.bookId}
                    href={ROUTES.PROFESSOR.ANALYTICS_BOOK(book.bookId)}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{book.bookTitle}</p>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3 shrink-0" />
                            {book.readers} {t('analytics.professor.readers')}
                          </span>
                          <span>{book.completionRate.toFixed(0)}% {t('analytics.professor.completionRate')}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quiz Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClipboardList className="h-5 w-5" />
              {t('analytics.professor.quizPerformance')}
            </CardTitle>
            <CardDescription>{t('quizzes.description')}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.quizPerformance.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('quizzes.noQuizzes')}
              </p>
            ) : (
              <div className="space-y-4">
                {data.quizPerformance.slice(0, 5).map((quiz) => (
                  <Link
                    key={quiz.quizId}
                    href={ROUTES.PROFESSOR.ANALYTICS_QUIZ(quiz.quizId)}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{quiz.quizTitle}</p>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground mt-1">
                          <span>{quiz.attempts} {t('analytics.professor.attempts')}</span>
                          <span className="hidden sm:inline">{t('analytics.quiz.avgScore')}: {quiz.avgScore.toFixed(1)}%</span>
                          <Badge variant={quiz.passRate >= 70 ? 'default' : 'secondary'} className="text-xs">
                            {quiz.passRate.toFixed(0)}%
                          </Badge>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            {t('analytics.professor.recentActivity')}
          </CardTitle>
          <CardDescription>{t('dashboard.recentActivity')}</CardDescription>
        </CardHeader>
        <CardContent>
          {data.recentActivity.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              {t('dashboard.noRecentActivity')}
            </p>
          ) : (
            <div className="space-y-3">
              {data.recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                  <div className={cn(
                    'p-2 rounded-full shrink-0',
                    activity.type === 'quiz_attempt' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' :
                    activity.type === 'book_read' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' :
                    'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400'
                  )}>
                    {activity.type === 'quiz_attempt' ? <ClipboardList className="h-4 w-4" /> :
                     activity.type === 'book_read' ? <BookOpen className="h-4 w-4" /> :
                     <BarChart3 className="h-4 w-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                      <p className="font-medium truncate">{activity.studentName}</p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground shrink-0">
                        <Clock className="h-3 w-3" />
                        {formatRelativeTime(new Date(activity.timestamp))}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground truncate mt-0.5">
                      {activity.type === 'quiz_attempt' && activity.score !== undefined
                        ? `Scored ${activity.score}% on ${activity.itemTitle}`
                        : `Accessed ${activity.itemTitle}`}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
