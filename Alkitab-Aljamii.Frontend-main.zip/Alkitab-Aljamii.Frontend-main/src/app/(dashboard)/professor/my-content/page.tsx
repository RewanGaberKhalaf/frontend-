'use client';

import { useTranslations } from 'next-intl';
import { DeprecatedFeature } from '@/components/shared';
import { ROUTES } from '@/lib/constants/routes';

export default function MyContentPage() {
  const t = useTranslations();

  return (
    <DeprecatedFeature
      redirectTo={ROUTES.PROFESSOR.BOOKS}
      redirectLabel={t('deprecated.goToBooks')}
    />
  );
}
