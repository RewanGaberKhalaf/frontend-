'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { Tags, Plus, Search, Pencil, Trash2, MoreHorizontal, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState, ConfirmDialog, PageHeader } from '@/components/shared';
import { topicsApi, type Topic, type CreateTopicData, type UpdateTopicData } from '@/lib/api/topics';
import { subjectsApi } from '@/lib/api/subjects';
import type { Subject } from '@/types';
import { TopicForm } from './topic-form';

export default function TopicsPage() {
  const t = useTranslations();

  // Data state
  const [topics, setTopics] = useState<Topic[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [searchValue, setSearchValue] = useState('');

  // Dialog state
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editTopic, setEditTopic] = useState<Topic | null>(null);
  const [deleteTopic, setDeleteTopic] = useState<Topic | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Load subjects
  const loadSubjects = useCallback(async () => {
    try {
      const result = await subjectsApi.getAll();
      setSubjects(result.items);
      // Auto-select first subject if available
      const firstSubject = result.items[0];
      if (firstSubject && !selectedSubject) {
        setSelectedSubject(firstSubject.id);
      }
    } catch (err) {
      console.error('Failed to load subjects:', err);
    }
  }, [selectedSubject]);

  // Load topics
  const loadTopics = useCallback(async () => {
    if (!selectedSubject) {
      setTopics([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const result = await topicsApi.getTopics(selectedSubject, {
        search: searchValue || undefined,
      });
      setTopics(result.data);
    } catch (err) {
      setError(t('errors.loadFailed'));
      console.error('Failed to load topics:', err);
    } finally {
      setIsLoading(false);
    }
  }, [selectedSubject, searchValue, t]);

  useEffect(() => {
    loadSubjects();
  }, [loadSubjects]);

  useEffect(() => {
    loadTopics();
  }, [loadTopics]);

  // Handlers
  const handleCreate = async (data: CreateTopicData | UpdateTopicData) => {
    setIsSubmitting(true);
    try {
      await topicsApi.createTopic(selectedSubject, data as CreateTopicData);
      toast.success(t('topics.createSuccess'));
      setCreateDialogOpen(false);
      loadTopics();
    } catch (err) {
      toast.error(t('topics.createError'));
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdate = async (data: CreateTopicData | UpdateTopicData) => {
    if (!editTopic) return;
    setIsSubmitting(true);
    try {
      await topicsApi.updateTopic(selectedSubject, editTopic.id, data);
      toast.success(t('topics.updateSuccess'));
      setEditTopic(null);
      loadTopics();
    } catch (err) {
      toast.error(t('topics.updateError'));
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTopic) return;
    setIsDeleting(true);
    try {
      await topicsApi.deleteTopic(selectedSubject, deleteTopic.id);
      toast.success(t('topics.deleteSuccess'));
      setDeleteTopic(null);
      loadTopics();
    } catch (err) {
      toast.error(t('topics.deleteError'));
      console.error(err);
    } finally {
      setIsDeleting(false);
    }
  };

  const selectedSubjectData = subjects.find((s) => s.id === selectedSubject);

  return (
    <div className="space-y-6">
      <PageHeader
        icon={Tags}
        title={t('topics.title')}
        description={t('topics.description')}
        badge={
          topics.length > 0 && (
            <Badge variant="secondary">
              {topics.length} {t('topics.title').toLowerCase()}
            </Badge>
          )
        }
        action={
          selectedSubject && (
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              {t('topics.create')}
            </Button>
          )
        }
      />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-3 rounded-lg border bg-card p-3 sm:p-4">
        <Select value={selectedSubject} onValueChange={setSelectedSubject}>
          <SelectTrigger className="w-full sm:w-[250px]">
            <SelectValue placeholder={t('subjects.selectFaculty')} />
          </SelectTrigger>
          <SelectContent>
            {subjects.map((subject) => (
              <SelectItem key={subject.id} value={subject.id}>
                {subject.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {selectedSubject && (
          <div className="relative flex-1 min-w-0 sm:min-w-[200px] sm:max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder={t('topics.searchTopics')}
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              className="pl-9"
            />
          </div>
        )}
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-md bg-destructive/10 p-4 text-destructive">
          {error}
        </div>
      )}

      {/* No subject selected */}
      {!selectedSubject && subjects.length > 0 && (
        <EmptyState
          title={t('topics.noTopics')}
          description="Select a course to manage its topics"
        />
      )}

      {/* No subjects available */}
      {subjects.length === 0 && !isLoading && (
        <EmptyState
          title={t('subjects.noSubjectsAssigned')}
          description={t('subjects.noSubjectsAssignedDescription')}
        />
      )}

      {/* Topics Table */}
      {selectedSubject && (
        <>
          {!isLoading && topics.length === 0 && !searchValue ? (
            <EmptyState
              title={t('topics.noTopics')}
              description={t('topics.noTopicsDescription')}
              action={
                <Button onClick={() => setCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  {t('topics.create')}
                </Button>
              }
            />
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table className="table-fixed">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[30%] min-w-[180px]">{t('topics.name')}</TableHead>
                    <TableHead className="w-[35%] min-w-[200px]">{t('topics.descriptionField')}</TableHead>
                    <TableHead className="w-[100px] text-center">{t('topics.questionCount')}</TableHead>
                    <TableHead className="w-[90px]">{t('common.status')}</TableHead>
                    <TableHead className="w-[60px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>
                        <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-48" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-12 mx-auto" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                      </TableRow>
                    ))
                  ) : topics.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center">
                        {t('topics.noTopicsFound')}
                      </TableCell>
                    </TableRow>
                  ) : (
                    topics.map((topic) => (
                      <TableRow key={topic.id}>
                        <TableCell>
                          <div className="min-w-0">
                            <p className="font-medium truncate">{topic.name}</p>
                            {topic.nameAr && (
                              <p className="text-sm text-muted-foreground truncate" dir="rtl">
                                {topic.nameAr}
                              </p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm text-muted-foreground truncate">
                            {topic.description || '-'}
                          </p>
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1">
                            <HelpCircle className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{topic.questionCount}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={topic.isActive ? 'default' : 'secondary'}>
                            {topic.isActive ? t('common.active') : t('common.inactive')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setEditTopic(topic)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                {t('common.edit')}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => setDeleteTopic(topic)}
                                className="text-destructive"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                {t('common.delete')}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </>
      )}

      {/* Create Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('topics.create')}</DialogTitle>
            <DialogDescription>{t('topics.createDescription')}</DialogDescription>
          </DialogHeader>
          <TopicForm
            onSubmit={handleCreate}
            onCancel={() => setCreateDialogOpen(false)}
            isLoading={isSubmitting}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editTopic} onOpenChange={(open) => !open && setEditTopic(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('topics.edit')}</DialogTitle>
            <DialogDescription>{t('topics.editDescription')}</DialogDescription>
          </DialogHeader>
          {editTopic && (
            <TopicForm
              topic={editTopic}
              onSubmit={handleUpdate}
              onCancel={() => setEditTopic(null)}
              isLoading={isSubmitting}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={!!deleteTopic}
        onOpenChange={(open) => !open && setDeleteTopic(null)}
        title={t('topics.deleteTitle')}
        description={t('topics.deleteDescription')}
        confirmLabel={t('common.delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />
    </div>
  );
}
