'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslations } from 'next-intl';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import type { Topic, CreateTopicData, UpdateTopicData } from '@/lib/api/topics';

const topicSchema = z.object({
  name: z.string().min(1, 'Name is required').max(100),
  nameAr: z.string().optional(),
  description: z.string().optional(),
  descriptionAr: z.string().optional(),
  isActive: z.boolean().optional(),
});

type TopicFormData = z.infer<typeof topicSchema>;

interface TopicFormProps {
  topic?: Topic;
  onSubmit: (data: CreateTopicData | UpdateTopicData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export function TopicForm({ topic, onSubmit, onCancel, isLoading = false }: TopicFormProps) {
  const t = useTranslations();
  const isEditing = !!topic;

  const form = useForm<TopicFormData>({
    resolver: zodResolver(topicSchema),
    defaultValues: {
      name: topic?.name ?? '',
      nameAr: topic?.nameAr ?? '',
      description: topic?.description ?? '',
      descriptionAr: topic?.descriptionAr ?? '',
      isActive: topic?.isActive ?? true,
    },
  });

  const handleSubmit = async (data: TopicFormData) => {
    await onSubmit(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('topics.name')}</FormLabel>
                <FormControl>
                  <Input placeholder={t('topics.namePlaceholder')} {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="nameAr"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('topics.nameAr')}</FormLabel>
                <FormControl>
                  <Input
                    placeholder={t('topics.nameArPlaceholder')}
                    dir="rtl"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('topics.descriptionField')}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder={t('topics.descriptionPlaceholder')}
                  className="resize-none"
                  rows={2}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="descriptionAr"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t('topics.descriptionAr')}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder={t('topics.descriptionArPlaceholder')}
                  className="resize-none"
                  dir="rtl"
                  rows={2}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {isEditing && (
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{t('common.active')}</FormLabel>
                  <FormDescription>
                    {t('questions.activeDescription')}
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        <div className="flex justify-end gap-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEditing ? t('common.save') : t('common.create')}
          </Button>
        </div>
      </form>
    </Form>
  );
}
