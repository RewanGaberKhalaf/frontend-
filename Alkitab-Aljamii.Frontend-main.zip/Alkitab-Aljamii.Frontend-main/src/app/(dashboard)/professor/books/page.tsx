'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { BookText, Plus, Eye, Trash2, Edit, Send, MoreHorizontal } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ServerDataTable } from '@/components/shared/data-table';
import {
  EmptyState,
  PageHeader,
  FilterBar,
  FilterGroup,
  SearchInput,
  BookStatusFilter,
  SubjectFilter,
} from '@/components/shared';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useServerTable, useSubjectOptions } from '@/hooks';
import { booksApi } from '@/lib/api/books';
import { subjectsApi } from '@/lib/api/subjects';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import { ROUTES } from '@/lib/constants/routes';
import { BookFormDialog } from '@/components/books/book-form-dialog';
import type { ColumnDef } from '@tanstack/react-table';
import type { BookListItem, BookStatus, Subject, BookQueryParams, PaginationParams } from '@/types';

const statusVariants: Record<BookStatus, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  draft: 'secondary',
  pending_review: 'outline',
  approved: 'default',
  rejected: 'destructive',
  published: 'default',
};


type BookFilters = Omit<BookQueryParams, keyof PaginationParams>;

export default function ProfessorBooksPage() {
  const t = useTranslations();
  const router = useRouter();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editBook, setEditBook] = useState<BookListItem | null>(null);

  const {
    data: books,
    meta,
    isLoading,
    searchValue,
    sortBy,
    sortOrder,
    filters,
    setPage,
    setPageSize,
    setSearch,
    setSort,
    setFilter,
    refetch,
  } = useServerTable<BookListItem, BookFilters>({
    fetchFn: booksApi.getAll,
    initialPageSize: 10,
  });

  const handleStatusFilter = (value: string | undefined) => {
    setFilter('status', value as BookStatus | undefined);
  };

  const handleSubjectFilter = (value: string | undefined) => {
    setFilter('subjectId', value);
  };

  // Load subjects for creating books (still need Subject[] for dialog)
  useEffect(() => {
    const loadSubjects = async () => {
      try {
        const params = currentFacultyId ? { facultyId: currentFacultyId } : {};
        const result = await subjectsApi.getAll(params);
        setSubjects(result.items);
      } catch {
        // Silently fail
      }
    };
    loadSubjects();
  }, [currentFacultyId]);

  const hasSubjects = subjects.length > 0;

  const handleDelete = async (id: string) => {
    if (!confirm(t('books.deleteConfirm'))) return;
    try {
      await booksApi.delete(id);
      toast.success(t('books.deleteSuccess'));
      refetch();
    } catch {
      toast.error(t('books.deleteError'));
    }
  };

  const handleSubmitForReview = async (id: string) => {
    try {
      await booksApi.submit(id);
      toast.success(t('books.submitSuccess'));
      refetch();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('books.submitError');
      toast.error(message);
    }
  };

  const columns: ColumnDef<BookListItem>[] = [
    {
      accessorKey: 'title',
      header: t('books.bookTitle'),
      enableSorting: true,
      cell: ({ row }) => (
        <div>
          <div className="font-medium">{row.original.title}</div>
          {row.original.titleAr && (
            <div className="text-sm text-muted-foreground" dir="rtl">
              {row.original.titleAr}
            </div>
          )}
        </div>
      ),
    },
    { accessorKey: 'subjectName', header: t('subjects.title'), enableSorting: false },
    {
      accessorKey: 'chapterCount',
      header: t('books.chapters'),
      enableSorting: false,
      cell: ({ row }) => (
        <span className="text-muted-foreground">{row.original.chapterCount}</span>
      ),
    },
    {
      accessorKey: 'status',
      header: t('content.status'),
      enableSorting: true,
      cell: ({ row }) => (
        <Badge variant={statusVariants[row.original.status]}>
          {t(`books.status.${row.original.status}`)}
        </Badge>
      ),
    },
    {
      accessorKey: 'updatedAt',
      header: t('common.lastUpdated'),
      enableSorting: true,
      cell: ({ row }) => new Date(row.original.updatedAt).toLocaleDateString(),
    },
    {
      id: 'actions',
      cell: ({ row }) => {
        const book = row.original;
        const canEdit = book.status === 'draft' || book.status === 'rejected';
        const canSubmit = (book.status === 'draft' || book.status === 'rejected') && book.chapterCount > 0;

        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href={ROUTES.PROFESSOR.BOOK_EDITOR(book.id)}>
                  {canEdit ? (
                    <>
                      <Edit className="h-4 w-4 me-2" />
                      {t('common.edit')}
                    </>
                  ) : (
                    <>
                      <Eye className="h-4 w-4 me-2" />
                      {t('common.view')}
                    </>
                  )}
                </Link>
              </DropdownMenuItem>
              {canSubmit && (
                <DropdownMenuItem onClick={() => handleSubmitForReview(book.id)}>
                  <Send className="h-4 w-4 me-2" />
                  {t('books.submitForReview')}
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              {canEdit && (
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => handleDelete(book.id)}
                >
                  <Trash2 className="h-4 w-4 me-2" />
                  {t('common.delete')}
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  const defaultMeta = {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  };

  return (
    <div className="space-y-6">
      <PageHeader
        icon={BookText}
        title={t('books.myBooks')}
        description={t('books.myBooksDescription')}
        badge={meta && meta.total > 0 && <Badge variant="secondary">{meta.total}</Badge>}
        action={
          <Button onClick={() => setCreateDialogOpen(true)} disabled={!hasSubjects}>
            <Plus className="me-2 h-4 w-4" />
            {t('books.createBook')}
          </Button>
        }
      />

      {!isLoading && !hasSubjects && (
        <Alert>
          <BookText className="h-4 w-4" />
          <AlertDescription>
            {t('books.needSubjectsAlert')}
          </AlertDescription>
        </Alert>
      )}

      {/* Filters */}
      <FilterBar>
        <SearchInput
          value={searchValue}
          onChange={setSearch}
          placeholder={t('books.searchPlaceholder')}
        />
        <FilterGroup>
          <BookStatusFilter
            value={filters.status as string | undefined}
            onChange={handleStatusFilter}
          />
          <SubjectFilter
            value={filters.subjectId as string | undefined}
            onChange={handleSubjectFilter}
            facultyId={currentFacultyId ?? undefined}
          />
        </FilterGroup>
      </FilterBar>

      {!isLoading && books.length === 0 && !searchValue ? (
        <EmptyState
          title={t('books.noBooksYet')}
          description={hasSubjects
            ? t('books.createFirstBook')
            : t('books.needSubjectsFirst')
          }
          action={hasSubjects ? (
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="me-2 h-4 w-4" />
              {t('books.createBook')}
            </Button>
          ) : undefined}
        />
      ) : (
        <ServerDataTable
          columns={columns}
          data={books}
          meta={meta ?? defaultMeta}
          isLoading={isLoading}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          onSortChange={setSort}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      )}

      <BookFormDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        subjects={subjects}
        onSuccess={(book) => {
          setCreateDialogOpen(false);
          router.push(ROUTES.PROFESSOR.BOOK_EDITOR(book.id));
        }}
      />
    </div>
  );
}
