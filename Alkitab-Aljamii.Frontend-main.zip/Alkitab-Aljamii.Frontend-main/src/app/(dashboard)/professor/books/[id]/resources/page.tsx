'use client';

import { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Upload,
  FileText,
  Image,
  Music,
  Video,
  Archive,
  Download,
  Trash2,
  Pencil,
  FolderOpen,
  BookOpen,
  Link as LinkIcon,
  ExternalLink,
  Youtube,
  Globe,
  FileUp,
  Plus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { booksApi } from '@/lib/api/books';
import { MediaLibraryConnected } from '@/components/shared/rich-text-editor/media-library-connected';
import type { MediaItem } from '@/lib/api/media';
import type { BookResource, GroupedBookResources, Chapter, LinkType } from '@/types';

const FILE_CATEGORY_ICONS = {
  document: FileText,
  image: Image,
  audio: Music,
  video: Video,
  archive: Archive,
  link: LinkIcon,
} as const;

const LINK_TYPE_ICONS = {
  youtube: Youtube,
  vimeo: Video,
  website: Globe,
  document: FileText,
  drive: FolderOpen,
  other: LinkIcon,
} as const;

function formatFileSize(bytes: number | null): string {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

function getLinkDomain(url: string): string {
  try {
    const domain = new URL(url).hostname.replace('www.', '');
    return domain;
  } catch {
    return url;
  }
}

export default function BookResourcesPage() {
  const params = useParams();
  const router = useRouter();
  const t = useTranslations();
  const locale = useLocale();
  const bookId = params['id'] as string;
  const isRtl = locale === 'ar';

  const [resources, setResources] = useState<GroupedBookResources | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedResource, setSelectedResource] = useState<BookResource | null>(null);
  const [mediaLibraryOpen, setMediaLibraryOpen] = useState(false);

  // Add form state
  const [resourceMode, setResourceMode] = useState<'file' | 'link'>('file');
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadTitleAr, setUploadTitleAr] = useState('');
  const [uploadDescription, setUploadDescription] = useState('');
  const [uploadDescriptionAr, setUploadDescriptionAr] = useState('');
  const [uploadChapterId, setUploadChapterId] = useState<string>('');
  const [linkUrl, setLinkUrl] = useState('');
  const [linkType, setLinkType] = useState<LinkType>('website');

  // Edit form state
  const [editTitle, setEditTitle] = useState('');
  const [editTitleAr, setEditTitleAr] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editDescriptionAr, setEditDescriptionAr] = useState('');
  const [editUrl, setEditUrl] = useState('');

  const loadResources = useCallback(async () => {
    try {
      const [resourcesData, chaptersData] = await Promise.all([
        booksApi.getResources(bookId),
        booksApi.getChapters(bookId),
      ]);
      setResources(resourcesData);
      setChapters(chaptersData);
    } catch (error) {
      console.error('[Resources] Failed to load:', error);
      toast.error(t('common.errorLoading'));
    } finally {
      setIsLoading(false);
    }
  }, [bookId, t]);

  useEffect(() => {
    loadResources();
  }, [loadResources]);

  const resetAddForm = () => {
    setResourceMode('file');
    setSelectedMedia(null);
    setUploadTitle('');
    setUploadTitleAr('');
    setUploadDescription('');
    setUploadDescriptionAr('');
    setUploadChapterId('');
    setLinkUrl('');
    setLinkType('website');
  };

  const handleMediaSelect = (media: MediaItem) => {
    setSelectedMedia(media);
    if (!uploadTitle) {
      setUploadTitle(media.name);
    }
  };

  const handleAdd = async () => {
    if (!uploadTitle.trim()) {
      toast.error(t('resources.titleRequired'));
      return;
    }

    if (resourceMode === 'file') {
      if (!selectedMedia) {
        toast.error(t('resources.selectFile'));
        return;
      }
    } else {
      if (!linkUrl.trim()) {
        toast.error(t('resources.urlRequired'));
        return;
      }
      try {
        new URL(linkUrl);
      } catch {
        toast.error(t('resources.invalidUrl'));
        return;
      }
    }

    setIsSubmitting(true);
    try {
      if (resourceMode === 'file' && selectedMedia) {
        await booksApi.createMediaResource(bookId, {
          title: uploadTitle,
          titleAr: uploadTitleAr || undefined,
          mediaId: selectedMedia.id,
          chapterId: uploadChapterId || undefined,
        });
      } else {
        await booksApi.createLinkResource(bookId, {
          title: uploadTitle,
          titleAr: uploadTitleAr || undefined,
          description: uploadDescription || undefined,
          descriptionAr: uploadDescriptionAr || undefined,
          url: linkUrl,
          linkType: linkType,
          chapterId: uploadChapterId || undefined,
        });
      }
      toast.success(resourceMode === 'file' ? t('resources.uploadSuccess') : t('resources.linkAddedSuccess'));
      setAddDialogOpen(false);
      resetAddForm();
      loadResources();
    } catch (error) {
      console.error('Add failed:', error);
      toast.error(resourceMode === 'file' ? t('resources.uploadFailed') : t('resources.addFailed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = async () => {
    if (!selectedResource) return;
    if (!editTitle.trim()) {
      toast.error(t('resources.titleRequired'));
      return;
    }

    if (selectedResource.resourceType === 'link' && editUrl) {
      try {
        new URL(editUrl);
      } catch {
        toast.error(t('resources.invalidUrl'));
        return;
      }
    }

    try {
      await booksApi.updateResource(bookId, selectedResource.id, {
        title: editTitle,
        titleAr: editTitleAr || undefined,
        description: editDescription || undefined,
        descriptionAr: editDescriptionAr || undefined,
        url: selectedResource.resourceType === 'link' ? editUrl : undefined,
      });
      toast.success(t('resources.updateSuccess'));
      setEditDialogOpen(false);
      loadResources();
    } catch (error) {
      console.error('Update failed:', error);
      toast.error(t('resources.updateFailed'));
    }
  };

  const handleDelete = async (resource: BookResource) => {
    if (!confirm(t('resources.deleteConfirm'))) return;

    try {
      await booksApi.deleteResource(bookId, resource.id);
      toast.success(t('resources.deleteSuccess'));
      loadResources();
    } catch (error) {
      console.error('Delete failed:', error);
      toast.error(t('resources.deleteFailed'));
    }
  };

  const handleDownload = async (resource: BookResource) => {
    try {
      const { url, fileName } = await booksApi.getResourceDownloadUrl(bookId, resource.id);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Download failed:', error);
      toast.error(t('resources.downloadFailed'));
    }
  };

  const handleOpenLink = (resource: BookResource) => {
    if (resource.url) {
      window.open(resource.url, '_blank', 'noopener,noreferrer');
    }
  };

  const openEditDialog = (resource: BookResource) => {
    setSelectedResource(resource);
    setEditTitle(resource.title);
    setEditTitleAr(resource.titleAr || '');
    setEditDescription(resource.description || '');
    setEditDescriptionAr(resource.descriptionAr || '');
    setEditUrl(resource.url || '');
    setEditDialogOpen(true);
  };

  const ResourceCard = ({ resource }: { resource: BookResource }) => {
    const isLink = resource.resourceType === 'link';
    const Icon = isLink
      ? (LINK_TYPE_ICONS[resource.linkType as keyof typeof LINK_TYPE_ICONS] || LinkIcon)
      : (FILE_CATEGORY_ICONS[resource.fileCategory as keyof typeof FILE_CATEGORY_ICONS] || FileText);
    const title = isRtl && resource.titleAr ? resource.titleAr : resource.title;
    const description = isRtl && resource.descriptionAr ? resource.descriptionAr : resource.description;

    return (
      <Card className="group hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${
              isLink ? 'bg-blue-100 dark:bg-blue-900/30' : 'bg-muted'
            }`}>
              <Icon className={`w-5 h-5 ${isLink ? 'text-blue-600 dark:text-blue-400' : 'text-muted-foreground'}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h4 className="font-medium truncate">{title}</h4>
                {isLink && (
                  <Badge variant="outline" className="text-xs shrink-0">
                    {resource.linkType || 'link'}
                  </Badge>
                )}
              </div>
              {description && (
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{description}</p>
              )}
              <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                {isLink ? (
                  <span className="truncate max-w-[200px]">{getLinkDomain(resource.url || '')}</span>
                ) : (
                  <>
                    <Badge variant="secondary" className="text-xs">
                      {resource.fileCategory}
                    </Badge>
                    <span>{formatFileSize(resource.fileSize)}</span>
                  </>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {isLink ? (
                <Button variant="ghost" size="icon" onClick={() => handleOpenLink(resource)} title={t('resources.openLink')}>
                  <ExternalLink className="w-4 h-4" />
                </Button>
              ) : (
                <Button variant="ghost" size="icon" onClick={() => handleDownload(resource)} title={t('resources.download')}>
                  <Download className="w-4 h-4" />
                </Button>
              )}
              <Button variant="ghost" size="icon" onClick={() => openEditDialog(resource)} title={t('common.edit')}>
                <Pencil className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleDelete(resource)} title={t('common.delete')}>
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="container py-6 max-w-5xl">
        <Skeleton className="h-8 w-48 mb-6" />
        <div className="space-y-4">
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
    );
  }

  const bookLevelResources = resources?.bookLevel || [];
  const chapterLevelResources = resources?.chapterLevel || {};
  const totalResources = bookLevelResources.length + Object.values(chapterLevelResources).reduce((acc, arr) => acc + arr.length, 0);

  return (
    <div className="container py-6 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{t('resources.title')}</h1>
            <p className="text-sm text-muted-foreground">
              {t('resources.description')} • {totalResources} {t('resources.items')}
            </p>
          </div>
        </div>
        <Button onClick={() => setAddDialogOpen(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          {t('resources.addResource')}
        </Button>
      </div>

      {/* Resources Tabs */}
      <Tabs defaultValue="book" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="book" className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            {t('resources.bookLevel')}
            {bookLevelResources.length > 0 && (
              <Badge variant="secondary" className="ms-1">{bookLevelResources.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="chapters" className="flex items-center gap-2">
            <FolderOpen className="w-4 h-4" />
            {t('resources.chapterLevel')}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="book" className="mt-0">
          {bookLevelResources.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-12 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                  <BookOpen className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-medium mb-2">{t('resources.noBookResources')}</h3>
                <p className="text-sm text-muted-foreground mb-4 max-w-sm mx-auto">
                  {t('resources.noBookResourcesDescription')}
                </p>
                <Button variant="outline" onClick={() => setAddDialogOpen(true)} className="gap-2">
                  <Plus className="w-4 h-4" />
                  {t('resources.addFirst')}
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-3">
              {bookLevelResources.map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="chapters" className="mt-0">
          {chapters.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-12 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                  <FolderOpen className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-medium mb-2">{t('resources.noChapters')}</h3>
                <p className="text-sm text-muted-foreground">
                  {t('resources.noChaptersDescription')}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {chapters.map((chapter) => {
                const chapterResources = chapterLevelResources[chapter.id] || [];
                const chapterTitle = isRtl && chapter.titleAr ? chapter.titleAr : chapter.title;

                return (
                  <div key={chapter.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium text-primary">
                          {chapter.order}
                        </div>
                        <h3 className="font-medium">{chapterTitle}</h3>
                        <Badge variant="outline">{chapterResources.length}</Badge>
                      </div>
                    </div>
                    {chapterResources.length === 0 ? (
                      <Card className="border-dashed">
                        <CardContent className="py-6 text-center">
                          <p className="text-sm text-muted-foreground">
                            {t('resources.noChapterResources')}
                          </p>
                        </CardContent>
                      </Card>
                    ) : (
                      <div className="grid gap-3 ps-10">
                        {chapterResources.map((resource) => (
                          <ResourceCard key={resource.id} resource={resource} />
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Add Resource Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('resources.addResource')}</DialogTitle>
            <DialogDescription>{t('resources.addResourceDescription')}</DialogDescription>
          </DialogHeader>

          {/* Resource Type Tabs */}
          <Tabs value={resourceMode} onValueChange={(v) => setResourceMode(v as 'file' | 'link')} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="file" className="gap-2">
                <FileUp className="w-4 h-4" />
                {t('resources.uploadFile')}
              </TabsTrigger>
              <TabsTrigger value="link" className="gap-2">
                <LinkIcon className="w-4 h-4" />
                {t('resources.addLink')}
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="space-y-4 py-2">
            {resourceMode === 'file' ? (
              <div className="space-y-2">
                <Label>{t('resources.file')}</Label>
                {selectedMedia ? (
                  <div className="flex items-center gap-3 p-3 rounded-lg border bg-muted/50">
                    <div className="h-10 w-10 rounded bg-background flex items-center justify-center shrink-0">
                      {selectedMedia.type === 'image' ? (
                        <Image className="h-5 w-5 text-muted-foreground" />
                      ) : selectedMedia.type === 'video' ? (
                        <Video className="h-5 w-5 text-muted-foreground" />
                      ) : selectedMedia.type === 'document' ? (
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <Music className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{selectedMedia.name}</p>
                      <p className="text-xs text-muted-foreground">{selectedMedia.type}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0"
                      onClick={() => setSelectedMedia(null)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    className="w-full h-20 border-dashed"
                    onClick={() => setMediaLibraryOpen(true)}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <FileUp className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm">{t('resources.selectFromLibrary')}</span>
                    </div>
                  </Button>
                )}
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="url">{t('resources.url')}</Label>
                  <Input
                    id="url"
                    type="url"
                    value={linkUrl}
                    onChange={(e) => setLinkUrl(e.target.value)}
                    placeholder="https://..."
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="linkType">{t('resources.linkType')}</Label>
                  <Select value={linkType} onValueChange={(v) => setLinkType(v as LinkType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="youtube">YouTube</SelectItem>
                      <SelectItem value="vimeo">Vimeo</SelectItem>
                      <SelectItem value="drive">Google Drive</SelectItem>
                      <SelectItem value="document">{t('resources.document')}</SelectItem>
                      <SelectItem value="website">{t('resources.website')}</SelectItem>
                      <SelectItem value="other">{t('resources.other')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">{t('resources.titleEn')}</Label>
                <Input
                  id="title"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder={t('resources.titlePlaceholder')}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="titleAr">{t('resources.titleAr')}</Label>
                <Input
                  id="titleAr"
                  value={uploadTitleAr}
                  onChange={(e) => setUploadTitleAr(e.target.value)}
                  placeholder={t('resources.titleArPlaceholder')}
                  dir="rtl"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="description">{t('resources.descriptionEn')}</Label>
                <Textarea
                  id="description"
                  value={uploadDescription}
                  onChange={(e) => setUploadDescription(e.target.value)}
                  placeholder={t('resources.descriptionPlaceholder')}
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="descriptionAr">{t('resources.descriptionAr')}</Label>
                <Textarea
                  id="descriptionAr"
                  value={uploadDescriptionAr}
                  onChange={(e) => setUploadDescriptionAr(e.target.value)}
                  placeholder={t('resources.descriptionArPlaceholder')}
                  rows={2}
                  dir="rtl"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="chapter">{t('resources.attachTo')}</Label>
              <Select value={uploadChapterId} onValueChange={setUploadChapterId}>
                <SelectTrigger>
                  <SelectValue placeholder={t('resources.selectChapterOrBook')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t('resources.bookLevel')}</SelectItem>
                  {chapters.map((chapter) => (
                    <SelectItem key={chapter.id} value={chapter.id}>
                      {t('resources.chapter')} {chapter.order}: {isRtl && chapter.titleAr ? chapter.titleAr : chapter.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button
              onClick={handleAdd}
              disabled={isSubmitting || (resourceMode === 'file' ? !selectedMedia : !linkUrl)}
            >
              {isSubmitting ? t('common.saving') : t('resources.add')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Media Library Dialog */}
      <MediaLibraryConnected
        open={mediaLibraryOpen}
        onOpenChange={setMediaLibraryOpen}
        onSelect={handleMediaSelect}
        title={t('resources.selectFromLibrary')}
      />

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('resources.editTitle')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedResource?.resourceType === 'link' && (
              <div className="space-y-2">
                <Label htmlFor="editUrl">{t('resources.url')}</Label>
                <Input
                  id="editUrl"
                  type="url"
                  value={editUrl}
                  onChange={(e) => setEditUrl(e.target.value)}
                  dir="ltr"
                />
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="editTitle">{t('resources.titleEn')}</Label>
                <Input
                  id="editTitle"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editTitleAr">{t('resources.titleAr')}</Label>
                <Input
                  id="editTitleAr"
                  value={editTitleAr}
                  onChange={(e) => setEditTitleAr(e.target.value)}
                  dir="rtl"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="editDescription">{t('resources.descriptionEn')}</Label>
                <Textarea
                  id="editDescription"
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editDescriptionAr">{t('resources.descriptionAr')}</Label>
                <Textarea
                  id="editDescriptionAr"
                  value={editDescriptionAr}
                  onChange={(e) => setEditDescriptionAr(e.target.value)}
                  rows={2}
                  dir="rtl"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={handleEdit}>
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
