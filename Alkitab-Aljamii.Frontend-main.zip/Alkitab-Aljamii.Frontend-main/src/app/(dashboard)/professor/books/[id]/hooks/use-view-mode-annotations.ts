'use client';

import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { annotationsApi } from '@/lib/api/annotations';
import { useAnnotationStore, useAuthStore } from '@/stores';
import type { Annotation, CreateAnnotationDto, Chapter } from '@/types';

interface UseViewModeAnnotationsOptions {
  bookId: string;
  activeChapter: Chapter | undefined;
  activeChapterId: string | null;
  chapters: Chapter[];
  isEditMode: boolean;
}

export function useViewModeAnnotations({
  bookId,
  activeChapter,
  activeChapterId,
  chapters,
  isEditMode,
}: UseViewModeAnnotationsOptions) {
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [targetPage, setTargetPage] = useState<number | undefined>(undefined);
  const [focusedAnnotationId, setFocusedAnnotationId] = useState<string | null>(null);

  const user = useAuthStore((state) => state.user);
  const {
    setContext,
    setSidebarOpen,
    isSidebarOpen,
    selectAnnotation,
    setAnnotations: setStoreAnnotations,
  } = useAnnotationStore();

  const targetPageRef = useRef(targetPage);
  targetPageRef.current = targetPage;

  // Initialize annotation store with book ID
  useEffect(() => {
    if (bookId) {
      setContext(bookId);
    }
  }, [bookId, setContext]);

  // Fetch annotations when in view mode
  useEffect(() => {
    if (!isEditMode && activeChapter) {
      const fetchAnnotations = async () => {
        try {
          const data = await annotationsApi.getAllBookAnnotations(bookId, {
            chapterId: activeChapter.id,
            limit: 100,
          });
          setAnnotations(data.items);
          setStoreAnnotations(data.items, data.total);
        } catch {
          setAnnotations([]);
          setStoreAnnotations([]);
        }
      };

      fetchAnnotations();
    }
  }, [isEditMode, activeChapter?.id, bookId, setStoreAnnotations]);

  // Handle page change from viewer
  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
    if (targetPageRef.current && page === targetPageRef.current) {
      setTargetPage(undefined);
    }
  }, []);

  // Handle annotation create
  const handleAnnotationCreate = useCallback(async (data: CreateAnnotationDto) => {
    if (!activeChapter) return;
    try {
      const annotation = await annotationsApi.create({
        ...data,
        bookId,
        chapterId: activeChapter.id,
        pageNumber: currentPage,
      });
      setAnnotations((prev) => [annotation, ...prev]);
      setStoreAnnotations([annotation, ...annotations], annotations.length + 1);
      toast.success('Annotation created');
    } catch (error) {
      console.error('Failed to create annotation:', error);
      toast.error('Failed to create annotation');
      throw error;
    }
  }, [activeChapter, bookId, currentPage, annotations, setStoreAnnotations]);

  // Handle annotation click
  const handleAnnotationClick = useCallback((annotation: Annotation, setActiveChapterId: (id: string) => void) => {
    setSidebarOpen(true);
    selectAnnotation(annotation);

    if (annotation.chapterId && annotation.chapterId !== activeChapterId) {
      const chapter = chapters.find((ch) => ch.id === annotation.chapterId);
      if (chapter) {
        setActiveChapterId(chapter.id);
      }
    }
    if (annotation.pageNumber) {
      setTargetPage(annotation.pageNumber);
    }
    setTimeout(() => {
      setFocusedAnnotationId(annotation.id);
      setTimeout(() => setFocusedAnnotationId(null), 4000);
    }, 500);
  }, [activeChapterId, chapters, setSidebarOpen, selectAnnotation]);

  // Chapter info for sidebar
  const chapterInfos = useMemo(() =>
    chapters.map((ch) => ({ id: ch.id, title: ch.title })),
    [chapters]
  );

  // Watermark text for view mode
  const watermarkText = useMemo(() => {
    if (user?.email) return user.email;
    if (user?.firstName) return `${user.firstName} ${user.lastName || ''}`.trim();
    return 'Professor View';
  }, [user]);

  return {
    annotations,
    currentPage,
    targetPage,
    focusedAnnotationId,
    user,
    isSidebarOpen,
    setSidebarOpen,
    chapterInfos,
    watermarkText,
    handlePageChange,
    handleAnnotationCreate,
    handleAnnotationClick,
  };
}
