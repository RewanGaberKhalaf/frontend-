'use client';

import { memo } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  History,
  Eye,
  EyeOff,
  Save,
  FileText,
  Library,
  ClipboardList,
  Menu,
  MoreVertical,
  MessageSquare,
  Check,
  Pencil,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { ROUTES } from '@/lib/constants/routes';
import { BookStatusDisplay } from './book-status-display';
import { BookPrimaryAction } from './book-primary-action';
import type { Book, Chapter } from '@/types';

interface BookEditorHeaderProps {
  book: Book;
  chapters: Chapter[];
  activeChapter: Chapter | undefined;
  isEditMode: boolean;
  canEdit: boolean;
  isSaving: boolean;
  hasUnsavedChanges: boolean;
  showPreview: boolean;
  previewMode: 'chapter' | 'book';
  isSidebarOpen: boolean;
  annotationsCount: number;
  isSubmitting?: boolean;
  t: (key: string) => string;
  onSetIsEditMode: (mode: boolean) => void;
  onSetShowPreview: (show: boolean) => void;
  onSetPreviewMode: (mode: 'chapter' | 'book') => void;
  onSetMobileSidebarOpen: (open: boolean) => void;
  onSetVersionDialogOpen: (open: boolean) => void;
  onOpenHistory: () => void;
  onSubmitForReview: () => void;
  onPublish?: () => void;
  onToggleSidebar: () => void;
}

export const BookEditorHeader = memo(function BookEditorHeader({
  book,
  chapters,
  activeChapter,
  isEditMode,
  canEdit,
  isSaving,
  hasUnsavedChanges,
  showPreview,
  previewMode,
  isSidebarOpen,
  annotationsCount,
  isSubmitting = false,
  t,
  onSetIsEditMode,
  onSetShowPreview,
  onSetPreviewMode,
  onSetMobileSidebarOpen,
  onSetVersionDialogOpen,
  onOpenHistory,
  onSubmitForReview,
  onPublish,
  onToggleSidebar,
}: BookEditorHeaderProps) {
  return (
    <div className="shrink-0 border-b bg-background px-3 py-2 md:px-4 md:py-3">
      <div className="flex items-center justify-between gap-2">
        {/* Left side: Back + Title + Status */}
        <div className="flex items-center gap-2 md:gap-4 min-w-0 flex-1">
          <Button variant="ghost" size="icon" className="shrink-0" asChild>
            <Link href={ROUTES.PROFESSOR.BOOKS}>
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="shrink-0 md:hidden"
            onClick={() => onSetMobileSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>

          <div className="min-w-0 flex-1">
            <h1 className="text-base md:text-xl font-semibold truncate">{book.title}</h1>
            <BookStatusDisplay
              status={book.status}
              hasPendingChanges={book.hasPendingChanges}
              isSaving={isSaving && !!activeChapter}
              hasUnsavedChanges={hasUnsavedChanges && !!activeChapter}
              isEditMode={isEditMode}
              t={t}
              className="text-xs md:text-sm"
            />
          </div>
        </div>

        {/* Right side: Actions */}
        <div className="flex items-center gap-1.5 md:gap-2 shrink-0">
          {/* Edit/View Mode Toggle - only show for published books (there's content to view) */}
          {canEdit && book.status === 'published' && (
            <div className="flex items-center border rounded-md overflow-hidden bg-muted/50">
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  "h-8 rounded-none border-0 gap-1.5 hover:bg-muted",
                  !isEditMode && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground shadow-sm"
                )}
                onClick={() => onSetIsEditMode(false)}
              >
                <Eye className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">View</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  "h-8 rounded-none border-0 gap-1.5 hover:bg-muted",
                  isEditMode && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground shadow-sm"
                )}
                onClick={() => onSetIsEditMode(true)}
              >
                <Pencil className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Edit</span>
              </Button>
            </div>
          )}

          {/* View mode: Chapter/Book toggle - only for published books */}
          {!isEditMode && book.status === 'published' && (
            <>
              <div className="hidden md:flex items-center border rounded-md overflow-hidden bg-muted/50">
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "h-8 rounded-none border-0 text-xs hover:bg-muted",
                    previewMode === 'chapter' && "bg-background shadow-sm font-medium"
                  )}
                  onClick={() => onSetPreviewMode('chapter')}
                >
                  {t('books.chapterView')}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "h-8 rounded-none border-0 text-xs hover:bg-muted",
                    previewMode === 'book' && "bg-background shadow-sm font-medium"
                  )}
                  onClick={() => onSetPreviewMode('book')}
                >
                  {t('books.fullBook')}
                </Button>
              </div>

              {previewMode === 'chapter' && (
                <Button
                  variant={isSidebarOpen ? 'secondary' : 'ghost'}
                  size="icon"
                  className="h-8 w-8 relative"
                  onClick={onToggleSidebar}
                >
                  <MessageSquare className="h-4 w-4" />
                  {annotationsCount > 0 && (
                    <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] text-primary-foreground flex items-center justify-center">
                      {annotationsCount > 99 ? '99+' : annotationsCount}
                    </span>
                  )}
                </Button>
              )}
            </>
          )}

          {/* Primary Action Button - only show in edit mode */}
          {canEdit && isEditMode && (
            <BookPrimaryAction
              status={book.status}
              hasPendingChanges={book.hasPendingChanges}
              hasChapters={chapters.length > 0}
              isSubmitting={isSubmitting}
              t={t}
              onSubmit={onSubmitForReview}
              onPublish={onPublish}
            />
          )}

          {/* More actions dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              {/* View mode options - only for published books */}
              {!isEditMode && book.status === 'published' && (
                <>
                  <DropdownMenuLabel className="text-xs">{t('books.chapterView')}</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => onSetPreviewMode('chapter')}>
                    <FileText className="h-4 w-4 me-2" />
                    {t('books.chapterView')}
                    {previewMode === 'chapter' && <Check className="h-4 w-4 ms-auto" />}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onSetPreviewMode('book')}>
                    <Library className="h-4 w-4 me-2" />
                    {t('books.fullBook')}
                    {previewMode === 'book' && <Check className="h-4 w-4 ms-auto" />}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                </>
              )}

              {isEditMode && (
                <>
                  <DropdownMenuItem onClick={() => onSetShowPreview(!showPreview)}>
                    {showPreview ? <EyeOff className="h-4 w-4 me-2" /> : <Eye className="h-4 w-4 me-2" />}
                    {showPreview ? 'Hide Side Preview' : 'Show Side Preview'}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                </>
              )}

              {/* View Annotations - only in view mode for published books */}
              {!isEditMode && book.status === 'published' && (
                <>
                  <DropdownMenuItem asChild>
                    <Link href={`/professor/books/${book.id}/annotations`}>
                      <ClipboardList className="h-4 w-4 me-2" />
                      View Annotations
                    </Link>
                  </DropdownMenuItem>
                  {canEdit && <DropdownMenuSeparator />}
                </>
              )}

              {canEdit && isEditMode && <DropdownMenuSeparator />}

              {/* Edit-specific actions - only in edit mode */}
              {canEdit && isEditMode && (
                <>
                  <DropdownMenuItem onClick={() => onSetVersionDialogOpen(true)}>
                    <Save className="h-4 w-4 me-2" />
                    {t('books.saveCheckpoint')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onOpenHistory}>
                    <History className="h-4 w-4 me-2" />
                    {t('books.versionHistory')}
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
});
