'use client';

import { memo } from 'react';
import type { Editor } from '@tiptap/react';
import { EditorContent } from '@tiptap/react';
import { BookOpen, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { EditorToolbar } from '@/components/shared/rich-text-editor/editor-toolbar';
import { TableFloatingToolbar } from '@/components/shared/rich-text-editor/table-floating-toolbar';
import { PaginatedPreview, type PageBoundary } from '@/components/shared/rich-text-editor/paginated-preview';
import { SecureBookViewer } from '@/components/shared/secure-book-viewer';
import { AnnotationSidebar } from '@/components/annotations';
import { MobileEditorToolbar } from './mobile-editor-toolbar';
import { cn } from '@/lib/utils';
import type { Book, Chapter, Annotation, CreateAnnotationDto } from '@/types';

interface EditorContentAreaProps {
  book: Book;
  chapters: Chapter[];
  activeChapter: Chapter | undefined;
  editor: Editor | null;
  isEditMode: boolean;
  canEdit: boolean;
  showPreview: boolean;
  previewMode: 'chapter' | 'book';
  fullBookHtml: string;
  watermarkText: string;
  annotations: Annotation[];
  currentPage: number;
  targetPage: number | undefined;
  focusedAnnotationId: string | null;
  chapterInfos: { id: string; title: string }[];
  userId: string | undefined;
  isSidebarOpen: boolean;
  t: (key: string) => string;
  onOpenMediaLibrary: () => void;
  onSetAddingChapter: (adding: boolean) => void;
  onBoundariesComputed: (boundaries: PageBoundary[], pageCount: number) => void;
  onAnnotationCreate: (data: CreateAnnotationDto) => Promise<void>;
  onAnnotationClick: (annotation: Annotation) => void;
  onPageChange: (page: number) => void;
}

export const EditorContentArea = memo(function EditorContentArea({
  book,
  chapters,
  activeChapter,
  editor,
  isEditMode,
  canEdit,
  showPreview,
  previewMode,
  fullBookHtml,
  watermarkText,
  annotations,
  currentPage,
  targetPage,
  focusedAnnotationId,
  chapterInfos,
  userId,
  isSidebarOpen,
  t,
  onOpenMediaLibrary,
  onSetAddingChapter,
  onBoundariesComputed,
  onAnnotationCreate,
  onAnnotationClick,
  onPageChange,
}: EditorContentAreaProps) {
  if (!activeChapter) {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/30">
        <div className="text-center max-w-md p-8">
          <div className="mx-auto w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <BookOpen className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">{t('books.getStarted')}</h3>
          <p className="text-muted-foreground mb-6">{t('books.getStartedDescription')}</p>
          {canEdit && (
            <Button onClick={() => onSetAddingChapter(true)}>
              <Plus className="h-4 w-4 me-2" />
              {t('books.addFirstChapter')}
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Toolbar - only shown in edit mode */}
      {isEditMode && canEdit && (
        <>
          {/* Desktop toolbar */}
          <div className="shrink-0 border-b bg-background hidden md:block">
            <EditorToolbar
              editor={editor}
              enableTable={true}
              enableCodeBlock={true}
              enableMedia={true}
              onOpenMediaLibrary={onOpenMediaLibrary}
            />
          </div>

          {/* Mobile compact toolbar */}
          <MobileEditorToolbar
            editor={editor}
            onOpenMediaLibrary={onOpenMediaLibrary}
          />
        </>
      )}

      {/* Content area */}
      {isEditMode ? (
        /* Edit Mode: Editor with optional side-by-side preview */
        <div className={cn("flex-1 flex min-h-0", showPreview && "gap-2 md:gap-4")}>
          {/* Editor Panel */}
          <div className={cn("flex-1 overflow-auto bg-muted/30", showPreview && "max-w-[50%] hidden md:block")}>
            <div className="max-w-4xl mx-auto p-4 md:p-8">
              <div className="bg-background rounded-lg shadow-sm border p-4 md:p-8 chapter-editor relative">
                <EditorContent editor={editor} />
                {editor && <TableFloatingToolbar editor={editor} />}
              </div>
            </div>
          </div>

          {/* Side Preview Panel */}
          {showPreview && (
            <div className="flex-1 border-l bg-muted/30 w-full md:max-w-[50%] flex flex-col">
              <PaginatedPreview
                html={previewMode === 'book' ? fullBookHtml : (editor?.getHTML() || '')}
                className="flex-1"
                zoom={0.5}
                title={previewMode === 'book' ? book?.title : activeChapter?.title}
                chapterTitles={previewMode === 'book' ? chapters.map(ch => ch.title) : undefined}
                onBoundariesComputed={previewMode === 'chapter' ? onBoundariesComputed : undefined}
              />
            </div>
          )}
        </div>
      ) : (
        /* View Mode: SecureBookViewer with annotations */
        <div className="flex-1 flex min-h-0">
          <div className="flex-1 overflow-hidden">
            {previewMode === 'book' ? (
              <PaginatedPreview
                html={fullBookHtml}
                className="h-full"
                zoom={0.6}
                title={book?.title}
                chapterTitles={chapters.map(ch => ch.title)}
                showSettings={false}
                showPrint={true}
              />
            ) : (
              <SecureBookViewer
                mode="local"
                html={activeChapter.publishedContent || activeChapter.content || ''}
                title={activeChapter?.title}
                watermarkText={watermarkText}
                showWatermark
                enableProtection={false}
                showPageNumbers
                enableAnnotations
                annotations={annotations}
                onAnnotationCreate={onAnnotationCreate}
                onAnnotationClick={onAnnotationClick}
                currentPageForAnnotation={currentPage}
                targetPage={targetPage}
                onPageChange={onPageChange}
                focusedAnnotationId={focusedAnnotationId}
                currentUserId={userId}
                showAllHighlights
                isProfessor
                bookId={book.id}
                chapterId={activeChapter.id}
              />
            )}
          </div>

          {/* Annotation Sidebar */}
          {previewMode === 'chapter' && (
            <AnnotationSidebar
              chapters={chapterInfos}
              onAnnotationClick={onAnnotationClick}
            />
          )}
        </div>
      )}
    </>
  );
});
