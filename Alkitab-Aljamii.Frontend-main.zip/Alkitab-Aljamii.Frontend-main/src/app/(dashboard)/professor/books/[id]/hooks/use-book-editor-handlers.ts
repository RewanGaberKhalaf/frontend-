'use client';

import { useCallback, useRef } from 'react';
import { toast } from 'sonner';
import { computeBoundariesFromHtml } from '@/lib/compute-boundaries';
import { booksApi } from '@/lib/api/books';
import { htmlToJson } from '@/components/shared/rich-text-editor/html-to-json';
import type { PageBoundary } from '@/components/shared/rich-text-editor/paginated-preview';
import type { Book, Chapter, Annotation, ProseMirrorDoc } from '@/types';
import type { Editor } from '@tiptap/react';

interface UseBookEditorHandlersOptions {
  bookId: string;
  bookEditor: {
    book: Book | null;
    activeChapterId: string | null;
    canEdit: boolean;
    chapters: Chapter[];
    previewMode: 'chapter' | 'book';
    hasUnsavedChanges: boolean;
    setIsSaving: (val: boolean) => void;
    setChapters: React.Dispatch<React.SetStateAction<Chapter[]>>;
    setHasUnsavedChanges: (val: boolean) => void;
    setHasSessionChanges: (val: boolean) => void;
    setBook: (book: Book) => void;
    setActiveChapterId: (id: string | null) => void;
    setHistoryDialogOpen: (open: boolean) => void;
    handleDiscardSession: (editor: Editor) => Promise<void>;
  };
  editor: Editor | null;
  clearSaveTimeout: () => void;
  setEditorContent: (content: string) => void;
  reloadActiveChapter: (chapter: Chapter) => void;
  viewAnnotations: {
    handleAnnotationClick: (annotation: Annotation, setActiveChapterId: (id: string | null) => void) => void;
  };
  handleTocClick: (chapterId: string, tocIndex: number, setActiveChapterId: (id: string | null) => void) => void;
  t: (key: string) => string;
}

export function useBookEditorHandlers(options: UseBookEditorHandlersOptions) {
  const { bookId, bookEditor, editor, clearSaveTimeout, setEditorContent, reloadActiveChapter, viewAnnotations, handleTocClick, t } = options;

  const pendingBoundariesRef = useRef<{ boundaries: PageBoundary[]; pageCount: number } | null>(null);

  const saveChapterContent = useCallback(
    async (editorInstance: Editor | null) => {
      if (!bookEditor.activeChapterId || !bookEditor.canEdit || !editorInstance) return;

      try {
        bookEditor.setIsSaving(true);
        const contentJson = editorInstance.getJSON();
        const content = editorInstance.getHTML();

        await booksApi.updateChapter(bookId, bookEditor.activeChapterId, {
          contentJson: contentJson as ProseMirrorDoc,
          content,
        });

        if (pendingBoundariesRef.current) {
          try {
            await booksApi.savePageBoundaries(bookId, bookEditor.activeChapterId, {
              boundaries: pendingBoundariesRef.current.boundaries,
              pageCount: pendingBoundariesRef.current.pageCount,
            });
            pendingBoundariesRef.current = null;
          } catch {
            // Non-critical
          }
        }

        bookEditor.setChapters((prev) =>
          prev.map((ch) =>
            ch.id === bookEditor.activeChapterId
              ? { ...ch, contentJson: contentJson as ProseMirrorDoc, content }
              : ch
          )
        );
        bookEditor.setHasUnsavedChanges(false);
        bookEditor.setHasSessionChanges(true);

        // If this is a published book and we just saved, the backend will set hasPendingChanges
        // Update the book state optimistically to show the banner
        if (bookEditor.book?.status === 'published' && !bookEditor.book.hasPendingChanges) {
          bookEditor.setBook({
            ...bookEditor.book,
            hasPendingChanges: true,
            pendingChangesAt: new Date(),
          });
        }
      } catch {
        toast.error(t('books.saveError'));
      } finally {
        bookEditor.setIsSaving(false);
      }
    },
    [bookEditor, bookId, t]
  );

  const handleSave = useCallback(() => {
    clearSaveTimeout();
    if (editor) {
      saveChapterContent(editor);
    }
  }, [editor, saveChapterContent, clearSaveTimeout]);

  const handleBoundariesComputed = useCallback((boundaries: PageBoundary[], pageCount: number) => {
    if (bookEditor.previewMode === 'chapter' && bookEditor.activeChapterId) {
      pendingBoundariesRef.current = { boundaries, pageCount };
    }
  }, [bookEditor.previewMode, bookEditor.activeChapterId]);

  const handleSubmitForReview = useCallback(async () => {
    if (bookEditor.hasUnsavedChanges) {
      handleSave();
    }

    try {
      toast.info(t('books.computingBoundaries') || 'Computing page boundaries...');

      for (const chapter of bookEditor.chapters) {
        const chapterData = await booksApi.getChapter(bookId, chapter.id);
        if (chapterData.content) {
          const { boundaries, pageCount } = computeBoundariesFromHtml(chapterData.content);
          await booksApi.savePageBoundaries(bookId, chapter.id, { boundaries, pageCount });
        }
      }

      const updatedBook = await booksApi.submit(bookId);
      bookEditor.setBook(updatedBook);
      toast.success(t('books.submitSuccess'));
    } catch (error) {
      const message = error instanceof Error ? error.message : t('books.submitError');
      toast.error(message);
    }
  }, [bookEditor, bookId, t, handleSave]);

  const handlePublish = useCallback(async () => {
    try {
      const updatedBook = await booksApi.publish(bookId);
      bookEditor.setBook(updatedBook);
      toast.success(t('books.publishSuccess'));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to publish book';
      toast.error(message);
    }
  }, [bookEditor, bookId, t]);

  const handleDiscardPendingChanges = useCallback(async () => {
    try {
      const updatedBook = await booksApi.discardPendingChanges(bookId);
      bookEditor.setBook(updatedBook);
      // Reload chapters to get the reverted content
      const chapters = await booksApi.getChapters(bookId);
      bookEditor.setChapters(chapters);

      // Reload the editor with the reverted content (emitUpdate: false to prevent auto-save)
      if (editor && bookEditor.activeChapterId) {
        const activeChapter = chapters.find(ch => ch.id === bookEditor.activeChapterId);
        if (activeChapter) {
          // Use same logic as initial load - validate JSON first, fall back to HTML
          const isEmptyDoc = (doc: unknown): boolean => {
            if (!doc || typeof doc !== 'object') return true;
            const d = doc as { content?: Array<{ type?: string; content?: unknown[] }> };
            if (!d.content || d.content.length === 0) return true;
            if (d.content.length === 1 && d.content[0]?.type === 'paragraph') {
              const para = d.content[0];
              if (!para.content || para.content.length === 0) return true;
            }
            return false;
          };
          const hasValidJson = activeChapter.contentJson && !isEmptyDoc(activeChapter.contentJson);
          const contentToLoad = hasValidJson ? activeChapter.contentJson : (activeChapter.content || '');
          editor.commands.setContent(contentToLoad, { emitUpdate: false });
          setEditorContent(editor.getHTML());
        }
      }

      bookEditor.setHasUnsavedChanges(false);
      bookEditor.setHasSessionChanges(false);
      toast.success(t('books.changesDiscarded') || 'Changes discarded');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to discard changes';
      toast.error(message);
    }
  }, [bookEditor, bookId, editor, setEditorContent, t]);

  const handleDiscardSession = useCallback(async () => {
    if (!editor) return;
    clearSaveTimeout();
    await bookEditor.handleDiscardSession(editor);
    setEditorContent(editor.getHTML());
  }, [editor, bookEditor, clearSaveTimeout, setEditorContent]);

  const handleImportDocument = useCallback(async (result: { chapters: Array<{ title: string; content?: string }> }) => {
    const newChapters: Chapter[] = [];
    const startOrder = bookEditor.chapters.length;

    for (let i = 0; i < result.chapters.length; i++) {
      const chapter = result.chapters[i];
      if (!chapter) continue;

      try {
        let newChapter = await booksApi.createChapter(bookId, {
          title: chapter.title,
          order: startOrder + i,
        });
        if (chapter.content) {
          const contentJson = htmlToJson(chapter.content);
          newChapter = await booksApi.updateChapter(bookId, newChapter.id, { contentJson });
        }
        newChapters.push(newChapter);
      } catch {
        toast.error(`Failed to create chapter: ${chapter.title}`);
        throw new Error(`Failed to create chapter: ${chapter.title}`);
      }
    }

    bookEditor.setChapters(prev => [...prev, ...newChapters]);

    if (newChapters.length > 0 && newChapters[0]) {
      bookEditor.setActiveChapterId(newChapters[0].id);
    }
    bookEditor.setHasSessionChanges(true);
  }, [bookEditor, bookId]);

  const handleTocClickWithSwitch = useCallback((chapterId: string, tocIndex: number) => {
    handleTocClick(chapterId, tocIndex, bookEditor.setActiveChapterId);
  }, [handleTocClick, bookEditor.setActiveChapterId]);

  const handleAnnotationClick = useCallback((annotation: Annotation) => {
    viewAnnotations.handleAnnotationClick(annotation, bookEditor.setActiveChapterId);
  }, [viewAnnotations, bookEditor.setActiveChapterId]);

  const handleRestoreVersion = useCallback(async (version: number) => {
    if (!confirm(t('books.restoreConfirm'))) return;

    try {
      // Fetch the version's content instead of doing a backend restore
      // This way the restored content becomes a new edit (can be undone)
      const versionData = await booksApi.getVersion(bookId, version);

      if (!versionData.chapters || versionData.chapters.length === 0) {
        toast.error(t('books.noContentToRestore') || 'No content to restore');
        return;
      }

      bookEditor.setIsSaving(true);

      // Apply each chapter snapshot as a new update
      for (const snapshot of versionData.chapters) {
        // Convert HTML to JSON for proper editor loading
        const contentJson = htmlToJson(snapshot.content);
        await booksApi.updateChapter(bookId, snapshot.chapterId, {
          content: snapshot.content,
          contentJson,
        });
      }

      // Refresh chapters to get updated content
      const chaptersData = await booksApi.getChapters(bookId);
      bookEditor.setChapters(chaptersData);

      // Reload the editor with the restored content
      const activeChapter = chaptersData.find(ch => ch.id === bookEditor.activeChapterId);
      if (activeChapter) {
        reloadActiveChapter(activeChapter);
      }

      bookEditor.setHasUnsavedChanges(false);
      bookEditor.setHasSessionChanges(true); // Mark as having changes for this session

      toast.success(t('books.restoreSuccess'));
      bookEditor.setHistoryDialogOpen(false);
    } catch {
      toast.error(t('common.error'));
    } finally {
      bookEditor.setIsSaving(false);
    }
  }, [bookId, bookEditor, reloadActiveChapter, t]);

  return {
    pendingBoundariesRef,
    saveChapterContent,
    handleSave,
    handleBoundariesComputed,
    handleSubmitForReview,
    handlePublish,
    handleDiscardPendingChanges,
    handleDiscardSession,
    handleImportDocument,
    handleTocClickWithSwitch,
    handleAnnotationClick,
    handleRestoreVersion,
  };
}
