'use client';

import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TextStyle } from '@tiptap/extension-text-style';
import { FontFamily } from '@tiptap/extension-font-family';
import { Color } from '@tiptap/extension-color';
import Highlight from '@tiptap/extension-highlight';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import { FontSize } from '@/components/shared/rich-text-editor/font-size-extension';
import { ResizableMedia } from '@/components/shared/rich-text-editor/resizable-media-extension';
import { MarkdownPaste } from '@/components/shared/rich-text-editor/markdown-paste-extension';
import { CodeBlockWithLanguage } from '@/components/shared/rich-text-editor/code-block-extension';
import { MathInline, MathBlock } from '@/components/shared/rich-text-editor/math-extension';
import { extractTableOfContents, type TocItem, CustomTableCell, CustomTableHeader } from '../lib';
import type { Chapter } from '@/types';

interface UseChapterTiptapOptions {
  activeChapter: Chapter | undefined;
  activeChapterId: string | null;
  chapters: Chapter[];
  canEdit: boolean;
  onContentChange: () => void;
  onAutoSave: (editor: ReturnType<typeof useEditor>) => void;
}

export function useChapterTiptap({
  activeChapter,
  activeChapterId,
  chapters,
  canEdit,
  onContentChange,
  onAutoSave,
}: UseChapterTiptapOptions) {
  const [editorContent, setEditorContent] = useState('');
  const [activeHeadingIndex, setActiveHeadingIndex] = useState<number | null>(null);
  const tocUpdateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  // Ref for dynamic auto-save callback updates
  const onAutoSaveRef = useRef(onAutoSave);
  onAutoSaveRef.current = onAutoSave;

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ codeBlock: false }),
      TextStyle,
      FontFamily,
      FontSize,
      Color,
      Highlight.configure({ multicolor: true }),
      Underline,
      TextAlign.configure({
        types: ['heading', 'paragraph'],
        alignments: ['left', 'center', 'right', 'justify'],
      }),
      Table.configure({ resizable: true }),
      TableRow,
      CustomTableCell,
      CustomTableHeader,
      ResizableMedia,
      MarkdownPaste,
      CodeBlockWithLanguage,
      MathInline,
      MathBlock,
    ],
    content: '',
    editable: canEdit,
    editorProps: {
      attributes: {
        class: 'focus:outline-none min-h-[500px] chapter-content',
        style: `
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 16px;
          line-height: 1.6;
        `,
      },
    },
    onUpdate: ({ editor: editorInstance }) => {
      if (!canEdit) return;
      onContentChange();

      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
      saveTimeoutRef.current = setTimeout(() => {
        onAutoSaveRef.current(editorInstance as ReturnType<typeof useEditor>);
      }, 2000);
    },
    immediatelyRender: false,
  });

  // Update editor content state when editor updates (debounced)
  useEffect(() => {
    if (!editor) return;

    setEditorContent(editor.getHTML());

    const updateHandler = () => {
      if (tocUpdateTimeoutRef.current) {
        clearTimeout(tocUpdateTimeoutRef.current);
      }
      tocUpdateTimeoutRef.current = setTimeout(() => {
        setEditorContent(editor.getHTML());
      }, 1000);
    };
    editor.on('update', updateHandler);

    return () => {
      editor.off('update', updateHandler);
      if (tocUpdateTimeoutRef.current) {
        clearTimeout(tocUpdateTimeoutRef.current);
      }
    };
  }, [editor]);

  // Load chapter content into editor when active chapter changes
  useEffect(() => {
    if (editor && activeChapter) {
      const isEmptyDoc = (doc: unknown): boolean => {
        if (!doc || typeof doc !== 'object') return true;
        const d = doc as { content?: Array<{ type?: string; content?: unknown[] }> };
        if (!d.content || d.content.length === 0) return true;
        if (d.content.length === 1 && d.content[0]?.type === 'paragraph') {
          const para = d.content[0];
          if (!para.content || para.content.length === 0) return true;
        }
        return false;
      };

      const hasValidJson = activeChapter.contentJson && !isEmptyDoc(activeChapter.contentJson);
      const contentToLoad = hasValidJson ? activeChapter.contentJson : (activeChapter.content || '');

      // Use emitUpdate: false to prevent triggering auto-save on initial load
      queueMicrotask(() => {
        editor.commands.setContent(contentToLoad, { emitUpdate: false });
      });
      setTimeout(() => {
        setEditorContent(editor.getHTML());
      }, 50);
    }
  }, [editor, activeChapter?.id]);

  // Update editor editable state when book status changes
  useEffect(() => {
    if (editor) {
      editor.setEditable(canEdit);
    }
  }, [editor, canEdit]);

  // Memoized TOC for each chapter
  const chapterTocs = useMemo(() => {
    const tocs: Record<string, TocItem[]> = {};
    chapters.forEach((chapter) => {
      let html = chapter.content || '';
      if (chapter.id === activeChapterId && editorContent && editorContent !== '<p></p>') {
        html = editorContent;
      }
      tocs[chapter.id] = extractTableOfContents(html);
    });
    return tocs;
  }, [chapters, activeChapterId, editorContent]);

  // Track active heading based on scroll position
  useEffect(() => {
    if (!editor) return;

    const editorEl = document.querySelector('.ProseMirror');
    if (!editorEl) return;

    const editorContainer = editorEl.closest('.overflow-auto');
    if (!editorContainer) return;

    let rafId: number | null = null;
    let ticking = false;

    const updateActiveHeading = () => {
      const headings = editorEl.querySelectorAll('h1, h2, h3, h4, h5, h6');
      if (headings.length === 0) {
        setActiveHeadingIndex(null);
        ticking = false;
        return;
      }

      const containerRect = editorContainer.getBoundingClientRect();
      let activeIndex = 0;

      for (let i = 0; i < headings.length; i++) {
        const heading = headings[i];
        if (!heading) continue;
        const rect = heading.getBoundingClientRect();
        if (rect.top <= containerRect.top + 100) {
          activeIndex = i;
        } else {
          break;
        }
      }

      setActiveHeadingIndex(activeIndex);
      ticking = false;
    };

    const onScroll = () => {
      if (!ticking) {
        rafId = requestAnimationFrame(updateActiveHeading);
        ticking = true;
      }
    };

    updateActiveHeading();
    editorContainer.addEventListener('scroll', onScroll, { passive: true });

    return () => {
      editorContainer.removeEventListener('scroll', onScroll);
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
    };
  }, [editor, activeChapterId, editorContent]);

  // TOC navigation
  const handleTocClick = useCallback((chapterId: string, tocIndex: number, setActiveChapterId: (id: string) => void) => {
    if (activeChapterId !== chapterId) {
      setActiveChapterId(chapterId);
      setTimeout(() => {
        const editorEl = document.querySelector('.ProseMirror');
        if (editorEl) {
          const headings = editorEl.querySelectorAll('h1, h2, h3, h4, h5, h6');
          const heading = headings[tocIndex];
          if (heading) {
            heading.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
      }, 100);
    } else {
      const editorEl = document.querySelector('.ProseMirror');
      if (editorEl) {
        const headings = editorEl.querySelectorAll('h1, h2, h3, h4, h5, h6');
        const heading = headings[tocIndex];
        if (heading) {
          heading.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    }
  }, [activeChapterId]);

  // Clear save timeout ref
  const clearSaveTimeout = useCallback(() => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = null;
    }
  }, []);

  // Force reload the active chapter's content into the editor
  // Use this after restoring a version or other external content changes
  const reloadActiveChapter = useCallback((chapter: Chapter) => {
    if (!editor) return;

    const isEmptyDoc = (doc: unknown): boolean => {
      if (!doc || typeof doc !== 'object') return true;
      const d = doc as { content?: Array<{ type?: string; content?: unknown[] }> };
      if (!d.content || d.content.length === 0) return true;
      if (d.content.length === 1 && d.content[0]?.type === 'paragraph') {
        const para = d.content[0];
        if (!para.content || para.content.length === 0) return true;
      }
      return false;
    };

    const hasValidJson = chapter.contentJson && !isEmptyDoc(chapter.contentJson);
    const contentToLoad = hasValidJson ? chapter.contentJson : (chapter.content || '');

    queueMicrotask(() => {
      editor.commands.setContent(contentToLoad, { emitUpdate: false });
    });
    setTimeout(() => {
      setEditorContent(editor.getHTML());
    }, 50);
  }, [editor]);

  return {
    editor,
    editorContent,
    setEditorContent,
    activeHeadingIndex,
    chapterTocs,
    saveTimeoutRef,
    handleTocClick,
    clearSaveTimeout,
    onAutoSaveRef,
    reloadActiveChapter,
  };
}
