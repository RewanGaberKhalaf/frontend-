'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import type { Editor } from '@tiptap/react';
import { booksApi } from '@/lib/api/books';
import { ROUTES } from '@/lib/constants/routes';
import type { Book, Chapter, BookVersionListItem } from '@/types';
import type { PageBoundary } from '@/components/shared/rich-text-editor/paginated-preview';
import { extractTableOfContents, type TocItem } from '../lib';

interface UseBookEditorOptions {
  bookId: string;
  t: (key: string) => string;
}

export function useBookEditor({ bookId, t }: UseBookEditorOptions) {
  const router = useRouter();

  // Core state
  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [activeChapterId, setActiveChapterId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [hasSessionChanges, setHasSessionChanges] = useState(false);

  // UI state
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(new Set());
  const [addingChapter, setAddingChapter] = useState(false);
  const [newChapterTitle, setNewChapterTitle] = useState('');
  const [isEditMode, setIsEditMode] = useState(false);

  // Dialogs
  const [mediaLibraryOpen, setMediaLibraryOpen] = useState(false);
  const [versionDialogOpen, setVersionDialogOpen] = useState(false);
  const [versionDescription, setVersionDescription] = useState('');
  const [versions, setVersions] = useState<BookVersionListItem[]>([]);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [quizConfigChapter, setQuizConfigChapter] = useState<{ id: string; title: string } | null>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Preview state
  const [showPreview, setShowPreview] = useState(false);
  const [previewMode, setPreviewMode] = useState<'chapter' | 'book'>('chapter');

  // Refs
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pendingBoundariesRef = useRef<{ boundaries: PageBoundary[]; pageCount: number } | null>(null);
  const originalChaptersRef = useRef<Chapter[] | null>(null);

  // Computed
  const activeChapter = chapters.find((ch) => ch.id === activeChapterId);
  const canEdit = book?.status === 'draft' || book?.status === 'rejected' || book?.status === 'published';

  // Full book HTML for preview
  const fullBookHtml = useMemo(() => {
    return chapters
      .map((chapter, index) => {
        const pageBreak = index > 0 ? '<div style="page-break-before: always;"></div>' : '';
        return pageBreak + (chapter.content || '');
      })
      .join('\n');
  }, [chapters]);

  // Load book and chapters
  useEffect(() => {
    const loadBook = async () => {
      try {
        setIsLoading(true);
        // Fetch book first to determine if we should use view mode
        const bookData = await booksApi.getById(bookId);
        setBook(bookData);

        // For published books, default to view mode (no drafts)
        // The user can toggle to edit mode if they want to see/edit drafts
        const defaultToViewMode = bookData.status === 'published';
        setIsEditMode(!defaultToViewMode);

        // Fetch chapters with appropriate view mode
        // viewMode=true means only get published content (no draft changes)
        const chaptersData = await booksApi.getChapters(bookId, defaultToViewMode);
        setChapters(chaptersData);
        originalChaptersRef.current = JSON.parse(JSON.stringify(chaptersData));
        setHasSessionChanges(false);

        if (chaptersData.length > 0 && chaptersData[0]) {
          setActiveChapterId(chaptersData[0].id);
          setExpandedChapters(new Set([chaptersData[0].id]));
        }
      } catch {
        toast.error(t('common.error'));
        router.push(ROUTES.PROFESSOR.BOOKS);
      } finally {
        setIsLoading(false);
      }
    };

    loadBook();
  }, [bookId, router, t]);

  // Auto-expand active chapter
  useEffect(() => {
    if (activeChapterId) {
      setExpandedChapters((prev) => {
        if (prev.has(activeChapterId)) return prev;
        const next = new Set(prev);
        next.add(activeChapterId);
        return next;
      });
    }
  }, [activeChapterId]);

  // Handle boundaries computed from preview
  const handleBoundariesComputed = useCallback((boundaries: PageBoundary[], pageCount: number) => {
    if (previewMode === 'chapter' && activeChapterId) {
      pendingBoundariesRef.current = { boundaries, pageCount };
    }
  }, [previewMode, activeChapterId]);

  // Save chapter content
  const saveChapterContent = useCallback(
    async (editor: Editor | null) => {
      if (!activeChapterId || !canEdit || !editor) return;

      try {
        setIsSaving(true);
        const contentJson = editor.getJSON();
        const content = editor.getHTML();

        await booksApi.updateChapter(bookId, activeChapterId, {
          contentJson: contentJson as import('@/types').ProseMirrorDoc,
          content,
        });

        if (pendingBoundariesRef.current) {
          try {
            await booksApi.savePageBoundaries(bookId, activeChapterId, {
              boundaries: pendingBoundariesRef.current.boundaries,
              pageCount: pendingBoundariesRef.current.pageCount,
            });
            pendingBoundariesRef.current = null;
          } catch {
            // Non-critical
          }
        }

        setChapters((prev) =>
          prev.map((ch) =>
            ch.id === activeChapterId
              ? { ...ch, contentJson: contentJson as import('@/types').ProseMirrorDoc, content }
              : ch
          )
        );
        setHasUnsavedChanges(false);
        setHasSessionChanges(true);
      } catch {
        toast.error(t('books.saveError'));
      } finally {
        setIsSaving(false);
      }
    },
    [activeChapterId, bookId, canEdit, t]
  );

  // Manual save
  const handleSave = useCallback((editor: Editor | null) => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    if (editor) {
      saveChapterContent(editor);
    }
  }, [saveChapterContent]);

  // Discard session
  const handleDiscardSession = useCallback(async (editor: Editor | null) => {
    if (!originalChaptersRef.current || !editor) return;

    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = null;
    }

    try {
      setIsSaving(true);

      for (const originalChapter of originalChaptersRef.current) {
        await booksApi.updateChapter(bookId, originalChapter.id, {
          content: originalChapter.content,
          contentJson: originalChapter.contentJson,
        });
      }

      const restoredChapters = JSON.parse(JSON.stringify(originalChaptersRef.current));
      setChapters(restoredChapters);

      const chapter = restoredChapters.find((ch: Chapter) => ch.id === activeChapterId);
      if (chapter) {
        const contentToLoad = chapter.contentJson || chapter.content || '';
        editor.commands.setContent(contentToLoad, { emitUpdate: false });
      }

      setHasUnsavedChanges(false);
      setHasSessionChanges(false);
      toast.success(t('books.sessionDiscarded') || 'Session discarded');
    } catch {
      toast.error(t('common.error'));
    } finally {
      setIsSaving(false);
    }
  }, [activeChapterId, bookId, t]);

  // Chapter operations
  const handleAddChapter = useCallback(async () => {
    if (!newChapterTitle.trim()) return;

    try {
      const newChapter = await booksApi.createChapter(bookId, {
        title: newChapterTitle.trim(),
        order: chapters.length,
      });
      setChapters((prev) => [...prev, newChapter]);
      setActiveChapterId(newChapter.id);
      setExpandedChapters((prev) => new Set([...prev, newChapter.id]));
      setAddingChapter(false);
      setNewChapterTitle('');
      toast.success(t('books.chapterAdded'));
    } catch {
      toast.error(t('common.error'));
    }
  }, [newChapterTitle, chapters.length, bookId, t]);

  const handleDeleteChapter = useCallback(async (chapterId: string) => {
    if (!confirm(t('books.deleteChapterConfirm'))) return;

    try {
      await booksApi.deleteChapter(bookId, chapterId);
      setChapters((prev) => prev.filter((ch) => ch.id !== chapterId));
      if (activeChapterId === chapterId) {
        const remaining = chapters.filter((ch) => ch.id !== chapterId);
        setActiveChapterId(remaining[0]?.id || null);
      }
      toast.success(t('books.chapterDeleted'));
    } catch {
      toast.error(t('common.error'));
    }
  }, [bookId, activeChapterId, chapters, t]);

  const handleRenameChapter = useCallback(async (chapterId: string, newTitle: string) => {
    try {
      await booksApi.updateChapter(bookId, chapterId, { title: newTitle });
      setChapters((prev) =>
        prev.map((ch) => (ch.id === chapterId ? { ...ch, title: newTitle } : ch))
      );
    } catch {
      toast.error(t('common.error'));
    }
  }, [bookId, t]);

  // Version operations
  const handleSaveVersion = useCallback(async () => {
    try {
      await booksApi.createVersion(bookId, {
        changeDescription: versionDescription || undefined,
      });
      toast.success(t('books.versionSaved'));
      setVersionDialogOpen(false);
      setVersionDescription('');

      const updatedBook = await booksApi.getById(bookId);
      setBook(updatedBook);
    } catch {
      toast.error(t('common.error'));
    }
  }, [bookId, versionDescription, t]);

  const handleOpenHistory = useCallback(async () => {
    try {
      const versionsData = await booksApi.getVersions(bookId);
      setVersions(versionsData);
      setHistoryDialogOpen(true);
    } catch {
      toast.error(t('common.error'));
    }
  }, [bookId, t]);

  // Note: Version restore is handled by useBookEditorHandlers to have access to the editor
  // This is kept for reference but the actual restore is done through handlers
  const handleRestoreVersion = useCallback(async (_version: number) => {
    // Handled by useBookEditorHandlers.handleRestoreVersion
  }, []);

  // Toggle handlers
  const handleToggleExpand = useCallback((chapterId: string) => {
    setExpandedChapters((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) {
        next.delete(chapterId);
      } else {
        next.add(chapterId);
      }
      return next;
    });
  }, []);

  const handleQuizConfig = useCallback((chapterId: string, chapterTitle: string) => {
    setQuizConfigChapter({ id: chapterId, title: chapterTitle });
  }, []);

  return {
    // State
    book,
    setBook,
    chapters,
    setChapters,
    activeChapterId,
    setActiveChapterId,
    activeChapter,
    isLoading,
    isSaving,
    setIsSaving,
    hasUnsavedChanges,
    setHasUnsavedChanges,
    hasSessionChanges,
    setHasSessionChanges,
    canEdit,

    // UI state
    expandedChapters,
    setExpandedChapters,
    addingChapter,
    setAddingChapter,
    newChapterTitle,
    setNewChapterTitle,
    isEditMode,
    setIsEditMode,

    // Dialogs
    mediaLibraryOpen,
    setMediaLibraryOpen,
    versionDialogOpen,
    setVersionDialogOpen,
    versionDescription,
    setVersionDescription,
    versions,
    historyDialogOpen,
    setHistoryDialogOpen,
    quizConfigChapter,
    setQuizConfigChapter,
    importDialogOpen,
    setImportDialogOpen,
    mobileSidebarOpen,
    setMobileSidebarOpen,

    // Preview
    showPreview,
    setShowPreview,
    previewMode,
    setPreviewMode,
    fullBookHtml,

    // Refs
    saveTimeoutRef,
    pendingBoundariesRef,

    // Handlers
    handleBoundariesComputed,
    saveChapterContent,
    handleSave,
    handleDiscardSession,
    handleAddChapter,
    handleDeleteChapter,
    handleRenameChapter,
    handleSaveVersion,
    handleOpenHistory,
    handleRestoreVersion,
    handleToggleExpand,
    handleQuizConfig,
  };
}

export type UseBookEditorReturn = ReturnType<typeof useBookEditor>;
