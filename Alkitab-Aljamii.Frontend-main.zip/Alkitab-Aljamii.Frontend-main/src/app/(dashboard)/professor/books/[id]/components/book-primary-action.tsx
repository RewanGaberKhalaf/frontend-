'use client';

import { memo } from 'react';
import { Send, Globe, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { BookStatus } from '@/types';

interface BookPrimaryActionProps {
  status: BookStatus;
  hasPendingChanges?: boolean;
  hasChapters: boolean;
  isSubmitting?: boolean;
  t: (key: string) => string;
  onSubmit: () => void;
  onPublish?: () => void;
}

/**
 * Contextual primary action button based on book state.
 *
 * | Book State               | Button                           |
 * |--------------------------|----------------------------------|
 * | Editing (draft)          | Send for Approval               |
 * | Waiting for Approval     | — (none)                        |
 * | Needs Changes (rejected) | Send for Approval               |
 * | Ready to Publish         | Publish                         |
 * | Live (no edits)          | — (none)                        |
 * | Live (with edits)        | Send Changes for Approval       |
 */
export const BookPrimaryAction = memo(function BookPrimaryAction({
  status,
  hasPendingChanges = false,
  hasChapters,
  isSubmitting = false,
  t,
  onSubmit,
  onPublish,
}: BookPrimaryActionProps) {
  // Determine what action to show
  const config = getActionConfig(status, hasPendingChanges, hasChapters);

  if (!config) {
    return null;
  }

  const { labelKey, variant, icon: Icon, action, disabled } = config;

  const handleClick = () => {
    if (action === 'submit') {
      onSubmit();
    } else if (action === 'publish' && onPublish) {
      onPublish();
    }
  };

  return (
    <Button
      variant={variant}
      size="sm"
      onClick={handleClick}
      disabled={disabled || isSubmitting}
      className="gap-2"
    >
      {isSubmitting ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Icon className="h-4 w-4" />
      )}
      <span className="hidden sm:inline">{t(labelKey)}</span>
    </Button>
  );
});

interface ActionConfig {
  labelKey: string;
  variant: 'default' | 'secondary' | 'outline';
  icon: typeof Send;
  action: 'submit' | 'publish';
  disabled: boolean;
}

function getActionConfig(
  status: BookStatus,
  hasPendingChanges: boolean,
  hasChapters: boolean,
): ActionConfig | null {
  switch (status) {
    case 'draft':
      // Draft books can be submitted for approval
      return {
        labelKey: 'books.actions.sendForApproval',
        variant: 'default',
        icon: Send,
        action: 'submit',
        disabled: !hasChapters,
      };

    case 'rejected':
      // Rejected books can be resubmitted after fixing issues
      return {
        labelKey: 'books.actions.sendForApproval',
        variant: 'default',
        icon: Send,
        action: 'submit',
        disabled: !hasChapters,
      };

    case 'approved':
      // Approved books can be published (by professor or admin)
      return {
        labelKey: 'books.actions.publish',
        variant: 'default',
        icon: Globe,
        action: 'publish',
        disabled: false,
      };

    case 'published':
      // Published books with pending changes can submit changes for approval
      if (hasPendingChanges) {
        return {
          labelKey: 'books.actions.sendChangesForApproval',
          variant: 'default',
          icon: Send,
          action: 'submit',
          disabled: false,
        };
      }
      // Published with no changes - no action needed
      return null;

    case 'pending_review':
      // Waiting for approval - no action available
      return null;

    default:
      return null;
  }
}
