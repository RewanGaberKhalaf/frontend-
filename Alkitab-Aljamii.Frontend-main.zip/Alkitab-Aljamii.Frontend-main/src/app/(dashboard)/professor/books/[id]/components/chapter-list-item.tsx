'use client';

import { useState, useCallback, memo } from 'react';
import { useTranslations } from 'next-intl';
import {
  ChevronDown,
  ChevronRight,
  Trash2,
  Check,
  X,
  Pencil,
  GripVertical,
  ClipboardList,
} from 'lucide-react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import type { Chapter } from '@/types';
import type { TocItem } from '../lib/toc-utils';

export interface ChapterListItemProps {
  chapter: Chapter;
  index: number;
  isActive: boolean;
  isExpanded: boolean;
  canEdit: boolean;
  isEditMode: boolean;
  toc: TocItem[];
  activeHeadingIndex: number | null;
  onSelect: (id: string) => void;
  onToggleExpand: (id: string) => void;
  onRename: (id: string, newTitle: string) => Promise<void>;
  onDelete: (id: string) => void;
  onTocClick: (chapterId: string, tocIndex: number) => void;
  onQuizConfig: (chapterId: string, chapterTitle: string) => void;
}

export const ChapterListItem = memo(function ChapterListItem({
  chapter,
  index,
  isActive,
  isExpanded,
  canEdit,
  isEditMode,
  toc,
  activeHeadingIndex,
  onSelect,
  onToggleExpand,
  onRename,
  onDelete,
  onTocClick,
  onQuizConfig,
}: ChapterListItemProps) {
  // Only allow editing when both canEdit (book status allows) AND isEditMode (user is in edit mode)
  const allowEdit = canEdit && isEditMode;
  const t = useTranslations();
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: chapter.id, disabled: !allowEdit });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const handleStartEdit = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setEditTitle(chapter.title);
    setIsEditing(true);
  }, [chapter.title]);

  const handleSaveEdit = useCallback(async () => {
    if (editTitle.trim()) {
      await onRename(chapter.id, editTitle.trim());
    }
    setIsEditing(false);
  }, [chapter.id, editTitle, onRename]);

  const handleCancelEdit = useCallback(() => {
    setIsEditing(false);
  }, []);

  return (
    <div ref={setNodeRef} style={style} className="flex flex-col w-full min-w-0">
      {/* Chapter row */}
      <div
        className={cn(
          'group flex items-center gap-2 rounded-md px-2 py-1.5 cursor-pointer transition-colors w-full min-w-0',
          isActive ? 'bg-primary/10 text-primary' : 'hover:bg-muted',
          isDragging && 'bg-muted shadow-md'
        )}
        onClick={() => {
          if (!isEditing) {
            onSelect(chapter.id);
          }
        }}
      >
        {allowEdit && (
          <div
            {...attributes}
            {...listeners}
            className="touch-none"
          >
            <GripVertical className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 cursor-grab shrink-0" />
          </div>
        )}

        <button
          className="shrink-0"
          onClick={(e) => {
            e.stopPropagation();
            onToggleExpand(chapter.id);
          }}
        >
          {isExpanded ? (
            <ChevronDown className="h-4 w-4" />
          ) : (
            <ChevronRight className="h-4 w-4" />
          )}
        </button>

        <div className="flex-1 min-w-0 overflow-hidden">
          {isEditing ? (
            <div className="flex items-center gap-1">
              <Input
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="h-6 text-sm"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleSaveEdit();
                  } else if (e.key === 'Escape') {
                    handleCancelEdit();
                  }
                }}
                onClick={(e) => e.stopPropagation()}
              />
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSaveEdit();
                }}
              >
                <Check className="h-3 w-3" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={(e) => {
                  e.stopPropagation();
                  handleCancelEdit();
                }}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-1 w-full min-w-0">
              <span
                className="text-sm truncate flex-1 min-w-0"
                title={`${index + 1}. ${chapter.title}`}
              >
                {index + 1}. {chapter.title}
              </span>
              <div className="flex items-center shrink-0 opacity-0 group-hover:opacity-100">
                {/* Quiz config button - only in edit mode */}
                {allowEdit && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    title="Configure quiz"
                    onClick={(e) => {
                      e.stopPropagation();
                      onQuizConfig(chapter.id, chapter.title);
                    }}
                  >
                    <ClipboardList className="h-3 w-3" />
                  </Button>
                )}
                {/* Edit/Delete only in edit mode */}
                {allowEdit && (
                  <>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={handleStartEdit}
                    >
                      <Pencil className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-destructive hover:text-destructive"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(chapter.id);
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Table of Contents - shown when chapter is expanded */}
      {isExpanded && (
        <div className="mt-1 ms-6 ps-2 border-s-2 border-primary/30 overflow-hidden w-[calc(100%-1.5rem)]">
          {toc.length > 0 ? (
            toc.map((item, tocIndex) => (
              <div
                key={`${chapter.id}-toc-${tocIndex}`}
                className={cn(
                  'text-xs py-0.5 cursor-pointer block overflow-hidden text-ellipsis whitespace-nowrap transition-colors',
                  item.level === 1 && 'font-medium',
                  item.level === 2 && 'ps-2',
                  item.level === 3 && 'ps-4',
                  item.level >= 4 && 'ps-6',
                  isActive && activeHeadingIndex === tocIndex
                    ? 'text-primary font-medium'
                    : 'text-muted-foreground hover:text-foreground'
                )}
                onClick={(e) => {
                  e.stopPropagation();
                  onTocClick(chapter.id, tocIndex);
                }}
                title={item.text}
              >
                {item.text}
              </div>
            ))
          ) : (
            <div className="text-xs text-muted-foreground italic py-1">
              {t('books.noHeadingsFound')}
            </div>
          )}
        </div>
      )}
    </div>
  );
});
