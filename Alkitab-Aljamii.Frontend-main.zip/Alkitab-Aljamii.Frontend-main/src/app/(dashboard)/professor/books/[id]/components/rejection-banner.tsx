'use client';

import { memo, useState, useEffect } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, Pencil, FileText, User, Calendar } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { booksApi } from '@/lib/api/books';
import type { RejectionFeedbackResponse } from '@/types';

interface RejectionBannerProps {
  bookId: string;
  reason: string;
  t: (key: string) => string;
  onStartEditing?: () => void;
  className?: string;
}

/**
 * Banner shown when a book has been rejected.
 *
 * Displays:
 * - Warning that book needs changes
 * - General feedback from reviewer
 * - Per-chapter feedback (if any)
 * - Actions: Start editing
 */
export const RejectionBanner = memo(function RejectionBanner({
  bookId,
  reason,
  t,
  onStartEditing,
  className,
}: RejectionBannerProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [feedback, setFeedback] = useState<RejectionFeedbackResponse | null>(null);
  const [loadingFeedback, setLoadingFeedback] = useState(true);

  // Load detailed feedback
  useEffect(() => {
    const loadFeedback = async () => {
      try {
        const data = await booksApi.getRejectionFeedback(bookId);
        setFeedback(data);
      } catch {
        // Fall back to just showing the reason from props
      } finally {
        setLoadingFeedback(false);
      }
    };
    loadFeedback();
  }, [bookId]);

  const displayReason = feedback?.reason || reason;
  const hasChapterFeedback = feedback?.chapterFeedback && feedback.chapterFeedback.length > 0;

  return (
    <Alert variant="destructive" className={cn("border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950 overflow-hidden", className)}>
      <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
      <AlertTitle className="text-amber-900 dark:text-amber-100">
        {t('books.rejectionBanner.title')}
      </AlertTitle>
      <AlertDescription className="text-amber-800 dark:text-amber-200 overflow-hidden">
        {/* Reviewer info */}
        {feedback && !loadingFeedback && (
          <div className="flex items-center gap-3 text-xs text-amber-700 dark:text-amber-300 mb-3">
            <span className="flex items-center gap-1">
              <User className="h-3 w-3" />
              {feedback.reviewerName}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {new Date(feedback.rejectedAt).toLocaleDateString()}
            </span>
          </div>
        )}

        {/* General Feedback */}
        <div className="mb-3">
          <p className="text-sm font-medium mb-1">
            {t('books.rejectionBanner.feedbackLabel')}
          </p>
          <blockquote className="border-s-2 border-amber-400 ps-3 italic text-sm">
            {displayReason}
          </blockquote>
        </div>

        {/* Chapter-specific Feedback */}
        {hasChapterFeedback && (
          <div className="mb-3">
            <Button
              variant="link"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-0 h-auto text-amber-700 dark:text-amber-300 mb-2"
            >
              {isExpanded ? (
                <>
                  <ChevronUp className="h-3 w-3 me-1" />
                  {t('books.rejectionBanner.hideChapterFeedback')}
                </>
              ) : (
                <>
                  <ChevronDown className="h-3 w-3 me-1" />
                  {t('books.rejectionBanner.showChapterFeedback')}
                  <Badge variant="secondary" className="ms-1 text-xs">
                    {feedback.chapterFeedback.length}
                  </Badge>
                </>
              )}
            </Button>

            {isExpanded && (
              <div className="space-y-2 rounded-md border border-amber-300 dark:border-amber-700 bg-amber-100/50 dark:bg-amber-900/30 p-3">
                {feedback.chapterFeedback.map((cf) => (
                  <div key={cf.chapterId} className="text-sm">
                    <div className="flex items-center gap-2 mb-1">
                      <FileText className="h-3 w-3 text-amber-600 dark:text-amber-400" />
                      <span className="font-medium">
                        {t('books.chapter')} {cf.chapterOrder + 1}: {cf.chapterTitle}
                      </span>
                    </div>
                    <blockquote className="border-s-2 border-amber-400 ps-3 italic text-sm ms-5">
                      {cf.feedback}
                    </blockquote>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {onStartEditing && (
          <Button
            variant="outline"
            size="sm"
            onClick={onStartEditing}
            className="gap-2 border-amber-300 text-amber-700 hover:bg-amber-100 dark:border-amber-700 dark:text-amber-300 dark:hover:bg-amber-900"
          >
            <Pencil className="h-4 w-4" />
            {t('books.actions.startEditing')}
          </Button>
        )}
      </AlertDescription>
    </Alert>
  );
});
