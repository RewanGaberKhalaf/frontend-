'use client';

import { memo } from 'react';
import type { Editor } from '@tiptap/react';
import { MoreVertical, Undo2, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { EditorToolbar } from '@/components/shared/rich-text-editor/editor-toolbar';
import { cn } from '@/lib/utils';

interface MobileEditorToolbarProps {
  editor: Editor | null;
  onOpenMediaLibrary: () => void;
}

export const MobileEditorToolbar = memo(function MobileEditorToolbar({
  editor,
  onOpenMediaLibrary,
}: MobileEditorToolbarProps) {
  return (
    <div className="shrink-0 border-b bg-background md:hidden">
      <div className="flex items-center gap-1 px-2 py-1.5 bg-muted/50">
        {/* Essential formatting buttons */}
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8", editor?.isActive('bold') && "bg-accent")}
          onClick={() => editor?.chain().focus().toggleBold().run()}
        >
          <span className="font-bold text-sm">B</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8", editor?.isActive('italic') && "bg-accent")}
          onClick={() => editor?.chain().focus().toggleItalic().run()}
        >
          <span className="italic text-sm">I</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8", editor?.isActive('underline') && "bg-accent")}
          onClick={() => editor?.chain().focus().toggleUnderline().run()}
        >
          <span className="underline text-sm">U</span>
        </Button>

        <div className="w-px h-6 bg-border mx-1" />

        {/* Lists */}
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8", editor?.isActive('bulletList') && "bg-accent")}
          onClick={() => editor?.chain().focus().toggleBulletList().run()}
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="9" y1="6" x2="20" y2="6" />
            <line x1="9" y1="12" x2="20" y2="12" />
            <line x1="9" y1="18" x2="20" y2="18" />
            <circle cx="4" cy="6" r="1.5" fill="currentColor" />
            <circle cx="4" cy="12" r="1.5" fill="currentColor" />
            <circle cx="4" cy="18" r="1.5" fill="currentColor" />
          </svg>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8", editor?.isActive('orderedList') && "bg-accent")}
          onClick={() => editor?.chain().focus().toggleOrderedList().run()}
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="10" y1="6" x2="20" y2="6" />
            <line x1="10" y1="12" x2="20" y2="12" />
            <line x1="10" y1="18" x2="20" y2="18" />
            <text x="4" y="8" fontSize="8" fill="currentColor" stroke="none">1</text>
            <text x="4" y="14" fontSize="8" fill="currentColor" stroke="none">2</text>
            <text x="4" y="20" fontSize="8" fill="currentColor" stroke="none">3</text>
          </svg>
        </Button>

        <div className="w-px h-6 bg-border mx-1" />

        {/* Undo/Redo */}
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => editor?.chain().focus().undo().run()}
          disabled={!editor?.can().undo()}
        >
          <Undo2 className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => editor?.chain().focus().redo().run()}
          disabled={!editor?.can().redo()}
        >
          <History className="h-4 w-4" />
        </Button>

        {/* Spacer */}
        <div className="flex-1" />

        {/* More options */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 gap-1">
              <MoreVertical className="h-4 w-4" />
              <span className="text-xs">More</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-auto max-h-[70vh]">
            <SheetHeader className="pb-2">
              <SheetTitle>Formatting Options</SheetTitle>
            </SheetHeader>
            <ScrollArea className="h-full">
              <EditorToolbar
                editor={editor}
                enableTable={true}
                enableCodeBlock={true}
                enableMedia={true}
                onOpenMediaLibrary={onOpenMediaLibrary}
              />
            </ScrollArea>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
});
