'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Download,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  BarChart3,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AnnotationStats,
  AnnotationFilters,
  AnnotationTable,
} from '@/components/professor/AnnotationDashboard';
import { useAnnotationDashboard } from './use-annotation-dashboard';

export default function AnnotationDashboardPage() {
  const params = useParams();
  const bookId = params['id'] as string;

  const {
    book,
    stats,
    recentActivity,
    annotations,
    pagination,
    filters,
    isLoading,
    isLoadingAnnotations,
    chapterOptions,
    userOptions,
    handleFiltersChange,
    handleSortChange,
    handlePageChange,
    handleAnnotationClick,
    handleRefresh,
    handleExport,
  } = useAnnotationDashboard(bookId);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div>
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-32 mt-2" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!book || !stats) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Book not found</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="shrink-0 border-b bg-background p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild>
              <Link href={`/professor/books/${bookId}`}>
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-semibold">Annotations</h1>
                <Badge variant="secondary">{book.title}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                View and manage student annotations
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleRefresh}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {/* Stats */}
          <AnnotationStats stats={stats} />

          {/* Main content tabs */}
          <Tabs defaultValue="all" className="space-y-4">
            <TabsList>
              <TabsTrigger value="all">All Annotations</TabsTrigger>
              <TabsTrigger value="activity">Recent Activity</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              {/* Filters */}
              <AnnotationFilters
                filters={filters}
                onFiltersChange={handleFiltersChange}
                chapters={chapterOptions}
                users={userOptions}
              />

              {/* Table */}
              <AnnotationTable
                annotations={annotations}
                isLoading={isLoadingAnnotations}
                onSortChange={handleSortChange}
                onAnnotationClick={handleAnnotationClick}
              />

              {/* Pagination */}
              {pagination.totalPages > 1 && (
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    Showing {(pagination.page - 1) * pagination.limit + 1} to{' '}
                    {Math.min(pagination.page * pagination.limit, pagination.total)} of{' '}
                    {pagination.total} annotations
                  </p>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={!pagination.hasPreviousPage}
                      onClick={() => handlePageChange(pagination.page - 1)}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Previous
                    </Button>
                    <span className="text-sm">
                      Page {pagination.page} of {pagination.totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={!pagination.hasNextPage}
                      onClick={() => handlePageChange(pagination.page + 1)}
                    >
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="activity" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>
                    Latest annotations and comments from students
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No recent activity
                      </p>
                    ) : (
                      recentActivity.map((activity) => (
                        <div
                          key={activity.id}
                          className="flex items-start gap-3 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">
                                {activity.user.firstName} {activity.user.lastName}
                              </span>
                              <Badge variant="secondary" className="text-xs">
                                {activity.type === 'comment' ? 'Commented' : 'Annotated'}
                              </Badge>
                              {activity.chapterTitle && (
                                <span className="text-xs text-muted-foreground">
                                  in {activity.chapterTitle}
                                </span>
                              )}
                            </div>
                            {activity.preview && (
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {activity.preview}
                              </p>
                            )}
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(activity.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                {/* Annotations by Type */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      By Type
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(stats.annotationsByType).map(([type, count]) => (
                        <div key={type} className="flex items-center justify-between">
                          <span className="text-sm capitalize">{type.replace('_', ' ')}</span>
                          <div className="flex items-center gap-2">
                            <div
                              className="h-2 bg-primary rounded"
                              style={{
                                width: `${(count / stats.totalAnnotations) * 100}px`,
                                minWidth: '8px',
                              }}
                            />
                            <span className="text-sm font-medium">{count}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Annotations by Chapter */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      By Chapter
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {stats.annotationsByChapter.slice(0, 5).map((item) => (
                        <div key={item.chapterId} className="flex items-center justify-between">
                          <span className="text-sm truncate max-w-[200px]" title={item.chapterTitle}>
                            {item.chapterTitle}
                          </span>
                          <div className="flex items-center gap-2">
                            <div
                              className="h-2 bg-blue-500 rounded"
                              style={{
                                width: `${(item.count / (stats.annotationsByChapter[0]?.count || 1)) * 100}px`,
                                minWidth: '8px',
                              }}
                            />
                            <span className="text-sm font-medium">{item.count}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Top Contributors */}
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>Top Contributors</CardTitle>
                    <CardDescription>Students with most annotations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {stats.topContributors.slice(0, 6).map((contributor, index) => (
                        <div
                          key={contributor.userId}
                          className="flex items-center gap-3 p-3 border rounded-lg"
                        >
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold text-sm">
                            {index + 1}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">
                              {contributor.userName}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {contributor.annotationCount} annotations, {contributor.commentCount} comments
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </ScrollArea>
    </div>
  );
}
