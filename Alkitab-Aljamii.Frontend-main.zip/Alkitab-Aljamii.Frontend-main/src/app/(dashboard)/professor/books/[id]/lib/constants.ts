import type { BookStatus } from '@/types';

/**
 * Badge variant mapping for book statuses.
 * Used for visual differentiation of status badges.
 */
export const statusVariants: Record<BookStatus, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  draft: 'secondary',
  pending_review: 'outline',
  approved: 'default',
  rejected: 'destructive',
  published: 'default',
};

/**
 * Fallback labels for book statuses.
 * Prefer using i18n keys from books.status.* for localized labels.
 * @deprecated Use getStatusKey() from book-status-display.tsx for i18n support
 */
export const statusLabels: Record<BookStatus, string> = {
  draft: 'Draft',
  pending_review: 'Pending Review',
  approved: 'Approved',
  rejected: 'Rejected',
  published: 'Published',
};

/**
 * i18n key mapping for book statuses.
 * Use with t() function to get localized status labels.
 */
export const statusI18nKeys: Record<BookStatus, string> = {
  draft: 'books.status.editing',
  pending_review: 'books.status.waitingForApproval',
  approved: 'books.status.readyToPublish',
  rejected: 'books.status.needsChanges',
  published: 'books.status.live',
};
