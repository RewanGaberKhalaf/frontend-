'use client';

import { memo } from 'react';
import { Loader2, Check } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { BookStatus } from '@/types';

interface BookStatusDisplayProps {
  status: BookStatus;
  hasPendingChanges?: boolean;
  isSaving?: boolean;
  hasUnsavedChanges?: boolean;
  isEditMode?: boolean;
  t: (key: string) => string;
  className?: string;
}

/**
 * Maps backend status to friendly i18n key
 */
function getStatusKey(status: BookStatus): string {
  switch (status) {
    case 'draft':
      return 'books.status.editing';
    case 'pending_review':
      return 'books.status.waitingForApproval';
    case 'approved':
      return 'books.status.readyToPublish';
    case 'rejected':
      return 'books.status.needsChanges';
    case 'published':
      return 'books.status.live';
    default:
      return 'books.status.editing';
  }
}

/**
 * Gets the appropriate badge variant for the status
 */
function getStatusVariant(status: BookStatus): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (status) {
    case 'draft':
      return 'secondary';
    case 'pending_review':
      return 'outline';
    case 'approved':
      return 'default';
    case 'rejected':
      return 'destructive';
    case 'published':
      return 'default';
    default:
      return 'secondary';
  }
}

/**
 * Displays the book status with a friendly label and optional save indicator.
 *
 * Examples:
 * - "Editing • Saved" (edit mode)
 * - "Live • Has unpublished edits" (edit mode, published with pending changes)
 * - "Live" (view mode, published)
 * - "Waiting for Approval"
 * - "Needs Changes"
 */
export const BookStatusDisplay = memo(function BookStatusDisplay({
  status,
  hasPendingChanges = false,
  isSaving = false,
  hasUnsavedChanges = false,
  isEditMode = false,
  t,
  className,
}: BookStatusDisplayProps) {
  const statusLabel = t(getStatusKey(status));
  const isLiveWithEdits = status === 'published' && hasPendingChanges;

  // Only show save indicators and pending changes info in edit mode
  const showSaveIndicator = isEditMode && (
    status === 'draft' ||
    status === 'rejected' ||
    isLiveWithEdits
  );

  return (
    <div className={cn("flex items-center gap-1.5 md:gap-2 text-sm flex-wrap", className)}>
      <Badge variant={getStatusVariant(status)} className="text-xs">
        {statusLabel}
      </Badge>

      {/* Save indicator - only show in edit mode */}
      {showSaveIndicator && (
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <span className="text-muted-foreground/50 hidden sm:inline">•</span>
          {isSaving ? (
            <>
              <Loader2 className="h-3 w-3 animate-spin" />
              <span className="hidden sm:inline">{t('books.status.savingIndicator')}</span>
            </>
          ) : hasUnsavedChanges ? (
            <span className="text-yellow-600">{t('books.unsaved')}</span>
          ) : (
            <span title={t('books.status.savedIndicator')}>
              <Check className="h-3 w-3 text-green-600" />
            </span>
          )}
        </span>
      )}

      {/* Published with pending changes indicator - only in edit mode, hide on mobile */}
      {isEditMode && isLiveWithEdits && !isSaving && !hasUnsavedChanges && (
        <span className="hidden sm:flex items-center gap-1 text-xs text-muted-foreground">
          <span className="text-muted-foreground/50">•</span>
          <span className="text-amber-600">{t('books.status.hasUnpublishedEdits')}</span>
        </span>
      )}
    </div>
  );
});

export { getStatusKey, getStatusVariant };
