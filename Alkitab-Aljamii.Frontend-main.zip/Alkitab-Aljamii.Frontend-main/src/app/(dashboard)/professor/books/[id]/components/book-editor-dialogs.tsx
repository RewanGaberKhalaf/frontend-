'use client';

import { useTranslations } from 'next-intl';
import { Save, Plus, Check, X, FileUp, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import type { Chapter, BookVersionListItem } from '@/types';

export interface SaveVersionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  description: string;
  onDescriptionChange: (description: string) => void;
  onSave: () => void;
}

export function SaveVersionDialog({
  open,
  onOpenChange,
  description,
  onDescriptionChange,
  onSave,
}: SaveVersionDialogProps) {
  const t = useTranslations();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t('books.saveVersion')}</DialogTitle>
          <DialogDescription>{t('books.saveVersionDescription')}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Textarea
            placeholder={t('books.changeDescriptionPlaceholder')}
            value={description}
            onChange={(e) => onDescriptionChange(e.target.value)}
            rows={3}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t('common.cancel')}
          </Button>
          <Button onClick={onSave}>
            <Save className="h-4 w-4 me-2" />
            {t('books.saveVersion')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export interface VersionHistoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  versions: BookVersionListItem[];
  canEdit: boolean;
  onRestore: (version: number) => void;
}

export function VersionHistoryDialog({
  open,
  onOpenChange,
  versions,
  canEdit,
  onRestore,
}: VersionHistoryDialogProps) {
  const t = useTranslations();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{t('books.versionHistory')}</DialogTitle>
        </DialogHeader>
        <ScrollArea className="max-h-[400px]">
          <div className="space-y-2">
            {versions.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {t('books.noVersions')}
              </p>
            ) : (
              versions.map((version) => (
                <div
                  key={version.id}
                  className="flex items-center justify-between p-3 rounded-lg border"
                >
                  <div>
                    <div className="font-medium">Version {version.version}</div>
                    <div className="text-sm text-muted-foreground">
                      {version.changeDescription || 'No description'}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(version.createdAt).toLocaleString()} by {version.createdByName}
                    </div>
                  </div>
                  {canEdit && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onRestore(version.version)}
                    >
                      {t('books.restoreVersion')}
                    </Button>
                  )}
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

export interface MobileChapterSidebarProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  chapters: Chapter[];
  activeChapterId: string | null;
  canEdit: boolean;
  addingChapter: boolean;
  newChapterTitle: string;
  onSetAddingChapter: (adding: boolean) => void;
  onSetNewChapterTitle: (title: string) => void;
  onSelectChapter: (id: string) => void;
  onAddChapter: () => void;
  onOpenImportDialog: () => void;
}

export function MobileChapterSidebar({
  open,
  onOpenChange,
  chapters,
  activeChapterId,
  canEdit,
  addingChapter,
  newChapterTitle,
  onSetAddingChapter,
  onSetNewChapterTitle,
  onSelectChapter,
  onAddChapter,
  onOpenImportDialog,
}: MobileChapterSidebarProps) {
  const t = useTranslations();

  return (
    <Sheet open={open} onOpenChange={(isOpen) => {
      onOpenChange(isOpen);
      if (!isOpen) {
        onSetAddingChapter(false);
        onSetNewChapterTitle('');
      }
    }}>
      <SheetContent side="left" className="w-80 p-0 flex flex-col">
        <SheetHeader className="px-4 py-3 border-b">
          <SheetTitle className="text-base">{t('books.chapters')}</SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-hidden flex flex-col">
          {canEdit && (
            <div className="px-3 py-2 border-b flex items-center justify-end gap-1">
              <Button
                variant="ghost"
                size="sm"
                title={t('books.importDocument')}
                onClick={() => {
                  onOpenChange(false);
                  setTimeout(() => onOpenImportDialog(), 150);
                }}
              >
                <FileUp className="h-4 w-4 me-2" />
                Import
              </Button>
              <Button
                variant="ghost"
                size="sm"
                title={t('books.addChapter')}
                onClick={() => onSetAddingChapter(true)}
              >
                <Plus className="h-4 w-4 me-2" />
                Add
              </Button>
            </div>
          )}

          {addingChapter && (
            <div className="px-3 py-2 border-b bg-muted/50">
              <div className="flex items-center gap-2">
                <Input
                  value={newChapterTitle}
                  onChange={(e) => onSetNewChapterTitle(e.target.value)}
                  placeholder={t('books.chapterTitlePlaceholder')}
                  className="h-9 text-sm flex-1"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newChapterTitle.trim()) {
                      onAddChapter();
                      onOpenChange(false);
                    } else if (e.key === 'Escape') {
                      onSetAddingChapter(false);
                      onSetNewChapterTitle('');
                    }
                  }}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 shrink-0"
                  onClick={() => {
                    if (newChapterTitle.trim()) {
                      onAddChapter();
                      onOpenChange(false);
                    }
                  }}
                >
                  <Check className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 shrink-0"
                  onClick={() => {
                    onSetAddingChapter(false);
                    onSetNewChapterTitle('');
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {chapters.length === 0 && !addingChapter ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p className="text-sm">{t('books.noChapters')}</p>
                </div>
              ) : (
                chapters.map((chapter, index) => (
                  <div
                    key={chapter.id}
                    className={cn(
                      'flex items-center gap-2 rounded-md px-3 py-2.5 cursor-pointer transition-colors',
                      activeChapterId === chapter.id
                        ? 'bg-primary/10 text-primary'
                        : 'hover:bg-muted'
                    )}
                    onClick={() => {
                      onSelectChapter(chapter.id);
                      onOpenChange(false);
                    }}
                  >
                    <BookOpen className="h-4 w-4 shrink-0" />
                    <span className="text-sm truncate flex-1">
                      {index + 1}. {chapter.title}
                    </span>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}
