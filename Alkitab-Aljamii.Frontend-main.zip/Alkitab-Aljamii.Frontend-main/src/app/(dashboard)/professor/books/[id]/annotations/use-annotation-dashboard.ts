'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { booksApi } from '@/lib/api/books';
import { annotationsApi } from '@/lib/api/annotations';
import { ROUTES } from '@/lib/constants/routes';
import type {
  Book,
  Chapter,
  Annotation,
  AnnotationStats,
  RecentActivity,
  QueryAnnotationsParams,
} from '@/types';

export interface PaginationState {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export function useAnnotationDashboard(bookId: string) {
  const router = useRouter();
  const t = useTranslations();

  // State
  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [stats, setStats] = useState<AnnotationStats | null>(null);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    total: 0,
    page: 1,
    limit: 20,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  });
  const [filters, setFilters] = useState<QueryAnnotationsParams>({
    page: 1,
    limit: 20,
    sortBy: 'createdAt',
    sortOrder: 'DESC',
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingAnnotations, setIsLoadingAnnotations] = useState(false);

  // Load book, chapters, and stats
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        const [bookData, chaptersData, dashboardData] = await Promise.all([
          booksApi.getById(bookId),
          booksApi.getChapters(bookId),
          annotationsApi.getDashboard({ bookId }),
        ]);
        setBook(bookData);
        setChapters(chaptersData);
        setStats(dashboardData.stats);
        setRecentActivity(dashboardData.recentActivity);
      } catch (error) {
        toast.error(t('common.error'));
        router.push(ROUTES.PROFESSOR.BOOKS);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [bookId, router, t]);

  // Load annotations with filters
  const loadAnnotations = useCallback(async () => {
    try {
      setIsLoadingAnnotations(true);
      const data = await annotationsApi.getAllBookAnnotations(bookId, filters);
      setAnnotations(data.items);
      setPagination({
        total: data.total,
        page: data.page,
        limit: data.limit,
        totalPages: data.totalPages,
        hasNextPage: data.hasNextPage,
        hasPreviousPage: data.hasPreviousPage,
      });
    } catch (error) {
      toast.error(t('common.error'));
    } finally {
      setIsLoadingAnnotations(false);
    }
  }, [bookId, filters, t]);

  useEffect(() => {
    if (book) {
      loadAnnotations();
    }
  }, [book, loadAnnotations]);

  // Handle filter changes
  const handleFiltersChange = useCallback((newFilters: QueryAnnotationsParams) => {
    setFilters(newFilters);
  }, []);

  // Handle sort change
  const handleSortChange = useCallback((field: 'createdAt' | 'updatedAt') => {
    setFilters((prev) => ({
      ...prev,
      sortBy: field,
      sortOrder: prev.sortBy === field && prev.sortOrder === 'DESC' ? 'ASC' : 'DESC',
    }));
  }, []);

  // Handle page change
  const handlePageChange = useCallback((page: number) => {
    setFilters((prev) => ({ ...prev, page }));
  }, []);

  // Handle annotation click - navigate to book viewer
  const handleAnnotationClick = useCallback((annotation: Annotation) => {
    const chapterId = annotation.chapterId || chapters[0]?.id;
    if (chapterId) {
      router.push(
        `/professor/view/book/${bookId}/chapter/${chapterId}?annotation=${annotation.id}&page=${annotation.pageNumber || 1}`
      );
    }
  }, [bookId, chapters, router]);

  // Handle refresh
  const handleRefresh = useCallback(async () => {
    try {
      const dashboardData = await annotationsApi.getDashboard({ bookId });
      setStats(dashboardData.stats);
      setRecentActivity(dashboardData.recentActivity);
      await loadAnnotations();
      toast.success('Dashboard refreshed');
    } catch (error) {
      toast.error(t('common.error'));
    }
  }, [bookId, loadAnnotations, t]);

  // Handle export
  const handleExport = useCallback(async () => {
    try {
      // Fetch all annotations (no pagination)
      const allData = await annotationsApi.getAllBookAnnotations(bookId, {
        ...filters,
        page: 1,
        limit: 10000,
      });

      // Create CSV
      const headers = ['Student', 'Email', 'Type', 'Chapter', 'Page', 'Selected Text', 'Note', 'Created At', 'Status'];
      const rows = allData.items.map((a) => [
        `${a.user.firstName} ${a.user.lastName}`,
        a.user.email || '',
        a.type,
        '',
        a.pageNumber?.toString() || '',
        a.textAnchor?.selectedText || '',
        a.content || '',
        new Date(a.createdAt).toISOString(),
        a.isOrphaned ? 'Orphaned' : 'Active',
      ]);

      const csv = [headers, ...rows].map((row) =>
        row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(',')
      ).join('\n');

      // Download
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `annotations-${book?.title || 'export'}-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success('Annotations exported successfully');
    } catch (error) {
      toast.error('Failed to export annotations');
    }
  }, [bookId, book, filters]);

  // Chapter options for filters
  const chapterOptions = useMemo(() =>
    chapters.map((ch) => ({ id: ch.id, title: ch.title })),
    [chapters]
  );

  // User options from top contributors
  const userOptions = useMemo(() =>
    stats?.topContributors.map((c) => ({ id: c.userId, name: c.userName })) || [],
    [stats]
  );

  return {
    // State
    book,
    chapters,
    stats,
    recentActivity,
    annotations,
    pagination,
    filters,
    isLoading,
    isLoadingAnnotations,
    // Computed
    chapterOptions,
    userOptions,
    // Handlers
    handleFiltersChange,
    handleSortChange,
    handlePageChange,
    handleAnnotationClick,
    handleRefresh,
    handleExport,
  };
}
