'use client';

import { memo, useCallback, useState } from 'react';
import { Plus, Check, X, FileUp, BookOpen, FolderDown } from 'lucide-react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { booksApi } from '@/lib/api/books';
import { ChapterListItem } from './chapter-list-item';
import { ResourcesPanel } from './resources-panel';
import type { TocItem } from '../lib';
import type { Chapter } from '@/types';

interface BookEditorSidebarProps {
  bookId: string;
  chapters: Chapter[];
  activeChapterId: string | null;
  canEdit: boolean;
  isEditMode: boolean;
  expandedChapters: Set<string>;
  addingChapter: boolean;
  newChapterTitle: string;
  chapterTocs: Record<string, TocItem[]>;
  activeHeadingIndex: number | null;
  t: (key: string) => string;
  onSetChapters: (chapters: Chapter[] | ((prev: Chapter[]) => Chapter[])) => void;
  onSetActiveChapterId: (id: string | null) => void;
  onSetExpandedChapters: (fn: (prev: Set<string>) => Set<string>) => void;
  onSetAddingChapter: (adding: boolean) => void;
  onSetNewChapterTitle: (title: string) => void;
  onSetImportDialogOpen: (open: boolean) => void;
  onToggleExpand: (chapterId: string) => void;
  onRenameChapter: (chapterId: string, newTitle: string) => Promise<void>;
  onDeleteChapter: (chapterId: string) => Promise<void>;
  onTocClick: (chapterId: string, tocIndex: number) => void;
  onQuizConfig: (chapterId: string, chapterTitle: string) => void;
}

export const BookEditorSidebar = memo(function BookEditorSidebar({
  bookId,
  chapters,
  activeChapterId,
  canEdit,
  isEditMode,
  expandedChapters,
  addingChapter,
  newChapterTitle,
  chapterTocs,
  activeHeadingIndex,
  t,
  onSetChapters,
  onSetActiveChapterId,
  onSetExpandedChapters,
  onSetAddingChapter,
  onSetNewChapterTitle,
  onSetImportDialogOpen,
  onToggleExpand,
  onRenameChapter,
  onDeleteChapter,
  onTocClick,
  onQuizConfig,
}: BookEditorSidebarProps) {
  const [activeTab, setActiveTab] = useState<'chapters' | 'resources'>('chapters');

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = useCallback(async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = chapters.findIndex((ch) => ch.id === active.id);
      const newIndex = chapters.findIndex((ch) => ch.id === over.id);

      const newChapters = arrayMove(chapters, oldIndex, newIndex);
      onSetChapters(newChapters);

      try {
        await booksApi.reorderChapters(bookId, {
          chapterIds: newChapters.map((ch) => ch.id),
        });
      } catch {
        onSetChapters(chapters);
        toast.error(t('common.error'));
      }
    }
  }, [chapters, bookId, t, onSetChapters]);

  const handleAddChapter = useCallback(async () => {
    if (!newChapterTitle.trim()) return;

    try {
      const newChapter = await booksApi.createChapter(bookId, {
        title: newChapterTitle.trim(),
        order: chapters.length,
      });
      onSetChapters((prev) => [...prev, newChapter]);
      onSetActiveChapterId(newChapter.id);
      onSetExpandedChapters((prev) => new Set([...prev, newChapter.id]));
      onSetAddingChapter(false);
      onSetNewChapterTitle('');
      toast.success(t('books.chapterAdded'));
    } catch {
      toast.error(t('common.error'));
    }
  }, [newChapterTitle, chapters.length, bookId, t, onSetChapters, onSetActiveChapterId, onSetExpandedChapters, onSetAddingChapter, onSetNewChapterTitle]);

  return (
    <div className={cn(
      "w-64 shrink-0 border-r bg-muted/30 flex-col overflow-hidden hidden md:flex",
      chapters.length === 0 && "md:flex"
    )}>
      {/* Tab Header */}
      <div className="p-2 border-b">
        <div className="flex items-center bg-muted rounded-md p-0.5">
          <Button
            variant="ghost"
            size="sm"
            className={cn(
              "flex-1 h-7 text-xs gap-1.5 rounded-sm",
              activeTab === 'chapters' && "bg-background shadow-sm"
            )}
            onClick={() => setActiveTab('chapters')}
          >
            <BookOpen className="h-3.5 w-3.5" />
            {t('books.chapters')}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className={cn(
              "flex-1 h-7 text-xs gap-1.5 rounded-sm",
              activeTab === 'resources' && "bg-background shadow-sm"
            )}
            onClick={() => setActiveTab('resources')}
          >
            <FolderDown className="h-3.5 w-3.5" />
            {t('resources.title')}
          </Button>
        </div>
      </div>

      {activeTab === 'chapters' ? (
        <>
          {/* Chapters Header with actions */}
          {canEdit && isEditMode && (
            <div className="px-3 py-2 border-b flex items-center justify-end gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                title={t('books.importDocument')}
                onClick={() => onSetImportDialogOpen(true)}
              >
                <FileUp className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                title={t('books.addChapter')}
                onClick={() => onSetAddingChapter(true)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          )}

          <ScrollArea className="flex-1 w-full chapter-list-scroll">
            <div className="p-2 space-y-1 w-full overflow-hidden">
              {chapters.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p className="text-sm">{t('books.noChapters')}</p>
                </div>
              ) : (
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext
                    items={chapters.map((ch) => ch.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    {chapters.map((chapter, index) => (
                      <ChapterListItem
                        key={chapter.id}
                        chapter={chapter}
                        index={index}
                        isActive={activeChapterId === chapter.id}
                        isExpanded={expandedChapters.has(chapter.id)}
                        canEdit={canEdit}
                        isEditMode={isEditMode}
                        toc={chapterTocs[chapter.id] || []}
                        activeHeadingIndex={activeChapterId === chapter.id ? activeHeadingIndex : null}
                        onSelect={onSetActiveChapterId}
                        onToggleExpand={onToggleExpand}
                        onRename={onRenameChapter}
                        onDelete={onDeleteChapter}
                        onTocClick={onTocClick}
                        onQuizConfig={onQuizConfig}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
              )}

              {addingChapter && (
                <div className="flex items-center gap-1 px-2 py-1">
                  <Input
                    value={newChapterTitle}
                    onChange={(e) => onSetNewChapterTitle(e.target.value)}
                    placeholder={t('books.chapterTitlePlaceholder')}
                    className="h-7 text-sm"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleAddChapter();
                      } else if (e.key === 'Escape') {
                        onSetAddingChapter(false);
                        onSetNewChapterTitle('');
                      }
                    }}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={handleAddChapter}
                  >
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => {
                      onSetAddingChapter(false);
                      onSetNewChapterTitle('');
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </ScrollArea>
        </>
      ) : (
        <ResourcesPanel
          bookId={bookId}
          chapters={chapters}
          isEditMode={isEditMode}
          canEdit={canEdit}
        />
      )}
    </div>
  );
});
