/**
 * Table of Contents utilities
 */

export interface TocItem {
  id: string;
  text: string;
  level: number;
}

/**
 * Extract headers from HTML content for TOC
 * @param html - The HTML string to parse
 * @returns Array of TOC items
 */
export function extractTableOfContents(html: string): TocItem[] {
  if (!html) return [];

  // DOMParser is not available during SSR
  if (typeof window === 'undefined') return [];

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const headers = doc.querySelectorAll('h1, h2, h3, h4, h5, h6');

    const toc: TocItem[] = [];
    headers.forEach((header, index) => {
      const level = parseInt(header.tagName.charAt(1));
      const text = header.textContent?.trim() || '';
      if (text) {
        toc.push({
          id: `heading-${index}`,
          text,
          level,
        });
      }
    });

    return toc;
  } catch (e) {
    console.error('Failed to extract TOC:', e);
    return [];
  }
}
