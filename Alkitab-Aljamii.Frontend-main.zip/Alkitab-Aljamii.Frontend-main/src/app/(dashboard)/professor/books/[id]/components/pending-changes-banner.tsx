'use client';

import { memo } from 'react';
import { Info, Send, Undo2, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PendingChangesBannerProps {
  t: (key: string) => string;
  isSubmitting?: boolean;
  isDiscarding?: boolean;
  onDiscard: () => void;
  onSubmit: () => void;
  className?: string;
}

/**
 * Banner shown when editing a published book.
 *
 * Displays:
 * - Info that students still see published version
 * - Changes will go live after approval
 * - Actions: Discard changes, Continue editing, Submit for approval
 */
export const PendingChangesBanner = memo(function PendingChangesBanner({
  t,
  isSubmitting = false,
  isDiscarding = false,
  onDiscard,
  onSubmit,
  className,
}: PendingChangesBannerProps) {
  const isLoading = isSubmitting || isDiscarding;

  return (
    <Alert className={cn("border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950 overflow-hidden", className)}>
      <Info className="h-4 w-4 text-blue-600 dark:text-blue-400 shrink-0" />
      <AlertTitle className="text-blue-900 dark:text-blue-100">
        {t('books.pendingChangesBanner.title')}
      </AlertTitle>
      <AlertDescription className="text-blue-800 dark:text-blue-200 overflow-hidden">
        <p className="mb-3 text-sm hidden sm:block">{t('books.pendingChangesBanner.description')}</p>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onDiscard}
            disabled={isLoading}
            className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-100 dark:border-blue-700 dark:text-blue-300 dark:hover:bg-blue-900 w-full sm:w-auto"
          >
            {isDiscarding ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Undo2 className="h-4 w-4" />
            )}
            {t('books.actions.revertToPublished')}
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={onSubmit}
            disabled={isLoading}
            className="gap-2 w-full sm:w-auto"
          >
            {isSubmitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            {t('books.actions.sendChangesForApproval')}
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
});
