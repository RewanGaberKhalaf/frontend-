'use client';

import { useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { MediaLibraryConnected } from '@/components/shared/rich-text-editor/media-library-connected';
import { ChapterQuizConfigDialog } from '@/components/quiz';
import { ImportDocumentDialog } from '@/components/books/import-document-dialog';

// Local modules
import { useBookEditor, useViewModeAnnotations, useChapterTiptap, useBookEditorHandlers } from './hooks';
import {
  SaveVersionDialog,
  VersionHistoryDialog,
  MobileChapterSidebar,
  BookEditorHeader,
  BookEditorSidebar,
  EditorContentArea,
} from './components';
import { PendingChangesBanner } from './components/pending-changes-banner';
import { RejectionBanner } from './components/rejection-banner';

export default function BookEditorPage() {
  const params = useParams();
  const t = useTranslations();
  const bookId = params['id'] as string;

  // Loading states for async actions
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDiscarding, setIsDiscarding] = useState(false);

  // Core book editor state
  const bookEditor = useBookEditor({ bookId, t });

  // Chapter TipTap editor - initialized with a placeholder for auto-save
  const chapterTiptap = useChapterTiptap({
    activeChapter: bookEditor.activeChapter,
    activeChapterId: bookEditor.activeChapterId,
    chapters: bookEditor.chapters,
    canEdit: bookEditor.canEdit,
    onContentChange: () => bookEditor.setHasUnsavedChanges(true),
    onAutoSave: () => {}, // Will be connected after handlers are initialized
  });
  const { editor, setEditorContent, activeHeadingIndex, chapterTocs, handleTocClick, clearSaveTimeout, reloadActiveChapter } = chapterTiptap;

  // View mode annotations
  const viewAnnotations = useViewModeAnnotations({
    bookId,
    activeChapter: bookEditor.activeChapter,
    activeChapterId: bookEditor.activeChapterId,
    chapters: bookEditor.chapters,
    isEditMode: bookEditor.isEditMode,
  });

  // All handlers extracted to hook
  const handlers = useBookEditorHandlers({
    bookId,
    bookEditor,
    editor,
    clearSaveTimeout,
    setEditorContent,
    reloadActiveChapter,
    viewAnnotations,
    handleTocClick,
    t,
  });

  // Connect auto-save to saveChapterContent
  chapterTiptap.onAutoSaveRef.current = handlers.saveChapterContent;

  // Full book HTML for preview
  // In view mode: show publishedContent (what students see) when available
  // In edit mode: show current draft content
  const fullBookHtml = useMemo(() => {
    const usePublishedContent = !bookEditor.isEditMode;

    return bookEditor.chapters
      .map((chapter, index) => {
        const pageBreak = index > 0 ? '<div style="page-break-before: always;"></div>' : '';
        // Use publishedContent in view mode if available, otherwise fall back to content
        const chapterHtml = usePublishedContent && chapter.publishedContent
          ? chapter.publishedContent
          : (chapter.content || '');
        return pageBreak + chapterHtml;
      })
      .join('\n');
  }, [bookEditor.chapters, bookEditor.isEditMode]);

  // Loading state
  if (bookEditor.isLoading) {
    return (
      <div className="h-full flex">
        <div className="w-64 border-r p-4 space-y-4 hidden md:block">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
        </div>
        <div className="flex-1 p-4">
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  // Error state
  if (!bookEditor.book) {
    return (
      <div className="flex items-center justify-center h-full">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t('common.error')}</AlertTitle>
          <AlertDescription>{t('books.notFound')}</AlertDescription>
        </Alert>
      </div>
    );
  }

  // Wrap handlers with loading state
  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await handlers.handleSubmitForReview();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePublish = async () => {
    setIsSubmitting(true);
    try {
      await handlers.handlePublish();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDiscardPendingChanges = async () => {
    if (!confirm(t('books.discardSessionConfirm'))) return;
    setIsDiscarding(true);
    try {
      await handlers.handleDiscardPendingChanges();
    } finally {
      setIsDiscarding(false);
    }
  };

  // Determine if we should show banners (only in edit mode)
  const showPendingChangesBanner =
    bookEditor.isEditMode &&
    bookEditor.book.status === 'published' &&
    bookEditor.book.hasPendingChanges;
  const showRejectionBanner =
    bookEditor.book.status === 'rejected' &&
    bookEditor.book.rejectionReason;

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <BookEditorHeader
        book={bookEditor.book}
        chapters={bookEditor.chapters}
        activeChapter={bookEditor.activeChapter}
        isEditMode={bookEditor.isEditMode}
        canEdit={bookEditor.canEdit}
        isSaving={bookEditor.isSaving}
        hasUnsavedChanges={bookEditor.hasUnsavedChanges}
        showPreview={bookEditor.showPreview}
        previewMode={bookEditor.previewMode}
        isSidebarOpen={viewAnnotations.isSidebarOpen}
        annotationsCount={viewAnnotations.annotations.length}
        isSubmitting={isSubmitting}
        t={t}
        onSetIsEditMode={bookEditor.setIsEditMode}
        onSetShowPreview={bookEditor.setShowPreview}
        onSetPreviewMode={bookEditor.setPreviewMode}
        onSetMobileSidebarOpen={bookEditor.setMobileSidebarOpen}
        onSetVersionDialogOpen={bookEditor.setVersionDialogOpen}
        onOpenHistory={bookEditor.handleOpenHistory}
        onSubmitForReview={handleSubmit}
        onPublish={handlePublish}
        onToggleSidebar={() => viewAnnotations.setSidebarOpen(!viewAnnotations.isSidebarOpen)}
      />

      <div className="flex-1 flex min-h-0">
        <BookEditorSidebar
          bookId={bookId}
          chapters={bookEditor.chapters}
          activeChapterId={bookEditor.activeChapterId}
          canEdit={bookEditor.canEdit}
          isEditMode={bookEditor.isEditMode}
          expandedChapters={bookEditor.expandedChapters}
          addingChapter={bookEditor.addingChapter}
          newChapterTitle={bookEditor.newChapterTitle}
          chapterTocs={chapterTocs}
          activeHeadingIndex={activeHeadingIndex}
          t={t}
          onSetChapters={bookEditor.setChapters}
          onSetActiveChapterId={bookEditor.setActiveChapterId}
          onSetExpandedChapters={bookEditor.setExpandedChapters}
          onSetAddingChapter={bookEditor.setAddingChapter}
          onSetNewChapterTitle={bookEditor.setNewChapterTitle}
          onSetImportDialogOpen={bookEditor.setImportDialogOpen}
          onToggleExpand={bookEditor.handleToggleExpand}
          onRenameChapter={bookEditor.handleRenameChapter}
          onDeleteChapter={bookEditor.handleDeleteChapter}
          onTocClick={handlers.handleTocClickWithSwitch}
          onQuizConfig={bookEditor.handleQuizConfig}
        />

        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Contextual banners - inside content area for proper alignment */}
          {showPendingChangesBanner && (
            <PendingChangesBanner
              t={t}
              isSubmitting={isSubmitting}
              isDiscarding={isDiscarding}
              onDiscard={handleDiscardPendingChanges}
              onSubmit={handleSubmit}
              className="shrink-0 rounded-none border-x-0"
            />
          )}

          {showRejectionBanner && (
            <RejectionBanner
              bookId={bookEditor.book.id}
              reason={bookEditor.book.rejectionReason!}
              t={t}
              onStartEditing={() => bookEditor.setIsEditMode(true)}
              className="shrink-0 rounded-none border-x-0"
            />
          )}

          <EditorContentArea
            book={bookEditor.book}
            chapters={bookEditor.chapters}
            activeChapter={bookEditor.activeChapter}
            editor={editor}
            isEditMode={bookEditor.isEditMode}
            canEdit={bookEditor.canEdit}
            showPreview={bookEditor.showPreview}
            previewMode={bookEditor.previewMode}
            fullBookHtml={fullBookHtml}
            watermarkText={viewAnnotations.watermarkText}
            annotations={viewAnnotations.annotations}
            currentPage={viewAnnotations.currentPage}
            targetPage={viewAnnotations.targetPage}
            focusedAnnotationId={viewAnnotations.focusedAnnotationId}
            chapterInfos={viewAnnotations.chapterInfos}
            userId={viewAnnotations.user?.id}
            isSidebarOpen={viewAnnotations.isSidebarOpen}
            t={t}
            onOpenMediaLibrary={() => bookEditor.setMediaLibraryOpen(true)}
            onSetAddingChapter={bookEditor.setAddingChapter}
            onBoundariesComputed={handlers.handleBoundariesComputed}
            onAnnotationCreate={viewAnnotations.handleAnnotationCreate}
            onAnnotationClick={handlers.handleAnnotationClick}
            onPageChange={viewAnnotations.handlePageChange}
          />
        </div>
      </div>

      {/* Dialogs */}
      <MediaLibraryConnected
        open={bookEditor.mediaLibraryOpen}
        onOpenChange={bookEditor.setMediaLibraryOpen}
        onSelect={(media) => {
          if (editor) {
            editor
              .chain()
              .focus()
              .setResizableMedia({
                src: media.url,
                mediaId: media.id,
                mediaType: media.type === 'image' ? 'image' : 'video',
                alt: media.name || '',
                title: media.name || '',
                width: '80%',
                alignment: 'center',
                float: 'none',
              })
              .run();
          }
          bookEditor.setMediaLibraryOpen(false);
        }}
      />

      <SaveVersionDialog
        open={bookEditor.versionDialogOpen}
        onOpenChange={bookEditor.setVersionDialogOpen}
        description={bookEditor.versionDescription}
        onDescriptionChange={bookEditor.setVersionDescription}
        onSave={bookEditor.handleSaveVersion}
      />

      <VersionHistoryDialog
        open={bookEditor.historyDialogOpen}
        onOpenChange={bookEditor.setHistoryDialogOpen}
        versions={bookEditor.versions}
        canEdit={bookEditor.canEdit}
        onRestore={handlers.handleRestoreVersion}
      />

      {bookEditor.quizConfigChapter && bookEditor.book && (
        <ChapterQuizConfigDialog
          open={!!bookEditor.quizConfigChapter}
          onOpenChange={(open) => !open && bookEditor.setQuizConfigChapter(null)}
          chapterId={bookEditor.quizConfigChapter.id}
          chapterTitle={bookEditor.quizConfigChapter.title}
          subjectId={bookEditor.book.subjectId}
          readOnly={!bookEditor.canEdit}
        />
      )}

      <ImportDocumentDialog
        open={bookEditor.importDialogOpen}
        onOpenChange={bookEditor.setImportDialogOpen}
        onImport={handlers.handleImportDocument}
      />

      <MobileChapterSidebar
        open={bookEditor.mobileSidebarOpen}
        onOpenChange={bookEditor.setMobileSidebarOpen}
        chapters={bookEditor.chapters}
        activeChapterId={bookEditor.activeChapterId}
        canEdit={bookEditor.canEdit}
        addingChapter={bookEditor.addingChapter}
        newChapterTitle={bookEditor.newChapterTitle}
        onSetAddingChapter={bookEditor.setAddingChapter}
        onSetNewChapterTitle={bookEditor.setNewChapterTitle}
        onSelectChapter={bookEditor.setActiveChapterId}
        onAddChapter={bookEditor.handleAddChapter}
        onOpenImportDialog={() => bookEditor.setImportDialogOpen(true)}
      />
    </div>
  );
}
