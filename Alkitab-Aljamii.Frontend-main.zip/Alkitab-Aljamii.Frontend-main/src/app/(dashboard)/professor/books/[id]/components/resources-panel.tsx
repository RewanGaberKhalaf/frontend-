'use client';

import { memo, useState, useEffect, useCallback } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { toast } from 'sonner';
import {
  Plus,
  FileText,
  Image,
  Music,
  Video,
  Archive,
  Download,
  Trash2,
  Link as LinkIcon,
  ExternalLink,
  Youtube,
  Globe,
  FolderOpen,
  FileUp,
  Loader2,
  X,
  Upload,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { MoreVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { booksApi } from '@/lib/api/books';
import { MediaLibraryConnected } from '@/components/shared/rich-text-editor/media-library-connected';
import type { MediaItem } from '@/lib/api/media';
import type { BookResource, GroupedBookResources, Chapter, LinkType } from '@/types';

const FILE_ICONS = {
  document: FileText,
  image: Image,
  audio: Music,
  video: Video,
  archive: Archive,
  link: LinkIcon,
} as const;

const LINK_ICONS = {
  youtube: Youtube,
  vimeo: Video,
  website: Globe,
  document: FileText,
  drive: FolderOpen,
  other: LinkIcon,
} as const;

function formatFileSize(bytes: number | null): string {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

interface ResourcesPanelProps {
  bookId: string;
  chapters: Chapter[];
  isEditMode: boolean;
  canEdit: boolean;
}

export const ResourcesPanel = memo(function ResourcesPanel({
  bookId,
  chapters,
  isEditMode,
  canEdit,
}: ResourcesPanelProps) {
  const t = useTranslations();
  const locale = useLocale();
  const isRtl = locale === 'ar';

  const [resources, setResources] = useState<GroupedBookResources | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [mediaLibraryOpen, setMediaLibraryOpen] = useState(false);
  const [publishDialogOpen, setPublishDialogOpen] = useState(false);
  const [discardDialogOpen, setDiscardDialogOpen] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isDiscarding, setIsDiscarding] = useState(false);

  // Add form state
  const [resourceMode, setResourceMode] = useState<'file' | 'link'>('file');
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadTitleAr, setUploadTitleAr] = useState('');
  const [uploadChapterId, setUploadChapterId] = useState<string>('');
  const [linkUrl, setLinkUrl] = useState('');
  const [linkType, setLinkType] = useState<LinkType>('website');

  const loadResources = useCallback(async () => {
    try {
      const data = await booksApi.getResources(bookId);
      setResources(data);
    } catch {
      toast.error(t('common.errorLoading'));
    } finally {
      setIsLoading(false);
    }
  }, [bookId, t]);

  useEffect(() => {
    loadResources();
  }, [loadResources]);

  const resetForm = () => {
    setResourceMode('file');
    setSelectedMedia(null);
    setUploadTitle('');
    setUploadTitleAr('');
    setUploadChapterId('');
    setLinkUrl('');
    setLinkType('website');
  };

  const handleMediaSelect = (media: MediaItem) => {
    setSelectedMedia(media);
    if (!uploadTitle) {
      setUploadTitle(media.name);
    }
  };

  const handleAdd = async () => {
    if (!uploadTitle.trim()) {
      toast.error(t('resources.titleRequired'));
      return;
    }

    if (resourceMode === 'file' && !selectedMedia) {
      toast.error(t('resources.selectFile'));
      return;
    }

    if (resourceMode === 'link') {
      if (!linkUrl.trim()) {
        toast.error(t('resources.urlRequired'));
        return;
      }
      try {
        new URL(linkUrl);
      } catch {
        toast.error(t('resources.invalidUrl'));
        return;
      }
    }

    setIsSubmitting(true);
    try {
      if (resourceMode === 'file' && selectedMedia) {
        await booksApi.createMediaResource(bookId, {
          title: uploadTitle,
          titleAr: uploadTitleAr || undefined,
          mediaId: selectedMedia.id,
          chapterId: uploadChapterId || undefined,
        });
      } else {
        await booksApi.createLinkResource(bookId, {
          title: uploadTitle,
          titleAr: uploadTitleAr || undefined,
          url: linkUrl,
          linkType,
          chapterId: uploadChapterId || undefined,
        });
      }
      toast.success(t('resources.uploadSuccess'));
      setAddDialogOpen(false);
      resetForm();
      loadResources();
    } catch {
      toast.error(t('resources.uploadFailed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = async (resource: BookResource) => {
    try {
      const { url, fileName } = await booksApi.getResourceDownloadUrl(bookId, resource.id);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      toast.error(t('resources.downloadFailed'));
    }
  };

  const handleDelete = async (resource: BookResource) => {
    if (!confirm(t('resources.deleteConfirm'))) return;
    try {
      await booksApi.deleteResource(bookId, resource.id);
      toast.success(t('resources.deleteSuccess'));
      loadResources();
    } catch {
      toast.error(t('resources.deleteFailed'));
    }
  };

  const handlePublish = async () => {
    setIsPublishing(true);
    try {
      const result = await booksApi.publishResources(bookId);
      toast.success(t('resources.publishSuccess', { count: result.publishedCount }));
      setPublishDialogOpen(false);
      loadResources();
    } catch {
      toast.error(t('resources.publishFailed'));
    } finally {
      setIsPublishing(false);
    }
  };

  const handleDiscard = async () => {
    setIsDiscarding(true);
    try {
      const result = await booksApi.discardDraftResources(bookId);
      toast.success(t('resources.discardSuccess', { count: result.discardedCount }));
      setDiscardDialogOpen(false);
      loadResources();
    } catch {
      toast.error(t('resources.discardFailed'));
    } finally {
      setIsDiscarding(false);
    }
  };

  const ResourceItem = ({ resource }: { resource: BookResource }) => {
    const isLink = resource.resourceType === 'link';
    const Icon = isLink
      ? (LINK_ICONS[resource.linkType as keyof typeof LINK_ICONS] || LinkIcon)
      : (FILE_ICONS[resource.fileCategory as keyof typeof FILE_ICONS] || FileText);
    const title = isRtl && resource.titleAr ? resource.titleAr : resource.title;

    return (
      <div className={cn(
        "flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted/50 group",
        resource.isDraft && "border-l-2 border-amber-500 bg-amber-50/50 dark:bg-amber-950/20"
      )}>
        <Icon className={cn("h-4 w-4 shrink-0", isLink ? "text-blue-500" : "text-muted-foreground")} />
        <span className="text-sm truncate flex-1">{title}</span>
        {resource.isDraft && (
          <Badge variant="outline" className="text-[9px] h-4 px-1 border-amber-500 text-amber-600 dark:text-amber-400">
            {t('resources.draft')}
          </Badge>
        )}
        {!isLink && resource.fileSize && (
          <span className="text-[10px] text-muted-foreground hidden group-hover:inline">
            {formatFileSize(resource.fileSize)}
          </span>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100">
              <MoreVertical className="h-3 w-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {isLink ? (
              <DropdownMenuItem onClick={() => window.open(resource.url!, '_blank')}>
                <ExternalLink className="h-4 w-4 me-2" />
                {t('resources.openLink')}
              </DropdownMenuItem>
            ) : (
              <DropdownMenuItem onClick={() => handleDownload(resource)}>
                <Download className="h-4 w-4 me-2" />
                {t('resources.download')}
              </DropdownMenuItem>
            )}
            {canEdit && isEditMode && (
              <DropdownMenuItem onClick={() => handleDelete(resource)} className="text-destructive">
                <Trash2 className="h-4 w-4 me-2" />
                {t('common.delete')}
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const bookLevelResources = resources?.bookLevel || [];
  const chapterLevelResources = resources?.chapterLevel || {};
  const totalResources = bookLevelResources.length +
    Object.values(chapterLevelResources).reduce((acc, arr) => acc + arr.length, 0);
  const draftCount = resources?.draftCount || 0;

  return (
    <>
      {/* Add Resource Button - Always visible in edit mode */}
      {canEdit && isEditMode && (
        <div className="px-2 py-2 border-b">
          <Button
            variant="outline"
            size="sm"
            className="w-full h-8 text-xs"
            onClick={() => setAddDialogOpen(true)}
          >
            <Plus className="h-3.5 w-3.5 me-1.5" />
            {t('resources.addResource')}
          </Button>
        </div>
      )}

      {/* Draft Actions Bar */}
      {canEdit && isEditMode && draftCount > 0 && (
        <div className="px-2 py-2 border-b bg-amber-50/80 dark:bg-amber-950/30">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <span className="text-xs font-medium text-amber-700 dark:text-amber-400">
              {t('resources.pendingDrafts', { count: draftCount })}
            </span>
          </div>
          <div className="flex gap-2">
            <Button
              variant="default"
              size="sm"
              className="h-7 text-xs flex-1 bg-amber-600 hover:bg-amber-700"
              onClick={() => setPublishDialogOpen(true)}
              disabled={isPublishing}
            >
              {isPublishing ? (
                <Loader2 className="h-3 w-3 animate-spin me-1" />
              ) : (
                <Upload className="h-3 w-3 me-1" />
              )}
              {t('resources.publishAll')}
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs"
              onClick={() => setDiscardDialogOpen(true)}
              disabled={isDiscarding}
            >
              {isDiscarding ? (
                <Loader2 className="h-3 w-3 animate-spin me-1" />
              ) : (
                <XCircle className="h-3 w-3 me-1" />
              )}
              {t('resources.discardDrafts')}
            </Button>
          </div>
        </div>
      )}

      <ScrollArea className="flex-1 w-full">
        <div className="p-2 space-y-3">
          {totalResources === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              <FolderOpen className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">{t('resources.noBookResources')}</p>
              {canEdit && isEditMode && (
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => setAddDialogOpen(true)}
                >
                  <Plus className="h-4 w-4 me-1" />
                  {t('resources.addFirst')}
                </Button>
              )}
            </div>
          ) : (
            <>
              {/* Book-level resources */}
              {bookLevelResources.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 px-2 mb-1">
                    <span className="text-xs font-medium text-muted-foreground uppercase">
                      {t('resources.bookLevel')}
                    </span>
                    <Badge variant="secondary" className="text-[10px] h-4">
                      {bookLevelResources.length}
                    </Badge>
                  </div>
                  {bookLevelResources.map((resource) => (
                    <ResourceItem key={resource.id} resource={resource} />
                  ))}
                </div>
              )}

              {/* Chapter-level resources */}
              {chapters.map((chapter) => {
                const chapterResources = chapterLevelResources[chapter.id] || [];
                if (chapterResources.length === 0) return null;

                const chapterTitle = isRtl && chapter.titleAr ? chapter.titleAr : chapter.title;

                return (
                  <div key={chapter.id}>
                    <div className="flex items-center gap-2 px-2 mb-1">
                      <span className="text-xs font-medium text-muted-foreground truncate">
                        {chapter.order}. {chapterTitle}
                      </span>
                      <Badge variant="secondary" className="text-[10px] h-4">
                        {chapterResources.length}
                      </Badge>
                    </div>
                    {chapterResources.map((resource) => (
                      <ResourceItem key={resource.id} resource={resource} />
                    ))}
                  </div>
                );
              })}
            </>
          )}
        </div>
      </ScrollArea>

      {/* Add Resource Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('resources.addResource')}</DialogTitle>
            <DialogDescription>{t('resources.addResourceDescription')}</DialogDescription>
          </DialogHeader>

          <Tabs value={resourceMode} onValueChange={(v) => setResourceMode(v as 'file' | 'link')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="file" className="gap-2">
                <FileUp className="w-4 h-4" />
                {t('resources.uploadFile')}
              </TabsTrigger>
              <TabsTrigger value="link" className="gap-2">
                <LinkIcon className="w-4 h-4" />
                {t('resources.addLink')}
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="space-y-4 py-2">
            {resourceMode === 'file' ? (
              <div className="space-y-2">
                <Label>{t('resources.file')}</Label>
                {selectedMedia ? (
                  <div className="flex items-center gap-3 p-3 rounded-lg border bg-muted/50">
                    <div className="h-10 w-10 rounded bg-background flex items-center justify-center shrink-0">
                      {selectedMedia.type === 'image' ? (
                        <Image className="h-5 w-5 text-muted-foreground" />
                      ) : selectedMedia.type === 'video' ? (
                        <Video className="h-5 w-5 text-muted-foreground" />
                      ) : selectedMedia.type === 'document' ? (
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <Music className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{selectedMedia.name}</p>
                      <p className="text-xs text-muted-foreground">{selectedMedia.type}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0"
                      onClick={() => setSelectedMedia(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    className="w-full h-20 border-dashed"
                    onClick={() => setMediaLibraryOpen(true)}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <FileUp className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm">{t('resources.selectFromLibrary')}</span>
                    </div>
                  </Button>
                )}
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label>{t('resources.url')}</Label>
                  <Input
                    type="url"
                    value={linkUrl}
                    onChange={(e) => setLinkUrl(e.target.value)}
                    placeholder="https://..."
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('resources.linkType')}</Label>
                  <Select value={linkType} onValueChange={(v) => setLinkType(v as LinkType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="youtube">YouTube</SelectItem>
                      <SelectItem value="vimeo">Vimeo</SelectItem>
                      <SelectItem value="drive">Google Drive</SelectItem>
                      <SelectItem value="website">{t('resources.website')}</SelectItem>
                      <SelectItem value="other">{t('resources.other')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>{t('resources.titleEn')}</Label>
                <Input
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder={t('resources.titlePlaceholder')}
                />
              </div>
              <div className="space-y-2">
                <Label>{t('resources.titleAr')}</Label>
                <Input
                  value={uploadTitleAr}
                  onChange={(e) => setUploadTitleAr(e.target.value)}
                  dir="rtl"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t('resources.attachTo')}</Label>
              <Select value={uploadChapterId || '__book__'} onValueChange={(v) => setUploadChapterId(v === '__book__' ? '' : v)}>
                <SelectTrigger>
                  <SelectValue placeholder={t('resources.selectChapterOrBook')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__book__">{t('resources.bookLevel')}</SelectItem>
                  {chapters.map((chapter) => (
                    <SelectItem key={chapter.id} value={chapter.id}>
                      {chapter.order}. {isRtl && chapter.titleAr ? chapter.titleAr : chapter.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button
              onClick={handleAdd}
              disabled={isSubmitting || (resourceMode === 'file' ? !selectedMedia : !linkUrl)}
            >
              {isSubmitting ? t('common.saving') : t('resources.add')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Media Library Dialog */}
      <MediaLibraryConnected
        open={mediaLibraryOpen}
        onOpenChange={setMediaLibraryOpen}
        onSelect={handleMediaSelect}
        title={t('resources.selectFromLibrary')}
      />

      {/* Publish Confirmation Dialog */}
      <AlertDialog open={publishDialogOpen} onOpenChange={setPublishDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('resources.publishConfirmTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('resources.publishConfirmDescription', { count: draftCount })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isPublishing}>
              {t('common.cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handlePublish}
              disabled={isPublishing}
              className="bg-amber-600 hover:bg-amber-700"
            >
              {isPublishing && <Loader2 className="h-4 w-4 animate-spin me-2" />}
              {t('resources.publishAll')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Discard Confirmation Dialog */}
      <AlertDialog open={discardDialogOpen} onOpenChange={setDiscardDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('resources.discardConfirmTitle')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('resources.discardConfirmDescription', { count: draftCount })}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDiscarding}>
              {t('common.cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDiscard}
              disabled={isDiscarding}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDiscarding && <Loader2 className="h-4 w-4 animate-spin me-2" />}
              {t('resources.discardDrafts')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
});
