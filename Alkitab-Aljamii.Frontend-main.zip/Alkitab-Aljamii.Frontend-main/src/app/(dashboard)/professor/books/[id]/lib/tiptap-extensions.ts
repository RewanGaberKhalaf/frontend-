import { TableCell } from '@tiptap/extension-table-cell';
import { TableHeader } from '@tiptap/extension-table-header';

// Extended TableCell with background color support
export const CustomTableCell = TableCell.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      backgroundColor: {
        default: null,
        parseHTML: (element) =>
          element.style.backgroundColor || element.getAttribute('data-background-color'),
        renderHTML: (attributes) => {
          if (!attributes['backgroundColor']) {
            return {};
          }
          return {
            style: `background-color: ${attributes['backgroundColor']}`,
            'data-background-color': attributes['backgroundColor'],
          };
        },
      },
    };
  },
});

// Extended TableHeader with background color support
export const CustomTableHeader = TableHeader.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      backgroundColor: {
        default: null,
        parseHTML: (element) =>
          element.style.backgroundColor || element.getAttribute('data-background-color'),
        renderHTML: (attributes) => {
          if (!attributes['backgroundColor']) {
            return {};
          }
          return {
            style: `background-color: ${attributes['backgroundColor']}`,
            'data-background-color': attributes['backgroundColor'],
          };
        },
      },
    };
  },
});
