'use client';

import { useState, useEffect } from 'react';
import { BookText, CheckCircle, Clock, Loader2, XCircle, BookOpen, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { statsApi, type ProfessorStats } from '@/lib/api';
import { useFacultyContextStore } from '@/stores/faculty-context-store';
import { ChartTooltip, ChartLegend } from '@/components/shared/chart-tooltip';
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  approved: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  rejected: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
};

export default function ProfessorDashboard() {
  const t = useTranslations();
  const currentFacultyId = useFacultyContextStore((s) => s.currentFacultyId);
  const [stats, setStats] = useState<ProfessorStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      setIsLoading(true);
      try {
        const data = await statsApi.getProfessorStats();
        setStats(data);
      } catch {
        toast.error(t('dashboard.failedToLoadStats'));
      } finally {
        setIsLoading(false);
      }
    };
    loadStats();
  }, [currentFacultyId, t]);

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const statCards = [
    { title: t('dashboard.professor.mySubjects'), value: stats?.totalSubjects ?? 0, icon: BookOpen, desc: t('dashboard.professor.assignedCourses'), color: 'text-blue-600' },
    { title: t('dashboard.professor.totalBooks'), value: stats?.totalBooks ?? 0, icon: BookText, desc: t('dashboard.professor.booksCreated'), color: 'text-purple-600' },
    { title: t('dashboard.professor.approved'), value: stats?.approvedBooks ?? 0, icon: CheckCircle, desc: t('dashboard.professor.publishedBooks'), color: 'text-green-600' },
    { title: t('dashboard.professor.pending'), value: stats?.pendingBooks ?? 0, icon: Clock, desc: t('dashboard.professor.awaitingApproval'), color: 'text-yellow-600' },
  ];

  const contentStatusData = [
    { name: t('content.approved'), value: stats?.approvedBooks ?? 0, color: '#10b981' },
    { name: t('content.pending'), value: stats?.pendingBooks ?? 0, color: '#f59e0b' },
    { name: t('content.rejected'), value: stats?.rejectedBooks ?? 0, color: '#ef4444' },
  ].filter(item => item.value > 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{t('dashboard.title')}</h2>
          <p className="text-muted-foreground">{t('dashboard.professor.subtitle')}</p>
        </div>
        <Link href="/professor/books">
          <Button size="sm"><BookText className="me-2 h-4 w-4" />{t('dashboard.professor.createBook')}</Button>
        </Link>
      </div>

      {/* Stat Cards */}
      <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
        {statCards.map((stat) => (
          <Card key={stat.title} className="h-full">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-xl sm:text-2xl font-bold ${stat.color}`}>{stat.value.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground truncate">{stat.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Rejected Content Alert */}
      {(stats?.rejectedBooks ?? 0) > 0 && (
        <Card className="border-destructive/50 bg-destructive/5 dark:bg-destructive/10">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-destructive text-sm">
              <XCircle className="h-4 w-4" />{t('dashboard.professor.rejectedContent')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              {t('dashboard.professor.rejectedUploads', { count: stats?.rejectedBooks ?? 0 })}
            </p>
            <Link href="/professor/books?status=rejected">
              <Button variant="outline" size="sm" className="mt-2">{t('dashboard.professor.viewRejected')}</Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Main Content Row */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {/* Recent Uploads */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-sm font-medium">{t('dashboard.professor.recentUploads')}</CardTitle>
              <CardDescription className="text-xs">{t('dashboard.professor.yourLatestContent')}</CardDescription>
            </div>
            <Link href="/professor/books">
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(stats?.recentBooks ?? []).length > 0 ? (
              <div className="space-y-2">
                {stats?.recentBooks.map((content) => (
                  <div key={content.id} className="flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{content.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{content.subjectName}</p>
                    </div>
                    <Badge variant="secondary" className={`shrink-0 text-xs ${STATUS_COLORS[content.status]}`}>
                      {t(`status.${content.status}`)}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <BookText className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">{t('dashboard.professor.noBooksYet')}</p>
                <Link href="/professor/books">
                  <Button variant="outline" size="sm" className="mt-2">
                    <BookText className="me-2 h-4 w-4" />{t('dashboard.professor.createFirst')}
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upload Status Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t('dashboard.professor.uploadStatus')}</CardTitle>
          </CardHeader>
          <CardContent>
            {contentStatusData.length > 0 ? (
              <div className="space-y-2">
                <div className="h-[180px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={contentStatusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {contentStatusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<ChartTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <ChartLegend items={contentStatusData} />
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">{t('common.noData')}</p>
            )}
          </CardContent>
        </Card>

      </div>

      {/* My Subjects */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-sm font-medium">{t('dashboard.professor.mySubjects')}</CardTitle>
            <CardDescription className="text-xs">{t('dashboard.professor.subjectsWithContent')}</CardDescription>
          </div>
          <Link href="/professor/subjects">
            <Button variant="ghost" size="sm" className="h-8 text-xs">
              {t('common.viewAll')}<ArrowRight className="ms-1 h-3 w-3" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {(stats?.subjects ?? []).length > 0 ? (
            <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {stats?.subjects.map((subject) => (
                <Link key={subject.id} href={`/professor/subjects/${subject.id}`}>
                  <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{subject.name}</p>
                          <p className="text-xs text-muted-foreground">{subject.code}</p>
                        </div>
                        <Badge variant="secondary" className="shrink-0">{subject.bookCount} {t('common.files')}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <BookOpen className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">{t('dashboard.professor.noSubjectsAssigned')}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">{t('dashboard.quickActions')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Link href="/professor/books">
            <Button variant="outline" size="sm"><BookText className="me-2 h-4 w-4" />{t('dashboard.professor.createBook')}</Button>
          </Link>
          <Link href="/professor/books">
            <Button variant="outline" size="sm"><BookText className="me-2 h-4 w-4" />{t('dashboard.professor.manageBooks')}</Button>
          </Link>
          <Link href="/professor/subjects">
            <Button variant="outline" size="sm"><BookOpen className="me-2 h-4 w-4" />{t('dashboard.professor.viewSubjects')}</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
