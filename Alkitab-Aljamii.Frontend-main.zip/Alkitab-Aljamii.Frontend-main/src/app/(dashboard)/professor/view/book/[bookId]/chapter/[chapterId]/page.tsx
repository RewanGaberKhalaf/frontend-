'use client';

import { useParams } from 'next/navigation';
import { useTranslations } from 'next-intl';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  AlertCircle,
  BookOpen,
  Loader2,
  MessageSquare,
  ClipboardList,
} from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';
import { SecureBookViewer } from '@/components/shared/secure-book-viewer';
import { AnnotationSidebar } from '@/components/annotations';
import { useProfessorChapterView } from './use-professor-chapter-view';

export default function ProfessorBookViewerPage() {
  const params = useParams();
  const t = useTranslations();

  const bookId = params['bookId'] as string;
  const initialChapterId = params['chapterId'] as string;

  const {
    book,
    chapters,
    activeChapterIndex,
    activeChapter,
    isLoading,
    expandedChapterId,
    chapterContent,
    isLoadingContent,
    contentError,
    annotations,
    currentPage,
    isSidebarOpen,
    toc,
    watermarkText,
    chapterInfos,
    isArabic,
    setSidebarOpen,
    handleAnnotationClick,
    goToPreviousChapter,
    goToNextChapter,
    handleChapterSelect,
    toggleChapterExpand,
  } = useProfessorChapterView(bookId, initialChapterId);

  if (isLoading) {
    return (
      <div className="h-full flex">
        <div className="w-72 border-r p-4 space-y-4">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
        </div>
        <div className="flex-1 p-4">
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="flex items-center justify-center h-full">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t('common.error')}</AlertTitle>
          <AlertDescription>{t('books.notFound')}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      {/* Header */}
      <div className="shrink-0 border-b bg-background px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <Button variant="ghost" size="icon" asChild className="shrink-0">
              <Link href={`/professor/books/${bookId}/annotations`}>
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="font-semibold truncate">
                  {isArabic && book.titleAr ? book.titleAr : book.title}
                </h1>
                <Badge variant="secondary">Professor View</Badge>
              </div>
              <p className="text-xs text-muted-foreground truncate">
                Viewing student annotations
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Chapter navigation */}
            <Button
              variant="outline"
              size="icon"
              onClick={goToPreviousChapter}
              disabled={activeChapterIndex === 0}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm text-muted-foreground min-w-[50px] text-center">
              {activeChapterIndex + 1} / {chapters.length}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={goToNextChapter}
              disabled={activeChapterIndex === chapters.length - 1}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>

            {/* Dashboard link */}
            <Button variant="outline" size="sm" asChild>
              <Link href={`/professor/books/${bookId}/annotations`}>
                <ClipboardList className="h-4 w-4 me-2" />
                Dashboard
              </Link>
            </Button>

            {/* Annotation sidebar toggle */}
            <Button
              variant={isSidebarOpen ? 'secondary' : 'outline'}
              size="icon"
              onClick={() => setSidebarOpen(!isSidebarOpen)}
              className="relative"
            >
              <MessageSquare className="h-4 w-4" />
              {annotations.length > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] text-primary-foreground flex items-center justify-center">
                  {annotations.length > 99 ? '99+' : annotations.length}
                </span>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex min-h-0">
        {/* Sidebar - Chapter list */}
        <div className="w-72 shrink-0 border-r flex flex-col overflow-hidden">
          {/* Chapters header */}
          <div className="px-3 py-2 border-b bg-muted/50 flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {t('books.chapters')}
            </span>
            <span className="text-xs text-muted-foreground">
              {chapters.length} chapters
            </span>
          </div>

          {/* Chapter list with TOC */}
          <ScrollArea className="flex-1">
            <div className="py-1">
              {chapters.map((chapter, index) => {
                const isActive = activeChapterIndex === index;
                const showToc = isActive && toc.length > 0;
                const isExpanded = expandedChapterId === chapter.id && showToc;

                return (
                  <div key={chapter.id}>
                    {/* Chapter row */}
                    <div
                      className={cn(
                        'flex items-center gap-2 px-3 py-2.5 cursor-pointer transition-colors',
                        isActive
                          ? 'bg-primary/10 border-s-2 border-primary'
                          : 'hover:bg-muted/50'
                      )}
                      onClick={() => handleChapterSelect(index)}
                    >
                      {/* Expand/collapse toggle */}
                      {showToc ? (
                        <button
                          className="shrink-0"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleChapterExpand(chapter.id);
                          }}
                        >
                          <ChevronDown
                            className={cn(
                              'h-4 w-4 text-muted-foreground transition-transform duration-200',
                              !isExpanded && 'ltr:-rotate-90 rtl:rotate-90'
                            )}
                          />
                        </button>
                      ) : (
                        <div className="w-4 shrink-0" />
                      )}

                      {/* Chapter icon */}
                      <BookOpen className="h-4 w-4 shrink-0 text-muted-foreground" />

                      {/* Title */}
                      <span
                        className={cn(
                          'flex-1 text-sm overflow-hidden text-ellipsis whitespace-nowrap',
                          isActive && 'font-medium'
                        )}
                        title={`${index + 1}. ${chapter.title}`}
                      >
                        {index + 1}. {chapter.title}
                      </span>
                    </div>

                    {/* TOC items */}
                    {isExpanded && (
                      <div className="bg-muted/30 py-1 border-t border-b border-border/50 w-full overflow-hidden">
                        {toc.map((item, tocIndex) => (
                          <div
                            key={tocIndex}
                            className={cn(
                              'py-1.5 pe-3 text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 cursor-pointer block overflow-hidden text-ellipsis whitespace-nowrap',
                              item.level === 1 && 'ps-10 font-medium text-foreground/80',
                              item.level === 2 && 'ps-14',
                              item.level === 3 && 'ps-[4.5rem]',
                              item.level >= 4 && 'ps-20'
                            )}
                            title={item.text}
                          >
                            {item.text}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Content area */}
        <div className="flex-1 overflow-hidden bg-muted/30">
          {isLoadingContent ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
                <p className="text-muted-foreground">{t('common.loading')}</p>
              </div>
            </div>
          ) : contentError ? (
            <div className="h-full flex items-center justify-center">
              <Alert variant="destructive" className="max-w-md">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>{t('common.error')}</AlertTitle>
                <AlertDescription>{contentError}</AlertDescription>
              </Alert>
            </div>
          ) : chapterContent ? (
            <SecureBookViewer
              html={chapterContent}
              title={isArabic && activeChapter?.titleAr ? activeChapter.titleAr : activeChapter?.title}
              watermarkText={watermarkText}
              showWatermark
              enableProtection={false}
              showPageNumbers
              enableAnnotations
              annotations={annotations}
              onAnnotationClick={handleAnnotationClick}
              currentPageForAnnotation={currentPage}
            />
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>{t('books.selectChapter')}</p>
              </div>
            </div>
          )}
        </div>

        {/* Annotation Sidebar */}
        <AnnotationSidebar
          chapters={chapterInfos}
          onAnnotationClick={handleAnnotationClick}
        />
      </div>
    </div>
  );
}
