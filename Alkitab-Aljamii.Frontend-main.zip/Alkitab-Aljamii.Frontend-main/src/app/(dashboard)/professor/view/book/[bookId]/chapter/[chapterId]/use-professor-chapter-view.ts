'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import { toast } from 'sonner';
import { booksApi } from '@/lib/api/books';
import { annotationsApi } from '@/lib/api/annotations';
import { useAuthStore, useAnnotationStore } from '@/stores';
import type { Book, Chapter, Annotation } from '@/types';

export interface TocItem {
  text: string;
  level: number;
}

export function extractTableOfContents(html: string): TocItem[] {
  if (!html || typeof window === 'undefined') return [];

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const headers = doc.querySelectorAll('h1, h2, h3, h4, h5, h6');

    const toc: TocItem[] = [];
    headers.forEach((header) => {
      const level = parseInt(header.tagName.charAt(1));
      const text = header.textContent?.trim() || '';
      if (text) {
        toc.push({ text, level });
      }
    });

    return toc;
  } catch {
    return [];
  }
}

export function useProfessorChapterView(bookId: string, initialChapterId: string) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const t = useTranslations();
  const locale = useLocale();
  const user = useAuthStore((state) => state.user);

  const highlightAnnotationId = searchParams.get('annotation');
  const initialPage = searchParams.get('page');

  const isArabic = locale === 'ar';

  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedChapterId, setExpandedChapterId] = useState<string | null>(null);

  // Content state
  const [chapterContent, setChapterContent] = useState<string>('');
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [contentError, setContentError] = useState<string | null>(null);

  // Annotation state
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [currentPage, setCurrentPage] = useState(initialPage ? parseInt(initialPage) : 1);
  const [selectedAnnotationId, setSelectedAnnotationId] = useState<string | null>(highlightAnnotationId);
  const {
    setContext,
    setSidebarOpen,
    isSidebarOpen,
    selectAnnotation,
  } = useAnnotationStore();

  const activeChapter = chapters[activeChapterIndex];

  // Extract TOC from content
  const toc = useMemo(() => {
    if (!chapterContent) return [];
    return extractTableOfContents(chapterContent);
  }, [chapterContent]);

  // Watermark text
  const watermarkText = useMemo(() => {
    if (user?.email) return user.email;
    if (user?.firstName) return `${user.firstName} ${user.lastName || ''}`.trim();
    return 'Professor View';
  }, [user]);

  // Chapter info for sidebar
  const chapterInfos = useMemo(() =>
    chapters.map((ch) => ({ id: ch.id, title: ch.title })),
    [chapters]
  );

  // Initialize annotation store with book ID
  useEffect(() => {
    if (bookId) {
      setContext(bookId);
    }
  }, [bookId, setContext]);

  // Load book and chapters
  useEffect(() => {
    const loadBook = async () => {
      try {
        setIsLoading(true);
        const [bookData, chaptersData] = await Promise.all([
          booksApi.getById(bookId),
          // Use viewMode=true to only get published content (no drafts)
          // This is a view-only page, so we should show what students see
          booksApi.getChapters(bookId, true),
        ]);

        setBook(bookData);
        setChapters(chaptersData);

        // Find initial chapter index
        if (initialChapterId) {
          const index = chaptersData.findIndex((ch) => ch.id === initialChapterId);
          if (index !== -1) {
            setActiveChapterIndex(index);
          }
        }
      } catch {
        toast.error(t('common.error'));
        router.push(`/professor/books/${bookId}`);
      } finally {
        setIsLoading(false);
      }
    };

    loadBook();
  }, [bookId, initialChapterId, router, t]);

  // Load chapter content when chapter changes
  const loadChapterContent = useCallback(async () => {
    if (!activeChapter) {
      setChapterContent('');
      return;
    }

    try {
      setIsLoadingContent(true);
      setContentError(null);

      const content = await booksApi.getProfessorChapterContent(bookId, activeChapter.id);
      setChapterContent(content.content);
    } catch (error) {
      const message = error instanceof Error ? error.message : t('common.error');
      setContentError(message);
      setChapterContent('');
    } finally {
      setIsLoadingContent(false);
    }
  }, [activeChapter, bookId, t]);

  useEffect(() => {
    loadChapterContent();
  }, [loadChapterContent]);

  // Fetch annotations for current chapter
  useEffect(() => {
    const fetchAnnotations = async () => {
      if (!activeChapter) {
        setAnnotations([]);
        return;
      }

      try {
        const data = await annotationsApi.getAllBookAnnotations(bookId, {
          chapterId: activeChapter.id,
          limit: 100,
        });
        setAnnotations(data.items);

        if (highlightAnnotationId) {
          const annotation = data.items.find((a) => a.id === highlightAnnotationId);
          if (annotation) {
            selectAnnotation(annotation);
            setSidebarOpen(true);
          }
        }
      } catch {
        // Silent fail
      }
    };

    fetchAnnotations();
  }, [activeChapter, bookId, highlightAnnotationId, selectAnnotation, setSidebarOpen]);

  // Auto-expand active chapter when it has content
  useEffect(() => {
    if (activeChapter?.id && toc.length > 0) {
      setExpandedChapterId(activeChapter.id);
    }
  }, [activeChapter?.id, toc.length]);

  // Handle annotation click
  const handleAnnotationClick = useCallback((annotation: Annotation) => {
    if (annotation.chapterId && annotation.chapterId !== activeChapter?.id) {
      const chapterIndex = chapters.findIndex((ch) => ch.id === annotation.chapterId);
      if (chapterIndex !== -1) {
        setActiveChapterIndex(chapterIndex);
      }
    }
    if (annotation.pageNumber) {
      setCurrentPage(annotation.pageNumber);
    }
    setSelectedAnnotationId(annotation.id);
  }, [activeChapter?.id, chapters]);

  // Navigation
  const goToPreviousChapter = useCallback(() => {
    if (activeChapterIndex > 0) {
      setActiveChapterIndex((prev) => prev - 1);
    }
  }, [activeChapterIndex]);

  const goToNextChapter = useCallback(() => {
    if (activeChapterIndex < chapters.length - 1) {
      setActiveChapterIndex((prev) => prev + 1);
    }
  }, [activeChapterIndex, chapters.length]);

  const handleChapterSelect = useCallback((index: number) => {
    setActiveChapterIndex(index);
  }, []);

  const toggleChapterExpand = useCallback((chapterId: string) => {
    setExpandedChapterId((prev) => (prev === chapterId ? null : chapterId));
  }, []);

  return {
    // State
    book,
    chapters,
    activeChapterIndex,
    activeChapter,
    isLoading,
    expandedChapterId,
    chapterContent,
    isLoadingContent,
    contentError,
    annotations,
    currentPage,
    selectedAnnotationId,
    isSidebarOpen,
    // Computed
    toc,
    watermarkText,
    chapterInfos,
    isArabic,
    // Setters
    setSidebarOpen,
    // Actions
    handleAnnotationClick,
    goToPreviousChapter,
    goToNextChapter,
    handleChapterSelect,
    toggleChapterExpand,
  };
}
