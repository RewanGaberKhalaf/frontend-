'use client';

import { useState, useEffect, useCallback, use } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Loader2, Users, BookText } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DataTable } from '@/components/shared/data-table';
import { EmptyState } from '@/components/shared';
import { subjectsApi } from '@/lib/api/subjects';
import type { Subject, SubjectAssignment } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';
import Link from 'next/link';

export default function ProfessorSubjectDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const router = useRouter();
  const t = useTranslations();
  const [subject, setSubject] = useState<Subject | null>(null);
  const [students, setStudents] = useState<SubjectAssignment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadSubject = useCallback(async () => {
    try {
      const data = await subjectsApi.getById(id);
      setSubject(data);
    } catch {
      toast.error(t('subjects.loadError'));
      router.push('/professor/subjects');
    }
  }, [id, router, t]);

  const loadStudents = useCallback(async () => {
    try {
      const result = await subjectsApi.getAssignments(id);
      // Filter only students
      setStudents(result.items.filter((a) => a.roleInSubject === 'student'));
    } catch {
      toast.error(t('subjects.loadAssignmentsError'));
    }
  }, [id, t]);

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      await Promise.all([loadSubject(), loadStudents()]);
      setIsLoading(false);
    };
    load();
  }, [loadSubject, loadStudents]);

  const columns: ColumnDef<SubjectAssignment>[] = [
    {
      id: 'name',
      header: t('common.name'),
      cell: ({ row }) => `${row.original.firstName} ${row.original.lastName}`,
    },
    { accessorKey: 'email', header: t('common.email') },
    {
      accessorKey: 'assignedAt',
      header: t('subjects.enrolledAt'),
      cell: ({ row }) => new Date(row.original.assignedAt).toLocaleDateString(),
    },
  ];

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!subject) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push('/professor/subjects')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold tracking-tight">{subject.name}</h2>
            <Badge variant={subject.isActive ? 'default' : 'secondary'}>
              {subject.isActive ? t('subjects.active') : t('subjects.inactive')}
            </Badge>
          </div>
          <p className="text-muted-foreground">{subject.code}</p>
        </div>
      </div>

      {subject.description && (
        <p className="text-muted-foreground">{subject.description}</p>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('subjects.enrolledStudents')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{students.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('subjects.viewBooks')}</CardTitle>
            <BookText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <Button variant="outline" size="sm" asChild>
              <Link href={`/professor/books?subjectId=${id}`}>
                {t('subjects.viewBooks')}
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">{t('subjects.enrolledStudents')} ({students.length})</h3>
        {students.length === 0 ? (
          <EmptyState
            title={t('subjects.noStudentsEnrolled')}
            description={t('subjects.noStudentsEnrolledDescription')}
            icon={Users}
          />
        ) : (
          <DataTable columns={columns} data={students} searchKey="email" />
        )}
      </div>
    </div>
  );
}
