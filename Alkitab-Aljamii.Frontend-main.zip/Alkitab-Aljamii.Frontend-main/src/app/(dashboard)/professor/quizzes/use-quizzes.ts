'use client';

import { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { useServerTable } from '@/hooks';
import {
  quizApi,
  type Quiz,
  type QuizQueryParams,
  type QuestionBank,
  type CreateQuizData,
  type UpdateQuizData,
} from '@/lib/api/quiz';

type QuizFilters = Omit<QuizQueryParams, 'page' | 'limit'>;

export function useQuizzes() {
  const t = useTranslations();

  // Question banks for filter
  const [banks, setBanks] = useState<QuestionBank[]>([]);

  // Dialog states (no create - quizzes are chapter-bound)
  const [editQuiz, setEditQuiz] = useState<Quiz | null>(null);
  const [deleteQuiz, setDeleteQuiz] = useState<Quiz | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Server-side table state
  const tableState = useServerTable<Quiz, QuizFilters>({
    fetchFn: quizApi.getQuizzes,
    initialPageSize: 10,
    initialFilters: {},
  });

  const { setFilter, refetch } = tableState;

  // Fetch question banks for filter
  useEffect(() => {
    const fetchBanks = async () => {
      try {
        const response = await quizApi.getQuestionBanks({ limit: 100 });
        setBanks(response.items);
      } catch (err) {
        console.error('Failed to fetch question banks:', err);
      }
    };
    fetchBanks();
  }, []);

  // Handle update
  const handleUpdate = useCallback(async (data: CreateQuizData | UpdateQuizData) => {
    if (!editQuiz) return;
    setIsSubmitting(true);
    try {
      await quizApi.updateQuiz(editQuiz.id, data);
      toast.success(t('quizzes.updateSuccess'));
      setEditQuiz(null);
      refetch();
    } catch {
      toast.error(t('quizzes.updateError'));
    } finally {
      setIsSubmitting(false);
    }
  }, [editQuiz, refetch, t]);

  // Handle delete
  const handleDelete = useCallback(async () => {
    if (!deleteQuiz) return;
    setIsDeleting(true);
    try {
      await quizApi.deleteQuiz(deleteQuiz.id);
      toast.success(t('quizzes.deleteSuccess'));
      setDeleteQuiz(null);
      refetch();
    } catch {
      toast.error(t('quizzes.deleteError'));
    } finally {
      setIsDeleting(false);
    }
  }, [deleteQuiz, refetch, t]);

  // Handle bank filter
  const handleBankFilter = useCallback((value: string) => {
    setFilter('bankId', value === 'all' ? undefined : value);
  }, [setFilter]);

  // Handle status filter
  const handleStatusFilter = useCallback((value: string) => {
    setFilter('isActive', value === 'all' ? undefined : value === 'active');
  }, [setFilter]);

  return {
    // Table state
    ...tableState,
    // Banks
    banks,
    // Dialog states (no create - quizzes are chapter-bound)
    editQuiz,
    setEditQuiz,
    deleteQuiz,
    setDeleteQuiz,
    isSubmitting,
    isDeleting,
    // Handlers
    handleUpdate,
    handleDelete,
    handleBankFilter,
    handleStatusFilter,
  };
}
