'use client';

import { useRouter } from 'next/navigation';
import { ClipboardList, Search, Database, Clock, Target, MoreHorizontal, Pencil, Trash2, Eye, BookOpen } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState, ConfirmDialog, PageHeader } from '@/components/shared';
import { QuizForm } from '@/components/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { useQuizzes } from './use-quizzes';

export default function QuizzesPage() {
  const t = useTranslations();
  const router = useRouter();

  const {
    data: quizzes,
    meta,
    isLoading,
    error,
    searchValue,
    filters,
    setPage,
    setSearch,
    banks,
    editQuiz,
    setEditQuiz,
    deleteQuiz,
    setDeleteQuiz,
    isSubmitting,
    isDeleting,
    handleUpdate,
    handleDelete,
    handleBankFilter,
    handleStatusFilter,
  } = useQuizzes();

  return (
    <div className="space-y-6">
      <PageHeader
        icon={ClipboardList}
        title={t('quizzes.title')}
        description={t('quizzes.description')}
        badge={meta && <Badge variant="secondary">{meta.total} {t('quizzes.quizzesTotal')}</Badge>}
      />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg border bg-card p-4">
        <div className="relative flex-1 min-w-0 sm:min-w-[200px] sm:max-w-sm">
          <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder={t('common.search') + '...'} value={searchValue} onChange={(e) => setSearch(e.target.value)} className="ps-9" />
        </div>
        <div className="flex items-center gap-3">
          <Select value={filters.bankId ?? 'all'} onValueChange={handleBankFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder={t('quizzes.filterByBank')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              {banks.map((bank) => <SelectItem key={bank.id} value={bank.id}>{bank.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filters.isActive === undefined ? 'all' : filters.isActive ? 'active' : 'inactive'} onValueChange={handleStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder={t('common.status')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('common.all')}</SelectItem>
              <SelectItem value="active">{t('common.active')}</SelectItem>
              <SelectItem value="inactive">{t('common.inactive')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Error state */}
      {error && <div className="rounded-md bg-destructive/10 p-4 text-destructive">{error}</div>}

      {/* Table or Empty state */}
      {!isLoading && quizzes.length === 0 && !searchValue && !filters.bankId ? (
        <EmptyState
          title={t('quizzes.noQuizzes')}
          description={t('quizzes.noQuizzesChapterBound')}
          action={
            <Button onClick={() => router.push(ROUTES.PROFESSOR.BOOKS)}>
              <BookOpen className="mr-2 h-4 w-4" />
              {t('nav.myBooks')}
            </Button>
          }
        />
      ) : (
        <div className="rounded-md border overflow-x-auto">
          <Table className="table-fixed">
            <TableHeader>
              <TableRow>
                <TableHead className="w-[22%] min-w-[160px]">{t('quizzes.name')}</TableHead>
                <TableHead className="w-[18%] min-w-[140px]">{t('quizzes.questionBank')}</TableHead>
                <TableHead className="w-[140px] text-center">{t('quizzes.totalQuestions')}</TableHead>
                <TableHead className="w-[90px] text-center">{t('quizzes.timeLimit')}</TableHead>
                <TableHead className="w-[90px] text-center">{t('quizzes.passingScore')}</TableHead>
                <TableHead className="w-[90px]">{t('common.status')}</TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                  </TableRow>
                ))
              ) : quizzes.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="h-24 text-center">{t('quizzes.noResults')}</TableCell></TableRow>
              ) : (
                quizzes.map((quiz) => (
                  <TableRow key={quiz.id}>
                    <TableCell>
                      <div className="min-w-0">
                        <p className="font-medium truncate">{quiz.title}</p>
                        {quiz.titleAr && <p className="text-sm text-muted-foreground truncate" dir="rtl">{quiz.titleAr}</p>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 min-w-0">
                        <Database className="h-4 w-4 text-muted-foreground shrink-0" />
                        <span className="text-sm truncate">{quiz.bankName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1 text-xs">
                        <span className="px-1.5 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">{quiz.easyQuestions}</span>
                        <span className="px-1.5 py-0.5 rounded bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400">{quiz.mediumQuestions}</span>
                        <span className="px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">{quiz.hardQuestions}</span>
                        <span className="ms-1 font-medium">= {quiz.totalQuestions}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {quiz.timeLimit ? (
                        <div className="flex items-center justify-center gap-1">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>{quiz.timeLimit} min</span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-center block">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        <Target className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{quiz.passingScore}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={quiz.isActive ? 'default' : 'secondary'}>{quiz.isActive ? t('common.active') : t('common.inactive')}</Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => router.push(ROUTES.PROFESSOR.QUIZ_DETAIL(quiz.id))}>
                            <Eye className="me-2 h-4 w-4" />
                            {t('common.view')}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setEditQuiz(quiz)}>
                            <Pencil className="me-2 h-4 w-4" />
                            {t('common.edit')}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setDeleteQuiz(quiz)} className="text-destructive">
                            <Trash2 className="me-2 h-4 w-4" />
                            {t('common.delete')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {meta && meta.totalPages > 1 && (
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-t px-4 py-3">
              <p className="text-sm text-muted-foreground text-center sm:text-start">
                {t('common.showingOf', { from: (meta.page - 1) * meta.limit + 1, to: Math.min(meta.page * meta.limit, meta.total), total: meta.total })}
              </p>
              <div className="flex items-center justify-center sm:justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => setPage(meta.page - 1)} disabled={meta.page <= 1}>
                  {t('common.previous')}
                </Button>
                <span className="text-sm">{meta.page} / {meta.totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setPage(meta.page + 1)} disabled={meta.page >= meta.totalPages}>
                  {t('common.next')}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editQuiz} onOpenChange={(open) => !open && setEditQuiz(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('quizzes.edit')}</DialogTitle>
            <DialogDescription>{t('quizzes.editDescription')}</DialogDescription>
          </DialogHeader>
          {editQuiz && <QuizForm quiz={editQuiz} onSubmit={handleUpdate} onCancel={() => setEditQuiz(null)} isLoading={isSubmitting} />}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={!!deleteQuiz}
        onOpenChange={(open) => !open && setDeleteQuiz(null)}
        title={t('quizzes.deleteTitle')}
        description={t('quizzes.deleteDescription', { name: deleteQuiz?.title ?? '' })}
        confirmLabel={t('common.delete')}
        onConfirm={handleDelete}
        loading={isDeleting}
        destructive
      />
    </div>
  );
}
