'use client';

import { useParams, useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { ClipboardList, ArrowLeft, Clock, Target, Database, Users, Shuffle, CheckCircle2, XCircle, BarChart3, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader } from '@/components/shared';
import { QuizForm } from '@/components/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { useQuizDetail, getStatusBadgeVariant, getStatusLabel } from './use-quiz-detail';

export default function QuizDetailPage() {
  const t = useTranslations();
  const router = useRouter();
  const params = useParams();
  const quizId = params['id'] as string;

  const {
    quiz,
    quizLoading,
    quizError,
    attempts,
    attemptsLoading,
    attemptsMeta,
    page,
    setPage,
    editDialogOpen,
    setEditDialogOpen,
    isSubmitting,
    stats,
    handleUpdate,
  } = useQuizDetail(quizId);

  if (quizLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (quizError || !quiz) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <p className="text-destructive mb-4">{quizError || t('quizzes.notFound')}</p>
        <Button onClick={() => router.push(ROUTES.PROFESSOR.QUIZZES)}><ArrowLeft className="mr-2 h-4 w-4" />{t('common.back')}</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Button variant="ghost" size="icon" className="shrink-0 mt-1" onClick={() => router.push(ROUTES.PROFESSOR.QUIZZES)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <PageHeader
            icon={ClipboardList}
            title={quiz.title}
            description={quiz.description || t('questionBanks.noDescription')}
            badge={<Badge variant={quiz.isActive ? 'default' : 'secondary'}>{quiz.isActive ? t('common.active') : t('common.inactive')}</Badge>}
            action={<Button onClick={() => setEditDialogOpen(true)}>{t('common.edit')}</Button>}
          />
        </div>
      </div>

      {/* Quiz Configuration */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Database className="h-4 w-4 shrink-0" />
            <span>{t('quizzes.questionBank')}</span>
          </div>
          <p className="font-medium truncate">{quiz.bankName}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground mb-2">{t('quizzes.totalQuestions')}</div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold">{quiz.totalQuestions}</span>
            <div className="flex flex-wrap gap-1 text-xs">
              <span className="px-1.5 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">{quiz.easyQuestions}E</span>
              <span className="px-1.5 py-0.5 rounded bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400">{quiz.mediumQuestions}M</span>
              <span className="px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">{quiz.hardQuestions}H</span>
            </div>
          </div>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Clock className="h-4 w-4 shrink-0" />
            <span>{t('quizzes.timeLimit')}</span>
          </div>
          <p className="text-2xl font-bold">{quiz.timeLimit ? `${quiz.timeLimit} min` : '-'}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Target className="h-4 w-4 shrink-0" />
            <span>{t('quizzes.passingScore')}</span>
          </div>
          <p className="text-2xl font-bold">{quiz.passingScore}%</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Users className="h-4 w-4 shrink-0" />
            <span>{t('quizzes.maxAttempts')}</span>
          </div>
          <p className="text-2xl font-bold">{quiz.maxAttempts || t('common.unlimited')}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground mb-2">{t('common.options')}</div>
          <div className="flex flex-wrap gap-1.5">
            {quiz.shuffleQuestions && <Badge variant="outline" className="text-xs"><Shuffle className="h-3 w-3 me-1" />Q</Badge>}
            {quiz.shuffleOptions && <Badge variant="outline" className="text-xs"><Shuffle className="h-3 w-3 me-1" />O</Badge>}
            {quiz.isPoolBased && <Badge variant="outline" className="text-xs">{t('quizzes.poolBased')}</Badge>}
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <BarChart3 className="h-4 w-4 shrink-0" />
            <span>{t('quizAttempts.totalAttempts')}</span>
          </div>
          <p className="text-2xl font-bold">{stats.totalAttempts}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-green-200 dark:border-green-800">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-green-600" />
            <span>{t('quizAttempts.passed')}</span>
          </div>
          <p className="text-2xl font-bold text-green-600">{stats.passedCount}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 border-red-200 dark:border-red-800">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <XCircle className="h-4 w-4 shrink-0 text-red-600" />
            <span>{t('quizAttempts.failed')}</span>
          </div>
          <p className="text-2xl font-bold text-red-600">{stats.failedCount}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground mb-2">{t('quizAttempts.avgScore')}</div>
          <p className="text-2xl font-bold">{stats.avgScore.toFixed(1)}%</p>
        </div>
      </div>

      {/* Attempts Table */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold">{t('quizAttempts.title')}</h2>
        <div className="rounded-md border overflow-x-auto">
          <Table className="table-fixed">
            <TableHeader>
              <TableRow>
                <TableHead className="w-[22%] min-w-[140px]">{t('quizAttempts.student')}</TableHead>
                <TableHead className="w-[80px] text-center">{t('quizAttempts.attempt')}</TableHead>
                <TableHead className="w-[80px] text-center">{t('quizAttempts.score')}</TableHead>
                <TableHead className="w-[90px] text-center">{t('quizAttempts.timeSpent')}</TableHead>
                <TableHead className="w-[100px]">{t('common.status')}</TableHead>
                <TableHead className="w-[120px]">{t('quizAttempts.submittedAt')}</TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {attemptsLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-12 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                  </TableRow>
                ))
              ) : attempts.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="h-24 text-center">{t('quizAttempts.noAttempts')}</TableCell></TableRow>
              ) : (
                attempts.map((attempt) => (
                  <TableRow key={attempt.id}>
                    <TableCell>
                      <div className="space-y-1">
                        {attempt.userFirstName && attempt.userLastName ? (
                          <>
                            <span className="font-medium block">{attempt.userFirstName} {attempt.userLastName}</span>
                            {attempt.userEmail && <span className="text-xs text-muted-foreground block">{attempt.userEmail}</span>}
                          </>
                        ) : (
                          <span className="font-medium">{attempt.userId.slice(0, 8)}...</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-center">#{attempt.attemptNumber}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-center">
                        {attempt.score !== null ? (
                          <span className={cn('font-medium', attempt.passed ? 'text-green-600' : 'text-red-600')}>{attempt.score.toFixed(1)}%</span>
                        ) : '-'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-center">{attempt.timeSpent ? `${Math.floor(attempt.timeSpent / 60)}m` : '-'}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(attempt)}>{getStatusLabel(attempt, t)}</Badge>
                    </TableCell>
                    <TableCell>
                      {attempt.submittedAt ? format(new Date(attempt.submittedAt), 'MMM d, HH:mm') : '-'}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => router.push(ROUTES.PROFESSOR.QUIZ_ATTEMPT_DETAIL(attempt.id))}
                        title={t('quizAttempts.viewDetails')}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {attemptsMeta && attemptsMeta.totalPages > 1 && (
            <div className="flex items-center justify-between border-t px-4 py-3">
              <p className="text-sm text-muted-foreground">
                {t('common.showingOf', { from: (attemptsMeta.page - 1) * attemptsMeta.limit + 1, to: Math.min(attemptsMeta.page * attemptsMeta.limit, attemptsMeta.total), total: attemptsMeta.total })}
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setPage(page - 1)} disabled={page <= 1}>{t('common.previous')}</Button>
                <span className="text-sm">{attemptsMeta.page} / {attemptsMeta.totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setPage(page + 1)} disabled={page >= attemptsMeta.totalPages}>{t('common.next')}</Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('quizzes.edit')}</DialogTitle>
            <DialogDescription>{t('quizzes.editDescription')}</DialogDescription>
          </DialogHeader>
          <QuizForm quiz={quiz} onSubmit={handleUpdate} onCancel={() => setEditDialogOpen(false)} isLoading={isSubmitting} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
