'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import {
  quizApi,
  type Quiz,
  type QuizAttempt,
  type UpdateQuizData,
} from '@/lib/api/quiz';

export interface AttemptsMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export function useQuizDetail(quizId: string) {
  const t = useTranslations();

  // Quiz state
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [quizLoading, setQuizLoading] = useState(true);
  const [quizError, setQuizError] = useState<string | null>(null);

  // Attempts state
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [attemptsLoading, setAttemptsLoading] = useState(true);
  const [attemptsMeta, setAttemptsMeta] = useState<AttemptsMeta | null>(null);
  const [page, setPage] = useState(1);

  // Dialog states
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch quiz details
  useEffect(() => {
    const fetchQuiz = async () => {
      setQuizLoading(true);
      setQuizError(null);
      try {
        const data = await quizApi.getQuiz(quizId);
        setQuiz(data);
      } catch (err) {
        console.error('Failed to fetch quiz:', err);
        setQuizError(t('quizzes.fetchError'));
      } finally {
        setQuizLoading(false);
      }
    };
    fetchQuiz();
  }, [quizId, t]);

  // Fetch attempts
  const fetchAttempts = useCallback(async () => {
    setAttemptsLoading(true);
    try {
      const response = await quizApi.getAllAttempts(quizId, { page, limit: 10 });
      setAttempts(response.items);
      setAttemptsMeta(response.meta);
    } catch (err) {
      console.error('Failed to fetch attempts:', err);
    } finally {
      setAttemptsLoading(false);
    }
  }, [quizId, page]);

  useEffect(() => {
    fetchAttempts();
  }, [fetchAttempts]);

  // Handle update
  const handleUpdate = useCallback(async (data: UpdateQuizData) => {
    if (!quiz) return;
    setIsSubmitting(true);
    try {
      const updatedQuiz = await quizApi.updateQuiz(quiz.id, data);
      setQuiz(updatedQuiz);
      toast.success(t('quizzes.updateSuccess'));
      setEditDialogOpen(false);
    } catch {
      toast.error(t('quizzes.updateError'));
    } finally {
      setIsSubmitting(false);
    }
  }, [quiz, t]);

  // Calculate statistics
  const stats = useMemo(() => ({
    totalAttempts: attemptsMeta?.total || 0,
    passedCount: attempts.filter((a) => a.passed === true).length,
    failedCount: attempts.filter((a) => a.passed === false).length,
    avgScore: attempts.length > 0
      ? attempts.reduce((sum, a) => sum + (a.score || 0), 0) / attempts.filter(a => a.score !== null).length
      : 0,
  }), [attempts, attemptsMeta?.total]);

  return {
    // Quiz state
    quiz,
    quizLoading,
    quizError,
    // Attempts state
    attempts,
    attemptsLoading,
    attemptsMeta,
    page,
    setPage,
    // Dialog state
    editDialogOpen,
    setEditDialogOpen,
    isSubmitting,
    // Computed
    stats,
    // Handlers
    handleUpdate,
  };
}

export function getStatusBadgeVariant(attempt: QuizAttempt): 'outline' | 'destructive' | 'default' | 'secondary' {
  if (attempt.status === 'in_progress') return 'outline';
  if (attempt.status === 'timed_out') return 'destructive';
  if (attempt.passed) return 'default';
  return 'secondary';
}

export function getStatusLabel(attempt: QuizAttempt, t: ReturnType<typeof useTranslations>): string {
  if (attempt.status === 'in_progress') return t('quizAttempts.inProgress');
  if (attempt.status === 'timed_out') return t('quizAttempts.timedOut');
  if (attempt.passed) return t('quizAttempts.passed');
  return t('quizAttempts.failed');
}
