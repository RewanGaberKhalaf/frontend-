'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import {
  Trophy,
  XCircle,
  Clock,
  Target,
  CheckCircle2,
  ArrowLeft,
  User,
  Mail,
  Calendar,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { QuestionDisplay } from '@/components/quiz';
import { quizApi, type QuizAttemptResult } from '@/lib/api/quiz';
import { ROUTES } from '@/lib/constants/routes';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export default function ProfessorQuizAttemptDetailPage() {
  const t = useTranslations();
  const locale = useLocale();
  const router = useRouter();
  const params = useParams();
  const attemptId = params['attemptId'] as string;
  const isArabic = locale === 'ar';

  const [result, setResult] = useState<QuizAttemptResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchResult = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await quizApi.getQuizAttempt(attemptId);
        setResult(data);
      } catch (err) {
        console.error('Failed to fetch result:', err);
        setError(t('quizTaking.fetchError'));
      } finally {
        setIsLoading(false);
      }
    };
    fetchResult();
  }, [attemptId, t]);

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-8 px-4 space-y-8">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-64 w-full rounded-2xl" />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
        <Skeleton className="h-96 w-full rounded-xl" />
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4">
        <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
          <XCircle className="h-10 w-10 text-destructive" />
        </div>
        <h2 className="text-2xl font-bold mb-2 text-center">{t('quizTaking.resultNotFound')}</h2>
        <p className="text-muted-foreground mb-6 text-center max-w-md">{error || t('quizTaking.fetchError')}</p>
        <Button onClick={() => router.back()} size="lg">
          <ArrowLeft className="me-2 h-4 w-4" />
          {t('common.back')}
        </Button>
      </div>
    );
  }

  const quizTitle = isArabic && result.quizTitleAr ? result.quizTitleAr : result.quizTitle;
  const passed = result.passed === true;
  const score = result.score || 0;
  const correctCount = result.correctCount || 0;
  const timeSpentMinutes = result.timeSpent ? Math.floor(result.timeSpent / 60) : 0;
  const timeSpentSeconds = result.timeSpent ? result.timeSpent % 60 : 0;

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-8">
      {/* Back Button */}
      <Button variant="ghost" onClick={() => router.back()}>
        <ArrowLeft className="me-2 h-4 w-4" />
        {t('common.back')}
      </Button>

      {/* Student Information Card */}
      <div className="rounded-xl border-2 bg-card p-6 space-y-4">
        <h2 className="text-xl font-bold">{t('quizAttempts.studentInfo')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{t('users.name')}</p>
              <p className="font-medium">
                {result.userFirstName && result.userLastName
                  ? `${result.userFirstName} ${result.userLastName}`
                  : t('quizAttempts.anonymous')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Mail className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{t('users.email')}</p>
              <p className="font-medium">{result.userEmail || t('common.notAvailable')}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Calendar className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{t('quizAttempts.submittedAt')}</p>
              <p className="font-medium">
                {result.submittedAt ? format(new Date(result.submittedAt), 'PPp') : t('common.notAvailable')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Target className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{t('quizAttempts.attempt')}</p>
              <p className="font-medium">#{result.attemptNumber}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Result Summary Card */}
      <div
        className={cn(
          'rounded-2xl border-2 p-8 md:p-10 text-center space-y-6 shadow-lg',
          passed
            ? 'border-green-500 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/20'
            : 'border-red-500 bg-gradient-to-br from-red-50 to-rose-50 dark:from-red-950/30 dark:to-rose-950/20'
        )}
      >
        <div className="flex justify-center">
          {passed ? (
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg ring-4 ring-green-200 dark:ring-green-900/50">
              <Trophy className="h-12 w-12 text-white" />
            </div>
          ) : (
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center shadow-lg ring-4 ring-red-200 dark:ring-red-900/50">
              <XCircle className="h-12 w-12 text-white" />
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold">
            {passed ? t('quizAttempts.passed') : t('quizAttempts.failed')}
          </h1>
          <p className="text-base md:text-lg text-muted-foreground font-medium break-words" dir={isArabic ? 'rtl' : 'ltr'}>
            {quizTitle}
          </p>
        </div>

        <div className="py-4">
          <div
            className={cn(
              'text-7xl md:text-8xl font-extrabold tracking-tight tabular-nums',
              passed ? 'text-green-600 dark:text-green-500' : 'text-red-600 dark:text-red-500'
            )}
          >
            {score.toFixed(1)}%
          </div>
        </div>

        <div className="w-full max-w-md mx-auto space-y-2">
          <Progress
            value={score}
            className={cn(
              "h-4 rounded-full",
              passed
                ? "bg-green-200 dark:bg-green-900/30"
                : "bg-red-200 dark:bg-red-900/30"
            )}
          />
          <p className="text-xs text-muted-foreground">
            {correctCount} {t('quizTaking.correctAnswers')} / {result.totalQuestions} {t('quizTaking.questions')}
          </p>
        </div>

        <div className="pt-2">
          <Badge
            variant={passed ? 'success' : 'destructive'}
            className="text-base px-6 py-2 font-semibold"
          >
            {passed ? t('quizAttempts.passed') : t('quizAttempts.failed')}
          </Badge>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
        <div className="rounded-xl border-2 bg-card p-5 md:p-6 text-center hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center gap-2 text-muted-foreground mb-3">
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-500" />
            <span className="text-sm font-medium">{t('quizTaking.correctAnswers')}</span>
          </div>
          <p className="text-3xl md:text-4xl font-bold text-foreground tabular-nums">
            {correctCount}<span className="text-2xl text-muted-foreground tabular-nums">/{result.totalQuestions}</span>
          </p>
        </div>

        <div className="rounded-xl border-2 bg-card p-5 md:p-6 text-center hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center gap-2 text-muted-foreground mb-3">
            <Clock className="h-5 w-5 text-blue-600 dark:text-blue-500" />
            <span className="text-sm font-medium">{t('quizAttempts.timeSpent')}</span>
          </div>
          <p className="text-3xl md:text-4xl font-bold text-foreground tabular-nums">
            {timeSpentMinutes}:{timeSpentSeconds.toString().padStart(2, '0')}
          </p>
        </div>

        <div className="rounded-xl border-2 bg-card p-5 md:p-6 text-center hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center gap-2 text-muted-foreground mb-3">
            <Target className="h-5 w-5 text-purple-600 dark:text-purple-500" />
            <span className="text-sm font-medium">{t('quizzes.attempts')}</span>
          </div>
          <p className="text-3xl md:text-4xl font-bold text-foreground">
            #{result.attemptNumber}
          </p>
        </div>
      </div>

      {/* Questions Review */}
      {result.questions && result.questions.length > 0 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between flex-wrap gap-3 border-b-2 pb-4">
            <h2 className="text-2xl md:text-3xl font-bold flex items-center gap-3">
              <div className="w-1 h-8 bg-primary rounded-full"></div>
              {t('quizTaking.reviewAnswers')}
            </h2>
            <Badge variant="muted" className="text-sm px-3 py-1.5">
              {result.questions.length} {t('quizTaking.questions')}
            </Badge>
          </div>

          <div className="space-y-6">
            {result.questions.map((question, index) => (
              <div
                key={question.id}
                className={cn(
                  "rounded-xl border-2 p-5 md:p-7 shadow-sm transition-all hover:shadow-md",
                  question.isCorrect
                    ? "border-green-300 bg-green-50/50 dark:border-green-800/70 dark:bg-green-950/20"
                    : "border-red-300 bg-red-50/50 dark:border-red-800/70 dark:bg-red-950/20"
                )}
              >
                {/* Question Status Badge */}
                <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
                  <Badge
                    variant={question.isCorrect ? 'success' : 'destructive'}
                    className="text-sm font-semibold px-3 py-1"
                  >
                    {question.isCorrect ? (
                      <>
                        <CheckCircle2 className="h-4 w-4 me-1.5" strokeWidth={2.5} />
                        {t('questions.correct')}
                      </>
                    ) : (
                      <>
                        <XCircle className="h-4 w-4 me-1.5" strokeWidth={2.5} />
                        {t('questions.incorrect')}
                      </>
                    )}
                  </Badge>
                  <span className="text-xs text-muted-foreground font-medium">
                    {t('quizTaking.pointsEarned')}: <span
                      className={cn(
                        'font-bold text-sm tabular-nums',
                        question.isCorrect ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                      )}
                    >
                      {question.earnedPoints}/{question.points}
                    </span>
                  </span>
                </div>

                <QuestionDisplay
                  question={{
                    id: question.id,
                    questionId: question.id,
                    questionText: question.questionText,
                    questionTextAr: question.questionTextAr,
                    questionType: question.questionType,
                    options: question.options.map((opt) => ({
                      key: opt.id,
                      text: opt.text,
                      textAr: opt.textAr,
                    })),
                  }}
                  questionNumber={index + 1}
                  selectedOptionId={question.selectedAnswer}
                  onSelectOption={() => {}}
                  disabled
                  showResult
                  correctOptionId={question.correctAnswer}
                  explanation={question.explanation}
                  explanationAr={question.explanationAr}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
