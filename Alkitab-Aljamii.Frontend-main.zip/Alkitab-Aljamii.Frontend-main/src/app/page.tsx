'use client';

import { useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore, useViewContextStore } from '@/stores';
import { ROLE_HOME_ROUTES } from '@/lib/constants';

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated, user, isHydrated, logout } = useAuthStore();
  const {
    activeView,
    primaryRole,
    availableViews,
    isLoading: viewsLoading,
    loadAvailableViews,
  } = useViewContextStore();
  const viewsRequestedRef = useRef(false);

  // Use activeView from context, fall back to primaryRole, then derive from isSuperAdmin
  const effectiveRole = activeView ?? primaryRole ?? (user?.isSuperAdmin ? 'super_admin' : null);

  // Load available views when authenticated
  useEffect(() => {
    if (isHydrated && isAuthenticated && user && !viewsRequestedRef.current && !viewsLoading) {
      viewsRequestedRef.current = true;
      loadAvailableViews();
    }
  }, [isHydrated, isAuthenticated, user, viewsLoading, loadAvailableViews]);

  // Handle routing based on authentication and role
  useEffect(() => {
    if (!isHydrated) return;

    if (!isAuthenticated) {
      router.push('/login');
      return;
    }

    // Check if views are loaded (not loading and have data OR is super admin)
    const viewsLoaded = !viewsLoading && (availableViews.length > 0 || primaryRole !== null);

    // Wait for views to load before deciding (unless super admin)
    if (!viewsLoaded && !user?.isSuperAdmin) return;

    if (effectiveRole) {
      router.push(ROLE_HOME_ROUTES[effectiveRole]);
    } else if (viewsRequestedRef.current && !viewsLoading) {
      // User has no roles - log them out as this is likely a data issue
      console.warn('User has no available roles, logging out');
      logout();
      router.push('/login');
    }
  }, [isAuthenticated, user, effectiveRole, isHydrated, availableViews, primaryRole, viewsLoading, router, logout]);

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="animate-pulse text-muted-foreground">Loading...</div>
    </div>
  );
}
