# Alexandria University - Digital Library Frontend

A modern digital library management system built with Next.js 16, React 19, and TypeScript. This frontend provides role-based interfaces for managing educational content across university faculties.

## Tech Stack

- **Framework:** Next.js 16 (App Router)
- **UI:** React 19 + shadcn/ui + Tailwind CSS 4
- **State Management:** Zustand with persist middleware
- **API Client:** Axios with interceptors
- **Forms:** React Hook Form + Zod validation
- **Tables:** TanStack Table
- **PDF Viewer:** pdfjs-dist with chunked streaming, copy/print protection
- **i18n:** next-intl (English/Arabic with RTL support)

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- Backend API running on `http://localhost:8000`

### Installation

```bash
npm install
```

### Environment Variables

Create a `.env.local` file:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

### Build

```bash
npm run build
npm run start
```

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── (auth)/            # Auth pages (login)
│   ├── (dashboard)/       # Protected dashboard pages
│   │   ├── super-admin/   # Super admin pages
│   │   ├── faculty-admin/ # Faculty admin pages
│   │   ├── professor/     # Professor pages
│   │   └── student/       # Student pages
│   └── layout.tsx         # Root layout with i18n
├── components/
│   ├── auth/              # Auth components (login form, guard)
│   ├── layout/            # Layout components (sidebar, header)
│   ├── shared/            # Shared components (data-table, pdf-viewer, etc.)
│   └── ui/                # shadcn/ui components
├── lib/
│   ├── api/               # API client and endpoint definitions
│   ├── constants/         # Navigation config, role mappings
│   └── validations/       # Zod schemas
├── stores/                # Zustand stores (auth, view-context, faculty-context, locale)
├── types/                 # TypeScript type definitions
└── i18n/                  # Internationalization (en/ar)
```

## PDF Viewer Architecture

The secure PDF viewer implements chunked streaming for security and performance:

```
┌─────────────────────────────────────────────────────────────┐
│                    SecurePDFViewer                          │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │  PDFToolbar │  │ PageRenderer│  │   ViewProtection    │ │
│  │ - Zoom      │  │ - Canvas    │  │ - Disable right-    │ │
│  │ - Navigate  │  │ - Scale     │  │   click/print/copy  │ │
│  │ - Page Jump │  │             │  │ - Watermark overlay │ │
│  └─────────────┘  └─────────────┘  └─────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────┐   │
│  │                   Chunk Management                   │   │
│  │  - 15 pages per chunk (configurable)                │   │
│  │  - Direction-aware prefetching (5 page threshold)   │   │
│  │  - In-memory chunk cache                            │   │
│  │  - Page jump with smart chunk loading               │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Security Features
- **Chunked Loading**: PDFs are never fully downloaded; only 15-page chunks
- **Server-side Watermarking**: Each chunk watermarked with user info
- **Copy/Print Protection**: Right-click, keyboard shortcuts disabled
- **No Download**: Stream-only viewing, no file download option

## Data Architecture

The system follows this hierarchy:

```
Faculty (1) ──→ (N) Subject (1) ──→ (N) Content
                      │
                      └──→ (N) User Assignments (Professor/Student)
```

- **Faculty**: Top-level academic departments
- **Subject**: Courses within a faculty (e.g., "Introduction to Programming")
- **Content**: Educational materials uploaded to subjects
- **User Assignments**: Professors teach subjects, students enroll in subjects

## User Roles

| Role | Access |
|------|--------|
| **SUPER_ADMIN** | Full system access, manage faculties, subjects & all users |
| **FACULTY_ADMIN** | Manage faculty subjects, professors, students, approve content |
| **PROFESSOR** | View assigned subjects, upload content |
| **STUDENT** | View enrolled subjects, browse and view approved content |

## Implementation Status

### ✅ Completed - Frontend Infrastructure

| Feature | Status |
|---------|--------|
| Project setup | ✅ Next.js 16, TypeScript, Tailwind CSS 4 |
| UI Components | ✅ shadcn/ui (button, input, dialog, table, etc.) |
| Authentication flow | ✅ Login form, auth guard, protected routes |
| Role-based routing | ✅ Middleware protection per role |
| State management | ✅ Zustand stores for auth, UI, locale, faculty-context |
| API client | ✅ Axios with token interceptors |
| i18n (en/ar) | ✅ Full translation files, RTL support |
| Layout system | ✅ Sidebar, header, responsive design |
| Data tables | ✅ Sortable, filterable, paginated |
| PDF viewer | ✅ Secure chunked viewer with copy/print protection |
| File uploader | ✅ Drag & drop with progress |
| Faculty context switcher | ✅ For faculty admin and professor roles |
| View context switcher | ✅ For users with multiple roles |
| PDF chunked streaming | ✅ 15-page chunks with prefetching |
| Page jump navigation | ✅ Click page counter to jump to any page |

### ✅ Integrated with Backend

| API | Frontend | Backend | Status |
|-----|----------|---------|--------|
| Auth - Login | ✅ | ✅ | **Integrated** |
| Auth - Refresh | ✅ | ✅ | **Integrated** |
| Auth - Logout | ✅ | ✅ | **Integrated** |
| Users - CRUD | ✅ | ✅ | **Integrated** |
| Users - Password Update | ✅ | ✅ | **Integrated** |
| Users - My Faculties | ✅ | ✅ | **Integrated** |
| Faculties - CRUD | ✅ | ✅ | **Integrated** |
| Faculties - Admin Assignment | ✅ | ✅ | **Integrated** |
| Faculties - Professors | ✅ | ✅ | **Integrated** |
| Faculties - Students | ✅ | ✅ | **Integrated** |
| Subjects - CRUD | ✅ | ✅ | **Integrated** |
| Subjects - Assignments | ✅ | ✅ | **Integrated** |
| Content - List/Get | ✅ | ✅ | **Integrated** |
| Content - Upload | ✅ | ✅ | **Integrated** |
| Content - Approve/Reject | ✅ | ✅ | **Integrated** |
| Content - Stream | ✅ | ✅ | **Integrated** |
| Content - Chunked Pages | ✅ | ✅ | **Integrated** |
| Content - Page Count | ✅ | ✅ | **Integrated** |
| Stats - Dashboard | ✅ | ✅ | **Integrated** |

## API Endpoints Reference

### Auth & Users (Integrated)

```
POST   /auth/login          # Login with email/password
POST   /auth/refresh        # Refresh access token
POST   /auth/logout         # Logout (requires auth)

GET    /users               # List users (paginated)
GET    /users/:id           # Get user by ID
POST   /users               # Create user
PATCH  /users/:id           # Update user
DELETE /users/:id           # Soft delete user
PATCH  /users/:id/password  # Update password
POST   /users/:id/restore   # Restore deleted user
GET    /users/me/faculties  # Get current user's accessible faculties
```

### Faculties (Integrated)

```
GET    /faculties                        # List faculties
GET    /faculties/:id                    # Get faculty
POST   /faculties                        # Create faculty
PATCH  /faculties/:id                    # Update faculty
DELETE /faculties/:id                    # Delete faculty
GET    /faculties/:id/professors         # List faculty professors
POST   /faculties/:id/professors         # Add professor to faculty
DELETE /faculties/:id/professors/:pid    # Remove professor from faculty
GET    /faculties/:id/students           # List faculty students
POST   /faculties/:id/students           # Add student to faculty
DELETE /faculties/:id/students/:sid      # Remove student from faculty
```

### Subjects (Integrated)

```
GET    /subjects                         # List subjects (role-filtered)
GET    /subjects/:id                     # Get subject
POST   /subjects                         # Create subject
PATCH  /subjects/:id                     # Update subject
DELETE /subjects/:id                     # Delete subject
GET    /subjects/:id/assignments         # List subject assignments
POST   /subjects/:id/assignments/:uid    # Assign user to subject
DELETE /subjects/:id/assignments/:uid    # Remove user from subject
```

### Content (Integrated)

```
GET    /contents                         # List contents (role-filtered)
GET    /contents/:id                     # Get content details
POST   /contents/upload                  # Upload content (multipart)
PUT    /contents/:id/approve             # Approve content
PUT    /contents/:id/reject              # Reject content (with reason)
DELETE /contents/:id                     # Delete content
GET    /contents/:id/stream              # Stream full PDF (watermarked)
GET    /contents/:id/pages?start=0&count=15  # Get PDF chunk (paginated)
GET    /contents/:id/page-count          # Get total page count
```

### PDF Chunked Streaming

The `/pages` endpoint returns a PDF chunk with these response headers:
- `X-Total-Pages`: Total pages in the PDF
- `X-Start-Page`: Start page of this chunk (0-indexed)
- `X-End-Page`: End page of this chunk (0-indexed)
- `X-Has-More`: Whether more pages exist

## Localization

The app supports English and Arabic with full RTL support:

- Language switcher in header
- Translations in `src/i18n/messages/`
- Auto-detection with cookie persistence

## State Management

The app uses Zustand stores with persistence:

| Store | Purpose | Persisted |
|-------|---------|-----------|
| `auth-store` | User authentication, tokens | Yes (cookies) |
| `view-context-store` | Active view role (super_admin, faculty_admin, etc.) | Yes (localStorage) |
| `faculty-context-store` | Current faculty selection | Yes (localStorage) |
| `locale-store` | Language preference | Yes (localStorage) |

### Optimizations
- **Duplicate request prevention**: Stores check `isLoading` and data existence before fetching
- **Idempotent load functions**: `loadAvailableViews()` and `loadFaculties()` are safe to call multiple times
- **Context-aware initialization**: Only calls `switchContext` API when view actually changes

## Next Steps

### Testing & Polishing
- Add error handling improvements
- Add loading skeletons
- Add confirmation dialogs

### Enhancements
- Add bulk operations
- Improve search and filtering
- Add notifications system
- Offline reading support (service worker caching)

## License

Private - Alexandria University
