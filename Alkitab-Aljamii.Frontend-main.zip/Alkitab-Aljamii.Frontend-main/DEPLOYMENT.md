# Frontend Deployment Guide

## Docker Image

```
ahmedfathy2001/alkitab-frontend:latest
```

## Build & Push

```bash
cd Alkitab-Aljamii.Frontend

# Build image (NO build args needed - nginx handles API routing)
docker build -t ahmedfathy2001/alkitab-frontend:latest .

# Push to Docker Hub
docker push ahmedfathy2001/alkitab-frontend:latest
```

**Important:** Do NOT set `NEXT_PUBLIC_API_URL` during build. API routing is handled by nginx.

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `NODE_ENV` | No | Default: `production` |
| `PORT` | No | Default: `3000` |
| `HOSTNAME` | No | Default: `0.0.0.0` |

## Server Deployment

### Update on Server

```bash
ssh root@138.201.48.22
cd /home/shamy/apps/alkitab

# Pull latest image
docker compose pull frontend

# Restart with new image
docker compose up -d frontend
```

### Useful Commands

```bash
# View logs
docker logs alkitab_frontend --tail 100 -f

# Restart
docker compose restart frontend

# Check status
docker compose ps frontend
```

## Nginx Configuration

The frontend runs on port `3001` internally. Nginx handles:
- Serving the frontend at `https://alkitab.nextgen-softwares.com`
- Proxying `/api/*` requests to the backend at `http://127.0.0.1:8000`
- SSL termination

Example nginx config (`/etc/nginx/sites-available/alkitab`):

```nginx
server {
    listen 443 ssl;
    server_name alkitab.nextgen-softwares.com;

    # Proxy /api requests to backend
    location /api/ {
        proxy_pass http://127.0.0.1:8000/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        client_max_body_size 100M;
    }

    # All other requests go to Next.js
    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    ssl_certificate /etc/letsencrypt/live/alkitab.nextgen-softwares.com-0001/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/alkitab.nextgen-softwares.com-0001/privkey.pem;
}
```

## Dockerfile Notes

- Uses multi-stage build (builder + production)
- Requires `output: 'standalone'` in `next.config.ts`
- Copies `.next/standalone`, `.next/static`, and `public/`
- Runs as non-root user `nextjs`
- Exposes port 3000

## API Routing

All API calls from the frontend should use `/api/*` paths:
- Frontend makes request to `/api/auth/login`
- Nginx proxies to `http://127.0.0.1:8000/auth/login`
- No CORS issues since same origin

**Production:** Do not set `NEXT_PUBLIC_API_URL` - nginx handles routing.

**Local development:** Set `NEXT_PUBLIC_API_URL=http://localhost:8000` in `.env.local` for direct backend access.

## Swagger Documentation

Swagger is available at:
- `https://api.alkitab.nextgen-softwares.com/docs` (direct backend)
- `https://alkitab.nextgen-softwares.com/api/docs` (via nginx proxy)
